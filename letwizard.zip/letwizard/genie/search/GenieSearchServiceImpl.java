package com.bestercapitalmedia.letwizard.genie.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.dozer.Mapper;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.buyer.dashboard.BuyerDashBoard;
import com.bestercapitalmedia.letwizard.buyer.dashboard.BuyerDashBoardRepository;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyUtils;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyGenieSearchDetailsDTO;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.bidprocess.Propertybidprocess;
import com.bestercapitalmedia.letwizard.property.bidprocess.PropertybidprocessRepository;
import com.bestercapitalmedia.letwizard.systemevents.GenieSearchLeadEvent;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.StringUtils;
import com.ibm.icu.math.BigDecimal;

@Service
public class GenieSearchServiceImpl implements GenieSearchService, ApplicationEventPublisherAware {

	private static final Logger logger = LoggerFactory.getLogger(GenieSearchServiceImpl.class);
	@Autowired
	private GenieSearchRepository genieSearchRepository;

	@Autowired
	private PropertyRepository propertyRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BuyerDashBoardRepository buyerdashboardRepository;
	
	@Autowired
	private PropertybidprocessRepository propertybidprocessRepo;
	
	@Autowired
	private ApplicationEventPublisher publisher;


	@Override
	public GenieSavedSearchResponseDto saveSearch(PaginatedSearchDetailRequestDTO request, Authentication authentication) {
		try {
			GenieSearch addedGenieSearch = null;
			if (request.getPage() == 0) {
				return null;
			}
			int page = request.getPage() - 1;
			logger.info("Page  = " + page);
			Integer Limit = request.getMaxResult();
			logger.info("Limit  = " + Limit);
			Integer Offset = request.getMaxResult() * page;
			logger.info("Offset  = " + Offset);

			GenieSavedSearchResponseDto genieSavedSearchResponse = new GenieSavedSearchResponseDto();

			if (null != request.getGenieSearch()) {
				// set search request to response DTO
				GenieSearchRequest genieSearchResponse = ObjectMapperUtils.map(request.getGenieSearch(),
						GenieSearchRequest.class);
				genieSavedSearchResponse.setGenieSearchRequest(genieSearchResponse);

				if (request.getPage() == 1) {
					// save search in database
					request.getGenieSearch().setCreatedAt(DateUtils.getDefault().currentDate());
					GenieSearch newGenieSearch = ObjectMapperUtils.map(request.getGenieSearch(), GenieSearch.class);
					newGenieSearch.setLocations(request.getGenieSearch().getLocations().toString());
					newGenieSearch.setSpendRange(request.getGenieSearch().getSpendRange().toString());
					addedGenieSearch = genieSearchRepository.save(newGenieSearch);
					logger.info("Genie search Request Stored to Database");

					// event listener to call "create lead 3rd party API"
					publisher.publishEvent(new GenieSearchLeadEvent(this, request));
					// search properties
					getGenieSearchProperties(request, genieSavedSearchResponse, Limit, Offset);
				}

			}

			if (genieSavedSearchResponse == null) {
				return null;
			} else {
				return genieSavedSearchResponse;
			}

		} catch (Exception e) {
			logger.error("Error Occures At Genie Web Search ", e);
			return null;
		}
	}

	private void getGenieSearchProperties(PaginatedSearchDetailRequestDTO request,
										  GenieSavedSearchResponseDto genieSavedSearchResponse, Integer Limit, Integer Offset) {

		PaginatedSearchDetailResponseDTO genieSearchResponse = new PaginatedSearchDetailResponseDTO();
		Chiraghuser chiraghuser = userRepository.findByUserName(request.getUserName());
		ModelMapper mapper = new ModelMapper();
		Integer totalRecord = 0;
		StringBuilder locationQuery = new StringBuilder("");
		String locQuery = "";
		StringBuilder openPriceQuery = new StringBuilder("");
		String priceQuery = "";
		StringBuilder propertyTypeQuery = new StringBuilder("");
		String typeQuery = "";
		int lastConditionIndex = 0;
		String sortType = "";

		// ---- Location Search ----
		if (null != request.getGenieSearch().getLocations()) {
			if (request.getGenieSearch().getLocations().size() > 1) {
				for (String locationList : request.getGenieSearch().getLocations()) {
					locationQuery.append(" p.address = '");
					locationQuery.append(locationList);
					locationQuery.append("'");
					locationQuery.append(" OR p.map_address_max = '");
					locationQuery.append(locationList);
					locationQuery.append("'");
					locationQuery.append(" OR");

				}
				lastConditionIndex = locationQuery.toString().lastIndexOf("OR");
				locQuery = locationQuery.toString().substring(0, lastConditionIndex - 1);
			} else {
				locationQuery.append(" p.address = '");
				locationQuery.append(request.getGenieSearch().getLocations().get(0));
				locationQuery.append("'");
				locationQuery.append(" OR p.map_address_max = '");
				locationQuery.append(request.getGenieSearch().getLocations().get(0));
				locationQuery.append("'");
				locQuery = locationQuery.toString();
			}

			logger.info("locationQuery :" + locQuery);
		}

		// ---- Price Search ----
		String[] minMaxValues = null;
		for (String spendRange : request.getGenieSearch().getSpendRange()) {
			minMaxValues = spendRange.split("-", 2);

			BigDecimal maxValue = null;
			BigDecimal minValue = new BigDecimal(minMaxValues[0]); // min value
			if (!minMaxValues[1].equals("more")) {
				maxValue = new BigDecimal(minMaxValues[1]); // max value
			}

			if (null != maxValue && null != minValue) {
				openPriceQuery.append(" (bp.open_price BETWEEN ");
				openPriceQuery.append(minValue);
				openPriceQuery.append(" AND ");
				openPriceQuery.append(maxValue);
				openPriceQuery.append(") OR");
				priceQuery = openPriceQuery.toString();

			} else if (maxValue == null) {
				openPriceQuery.append(" (bp.open_price >= ");
				openPriceQuery.append(minValue);
				openPriceQuery.append(") OR");
				priceQuery = openPriceQuery.toString();

			}
			priceQuery = priceQuery.substring(0, priceQuery.length() - 2);
		}
		logger.info("openPriceQuery :" + priceQuery);

		// --- property Type Search ---
		if (null != request.getGenieSearch().getPropertyTypes()) {
			List<String> propertyTypesList = Arrays.asList(request.getGenieSearch().getPropertyTypes().split(","));
			if (propertyTypesList.size() > 1) {
				for (String pTypeList : propertyTypesList) {
					propertyTypeQuery.append(" p.property_type = '");
					propertyTypeQuery.append(StringUtils.capitalizer(pTypeList));
					propertyTypeQuery.append("' OR");

				}
				lastConditionIndex = propertyTypeQuery.toString().lastIndexOf("OR");
				typeQuery = propertyTypeQuery.toString().substring(0, lastConditionIndex - 1);
			} else {
				propertyTypeQuery.append(" p.property_type = '");
				propertyTypeQuery.append(StringUtils.capitalizer(request.getGenieSearch().getPropertyTypes()));
				propertyTypeQuery.append("'");
				typeQuery = propertyTypeQuery.toString();
			}
			logger.info("propertyTypeQuery :" + typeQuery);
		}

		List<Chiraghproperty> genieSearchResult = null;
		// sorting

		if ((ChiraghPropertyUtils.SortType.auctionDateAscending).equalsIgnoreCase(request.getSortType())) {
			sortType = " ORDER BY DATE_ADD(DATE(bp.auction_start_date), INTERVAL bp.auction_duration DAY) ASC ";
		} else if ((ChiraghPropertyUtils.SortType.auctionDateDescending).equalsIgnoreCase(request.getSortType())) {
			sortType = " ORDER BY DATE_ADD(DATE(bp.auction_start_date), INTERVAL bp.auction_duration DAY) DESC ";
		} else if ((ChiraghPropertyUtils.SortType.numberOfBid).equalsIgnoreCase(request.getSortType())) {
			sortType = " ORDER BY hb.bid_count DESC ";
		} else {
			// Add a default sort type when the sortType parameter is not recognized
			sortType = " ORDER BY p.property_Id ASC ";
		}

		genieSearchResult = propertyRepository.findAllGenieSearchProperties(locQuery, priceQuery, typeQuery,
				sortType, Limit, Offset);

		totalRecord = propertyRepository.getCountGenieSearchProperties(locQuery, priceQuery, typeQuery);

		List<PropertyGenieSearchDetailsDTO> searchedProperties = ObjectMapperUtils.mapAll(genieSearchResult,
				PropertyGenieSearchDetailsDTO.class);
		if (totalRecord == null) {
			totalRecord = 0;
		}
		// set search in property list of response DTO
		genieSearchResponse.setSearchpropertylist(searchedProperties);
		genieSearchResponse.setPageNumber(request.getPage());
		genieSearchResponse.setNumberOfElements(genieSearchResult.size());
		Integer pagenumber = (int) Math.ceil(totalRecord / request.getMaxResult());
		genieSearchResponse.setTotalPages(pagenumber + 1);
		genieSearchResponse.setTotalRecords(totalRecord);

		// add watchlist & bid count
		addWatchlistAndBidCount(genieSearchResponse, chiraghuser);
		// set genie search response
		genieSavedSearchResponse.setGenieSearchResponse(genieSearchResponse);

	}






	private void addWatchlistAndBidCount( PaginatedSearchDetailResponseDTO genieSearchResponse, Chiraghuser chiraghuser) {
		// set is watchlist key 
		genieSearchResponse.getSearchpropertylist().forEach(s -> {
			try {
				logger.info("Property for each" + s.getPropertyId());
				if (chiraghuser == null) {
					s.setIsWatchedList("");
				} else {
					BuyerDashBoard obj = buyerdashboardRepository.getPropertiesByUserIdAndPropertyId(chiraghuser.getUserId(),
							s.getPropertyId());
					if (obj == null) {
						s.setIsWatchedList("false");
					} else {
						s.setIsWatchedList("true");
					}
				}
			} catch (Exception e) {
				logger.error("Exception Occured While adding watch list ", e);
			}
		});
		
		// add bid count
		
		genieSearchResponse.getSearchpropertylist().forEach(o -> {
		try {
			
			List<Propertybidprocess> propertybidprocess = propertybidprocessRepo.findBidDetailsByPropertyId(o.getPropertyId());
			o.setBidCount(propertybidprocess.stream().collect(Collectors.counting()));

		} catch (Exception e) {
			logger.error("Exception Occured While adding bid count ", e);
		}
	});
	}

	@Override
	public List<GenieSuggestionResponseDTO> getSearchSuggestion(String text, Authentication authentication) {
		try {

			List<GenieSuggestionResponseDTO> genieSuggestionResponse = new ArrayList<GenieSuggestionResponseDTO>();
			if (text != null) {
				logger.info("Feching Suggestion From Database");
				List<Object[]> genieMapAddressSuggestion = propertyRepository.getGenieSearchMapAddressSuggestionForLatLong(text);
				logger.info("Feching Suggestion From Database size : "+genieMapAddressSuggestion.size());
				if (!genieMapAddressSuggestion.isEmpty()) {
					for (Object[] object : genieMapAddressSuggestion) {
						GenieSuggestionResponseDTO dto = new GenieSuggestionResponseDTO();
						dto.setAddress((String)object[0]);
						String latLong = (String) object[1];
						if(latLong != null && !latLong.isEmpty()) {
							List<String> latLongList = Arrays.asList(latLong.split(","));
							dto.setLatitude(Double.parseDouble(latLongList.get(0)));
							dto.setLongitude(Double.parseDouble(latLongList.get(1)));
						}
						genieSuggestionResponse.add(dto);
					}
				}
				return genieSuggestionResponse;
			} else {
				return null;
			}
		} catch (Exception e) {
			logger.error("Error Occures While Fetching Suggestion For Genie Search ", e);
			return null;
		}
	}

	@Override
	public GenieSavedSearchResponseDto getSearch(PaginatedSearchDetailRequestDTO request,
			Authentication authentication) {
		try {

			GenieSearch addedGenieSearch = null;
			if (request.getPage() == 0) {
				return null;
			}
			int page = request.getPage() - 1;
			logger.info("Page  = " + page);
			Integer Limit = request.getMaxResult();
			logger.info("Limit  = " + Limit);
			Integer Offset = request.getMaxResult() * page;
			logger.info("Offset  = " + Offset);

			GenieSavedSearchResponseDto genieSavedSearchResponse = new GenieSavedSearchResponseDto();
			if (null != request.getGenieSearch()) {
				// set search request to response DTO
				GenieSearchRequest genieSearchResponse = ObjectMapperUtils.map(request.getGenieSearch(),
						GenieSearchRequest.class);
				genieSavedSearchResponse.setGenieSearchRequest(genieSearchResponse);

				// search properties
				getGenieSearchProperties(request, genieSavedSearchResponse, Limit, Offset);
			}
			if (genieSavedSearchResponse == null) {
				return null;
			} else {

				return genieSavedSearchResponse;
			}

		} catch (Exception e) {
			logger.error("Error Occures At Genie Web Search ", e);
			return null;
		}
	}
	
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;

	}

	@Override
	public GenieSavedSearchResponseDto getAll() {
		try {
			GenieSavedSearchResponseDto genieSavedSearchResponse = new GenieSavedSearchResponseDto();
			getAllGenieSearchProperties(genieSavedSearchResponse);

			return genieSavedSearchResponse;

		} catch (Exception e) {
			logger.error("Error Occures At Genie Web Search ", e);
			return null;
		}
	}

	@Override
	public GenieSavedSearchResponseDto getAllRentalProperties() {
		try {
			GenieSavedSearchResponseDto genieSavedSearchResponse = new GenieSavedSearchResponseDto();
			PaginatedSearchDetailResponseDTO genieSearchResponse = new PaginatedSearchDetailResponseDTO();

			List<Chiraghproperty> genieSearchResult = propertyRepository.findAllGenieSearchRentalProperties();
			List<PropertyGenieSearchDetailsDTO> searchedProperties = ObjectMapperUtils.mapAll(genieSearchResult,
					PropertyGenieSearchDetailsDTO.class);
			genieSearchResponse.setSearchpropertylist(searchedProperties);
			genieSearchResponse.setNumberOfElements(genieSearchResult.size());
			genieSearchResponse.setTotalRecords(propertyRepository.findCountAllGenieSearchRentalProperties());

			genieSavedSearchResponse.setGenieSearchResponse(genieSearchResponse);
			return genieSavedSearchResponse;

		}catch (Exception e) {
			logger.error("Error Occures At Genie Web Rental Search ", e);
			return null;
		}
	}

	@Override
	public GenieSavedSearchResponseDto getAllSaleProperties() {
		try {
			GenieSavedSearchResponseDto genieSavedSearchResponse = new GenieSavedSearchResponseDto();
			PaginatedSearchDetailResponseDTO genieSearchResponse = new PaginatedSearchDetailResponseDTO();

			List<Chiraghproperty> genieSearchResult = propertyRepository.findAllGenieSearchSaleProperties();
			List<PropertyGenieSearchDetailsDTO> searchedProperties = ObjectMapperUtils.mapAll(genieSearchResult,
					PropertyGenieSearchDetailsDTO.class);
			genieSearchResponse.setSearchpropertylist(searchedProperties);
			genieSearchResponse.setNumberOfElements(genieSearchResult.size());
			genieSearchResponse.setTotalRecords(propertyRepository.findCountAllGenieSearchSaleProperties());

			genieSavedSearchResponse.setGenieSearchResponse(genieSearchResponse);
			return genieSavedSearchResponse;

		}catch (Exception e) {
			logger.error("Error Occures At Genie Web Rental Search ", e);
			return null;
		}
	}

	private void getAllGenieSearchProperties(GenieSavedSearchResponseDto genieSavedSearchResponse) {

		PaginatedSearchDetailResponseDTO genieSearchResponse = new PaginatedSearchDetailResponseDTO();

		List<Chiraghproperty> genieSearchResult = propertyRepository.findAllGenieSearchProperties();
		List<PropertyGenieSearchDetailsDTO> searchedProperties = ObjectMapperUtils.mapAll(genieSearchResult,
				PropertyGenieSearchDetailsDTO.class);
		genieSearchResponse.setSearchpropertylist(searchedProperties);

		genieSearchResponse.setNumberOfElements(genieSearchResult.size());
		genieSearchResponse.setTotalRecords(propertyRepository.findCountAllGenieSearchProperties());
		genieSavedSearchResponse.setGenieSearchResponse(genieSearchResponse);

	}

}
