package com.bestercapitalmedia.letwizard.genie.search;

import lombok.Data;

@Data
public class GenieSavedSearchResponseDto {

	private GenieSearchRequest genieSearchRequest;
	private PaginatedSearchDetailResponseDTO genieSearchResponse;

}
