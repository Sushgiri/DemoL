package com.bestercapitalmedia.letwizard.genie.search;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "genie_search")
public class GenieSearch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "name")
	@Basic(fetch = FetchType.EAGER)
	private String name;

	@Column(name = "email")
	@Basic(fetch = FetchType.EAGER)
	private String email;

	@Column(name = "contact_no")
	@Basic(fetch = FetchType.EAGER)
	private String contactNo;

	@Column(name = "locations")
	@Basic(fetch = FetchType.EAGER)
	private String locations;

	@Column(name = "min_to_spend")
	@Basic(fetch = FetchType.EAGER)
	private BigInteger minToSpend;

	@Column(name = "max_to_spend")
	@Basic(fetch = FetchType.EAGER)
	private BigInteger maxToSpend;

	@Column(name = "property_types")
	@Basic(fetch = FetchType.EAGER)
	private String propertyTypes;

	@Column(name = "how_soon_buy")
	@Basic(fetch = FetchType.EAGER)
	private String howSoonBuy;

	@Column(name = "real_estate_experience")
	@Basic(fetch = FetchType.EAGER)
	private String realEstateExperience;
	
	@Column(name = "spend_range")
	@Basic(fetch = FetchType.EAGER)
	private String spendRange;

	@Column(name = "created_at")
	@Basic(fetch = FetchType.EAGER)
	private Date createdAt;

	@Column(name = "is_rental_property")
	@Basic(fetch = FetchType.EAGER)
	private boolean rentalProperty;

	public GenieSearch() {

	}

}
