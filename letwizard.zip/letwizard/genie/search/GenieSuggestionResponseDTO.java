package com.bestercapitalmedia.letwizard.genie.search;

import lombok.Data;

@Data
public class GenieSuggestionResponseDTO {

	private String address;
	private double latitude;
	private double longitude;
	
	public GenieSuggestionResponseDTO() {
	}
}