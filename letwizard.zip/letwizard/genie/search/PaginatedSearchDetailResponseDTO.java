package com.bestercapitalmedia.letwizard.genie.search;

import java.util.List;

import com.bestercapitalmedia.letwizard.property.PropertyGenieSearchDetailsDTO;

import lombok.Data;

@Data
public class PaginatedSearchDetailResponseDTO {

	int totalPages;
	int pageNumber;
	int numberOfElements;
	long totalRecords;

	List<PropertyGenieSearchDetailsDTO> searchpropertylist;
}
