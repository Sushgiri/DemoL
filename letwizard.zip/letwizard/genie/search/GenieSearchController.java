package com.bestercapitalmedia.letwizard.genie.search;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.BuyerMessages;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;

@RestController
@CrossOrigin
@RequestMapping("/api/genie/search")
public class GenieSearchController {

	private static final Logger logger = LoggerFactory.getLogger(GenieSearchController.class);
	@Autowired
	private ResponseUtill responseUtill;
	@Autowired
	private GenieSearchService genieSearchService;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/post", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity saveSearch(@Valid @RequestBody PaginatedSearchDetailRequestDTO request,
			Authentication authentication, HttpServletRequest httpServletRequest) {
		try {
			GenieSavedSearchResponseDto genieSearchResponse = genieSearchService.saveSearch(request, authentication);

			if (genieSearchResponse == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(genieSearchResponse).collect(Collectors.toList()));

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/suggestion", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity getGenieSuggestion(
			@Valid @RequestBody GenieSuggestionRequestDTO suggestionRequest, Authentication authentication,
			HttpServletRequest httpServletRequest) {
		try {
			List<GenieSuggestionResponseDTO> genieSuggestionResponse = genieSearchService.getSearchSuggestion(suggestionRequest.getText(),
					authentication);

			if (genieSuggestionResponse == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						genieSuggestionResponse);

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/get", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity getPaginatedSearch(@Valid @RequestBody PaginatedSearchDetailRequestDTO request,
			Authentication authentication, HttpServletRequest httpServletRequest) {
		try {
			GenieSavedSearchResponseDto genieSearchResponse = genieSearchService.getSearch(request, authentication);

			if (genieSearchResponse == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(genieSearchResponse).collect(Collectors.toList()));

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getAll(HttpServletRequest httpServletRequest) {
		try {
			GenieSavedSearchResponseDto genieSearchResponse = genieSearchService.getAll();

			if (genieSearchResponse == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(genieSearchResponse).collect(Collectors.toList()));

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getAllSaleProperties", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getAllSaleProperties(HttpServletRequest httpServletRequest) {
		try {
			GenieSavedSearchResponseDto genieSearchResponse = genieSearchService.getAllSaleProperties();

			if (genieSearchResponse == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(genieSearchResponse).collect(Collectors.toList()));

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getAllRentalProperties", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getAllRentalProperties(HttpServletRequest httpServletRequest) {
		try {
			GenieSavedSearchResponseDto genieSearchResponse = genieSearchService.getAllRentalProperties();

			if (genieSearchResponse == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(genieSearchResponse).collect(Collectors.toList()));

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
}
