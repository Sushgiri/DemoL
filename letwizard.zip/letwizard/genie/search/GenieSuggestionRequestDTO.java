package com.bestercapitalmedia.letwizard.genie.search;

import lombok.Data;

@Data
public class GenieSuggestionRequestDTO {

	private String text;

	public GenieSuggestionRequestDTO() {

	}

}
