package com.bestercapitalmedia.letwizard.genie.search;

import lombok.Data;

@Data
public class PaginatedSearchDetailRequestDTO {

	private GenieSearchDTO genieSearch;
	int page;
	int maxResult;
	String sortType;
	String userName;
	
	public PaginatedSearchDetailRequestDTO() {

	}

}
