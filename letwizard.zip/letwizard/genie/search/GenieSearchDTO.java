package com.bestercapitalmedia.letwizard.genie.search;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class GenieSearchDTO {

	private String name;
	private String email;
	private String contactNo;
	private List<String> locations;
	private BigInteger minToSpend;
	private BigInteger maxToSpend;
	private List<String> spendRange;
	private String propertyTypes;
	private String howSoonBuy;
	private String realEstateExperience;
	private Date createdAt;
	private boolean rentalProperty;

	public GenieSearchDTO() {

	}

}
