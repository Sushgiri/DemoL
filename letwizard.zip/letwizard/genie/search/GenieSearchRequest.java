package com.bestercapitalmedia.letwizard.genie.search;

import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;

import lombok.Data;

@Data
public class GenieSearchRequest {

	private List<String> locations;
	private BigInteger minToSpend;
	private BigInteger maxToSpend;
	private List<String> spendRange;
	private String propertyTypes;
	private boolean rentalProperty;
	
	public GenieSearchRequest() {

	}

}
