package com.bestercapitalmedia.letwizard.genie.search;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GenieSearchRepository extends JpaRepository<GenieSearch, Integer> {

}
