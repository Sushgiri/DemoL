package com.bestercapitalmedia.letwizard.genie.search;

import java.util.List;

import org.springframework.security.core.Authentication;

public interface GenieSearchService {

	GenieSavedSearchResponseDto saveSearch(PaginatedSearchDetailRequestDTO request, Authentication authentication);

	List<GenieSuggestionResponseDTO> getSearchSuggestion(String text, Authentication authentication);

	GenieSavedSearchResponseDto getSearch(PaginatedSearchDetailRequestDTO request, Authentication authentication);
	
	GenieSavedSearchResponseDto getAll();
	GenieSavedSearchResponseDto getAllRentalProperties();
	GenieSavedSearchResponseDto getAllSaleProperties();

}
