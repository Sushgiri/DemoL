package com.bestercapitalmedia.letwizard.bid;

import java.util.Date;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.BidMessages;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.Product;
import com.bestercapitalmedia.letwizard.property.bidfinalize.Bid;
import com.bestercapitalmedia.letwizard.property.bidfinalize.Propertybidfinalize;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;

@RestController
@RequestMapping("/api/bid/")
public class BidController {

	@Autowired
	private BidService bidService;

	@Autowired
	private ResponseUtill responseUtill;

	@RequestMapping(value = "/post",method = RequestMethod.POST)
	public CompletableFuture<ResponseEntity> create(@RequestBody BidDTO bid) {
		return bidService.saveBid(bid);
		
	}
}
