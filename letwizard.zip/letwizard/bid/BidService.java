package com.bestercapitalmedia.letwizard.bid;

import java.util.concurrent.CompletableFuture;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface BidService {

	public CompletableFuture saveBid(BidDTO bid);
	
	
}
