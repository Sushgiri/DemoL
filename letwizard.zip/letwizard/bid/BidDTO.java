package com.bestercapitalmedia.letwizard.bid;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BidDTO {

	private Integer bidId;
	private Integer productId;
	private Integer userId;
	private BigDecimal bidAmount;
	
	@JsonProperty("date")
	private Date date;
	
	private String userEmail;
	private String userName;
	private String otp;
	private int clientId;
	private String token;
	
	private String Name;
	private String city;
	private String country;
	private Boolean finalized;
	private Integer voucherId;
	private Integer currencyId;
	private BigDecimal exchangeAmount;
	private String bidType;
	
	@JsonProperty("checkInDate")
	private String checkInDate;
	
	@JsonProperty("checkOutDate")
	private String checkOutDate;
	private Integer occupancy;

	private BigDecimal lunchPrice;
	private BigDecimal dinnerPrice;
	private BigDecimal breakfastPrice;
	private BigDecimal totalFoodAndBeveragesPrice;

	private ArrayList<String> adultFoodAndBeverages;
	private ArrayList <String> childrenFoodAndBeverages;
	private ArrayList <String> infantFoodAndBeverages;
//	private Integer occupancy;
//	
//	private Integer occupancy;
//	
//	private Integer occupancy;
	
	public BidDTO() {
		super();
	}
	
	public Integer getBidId() {
		return bidId;
	}
	public void setBidId(Integer bidId) {
		this.bidId = bidId;
	}
	public Integer getProductId() {
		return productId;
	}
	public void setProductId(Integer productId) {
		this.productId = productId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public BigDecimal getBidAmount() {
		return bidAmount;
	}
	public void setBidAmount(BigDecimal bidAmount) {
		this.bidAmount = bidAmount;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Boolean getFinalized() {
		return finalized;
	}
	public void setFinalized(Boolean finalized) {
		this.finalized = finalized;
	}
	public Integer getVoucherId() {
		return voucherId;
	}
	public void setVoucherId(Integer voucherId) {
		this.voucherId = voucherId;
	}
	public Integer getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	public BigDecimal getExchangeAmount() {
		return exchangeAmount;
	}
	public void setExchangeAmount(BigDecimal exchangeAmount) {
		this.exchangeAmount = exchangeAmount;
	}
	public String getBidType() {
		return bidType;
	}
	public void setBidType(String bidType) {
		this.bidType = bidType;
	}

	public String getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	public String getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public Integer getOccupancy() {
		return occupancy;
	}

	public void setOccupancy(Integer occupancy) {
		this.occupancy = occupancy;
	}
	public BigDecimal getLunchPrice() {
		return lunchPrice;
	}

	public void setLunchPrice(BigDecimal lunchPrice) {
		this.lunchPrice = lunchPrice;
	}

	public BigDecimal getDinnerPrice() {
		return dinnerPrice;
	}

	public void setDinnerPrice(BigDecimal dinnerPrice) {
		this.dinnerPrice = dinnerPrice;
	}

	public BigDecimal getBreakfastPrice() {
		return breakfastPrice;
	}

	public void setBreakfastPrice(BigDecimal breakfastPrice) {
		this.breakfastPrice = breakfastPrice;
	}

	public BigDecimal getTotalFoodAndBeveragesPrice() {
		return totalFoodAndBeveragesPrice;
	}

	public void setTotalFoodAndBeveragesPrice(BigDecimal totalFoodAndBeveragesPrice) {
		this.totalFoodAndBeveragesPrice = totalFoodAndBeveragesPrice;
	}

	public ArrayList<String> getAdultFoodAndBeverages() {
		return adultFoodAndBeverages;
	}

	public void setAdultFoodAndBeverages(ArrayList<String> adultFoodAndBeverages) {
		this.adultFoodAndBeverages = adultFoodAndBeverages;
	}

	public ArrayList<String> getChildrenFoodAndBeverages() {
		return childrenFoodAndBeverages;
	}

	public void setChildrenFoodAndBeverages(ArrayList<String> childrenFoodAndBeverages) {
		this.childrenFoodAndBeverages = childrenFoodAndBeverages;
	}

	public ArrayList<String> getInfantFoodAndBeverages() {
		return infantFoodAndBeverages;
	}

	public void setInfantFoodAndBeverages(ArrayList<String> infantFoodAndBeverages) {
		this.infantFoodAndBeverages = infantFoodAndBeverages;
	}

}