package com.bestercapitalmedia.letwizard.bid;

import java.util.List;
import java.util.Optional;

import com.bestercapitalmedia.letwizard.property.bidfinalize.Bid;


public class BidDetailsResponse {

	Bid maxBid;
	long bidCount;
	List<Bid> bidHistory;

	public List<Bid> getBidHistory() {
		return bidHistory;
	}

	public void setBidHistory(List<Bid> bidHistory) {
		this.bidHistory = bidHistory;
	}

	public long getBidCount() {
		return bidCount;
	}

	public void setBidCount(long bidCount) {
		this.bidCount = bidCount;
	}

	public BidDetailsResponse() {
	}

	public Bid getMaxBid() {
		return maxBid;
	}

	public void setMaxBid(Bid maxBid) {
		this.maxBid = maxBid;
	}

}
