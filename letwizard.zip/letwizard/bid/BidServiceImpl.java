package com.bestercapitalmedia.letwizard.bid;

import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bestercapitalmedia.letwizard.auction.Auction;
import com.bestercapitalmedia.letwizard.auction.AuctionRepository;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.mail.EmailDTO;
import com.bestercapitalmedia.letwizard.mail.MailManager;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class BidServiceImpl implements BidService {

	private static final Logger logger = LoggerFactory.getLogger(BidServiceImpl.class);
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private MailManager mailManager;
	
	@Autowired
	private PropertyRepository propertyRepository;
	
	private AuctionRepository auctionRepository;
	
	ResponseEntity r = null;

	@Override
	public CompletableFuture<ResponseEntity> saveBid(BidDTO bid) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			BidDTO bidDTO = new BidDTO();
			bidDTO.setBidAmount(bid.getBidAmount());
			bidDTO.setProductId(bid.getProductId());

			try {
				Chiraghuser chiraghuser = userRepository.findByUserNameWithActivatedAccount(bid.getUserName());
				bidDTO.setUserId(chiraghuser.getUserId());
				bidDTO.setUserEmail(chiraghuser.getUserEmail());
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				logger.info("user id error");
			}
			// http://18.221.100.88:8085/BiddingEngine/api
			HttpEntity<BidDTO> entity = new HttpEntity(bidDTO, headers);
			CompletableFuture<ResponseEntity> res = restTemplate.postForObject(
					  "/api/bid/save", entity, CompletableFuture.class);
			logger.info("Response" + res);
			res.thenApply(s -> s);
			logger.info("Response" + res);
		
			return res;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

}
