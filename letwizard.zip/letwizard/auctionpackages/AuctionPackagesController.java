package com.bestercapitalmedia.letwizard.auctionpackages;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@CrossOrigin(origins = "*")
@RequestMapping("/api/auctionpackages")
public class AuctionPackagesController {

	@Autowired
	private AuctionPackagesService auctionPackagesService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/all/{userName}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getAllAuctionPackages(@PathVariable(value = "userName") String username, HttpServletRequest httpServletRequest) {
		return auctionPackagesService.getAuctionPackages(username);
	}
}
