package com.bestercapitalmedia.letwizard.auctionpackages;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;

@Service
public class AuctionPackagesService {

	@Autowired
	private AuctionPackagesRepository auctionPackagesRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ResponseUtill responseUtill;

	public ResponseEntity getAuctionPackages(String username) {
		try {
			Chiraghuser chiraghuser = userRepository.findByUserName(username);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_NOT_FOUND, null);
			}
			else {
				List<AuctionPackages> packages = auctionPackagesRepository.getAllAuctionPackages();
				if (packages == null) {
					return responseUtill.getApiResponse(ResponseCodes.FAILURE,
							PropertyMessages.DATA_RETRIVED_FAILURE, null);
				}
				else {
					
					List<AuctionPackagesDTO> packagesList =  ObjectMapperUtils.mapAll(packages, AuctionPackagesDTO.class);
					Collections.sort(packagesList, Comparator.comparingInt(AuctionPackagesDTO::getDurationDays));
					if (packagesList == null) {
						return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
					} else {
						return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
								packagesList);
					}
					
				}
			}
		}
		catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
}
