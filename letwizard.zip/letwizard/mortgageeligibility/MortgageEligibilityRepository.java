package com.bestercapitalmedia.letwizard.mortgageeligibility;


import org.springframework.data.repository.CrudRepository;

public interface MortgageEligibilityRepository extends CrudRepository<MortgageEligibility,Integer>{
	

}
