package com.bestercapitalmedia.letwizard.mortgageeligibility;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.MortgageEligibilityMessages;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.systemevents.MortgageEligibilityLeadEvent;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;

@Service
public class MortgageEligibilityService implements ApplicationEventPublisherAware {

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private MortgageEligibilityRepository mortgageEligibilityRepository;

	@Autowired
	private ApplicationEventPublisher publisher;

	public @ResponseBody ResponseEntity createEligibleMortgage(MortgageEligibilityDTO mortgageEligibilityRequestDTO,
			String IpAddress) {
		try {

			ModelMapper mapper = new ModelMapper();

			ChiragUtill chiragUtill = new ChiragUtill();
			String emailValid = chiragUtill.validateEmailAddress(mortgageEligibilityRequestDTO.getEmail());
			if (emailValid.equals("valid")) {

				mortgageEligibilityRequestDTO.setCreatedAt(DateUtils.getDefault().getNowTime());
				mortgageEligibilityRequestDTO.setUpdatedAt(DateUtils.getDefault().getNowTime());
				mortgageEligibilityRequestDTO.setIpAddress(IpAddress);

				MortgageEligibility addMortgageEligibility = mapper.map(mortgageEligibilityRequestDTO,
						MortgageEligibility.class);
				mortgageEligibilityRepository.save(addMortgageEligibility);

				// event listener to call create mortgage eligibility lead API
				publisher.publishEvent(new MortgageEligibilityLeadEvent(this, mortgageEligibilityRequestDTO));

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, MortgageEligibilityMessages.SAVED_SUCCESS,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, MortgageEligibilityMessages.INVALID_EMAIL,
						null);
			}
		}

		catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;

	}

}
