package com.bestercapitalmedia.letwizard.mortgageeligibility;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonManagedReference;

import com.bestercapitalmedia.letwizard.bank.Bank;
import com.bestercapitalmedia.letwizard.seller.details.Propertysellerdetails;

@Entity
@Table(name = "mortgage_eligibility")
public class MortgageEligibility implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	Integer mortgageEligibilityId;

	@Column(name = "residency_status")
	@Basic(fetch = FetchType.EAGER)
	String residencyStatus;

	@Column(name = "date_of_birth")
	@Basic(fetch = FetchType.EAGER)
	Date dateOfBirth;

	@Column(name = "employement_type")
	@Basic(fetch = FetchType.EAGER)
	String employementType;

	@Column(name = "monthly_fixed_income")
	@Basic(fetch = FetchType.EAGER)
	String monthlyFixedIncome;

	@Column(name = "additional_monthly_income")
	@Basic(fetch = FetchType.EAGER)
	String additionalAnnualIncome;

	@Column(name = "auto_finance")
	@Basic(fetch = FetchType.EAGER)
	String autoFinance;

	@Column(name = "personal_finance")
	@Basic(fetch = FetchType.EAGER)
	String personalFinance;

	@Column(name = "home_finance")
	@Basic(fetch = FetchType.EAGER)
	String homeFinance;

	@Column(name = "other_installments")
	@Basic(fetch = FetchType.EAGER)
	String otherInstallments;

	@Column(name = "credit_card_limit")
	@Basic(fetch = FetchType.EAGER)
	String creditCardLimit;

	@Column(name = "who_am_i")
	@Basic(fetch = FetchType.EAGER)
	String whoAmI;

	@Column(name = "full_name")
	@Basic(fetch = FetchType.EAGER)
	String fullName;

	@Column(name = "mobile_no")
	@Basic(fetch = FetchType.EAGER)
	String mobileNo;

	@Column(name = "email")
	@Basic(fetch = FetchType.EAGER)
	String email;

	@Column(name = "bank_ids")
	@Basic(fetch = FetchType.EAGER)
	String bankIds;

	@Column(name = "eligibility_amount")
	@Basic(fetch = FetchType.EAGER)
	String eligibilityAmount;

	@Column(name = "maximum_tenor")
	@Basic(fetch = FetchType.EAGER)
	String maximumTenor;

	@Column(name = "created_at")
	@Basic(fetch = FetchType.EAGER)
	Date createdAt;

	@Column(name = "updated_at")
	@Basic(fetch = FetchType.EAGER)
	Date updatedAt;

	@Column(name = "ip_address")
	@Basic(fetch = FetchType.EAGER)
	String ipAddress;

	@Column(name = "is_pre_qualified")
	@Basic(fetch = FetchType.EAGER)
	Boolean isPreQualified;

	public MortgageEligibility() {

	}

	public Integer getMortgageEligibilityId() {
		return mortgageEligibilityId;
	}

	public void setMortgageEligibilityId(Integer mortgageEligibilityId) {
		this.mortgageEligibilityId = mortgageEligibilityId;
	}

	public String getResidencyStatus() {
		return residencyStatus;
	}

	public void setResidencyStatus(String residencyStatus) {
		this.residencyStatus = residencyStatus;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmployementType() {
		return employementType;
	}

	public void setEmployementType(String employementType) {
		this.employementType = employementType;
	}

	public String getMonthlyFixedIncome() {
		return monthlyFixedIncome;
	}

	public void setMonthlyFixedIncome(String monthlyFixedIncome) {
		this.monthlyFixedIncome = monthlyFixedIncome;
	}

	public String getAdditionalAnnualIncome() {
		return additionalAnnualIncome;
	}

	public void setAdditionalAnnualIncome(String additionalAnnualIncome) {
		this.additionalAnnualIncome = additionalAnnualIncome;
	}

	public String getAutoFinance() {
		return autoFinance;
	}

	public void setAutoFinance(String autoFinance) {
		this.autoFinance = autoFinance;
	}

	public String getPersonalFinance() {
		return personalFinance;
	}

	public void setPersonalFinance(String personalFinance) {
		this.personalFinance = personalFinance;
	}

	public String getHomeFinance() {
		return homeFinance;
	}

	public void setHomeFinance(String homeFinance) {
		this.homeFinance = homeFinance;
	}

	public String getOtherInstallments() {
		return otherInstallments;
	}

	public void setOtherInstallments(String otherInstallments) {
		this.otherInstallments = otherInstallments;
	}

	public String getCreditCardLimit() {
		return creditCardLimit;
	}

	public void setCreditCardLimit(String creditCardLimit) {
		this.creditCardLimit = creditCardLimit;
	}

	public String getWhoAmI() {
		return whoAmI;
	}

	public void setWhoAmI(String whoAmI) {
		this.whoAmI = whoAmI;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBankIds() {
		return bankIds;
	}

	public void setBankIds(String bankIds) {
		this.bankIds = bankIds;
	}

	public String getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(String eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public String getMaximumTenor() {
		return maximumTenor;
	}

	public void setMaximumTenor(String maximumTenor) {
		this.maximumTenor = maximumTenor;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Boolean getIsPreQualified() {
		return isPreQualified;
	}

	public void setIsPreQualified(Boolean isPreQualified) {
		this.isPreQualified = isPreQualified;
	}

}
