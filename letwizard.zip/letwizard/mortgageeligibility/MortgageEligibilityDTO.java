package com.bestercapitalmedia.letwizard.mortgageeligibility;

import java.util.Date;

public class MortgageEligibilityDTO {

	private String residencyStatus;
	private Date dateOfBirth;
	private String employementType;
	private String monthlyFixedIncome;
	private String additionalAnnualIncome;
	private String autoFinance;
	private String personalFinance;
	private String homeFinance;
	private String otherInstallments;
	private String creditCardLimit;
	private String whoAmI;
	private String fullName;
	private String mobileNo;
	private String email;
	private String bankIds;
	private String eligibilityAmount;
	private String maximumTenor;
	private Date createdAt;
	private Date updatedAt;
	private String ipAddress;
	private Boolean isPreQualified;

	public MortgageEligibilityDTO() {
		// super();
		// TODO Auto-generated constructor stub
	}

	public String getResidencyStatus() {
		return residencyStatus;
	}

	public void setResidencyStatus(String residencyStatus) {
		this.residencyStatus = residencyStatus;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmployementType() {
		return employementType;
	}

	public void setEmployementType(String employementType) {
		this.employementType = employementType;
	}

	public String getMonthlyFixedIncome() {
		return monthlyFixedIncome;
	}

	public void setMonthlyFixedIncome(String monthlyFixedIncome) {
		this.monthlyFixedIncome = monthlyFixedIncome;
	}

	public String getAdditionalAnnualIncome() {
		return additionalAnnualIncome;
	}

	public void setAdditionalAnnualIncome(String additionalAnnualIncome) {
		this.additionalAnnualIncome = additionalAnnualIncome;
	}

	public String getAutoFinance() {
		return autoFinance;
	}

	public void setAutoFinance(String autoFinance) {
		this.autoFinance = autoFinance;
	}

	public String getPersonalFinance() {
		return personalFinance;
	}

	public void setPersonalFinance(String personalFinance) {
		this.personalFinance = personalFinance;
	}

	public String getHomeFinance() {
		return homeFinance;
	}

	public void setHomeFinance(String homeFinance) {
		this.homeFinance = homeFinance;
	}

	public String getOtherInstallments() {
		return otherInstallments;
	}

	public void setOtherInstallments(String otherInstallments) {
		this.otherInstallments = otherInstallments;
	}

	public String getCreditCardLimit() {
		return creditCardLimit;
	}

	public void setCreditCardLimit(String creditCardLimit) {
		this.creditCardLimit = creditCardLimit;
	}

	public String getWhoAmI() {
		return whoAmI;
	}

	public void setWhoAmI(String whoAmI) {
		this.whoAmI = whoAmI;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBankingIds() {
		return bankIds;
	}

	public void setBankingIds(String bankingIds) {
		this.bankIds = bankingIds;
	}

	public String getEligibilityAmount() {
		return eligibilityAmount;
	}

	public void setEligibilityAmount(String eligibilityAmount) {
		this.eligibilityAmount = eligibilityAmount;
	}

	public String getMaximumTenor() {
		return maximumTenor;
	}

	public void setMaximumTenor(String maximumTenor) {
		this.maximumTenor = maximumTenor;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getBankIds() {
		return bankIds;
	}

	public void setBankIds(String bankIds) {
		this.bankIds = bankIds;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Boolean getIsPreQualified() {
		return isPreQualified;
	}

	public void setIsPreQualified(Boolean isPreQualified) {
		this.isPreQualified = isPreQualified;
	}

}
