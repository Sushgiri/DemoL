
package com.bestercapitalmedia.letwizard.audit.user;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonBackReference;

import com.bestercapitalmedia.letwizard.user.Chiraghuser;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "audit_user_logs")
@Data
@NoArgsConstructor
public class AuditUserLogs implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "user_Id", referencedColumnName = "user_id") })
	@JsonBackReference
	Chiraghuser chiraghuser;

	@Column(name = "location")
	private String location;

	@Column(name = "ip_address")
	@Basic(fetch = FetchType.EAGER)
	private String ipAddress;

	@Column(name = "device")
	@Basic(fetch = FetchType.EAGER)
	private String device;
	
	@Column(name = "data")
	@Basic(fetch = FetchType.EAGER)
	private String data;

	@Column(name = "updated_at")
	@Basic(fetch = FetchType.EAGER)
	private Date updatedAt;

	public AuditUserLogs(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
}