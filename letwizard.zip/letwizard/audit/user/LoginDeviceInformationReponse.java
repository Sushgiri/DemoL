
package com.bestercapitalmedia.letwizard.audit.user;

import com.ibm.icu.math.BigDecimal;

import lombok.Data;

@Data
public class LoginDeviceInformationReponse {

	private String as;
	private String city;
	private String country;
	private String countryCode;
	private String isp;
	private BigDecimal lat;
	private BigDecimal lon;
	private String org;
	private String query;
	private String region;
	private String regionName;
	private String status;
	private String timezone;
	private String zip;
}
