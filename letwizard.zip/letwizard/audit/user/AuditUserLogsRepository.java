package com.bestercapitalmedia.letwizard.audit.user;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AuditUserLogsRepository extends JpaRepository<AuditUserLogs, Integer> {
	
	@Query(value = "SELECT * FROM audit_user_logs WHERE user_id =?1 AND ip_address= ?2  AND location =?3 AND device =?4", nativeQuery = true)
	public AuditUserLogs getAuditLog(int userId, String ip, String location, String device );
	
	@Query(value = "SELECT * FROM audit_user_logs WHERE user_id =?1 ", nativeQuery = true)
	public List<AuditUserLogs> findByUserId(int userId);

}
