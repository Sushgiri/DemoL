package com.bestercapitalmedia.letwizard.amenities;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.bestercapitalmedia.letwizard.attributelist.Propertyattributeslist;
import com.bestercapitalmedia.letwizard.evaluation.PropertyEvaluation;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "property_amenities")
public class PropertyEvaluationAmenities implements Serializable {
	private static final long serialVersionUID = 1L;
	
		@Column(name = "id", nullable = false)
		@Basic(fetch = FetchType.EAGER)
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		Integer amenityId;
	
		@Column(name = "value")
		@Basic(fetch = FetchType.EAGER)
	    Integer value;

		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumns({ @JoinColumn(name = "property_attributes_id", referencedColumnName = "property_Attributes_Id") })
		@JsonBackReference
		Propertyattributeslist propertyattributeslist;

		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumns({ @JoinColumn(name = "property_evaluation_id", referencedColumnName = "id") })
		@JsonBackReference(value = "property_evaluation")
		PropertyEvaluation evaluation;
		
		public PropertyEvaluationAmenities() {
			
		}

		public Integer getAmenityId() {
			return amenityId;
		}

		public void setAmenityId(Integer amenityId) {
			this.amenityId = amenityId;
		}

		public Integer getValue() {
			return value;
		}

		public void setValue(Integer value) {
			this.value = value;
		}

		public Propertyattributeslist getPropertyattributeslist() {
			return propertyattributeslist;
		}

		public void setPropertyattributeslist(Propertyattributeslist propertyattributeslist) {
			this.propertyattributeslist = propertyattributeslist;
		}

		public PropertyEvaluation getEvaluation() {
			return evaluation;
		}

		public void setEvaluation(PropertyEvaluation evaluation) {
			this.evaluation = evaluation;
		}
		
		
}
