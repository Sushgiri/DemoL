package com.bestercapitalmedia.letwizard.amenities;


import org.springframework.data.repository.CrudRepository;

public interface PropertyEvaluationAmenitiesRepository  extends CrudRepository<PropertyEvaluationAmenities, Integer>{



	
}
