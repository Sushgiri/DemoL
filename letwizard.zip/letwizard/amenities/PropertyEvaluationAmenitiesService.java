package com.bestercapitalmedia.letwizard.amenities;

import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.evaluation.PropertyEvaluationDTO;


@Service
public interface PropertyEvaluationAmenitiesService {

	public String save(PropertyEvaluationDTO EvaluationRequestDto);
	public String saveAll(PropertyEvaluationDTO propertyEvaluationaRequestDto);
	
}
