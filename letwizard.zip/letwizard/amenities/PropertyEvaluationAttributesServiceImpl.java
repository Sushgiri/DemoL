package com.bestercapitalmedia.letwizard.amenities;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.attributelist.PropertyAttributesListService;
import com.bestercapitalmedia.letwizard.attributelist.Propertyattributeslist;
import com.bestercapitalmedia.letwizard.evaluation.PropertyEvaluation;
import com.bestercapitalmedia.letwizard.evaluation.PropertyEvaluationDTO;
import com.bestercapitalmedia.letwizard.evaluation.PropertyEvaluationRepository;

@Service
public class PropertyEvaluationAttributesServiceImpl implements PropertyEvaluationAmenitiesService {


	@Autowired
	private PropertyEvaluationAmenitiesRepository evaluationAmenitiesRepository;
	
	@Autowired
	private PropertyEvaluationRepository propertyEvaluationRepository;
	
	@Autowired
	private PropertyAttributesListService propertyAttributesListService;
	

	@Override
	public String saveAll(PropertyEvaluationDTO propertyEvaluationaRequestDto) {

		List<PropertyEvaluationAmenities> evaluationAmenitiesList = new ArrayList<>();

		PropertyEvaluation propertyEvaluation = propertyEvaluationRepository.findByEvaluationId(propertyEvaluationaRequestDto.getPropertyEvaluationId());		
		propertyEvaluationaRequestDto.getAmenities().stream().forEach(m -> {
			Propertyattributeslist amenitiesList = propertyAttributesListService.findById(m.getPropertyAttributesId());
			PropertyEvaluationAmenities amenities = new PropertyEvaluationAmenities();
			amenities.setEvaluation(propertyEvaluation);
			amenities.setPropertyattributeslist(amenitiesList);
			evaluationAmenitiesList.add(amenities);

		});
		evaluationAmenitiesRepository.saveAll(evaluationAmenitiesList);
		return "saved";
	}


	@Override
	public String save(PropertyEvaluationDTO EvaluationRequestDto) {
		// TODO Auto-generated method stub
		return null;
	}

}
