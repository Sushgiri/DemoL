package com.bestercapitalmedia.letwizard.company.attributes;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "companyattributes")
public class CompanyAttributes implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "company_attributes_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer companyAttributesId;

	@Column(name = "name", length = 225)
	@Basic(fetch = FetchType.EAGER)
	String name;

	@Column(name = "type", length = 45)
	@Basic(fetch = FetchType.EAGER)
	String type;

	@Column(name = "status")
	@Basic(fetch = FetchType.EAGER)
	Boolean status;

	public Integer getCompanyAttributesId() {
		return companyAttributesId;
	}

	public void setCompanyAttributesId(Integer companyAttributesId) {
		this.companyAttributesId = companyAttributesId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public CompanyAttributes() {

	}

}
