package com.bestercapitalmedia.letwizard.company.attributes;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;



public interface CompanyAttributesRepository extends CrudRepository<CompanyAttributes, Integer>{
	
	
	@Query(value = "select * from companyattributes where status = 'true'", nativeQuery = true)
	public List<CompanyAttributes> getAllCompanyAttributes();

}
