package com.bestercapitalmedia.letwizard.company.attributes;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.constants.UserMessages;
import com.bestercapitalmedia.letwizard.seller.details.PropertySellerDetailsService;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;

@Service 
public class CompanyAttributesService {
	private static final Logger logger = LoggerFactory.getLogger(PropertySellerDetailsService.class);
	
	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	CompanyAttributesRepository companyAttributeRepository;
	@Autowired
	private ResponseUtill responseUtil;
	
	public ResponseEntity getAllCompanyAttributes() {
		try {
			List<CompanyAttributes> list = companyAttributeRepository.getAllCompanyAttributes();

			if (list.isEmpty()) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.COMPANY_ATTRIBUTES_RETRIEVAL_FAILURE, null);
			} else {
				return responseUtil.getApiResponse(ResponseCodes.SUCCESS, SellerMessages.COMPANY_ATTRIBUTES_RETRIEVAL_SUCCESS,list);
			}
		} catch (Exception e) {
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					UserMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

}
