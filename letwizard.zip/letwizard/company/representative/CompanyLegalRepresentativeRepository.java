package com.bestercapitalmedia.letwizard.company.representative;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.company.attributes.CompanyAttributes;

public interface CompanyLegalRepresentativeRepository extends CrudRepository<CompanyLegalRepresentative, Integer> {
	
	
	@Query(value = "select * from companylegalrepresentative where property_seller_id=?1", nativeQuery = true)
	public List<CompanyLegalRepresentative> getAllCompanyLegalRepresentativeById(int seller_Id);
	
	@Query(value = "select * from companylegalrepresentative where company_legal_representative_id=?1", nativeQuery = true)
	public CompanyLegalRepresentative getCompanyLegalRepresentativeById(int companyLegalRepresentativeId);
	
	@Query(value = "delete from companylegalrepresentative where property_seller_id=?1", nativeQuery = true)
	public List<CompanyLegalRepresentative> deleteAllCompanyLegalRepresentativeById(int seller_Id);

	@Query(value = "select * from companylegalrepresentative where property_buyer_id=?1", nativeQuery = true)
	public List<CompanyLegalRepresentative> getAllCompanyLegalRepresentativeByBuyerId(int buyerId);
	
}
