package com.bestercapitalmedia.letwizard.company.representative;

import java.io.Serializable;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.SortNatural;
import org.hibernate.envers.Audited;

import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetails;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.seller.details.Propertysellerdetails;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "companylegalrepresentative")
public class CompanyLegalRepresentative implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "company_legal_representative_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	Integer companyLegalRepresentativeId;

	@Column(name = "first_name", length = 225)
	@Basic(fetch = FetchType.EAGER)

	String firstName;

	@Column(name = "last_name", length = 225)
	@Basic(fetch = FetchType.EAGER)

	String lastName;

	@Column(name = "nationality", length = 25)
	@Basic(fetch = FetchType.EAGER)

	String nationality;

	@Column(name = "designation", length = 50)
	@Basic(fetch = FetchType.EAGER)

	String designation;

	@Column(name = "country_code")
	@Basic(fetch = FetchType.EAGER)

	Integer countryCode;

	@Column(name = "mobile_number", length = 225)
	@Basic(fetch = FetchType.EAGER)

	String mobileNumber;

	@Column(name = "email_address", length = 250)
	@Basic(fetch = FetchType.EAGER)

	String emailAddress;


	@Column(name = "passport_document")
	@Basic(fetch = FetchType.EAGER)

	String passportDocument;
	
	@Column(name = "idcopy_document")
	@Basic(fetch = FetchType.EAGER)

	String idcopyDocument;

	
	
	public String getPassportDocument() {
		return passportDocument;
	}

	public void setPassportDocument(String passportDocument) {
		this.passportDocument = passportDocument;
	}

	public String getIdcopyDocument() {
		return idcopyDocument;
	}

	public void setIdcopyDocument(String idcopyDocument) {
		this.idcopyDocument = idcopyDocument;
	}


	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "property_seller_id", referencedColumnName = "property_Seller_Id") })
	@JsonBackReference
	Propertysellerdetails propertysellerdetails;

	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "property_buyer_id", referencedColumnName = "property_Buyer_Id") })
	@JsonBackReference
	PropertyBuyerDetails propertyBuyerDetails;



	public Propertysellerdetails getPropertysellerdetails() {
		return propertysellerdetails;
	}

	public void setPropertysellerdetails(Propertysellerdetails propertysellerdetails) {
		this.propertysellerdetails = propertysellerdetails;
	}
	
	

	public PropertyBuyerDetails getPropertyBuyerDetails() {
		return propertyBuyerDetails;
	}

	public void setPropertyBuyerDetails(PropertyBuyerDetails propertyBuyerDetails) {
		this.propertyBuyerDetails = propertyBuyerDetails;
	}

	public CompanyLegalRepresentative() {

	}

	public Integer getCompanyLegalRepresentativeId() {
		return companyLegalRepresentativeId;
	}

	public void setCompanyLegalRepresentativeId(Integer companyLegalRepresentativeId) {
		this.companyLegalRepresentativeId = companyLegalRepresentativeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Integer getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
