package com.bestercapitalmedia.letwizard.company.representative;

public class ResponseCompanyLegalRepresentativeDTO {
	
	
	String firstName;
	String lastName;
	String nationality;
	String designation;
	Integer countryCode;
	String mobileNumber;
	String passportDocument;
	String idcopyDocument;
	String emailAddress;
	Integer companyLegalRepresentativeId;

	
	public String getPassportDocument() {
		return passportDocument;
	}


	public void setPassportDocument(String passportDocument) {
		this.passportDocument = passportDocument;
	}


	

	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getNationality() {
		return nationality;
	}


	public void setNationality(String nationality) {
		this.nationality = nationality;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public Integer getCountryCode() {
		return countryCode;
	}


	public void setCountryCode(Integer countryCode) {
		this.countryCode = countryCode;
	}


	public String getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public Integer getCompanyLegalRepresentativeId() {
		return companyLegalRepresentativeId;
	}


	public void setCompanyLegalRepresentativeId(Integer companyLegalRepresentativeId) {
		this.companyLegalRepresentativeId = companyLegalRepresentativeId;
	}


	public ResponseCompanyLegalRepresentativeDTO() {
		
	}


	public String getEmailAddress() {
		return emailAddress;
	}


	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}


	public String getIdcopyDocument() {
		return idcopyDocument;
	}


	public void setIdcopyDocument(String idcopyDocument) {
		this.idcopyDocument = idcopyDocument;
	}

}
