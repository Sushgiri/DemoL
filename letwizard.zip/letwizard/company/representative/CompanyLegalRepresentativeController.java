package com.bestercapitalmedia.letwizard.company.representative;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.city.City;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.country.Country;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyDetailsDTO;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.type.Propertytype;
import com.bestercapitalmedia.letwizard.seller.details.PropertySellerDetailDTO;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.utill.StringValidationUtils;
import com.bestercapitalmedia.letwizard.valuation.compaines.process.ValuationCompaniesProcess;

@RestController
@CrossOrigin(origins = "*")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class CompanyLegalRepresentativeController {
	
	
	@Autowired
	CompanyLegalRepresentativeService companyLegalRepresentativeService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/companyLegalRepresentatives/{sellerId}", method = RequestMethod.GET)
	public ResponseEntity getAllCompanyAttributes(@PathVariable(value = "sellerId") int sellerId,HttpServletRequest httpServletRequest) {
		return companyLegalRepresentativeService.getCompanyLegalRepresentative(sellerId);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/companyLegalRepresentatives", method = RequestMethod.POST)
	public ResponseEntity save(@RequestBody  RequestCompanyLegalRepresentativeDTO  companyLegalRepresentativeDTO,
								 HttpServletRequest httpServletRequest) {
		
		return companyLegalRepresentativeService.saveCompanyLegalRepresentative(companyLegalRepresentativeDTO);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/companyLegalRepresentatives", method = RequestMethod.PUT)
	public ResponseEntity update(@RequestBody  ResponseCompanyLegalRepresentativeDTO  companyLegalRepresentativeDTO,
								 HttpServletRequest httpServletRequest) {
		
		return companyLegalRepresentativeService.updateCompanyLegalRepresentative(companyLegalRepresentativeDTO);
	}

}
