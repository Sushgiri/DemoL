package com.bestercapitalmedia.letwizard.company.representative;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.city.City;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.country.Country;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.type.Propertytype;
import com.bestercapitalmedia.letwizard.seller.details.PropertySellerDetailsRepository;
import com.bestercapitalmedia.letwizard.seller.details.PropertySellerDetailsService;
import com.bestercapitalmedia.letwizard.seller.details.Propertysellerdetails;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.StringValidationUtils;

@Service
public class CompanyLegalRepresentativeService {

	private static final Logger logger = LoggerFactory.getLogger(PropertySellerDetailsService.class);

	@Autowired
	private PropertySellerDetailsRepository propertySellerDetailsRepository;

	@Autowired
	private ResponseUtill responseUtil;

	@Autowired
	private CompanyLegalRepresentativeRepository companyLegalRepresentativeRepository;

	public ResponseEntity saveCompanyLegalRepresentative(RequestCompanyLegalRepresentativeDTO companyLegalRepresentativeDTO) {

		try {
			int propertySellerId = companyLegalRepresentativeDTO.getPropertySellerId();
			logger.info("Proeprty Seller Id" + propertySellerId);
			Propertysellerdetails sellerdetails = propertySellerDetailsRepository.findCompanyById(propertySellerId);

			if (sellerdetails == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.COMPANY_LEGAL_RESOURCE_NOT_FOUND, null);
			} else {
				ModelMapper mapper = new ModelMapper();

				CompanyLegalRepresentative legalrepresenatative = mapper.map(companyLegalRepresentativeDTO,
						CompanyLegalRepresentative.class);
				legalrepresenatative.setPropertysellerdetails(sellerdetails);
				CompanyLegalRepresentative legalrepresenatative2=companyLegalRepresentativeRepository.save(legalrepresenatative);
				ResponseCompanyLegalRepresentativeDTO responsedto = mapper.map(legalrepresenatative2,
						ResponseCompanyLegalRepresentativeDTO.class);
				responsedto .setCompanyLegalRepresentativeId(legalrepresenatative2.getCompanyLegalRepresentativeId());
				return responseUtil.getApiResponse(ResponseCodes.SUCCESS,
						SellerMessages.COMPANY_LEGAL_REPRESENTATIVE_SUCCESS, Stream.of(responsedto).collect(Collectors.toList()));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}

	public ResponseEntity getCompanyLegalRepresentative(int propertySellerId) {

		try {
			logger.info("Proeprty Seller Id" + propertySellerId);

			List<CompanyLegalRepresentative> legalrepresenatative = companyLegalRepresentativeRepository
					.getAllCompanyLegalRepresentativeById(propertySellerId);

			if (legalrepresenatative == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.COMPANY_LEGAL_RESOURCE_NOT_FOUND, null);
			} else {

				return responseUtil.getApiResponse(ResponseCodes.SUCCESS,
						SellerMessages.COMPANY_LEGAL_REPRESENTATIVE_SUCCESS, legalrepresenatative);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}
	
	
	public ResponseEntity updateCompanyLegalRepresentative(ResponseCompanyLegalRepresentativeDTO companyLegalRepresentativeDTO) {

		try {
		
			CompanyLegalRepresentative legalrepresenatative = companyLegalRepresentativeRepository.getCompanyLegalRepresentativeById(companyLegalRepresentativeDTO.getCompanyLegalRepresentativeId());
			

			if (legalrepresenatative == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.COMPANY_LEGAL_RESOURCE_NOT_FOUND, null);
			} else {
				//Propertysellerdetails sellerdetails = propertySellerDetailsRepository.findCompanyById(companyLegalRepresentativeDTO.getPropertySellerId());
				legalrepresenatative.setCountryCode(companyLegalRepresentativeDTO.getCountryCode());
				legalrepresenatative.setDesignation(companyLegalRepresentativeDTO.getDesignation());
				legalrepresenatative.setFirstName(companyLegalRepresentativeDTO.getFirstName());
				legalrepresenatative.setLastName(companyLegalRepresentativeDTO.getLastName());
				legalrepresenatative.setMobileNumber(companyLegalRepresentativeDTO.getMobileNumber());
				legalrepresenatative.setNationality(companyLegalRepresentativeDTO.getNationality());
				legalrepresenatative.setPropertysellerdetails(legalrepresenatative .getPropertysellerdetails());
				companyLegalRepresentativeRepository.save(legalrepresenatative);

				return responseUtil.getApiResponse(ResponseCodes.SUCCESS,
						SellerMessages.COMPANY_LEGAL_REPRESENTATIVE_SUCCESS, null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}


}
