package com.bestercapitalmedia.letwizard.banner;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BannerService {
    @Autowired
    private BannerRepository bannerRepository;

    @Autowired
    private ResponseUtill responseUtill;

    public ResponseEntity getAllActiveBanners() {

        try {

            List<Banner> bannerList = bannerRepository.getAllActiveBanners();
            if (bannerList == null) {
                return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
                        null);
            } else {

                return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
                        bannerList);
            }
        } catch (Exception e) {

            return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
                    SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
        }
    }
}
