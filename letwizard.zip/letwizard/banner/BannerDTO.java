package com.bestercapitalmedia.letwizard.banner;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BannerDTO {
    private Integer bannerId;
    private  String bannerTitle;
    private  String bannerSubtitle1;
    private  String bannerSubtitle2;
    private  String bannerImage;
    private Boolean isActive;
    private  String bannerMobileImage;
}
