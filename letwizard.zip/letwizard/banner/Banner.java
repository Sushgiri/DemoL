package com.bestercapitalmedia.letwizard.banner;

import lombok.Data;

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;

@Entity
@Table(name = "banners")
@Data
public class Banner {

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "banner_Id")
    private Integer bannerId;

    @Column(name = "banner_title")
    private String bannerTitle;

    @Column(name = "banner_subtitle1")
    private String bannerSubtitle1;

    @Column(name = "banner_subtitle2")
    private String bannerSubtitle2;

    @Column(name = "banner_image")
    private String bannerImage;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "banner_mobile_image")
    private String bannerMobileImage;
}
