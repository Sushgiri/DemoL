package com.bestercapitalmedia.letwizard.banner;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;


import java.util.List;

public interface BannerRepository extends PagingAndSortingRepository<Banner, Integer> {

    @Query(value = "SELECT * FROM banners WHERE is_active = TRUE", nativeQuery = true)
    List<Banner> getAllActiveBanners();

}
