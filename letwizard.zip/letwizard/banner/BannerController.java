package com.bestercapitalmedia.letwizard.banner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bestercapitalmedia.letwizard.utill.CompressAnnotation.Compress;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@RestController
//@RequestMapping("/api")
public class BannerController {

    @Autowired
    BannerService bannerService;

    @Compress
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    @CrossOrigin(origins = "*")
    @RequestMapping(value="/banners",method=RequestMethod.GET)
    public ResponseEntity getAllCountries() {
        return bannerService.getAllActiveBanners();
    }

}
