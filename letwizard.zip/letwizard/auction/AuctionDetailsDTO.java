package com.bestercapitalmedia.letwizard.auction;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;

// TODO: Auto-generated Javadoc
/**
 * The Class ChiraghPropertyAuctionDetailsDTO.
 */
public class AuctionDetailsDTO {

	/** The property id. */
	int propertyId;
	
	/** The user name. */
	String userName;
	
	/** The auction duration. */
	String auctionDuration;
	
	/** The auction cost. */
	String auctionCost;
	
	/** The security deposit. */
	float securityDeposit;
	
	/** The auction start date. */
    Date auctionStartDate;
	
    
	public Date getAuctionStartDate() {
		return auctionStartDate;
	}

	public void setAuctionStartDate(Date auctionStartDate) {
		this.auctionStartDate = auctionStartDate;
	}

	Date auctionEndDate;
	
	public Date getAuctionEndDate() {
		return auctionEndDate;
	}

	public void setAuctionEndDate(Date auctionEndDate) {
		this.auctionEndDate = auctionEndDate;
	}

	

	/**
	 * Gets the auction duration.
	 *
	 * @return the auction duration
	 */
	public String getAuctionDuration() {
		return auctionDuration;
	}

	/**
	 * Sets the auction duration.
	 *
	 * @param auctionDuration the new auction duration
	 */
	public void setAuctionDuration(String auctionDuration) {
		this.auctionDuration = auctionDuration;
	}

	/**
	 * Gets the auction cost.
	 *
	 * @return the auction cost
	 */
	public String getAuctionCost() {
		return auctionCost;
	}

	/**
	 * Sets the auction cost.
	 *
	 * @param auctionCost the new auction cost
	 */
	public void setAuctionCost(String auctionCost) {
		this.auctionCost = auctionCost;
	}

	/**
	 * Gets the security deposit.
	 *
	 * @return the security deposit
	 */
	

	/**
	 * Instantiates a new chiragh property auction details DTO.
	 */
	public AuctionDetailsDTO() {
		
		// TODO Auto-generated constructor stub
	}

	public float getSecurityDeposit() {
		return securityDeposit;
	}

	public void setSecurityDeposit(float securityDeposit) {
		this.securityDeposit = securityDeposit;
	}

	public int getPropertyId() {
		return propertyId;
	}

	/**
	 * Sets the property id.
	 *
	 * @param propertyId the new property id
	 */
	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}


	/**
	 * Gets the user name.
	 *
	 * @return the user name
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * Sets the user name.
	 *
	 * @param userName the new user name
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
