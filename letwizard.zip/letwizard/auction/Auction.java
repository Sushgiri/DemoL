
package com.bestercapitalmedia.letwizard.auction;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.auctionprocess.Propertyauctionprocess;
import com.fasterxml.jackson.annotation.JsonBackReference;

// TODO: Auto-generated Javadoc
/**
 * The Class Auction.
 */

@Entity
@Table(name = "auction")
public class Auction implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The auction duration id. */

	@Column(name = "auction_Duration_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer auctionDurationId;

	/** The auction duration. */

	@Column(name = "auction_Duration", length = 25)
	@Basic(fetch = FetchType.EAGER)

	String auctionDuration;

	/** The auction cost. */

	@Column(name = "auction_Cost", length = 25)
	@Basic(fetch = FetchType.EAGER)

	String auctionCost;

	/** The is published. */

	@Column(name = "is_Published", length = 25)
	@Basic(fetch = FetchType.EAGER)

	String isPublished;

	/** The security deposit. */

	@Column(name = "security_Deposit")
	@Basic(fetch = FetchType.EAGER)

	float securityDeposit;

	/** The auction start date. */
	@Column(name = "auction_Start_Date")
	Date auctionStartDate;

	/** The auction end date. */
	@Column(name = "auction_End_date")
	Date auctionEndDate;

	/** The chiraghproperty. */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "property_Id", referencedColumnName = "property_Id") })
	@JsonBackReference
	Chiraghproperty chiraghproperty;

	/** The propertyauctionprocesses. */
	@OneToMany(mappedBy = "auction", fetch = FetchType.LAZY)

	java.util.Set<Propertyauctionprocess> propertyauctionprocesses;

	/**
	 * Instantiates a new auction.
	 */
	
	
	
	public Auction() {
	}

	public Date getAuctionStartDate() {
		return auctionStartDate;
	}

	public void setAuctionStartDate(Date auctionStartDate) {
		this.auctionStartDate = auctionStartDate;
	}

	public Date getAuctionEndDate() {
		return auctionEndDate;
	}

	public void setAuctionEndDate(Date auctionEndDate) {
		this.auctionEndDate = auctionEndDate;
	}

	/**
	 * Sets the auction duration id.
	 *
	 * @param auctionDurationId
	 *            the new auction duration id
	 */
	public void setAuctionDurationId(Integer auctionDurationId) {
		this.auctionDurationId = auctionDurationId;
	}

	/**
	 * Gets the auction duration id.
	 *
	 * @return the auction duration id
	 */
	public Integer getAuctionDurationId() {
		return this.auctionDurationId;
	}

	/**
	 * Sets the auction duration.
	 *
	 * @param auctionDuration
	 *            the new auction duration
	 */
	public void setAuctionDuration(String auctionDuration) {
		this.auctionDuration = auctionDuration;
	}

	/**
	 * Gets the auction duration.
	 *
	 * @return the auction duration
	 */
	public String getAuctionDuration() {
		return this.auctionDuration;
	}

	/**
	 * Sets the auction cost.
	 *
	 * @param auctionCost
	 *            the new auction cost
	 */
	public void setAuctionCost(String auctionCost) {
		this.auctionCost = auctionCost;
	}

	/**
	 * Gets the auction cost.
	 *
	 * @return the auction cost
	 */
	public String getAuctionCost() {
		return this.auctionCost;
	}

	/**
	 * Sets the checks if is published.
	 *
	 * @param isPublished
	 *            the new checks if is published
	 */
	public void setIsPublished(String isPublished) {
		this.isPublished = isPublished;
	}

	/**
	 * Gets the checks if is published.
	 *
	 * @return the checks if is published
	 */
	public String getIsPublished() {
		return this.isPublished;
	}

	/**
	 * Sets the security deposit.
	 *
	 * @param securityDeposit
	 *            the new security deposit
	 */
	

	/**
	 * Sets the chiraghproperty.
	 *
	 * @param chiraghproperty
	 *            the new chiraghproperty
	 */
	public void setChiraghproperty(Chiraghproperty chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}

	public float getSecurityDeposit() {
		return securityDeposit;
	}

	public void setSecurityDeposit(float securityDeposit) {
		this.securityDeposit = securityDeposit;
	}

	/**
	 * Gets the chiraghproperty.
	 *
	 * @return the chiraghproperty
	 */
	public Chiraghproperty getChiraghproperty() {
		return chiraghproperty;
	}

	/**
	 * Sets the propertyauctionprocesses.
	 *
	 * @param propertyauctionprocesses
	 *            the new propertyauctionprocesses
	 */
	public void setPropertyauctionprocesses(Set<Propertyauctionprocess> propertyauctionprocesses) {
		this.propertyauctionprocesses = propertyauctionprocesses;
	}

	/**
	 * Gets the propertyauctionprocesses.
	 *
	 * @return the propertyauctionprocesses
	 */
	public Set<Propertyauctionprocess> getPropertyauctionprocesses() {
		if (propertyauctionprocesses == null) {
			propertyauctionprocesses = new java.util.LinkedHashSet<>();
		}
		return propertyauctionprocesses;
	}

	
}
