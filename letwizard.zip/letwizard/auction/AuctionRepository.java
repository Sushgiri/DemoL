package com.bestercapitalmedia.letwizard.auction;

import org.springframework.data.repository.CrudRepository;

/**
 * The Interface AuctionRepository.
 */
public interface AuctionRepository  extends CrudRepository<Auction, Integer>{

}
