package com.bestercapitalmedia.letwizard.auction;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.RequestDtoForDashBoardPaginatedProperties;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.LogUtill;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

// TODO: Auto-generated Javadoc
/**
 * The Class AuctionController.
 */
@Controller
@CrossOrigin
@RequestMapping("/api/auction")
public class AuctionController {

	/** The Constant log. */
	private static final Logger log = LoggerFactory.getLogger(AuctionController.class);

	/** The auction repository. */
	@Autowired
	private AuctionRepository auctionRepository;

	/** The property repository. */
	@Autowired
	private PropertyRepository propertyRepository;

	/** The auction service. */
	@Autowired
	private AuctionService auctionService;

	/** The chiragh utill. */
	@Autowired
	private ChiragUtill chiraghUtill;

	/** The log utill. */
	@Autowired
	private LogUtill logUtill;

	/**
	 * List.
	 *
	 * @return the string
//	 */
//	@RequestMapping(value = "/saveauction", method = RequestMethod.GET)
//	public String list() {
//		log.info("GET: /api/auction/getAll");
//		ObjectMapper objectMapper = new ObjectMapper();
//		Iterable<Auction> auctionList = auctionRepository.findAll();
//		String rtnObject = "";
//		try {
//			rtnObject = objectMapper.writeValueAsString(auctionList);
//		} catch (JsonProcessingException e) {
//			log.error(e.getMessage(), e);
//		}
//
//		log.info("Output: " + rtnObject);
//		log.info("--------------------------------------------------------");
//		return rtnObject;
//	}// end of list method

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/saveAuctionDetails", method = RequestMethod.POST)
	public ResponseEntity saveAuctionDetails(
			@RequestBody AuctionDetailsDTO AuctionDetailsDTO,
			HttpServletRequest httpServletRequest) {
		return auctionService.saveAuctionDetails(AuctionDetailsDTO);
	}
	
	

}// end of controller
