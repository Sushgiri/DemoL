package com.bestercapitalmedia.letwizard.auction;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.admin.checklist.CheckListRepository;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.PropertyCheckListRepository;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.Propertychecklist;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.SearchDTO;
import com.bestercapitalmedia.letwizard.seller.details.PropertySellerDetailsService;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// TODO: Auto-generated Javadoc
/**
 * The Class AuctionService.
 */
@Service
public class AuctionService {

	private static final Logger logger = LoggerFactory.getLogger(AuctionService.class);

	/** The property seller details service. */
	@Autowired
	private PropertySellerDetailsService propertySellerDetailsService;

	/** The property repository. */
	@Autowired
	private PropertyRepository propertyRepository;

	/** The auction repository. */
	@Autowired
	private AuctionRepository auctionRepository;
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private CheckListRepository checkListRepository;

	@Autowired
	private PropertyCheckListRepository propertyCheckListRepository;
	


	public ResponseEntity saveAuctionDetails(AuctionDetailsDTO auctionDetails) {
		try {

			Chiraghuser chiraghuser = userRepository.findByUserName(auctionDetails.getUserName());
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(auctionDetails.getPropertyId());
			
			if (chiraghuser == null || chiraghproperty == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_NOT_FOUND,
						null);
			}
			
			//process of retrieving listing price
			Checklist checklist=checkListRepository.getByDepartmentId();
			Propertychecklist propertycheckList=propertyCheckListRepository.getPropertyListingprice(checklist.getChecklistId(),chiraghuser.getUserId(),chiraghproperty.getPropertyId());
			float calculateSecurityDeposit=(float) ((Float.valueOf(propertycheckList.getUserInput())/100)*2.5);
			
			System.out.println("Start Date"+auctionDetails.getAuctionStartDate());
			ModelMapper mapper = new ModelMapper();
			Auction auctiondetails = mapper.map(auctionDetails, Auction.class);
     		auctiondetails.setChiraghproperty(chiraghproperty);
     		auctiondetails.setIsPublished("0");
     		auctiondetails.setSecurityDeposit(calculateSecurityDeposit);
			Auction saveAuction =auctionRepository.save(auctiondetails);
			
			AuctionDetailsDTO dtoMapping=mapper.map(saveAuction,AuctionDetailsDTO.class);
			dtoMapping.setPropertyId(saveAuction.getChiraghproperty().getPropertyId());
			if (saveAuction == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE,
						PropertyMessages.AUCTION_FEE_DETAILS_FAILURE, null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
						PropertyMessages.AUCTION_FEE_DETAILS_SUCCESS, 
						Stream.of(dtoMapping).collect(Collectors.toList()));
			}
		
		} catch (Exception e) {
			e.printStackTrace();
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
}
