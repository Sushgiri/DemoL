package com.bestercapitalmedia.letwizard.configurations;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EMIConfigDTO {
	
	private String down_payment;
	private String loan_term_years;
	private String interest_only_period;
	private String lowest_interest_rate;

}
