package com.bestercapitalmedia.letwizard.configurations;

import lombok.Data;

@Data
public class CurrencyTransactionLimitModel {
	
	private boolean MD_APPROVAL_REQUIRED;
	private boolean FINANCE_HOD_APPROVAL_REQUIRED;

}
