package com.bestercapitalmedia.letwizard.configurations;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface ConfigurationsRepository extends CrudRepository<Configurations, Integer> {
	
	@Query(value = "SELECT * FROM configurations WHERE key_Name = 'blockchain_unseal_token'", nativeQuery = true)
	public Configurations getUnsealTokenForBlockchain();
	
	@Query(value = "SELECT * FROM configurations WHERE key_Name = 'bid_extension_time_min'", nativeQuery = true)
	public Configurations getPropertyBidExtensionTimeInMinutes();
}
