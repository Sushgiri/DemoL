package com.bestercapitalmedia.letwizard.configurations;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ConfigurationsDTO {
	
	private Integer configurationsId;
	private String keyName;
	private String keyValue;

}
