package com.bestercapitalmedia.letwizard.configurations;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.glassfish.jersey.internal.guava.Lists;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.currencyexchangerate.CurrencyRate;
import com.bestercapitalmedia.letwizard.currencyexchangerate.CurrencyRateRepository;
import com.bestercapitalmedia.letwizard.daxexports.ListToCsvWriter;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrency;
import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrencyRepository;
import com.google.gson.Gson;

@Service
public class ConfigurationsServiceImpl implements ConfigurationsService {

	@Autowired
	private ConfigurationsRepository configurationsRepository;

	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private VoucherCurrencyRepository voucherCurrencyRepository;
	
	@Autowired
	private CurrencyRateRepository currencyRateRepository;

	static final Logger logger = LoggerFactory.getLogger(ConfigurationsServiceImpl.class);

	@Override
	public ResponseEntity getAllConfigurations() {

		try {
			Iterable<Configurations> configurations = new ArrayList();
			configurations = configurationsRepository.findAll();
			List<Configurations> configurationsList = Lists.newArrayList(configurations);

			if (configurationsList.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					configurationsList);

		}

		catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
					Stream.of(e).collect(Collectors.toList()));

		}
	}

	@Override
	public ResponseEntity getEMIConfigurations() {

		try {
			Iterable<Configurations> configurations = new ArrayList<>();
			logger.info("Getting Configurations data from database");
			configurations = configurationsRepository.findAll();
			List<Configurations> configurationsList = Lists.newArrayList(configurations);

			if (configurationsList.isEmpty()) {
				logger.info("Data not retreived failure from database");
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			EMIConfigDTO emiConfigDTO = new EMIConfigDTO();
			emiConfigDTO.setDown_payment(configurationsList.get(0).getKeyValue());
			emiConfigDTO.setLoan_term_years(configurationsList.get(1).getKeyValue());
			emiConfigDTO.setInterest_only_period(configurationsList.get(2).getKeyValue());
			emiConfigDTO.setLowest_interest_rate(configurationsList.get(3).getKeyValue());
			logger.info("Configurations Data Dispatched");
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(emiConfigDTO).collect(Collectors.toList()));
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
					Stream.of(e).collect(Collectors.toList()));

		}
	}
	
	public ResponseEntity getTransactionCurrencyLimit(String currencyCode, Double amount) {

		CurrencyTransactionLimitModel currencyLimitModel = new CurrencyTransactionLimitModel();
		VoucherCurrency voucherCurrency = voucherCurrencyRepository.findByCode(currencyCode);
		VoucherCurrency aedCurrency = voucherCurrencyRepository.findByCode("AED");
		VoucherCurrency usdCurrency = voucherCurrencyRepository.findByCode("USD");

		if (null == voucherCurrency) {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
		}
		if ("AED".equalsIgnoreCase(currencyCode) || "USD".equalsIgnoreCase(currencyCode)) {
			if (100000 <= amount) {

				currencyLimitModel.setFINANCE_HOD_APPROVAL_REQUIRED(true);
				currencyLimitModel.setMD_APPROVAL_REQUIRED(true);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(currencyLimitModel).collect(Collectors.toList()));
			}
		}
		if (!("AED".equalsIgnoreCase(currencyCode) || "USD".equalsIgnoreCase(currencyCode))) {
			CurrencyRate sourceToAED = currencyRateRepository.getCurrencyRateByCurrencyIds(voucherCurrency.getId(),
					aedCurrency.getId());
			CurrencyRate sourceToUSD = currencyRateRepository.getCurrencyRateByCurrencyIds(voucherCurrency.getId(),
					usdCurrency.getId());
			if (100000 <= amount * Double.parseDouble(sourceToAED.getSpotRate().toString())
					|| 100000 <= amount * Double.parseDouble(sourceToUSD.getSpotRate().toString())) {

				currencyLimitModel.setFINANCE_HOD_APPROVAL_REQUIRED(true);
				currencyLimitModel.setMD_APPROVAL_REQUIRED(true);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(currencyLimitModel).collect(Collectors.toList()));
			}
		}

		currencyLimitModel.setFINANCE_HOD_APPROVAL_REQUIRED(true);
		currencyLimitModel.setMD_APPROVAL_REQUIRED(false);
		return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
				Stream.of(currencyLimitModel).collect(Collectors.toList()));

	}
}
