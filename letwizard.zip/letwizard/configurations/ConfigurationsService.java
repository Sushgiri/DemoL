package com.bestercapitalmedia.letwizard.configurations;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;

public interface ConfigurationsService {
	
	public abstract ResponseEntity getAllConfigurations();
	public abstract ResponseEntity getEMIConfigurations();
	public ResponseEntity getTransactionCurrencyLimit(String currencyCode, Double amount);
	
}
