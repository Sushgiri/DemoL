package com.bestercapitalmedia.letwizard.configurations;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
public class ConfigurationsController {
	
	@Autowired
	private ConfigurationsService configurationsService;
	
	@GetMapping("/getallconfigurations")
	@CrossOrigin(origins = "*")
	public ResponseEntity getAllConfigurations(HttpServletRequest httpServletRequest) {
		
		return configurationsService.getAllConfigurations();
		
	}
	
	@GetMapping("/emiconfig")
	@CrossOrigin(origins = "*")
	public ResponseEntity getEMIConfigurations(HttpServletRequest httpServletRequest) {
		
		return configurationsService.getEMIConfigurations();
		
	}
	
	@GetMapping("/currencyLimitCheck/{currencyCode}/{amount}")
	@CrossOrigin(origins = "*")
	public ResponseEntity getTransactionCurrencyLimit(@PathVariable(value = "currencyCode") String currencyCode,
			@PathVariable(value = "amount") Double amount, HttpServletRequest httpServletRequest) {

		return configurationsService.getTransactionCurrencyLimit(currencyCode, amount);

	}	
	

}
