package com.bestercapitalmedia.letwizard.evaluation;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonManagedReference;

import com.bestercapitalmedia.letwizard.attributelist.PropertyAttributesListDTO;
import com.bestercapitalmedia.letwizard.bank.Bank;
import com.bestercapitalmedia.letwizard.city.City;
import com.bestercapitalmedia.letwizard.propertyattributes.Propertyattributes;
import com.bestercapitalmedia.letwizard.seller.details.Propertysellerdetails;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "property_evaluation")
public class PropertyEvaluation implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	Integer evaluationId;
	
	@Column(name = "name")
	@Basic(fetch = FetchType.EAGER)
	String name;
	
	@Column(name = "email")
	@Basic(fetch = FetchType.EAGER)
	String email;
	
	@Column(name = "phone_no")
	@Basic(fetch = FetchType.EAGER)
	String phoneNo;
	
	@Column(name = "property_type")
	@Basic(fetch = FetchType.EAGER)
	String propertyType;
	
	@Column(name = "city_id")
	@Basic(fetch = FetchType.EAGER)
	Integer cityId;
	
	@Column(name = "property_status")
	@Basic(fetch = FetchType.EAGER)
	String propertyStatus;
	
	@Column(name = "no_of_bedrooms")
	@Basic(fetch = FetchType.EAGER)
	String noOfBedrooms;
	
	@Column(name = "no_of_bath")
	@Basic(fetch = FetchType.EAGER)
	String noOfBath;
	
	@Column(name = "size")
	@Basic(fetch = FetchType.EAGER)
	String size;
	
	@Column(name = "market_value")
	@Basic(fetch = FetchType.EAGER)
	String marketValue;
	
	@Column(name = "minimum_value")
	@Basic(fetch = FetchType.EAGER)
	String minimumValue;
	
	@Column(name = "maximum_value")
	@Basic(fetch = FetchType.EAGER)
	String maximumValue;
	
	@Column(name = "currency_id")
	@Basic(fetch = FetchType.EAGER)
	Integer currencyId;
	
	@Column(name = "present_use")
	@Basic(fetch = FetchType.EAGER)
	String presentUse;
	
	@Column(name = "building_name")
	@Basic(fetch = FetchType.EAGER)
	String buildingName;
	
	@Column(name = "size_unit")
	@Basic(fetch = FetchType.EAGER)
	String sizeUnit;
	
	@Column(name = "created_at")
	@Basic(fetch = FetchType.EAGER)
	Date createdAt;
	
	@Column(name = "updated_at")
	@Basic(fetch = FetchType.EAGER)
	Date updatedAt;
	
	public PropertyEvaluation() {
		
	}

	public Integer getEvaluationId() {
		return evaluationId;
	}

	public void setEvaluationId(Integer evaluationId) {
		this.evaluationId = evaluationId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getPropertyStatus() {
		return propertyStatus;
	}

	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}

	public String getNoOfBedrooms() {
		return noOfBedrooms;
	}

	public void setNoOfBedrooms(String noOfBedrooms) {
		this.noOfBedrooms = noOfBedrooms;
	}

	public String getNoOfBath() {
		return noOfBath;
	}

	public void setNoOfBath(String noOfBath) {
		this.noOfBath = noOfBath;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getMarketValue() {
		return marketValue;
	}

	public void setMarketValue(String marketValue) {
		this.marketValue = marketValue;
	}

	public String getMinimumValue() {
		return minimumValue;
	}

	public void setMinimumValue(String minimumValue) {
		this.minimumValue = minimumValue;
	}

	public String getMaximumValue() {
		return maximumValue;
	}

	public void setMaximumValue(String maximumValue) {
		this.maximumValue = maximumValue;
	}

	public Integer getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}
	
	public String getPresentUse() {
		return presentUse;
	}

	public void setPresentUse(String presentUse) {
		this.presentUse = presentUse;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getSizeUnit() {
		return sizeUnit;
	}

	public void setSizeUnit(String sizeUnit) {
		this.sizeUnit = sizeUnit;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

}
