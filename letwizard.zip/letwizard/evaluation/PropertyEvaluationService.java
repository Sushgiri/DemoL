package com.bestercapitalmedia.letwizard.evaluation;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bestercapitalmedia.letwizard.amenities.PropertyEvaluationAmenitiesService;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.attributelist.PropertyAttributesListDTO;
import com.bestercapitalmedia.letwizard.attributelist.PropertyAttributesListRepository;
import com.bestercapitalmedia.letwizard.constants.MortgageEligibilityMessages;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.systemevents.PropertyEstimationLeadEvent;
import com.bestercapitalmedia.letwizard.utill.DateUtils;

@Service
public class PropertyEvaluationService implements ApplicationEventPublisherAware {

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private PropertyEvaluationRepository propertyEvaluationRepository;

	@Autowired
	private PropertyEvaluationAmenitiesService propertyEvaluationAmenitiesService;

	@Autowired
	private PropertyAttributesListRepository attributesListRepository;

	@Autowired
	private ApplicationEventPublisher publisher;

	public @ResponseBody ResponseEntity createPropertyEvaluation(PropertyEvaluationDTO propertyEvaluationRequestDto) {
		try {

			ModelMapper mapper = new ModelMapper();

			List<PropertyAttributesListDTO> amenitiesList = attributesListRepository
					.findByAmenitiesIds(propertyEvaluationRequestDto.getAmenitiesList()).stream()
					.map(s -> mapper.map(s, PropertyAttributesListDTO.class)).collect(Collectors.toList());

			propertyEvaluationRequestDto.setAmenities(amenitiesList);

			PropertyEvaluation addPropertyEvaluation = mapper.map(propertyEvaluationRequestDto,
					PropertyEvaluation.class);

			addPropertyEvaluation.setMarketValue(propertyEvaluationRequestDto.getMedianEstimation());
			addPropertyEvaluation.setMaximumValue(propertyEvaluationRequestDto.getMaxEstimation());
			addPropertyEvaluation.setMinimumValue(propertyEvaluationRequestDto.getMinEstimation());

			addPropertyEvaluation.setCurrencyId(2);

			addPropertyEvaluation.setCreatedAt(DateUtils.getDefault().getNowTime());
			addPropertyEvaluation.setUpdatedAt(DateUtils.getDefault().getNowTime());

			PropertyEvaluation savedEvaluation = propertyEvaluationRepository.save(addPropertyEvaluation);

			propertyEvaluationRequestDto.setPropertyEvaluationId(savedEvaluation.getEvaluationId());
			propertyEvaluationAmenitiesService.saveAll(propertyEvaluationRequestDto);

			// event listener to call create estimation lead API
			publisher.publishEvent(new PropertyEstimationLeadEvent(this, propertyEvaluationRequestDto));

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, MortgageEligibilityMessages.SAVED_SUCCESS, null);
		}

		catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;

	}
}
