package com.bestercapitalmedia.letwizard.evaluation;

import java.util.List;

import com.bestercapitalmedia.letwizard.attributelist.PropertyAttributesListDTO;

public class PropertyEvaluationDTO {
	
	private String name;
	private String email;
	private String phoneNo;
	private String propertyType;
	private Integer cityId;
	private String propertyStatus;
	private String noOfBedrooms;
	private String noOfBath;
	private String size;
	private String presentUse;
	private String buildingName;
	private String sizeUnit;
	private Integer propertyEvaluationId;
	List<PropertyAttributesListDTO> amenities;
	List<Integer> amenitiesList;
	private String minEstimation;
	private String maxEstimation;
	private String medianEstimation;
	
	public PropertyEvaluationDTO() {
		// super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getPropertyStatus() {
		return propertyStatus;
	}

	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}

	public String getNoOfBedrooms() {
		return noOfBedrooms;
	}

	public void setNoOfBedrooms(String noOfBedrooms) {
		this.noOfBedrooms = noOfBedrooms;
	}

	public String getNoOfBath() {
		return noOfBath;
	}

	public void setNoOfBath(String noOfBath) {
		this.noOfBath = noOfBath;
	}

	public String getSize() {
		return size;
	}

	public String getPresentUse() {
		return presentUse;
	}

	public void setPresentUse(String presentUse) {
		this.presentUse = presentUse;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getSizeUnit() {
		return sizeUnit;
	}

	public void setSizeUnit(String sizeUnit) {
		this.sizeUnit = sizeUnit;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Integer getPropertyEvaluationId() {
		return propertyEvaluationId;
	}

	public void setPropertyEvaluationId(Integer propertyEvaluationId) {
		this.propertyEvaluationId = propertyEvaluationId;
	}

	public List<PropertyAttributesListDTO> getAmenities() {
		return amenities;
	}

	public void setAmenities(List<PropertyAttributesListDTO> amenities) {
		this.amenities = amenities;
	}

	public List<Integer> getAmenitiesList() {
		return amenitiesList;
	}

	public void setAmenitiesList(List<Integer> amenitiesList) {
		this.amenitiesList = amenitiesList;
	}

	public String getMinEstimation() {
		return minEstimation;
	}

	public void setMinEstimation(String minEstimation) {
		this.minEstimation = minEstimation;
	}

	public String getMaxEstimation() {
		return maxEstimation;
	}

	public void setMaxEstimation(String maxEstimation) {
		this.maxEstimation = maxEstimation;
	}

	public String getMedianEstimation() {
		return medianEstimation;
	}

	public void setMedianEstimation(String medianEstimation) {
		this.medianEstimation = medianEstimation;
	}

	

}
