package com.bestercapitalmedia.letwizard.evaluation;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.attributelist.Propertyattributeslist;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;

public interface PropertyEvaluationRepository extends CrudRepository<PropertyEvaluation,Integer>{
	
	@Query(value = "select * from property_evaluation where id=?1  ", nativeQuery = true)
	public PropertyEvaluation findByEvaluationId(int evaluationId);

}
