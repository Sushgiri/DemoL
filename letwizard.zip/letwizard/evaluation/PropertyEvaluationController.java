package com.bestercapitalmedia.letwizard.evaluation;

import java.net.InetAddress;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.vouchers.PaytabModel;
import com.bestercapitalmedia.letwizard.vouchers.VoucherService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/property/evaluation")
public class PropertyEvaluationController {

	@Autowired
	private PropertyEvaluationService propertyEvaluationService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity savePropertyEvaluation(@RequestBody PropertyEvaluationDTO propertyEvaluationDTO, HttpServletRequest httpServletRequest) {

		return propertyEvaluationService.createPropertyEvaluation(propertyEvaluationDTO);
	}
	
}
