package com.bestercapitalmedia.letwizard.bank;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;



public interface BankRepository extends CrudRepository<Bank,Integer>{
	
	@Query(value = "Select * from bank WHERE is_active = 1 ORDER BY bank_Name", nativeQuery = true)
	public List<Bank> getAllBanks();
	
	@Query(value = "Select * FROM bank WHERE bank_Name = :bankName", nativeQuery = true)
	public Bank isBankExist(@Param("bankName") String bankName);

}
