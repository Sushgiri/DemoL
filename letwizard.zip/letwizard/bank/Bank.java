package com.bestercapitalmedia.letwizard.bank;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "bank")
public class Bank implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Column(name = "bank_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer bankId;
	
	@Column(name = "bank_Name", length = 255)
	@Basic(fetch = FetchType.EAGER)
	String bankName;
	@Column(name = "is_active")
	@Basic(fetch = FetchType.EAGER)
	Integer isActive;
	
	@Column(name = "is_for_mortgage")
	@Basic(fetch = FetchType.EAGER)
	Integer isForMortgage;
	
	public Bank() {
		
	}



	public Integer getBankId() {
		return bankId;
	}



	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}



	public String getBankName() {
		return bankName;
	}



	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Integer getIsActive() {
		return isActive;
	}



	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}



	public Integer getIsForMortgage() {
		return isForMortgage;
	}



	public void setIsForMortgage(Integer isForMortgage) {
		this.isForMortgage = isForMortgage;
	}
	
	


	
	
}
