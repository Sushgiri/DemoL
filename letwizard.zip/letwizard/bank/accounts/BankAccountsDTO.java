package com.bestercapitalmedia.letwizard.bank.accounts;

public class BankAccountsDTO {
	
	private Integer id;
	private String accountName;
	private String currency;
	private String bank;
	private String accountNumber;
	private String branchName;
	private String iban;
	private String swiftcode;
	private String correspondantBank;
	private String correspondantSwiftcode;
	
	public BankAccountsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public String getSwiftcode() {
		return swiftcode;
	}

	public void setSwiftcode(String swiftcode) {
		this.swiftcode = swiftcode;
	}

	public String getCorrespondantBank() {
		return correspondantBank;
	}

	public void setCorrespondantBank(String correspondantBank) {
		this.correspondantBank = correspondantBank;
	}

	public String getCorrespondantSwiftcode() {
		return correspondantSwiftcode;
	}

	public void setCorrespondantSwiftcode(String correspondantSwiftcode) {
		this.correspondantSwiftcode = correspondantSwiftcode;
	}
	
}
