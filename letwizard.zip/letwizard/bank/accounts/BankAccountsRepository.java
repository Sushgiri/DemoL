package com.bestercapitalmedia.letwizard.bank.accounts;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.transaction.TransactionStatus;

public interface BankAccountsRepository extends CrudRepository<BankAccounts, Integer> {
	
	@Query(value = "select * from bank_accounts", nativeQuery = true)
	public List<BankAccounts> getAllBanks();
	
	@Query(value = "select * from bank_accounts where id=?1 ", nativeQuery = true)
	public BankAccounts getBankById(int bankId);
	
	@Query(value = "SELECT * FROM bank_accounts WHERE is_active =1 AND (is_mashreq IS NULL OR is_mashreq = 0 ) AND currency= ?1 LIMIT 1", nativeQuery = true)
	public BankAccounts getChiraghBankByCurrency(String currency);
	
}
