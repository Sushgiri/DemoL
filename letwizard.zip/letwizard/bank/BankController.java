package com.bestercapitalmedia.letwizard.bank;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.LogUtill;


@RestController
@CrossOrigin
@RequestMapping("/api/bank")
public class BankController {


	private static final Logger log = LoggerFactory.getLogger(BankController.class);
	@Autowired
	ChiragUtill chiraghUtill;
	@Autowired
	private LogUtill logUtill;
	@Autowired
	private ChiragUtill chiraghUtil;
	@Autowired
	private ResponseUtill responseUtill;
	@Autowired
	private BankRepository bankRepository;





	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getBank", method = RequestMethod.GET)
	@Cacheable("banks")
	public @ResponseBody ResponseEntity GetBank(HttpServletRequest httpServletRequest) {

		try {

			List<Bank> bank = bankRepository.getAllBanks();

			if (bank == null) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.BANK_ADDED, null);
			}

			else  {

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.BANK_SUCCESS,bank);
			}

		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}



	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/postBank/{bankName}", method = RequestMethod.POST)
	@CachePut(value = "banks", key = "#bank.bankId")
	public @ResponseBody ResponseEntity AddBank(@PathVariable(value = "bankName") String bankName , HttpServletRequest httpServletRequest) {

		try {

			log.info("bank name ="+bankName);


			Bank bank1 = bankRepository.isBankExist(bankName);
			//System.out.println("bank id="+bank1.getBankId());
			if(bank1 == null) {
				Bank addbank = new Bank();
				addbank.setBankName(bankName);
				Bank newbank =bankRepository.save(addbank);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.BANK_ADDED,null);
			}

			else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.BANK_EXISTED,Stream.of(bank1).collect(Collectors.toList()));
			}
		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}


}
