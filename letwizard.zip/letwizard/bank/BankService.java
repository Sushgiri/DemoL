package com.bestercapitalmedia.letwizard.bank;

public class BankService {

}
