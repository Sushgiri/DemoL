package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class UserPropertySeenService.
 */
public class UserPropertySeenService {

}
