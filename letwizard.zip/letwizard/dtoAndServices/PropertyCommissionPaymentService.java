package com.bestercapitalmedia.letwizard.dtoAndServices;

import org.springframework.stereotype.Service;

/**
 * The Class PropertyCommissionPaymentService.
 */
@Service
public class PropertyCommissionPaymentService {

}
