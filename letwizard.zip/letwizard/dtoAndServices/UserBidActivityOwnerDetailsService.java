package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class UserBidActivityOwnerDetailsService.
 */
public class UserBidActivityOwnerDetailsService {

}
