package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class BuyerAllListService.
 */
public class BuyerAllListService {
	
	

}
