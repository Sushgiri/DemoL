package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class PropertySecurityDepositService.
 */
public class PropertySecurityDepositService {

}
