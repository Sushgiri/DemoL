package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class AuctionFeesDetailsService.
 */
public class AuctionFeesDetailsService {

}
