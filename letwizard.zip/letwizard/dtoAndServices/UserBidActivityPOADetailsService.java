package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class UserBidActivityPOADetailsService.
 */
public class UserBidActivityPOADetailsService {

}
