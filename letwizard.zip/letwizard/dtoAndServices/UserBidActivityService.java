package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class UserBidActivityService.
 */
public class UserBidActivityService {

}
