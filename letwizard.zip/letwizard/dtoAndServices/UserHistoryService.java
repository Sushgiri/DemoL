package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class UserHistoryService.
 */
public class UserHistoryService {

}
