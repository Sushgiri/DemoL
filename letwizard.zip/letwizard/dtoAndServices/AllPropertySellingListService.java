package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class AllPropertySellingListService.
 */
public class AllPropertySellingListService {

}
