package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class BuyerCommissionDepositService.
 */
public class BuyerCommissionDepositService {

}
