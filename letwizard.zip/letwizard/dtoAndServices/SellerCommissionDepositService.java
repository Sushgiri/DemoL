package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class SellerCommissionDepositService.
 */
public class SellerCommissionDepositService {

}
