package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class HomePageCurrentAuctionsService.
 */
public class HomePageCurrentAuctionsService {

}
