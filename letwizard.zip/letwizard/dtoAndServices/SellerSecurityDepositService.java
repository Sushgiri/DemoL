package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class SellerSecurityDepositService.
 */
public class SellerSecurityDepositService {

}
