package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class UserWatchListService.
 */
public class UserWatchListService {

}
