package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class BuyerSecurityDepositService.
 */
public class BuyerSecurityDepositService {

}
