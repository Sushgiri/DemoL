package com.bestercapitalmedia.letwizard.dtoAndServices;

/**
 * The Class PropertyBuyerUpComingAuctionService.
 */
public class PropertyBuyerUpComingAuctionService {

}
