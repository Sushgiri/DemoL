package com.bestercapitalmedia.letwizard.leads;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.mortgage.PropertyMortgageDetails;
import com.bestercapitalmedia.letwizard.property.mortgage.PropertyMortgageDetailsDTO;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.LogUtill;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service

public class LeadsService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ChiragUtill chiraghUtil;

	@Autowired
	private LogUtill logUtill;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private LeadsRepository leadsRepository;

	public ResponseEntity getNewLeads(int userId) {
		try {
			ModelMapper mapper = new ModelMapper();

			Chiraghuser chiraghuser = userRepository.findByUserId(userId);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			List<Leads> leads = leadsRepository.findByDepartementId(chiraghuser.getDepartements().getDepartementsId());

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS, leads);

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}

}
