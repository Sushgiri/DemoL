package com.bestercapitalmedia.letwizard.leads;

public class LeadUtils {
	
	public class LeadProcess{
		public static final String APPROVAL="approval";
		public static final String REQUEST_FOR_CHANGE="request for change";
		public static final String REQUEST_FOR_ARCHIVE="request for archive";
		public static final String REQUEST_FOR_CHANGE_DONE="change request done";
		public static final String REVIEW="review";
	}
	
	
	public class LeadStatus{
		public static final String DONE="done";
		public static final String IN_PROCESS="in process";
		public static final String NOT_STARTED="not started";
		public static final String REJECT="reject";
		public static final String ARCHIVE="archive";
		public static final String REQUEST_FOR_CHANGE="request for change";
	}
	
	public class Department{
		public static final int VERIFICATION = 1;
		public static final int VALUATION = 2;
		public static final int BROKERAGE = 3;
		public static final int FINANCE = 4;
		public static final int LISTING = 5;
		public static final int SUPER_ADMIN = 6;
		public static final int THIRD_PARTY_VALUATION = 7;
	}

	public class KycStatus {
		public static final String PENDING = "pending";
		public static final String APPROVE= "approve";
		public static final String CANCELLED = "cancelled";
	}
	public class OverDraftStatus {
		public static final String OVERDRAFT_STATUS_APPROVE = "approve";
		public static final String OVERDRAFT_STATUS_TERMINATED = "settled";
		public static final String OVERDRAFT_STATUS_CANCELLED = "cancelled";

		public static final String MD_APPROVAL = "approved";

	}
}
