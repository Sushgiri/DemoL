package com.bestercapitalmedia.letwizard.leads;

import java.util.Date;

import com.bestercapitalmedia.letwizard.property.PropertyBaseDTO;
import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;
import com.fasterxml.jackson.annotation.JsonProperty;

public class LeadDTO {

	private Integer id;
	@JsonProperty("property")
	private PropertyBaseDTO chiraghproperty;
	private ChiraghUserDTO assignedTo;
	private ChiraghUserDTO assignedBy;
	private Date assignedAt;
//	private ChangeRequestDTO changeRequest;
	private Integer departementId;
	private String status;
	private Date createdAt;
	private Date updatedAt;
	private String remarks;
	private Integer archive_by;
	private Integer forwardBy;
	private String process;
	private Date receivedAtDepartment;
	private Integer voucherId;
//	private AppointmentResponseDTO appointment;
//	private AppointmentResponseDTO brokerageAppointment;
//	private AppointmentResponseDTO registrationAppointment;
	
	public LeadDTO() {
	}


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	public ChiraghUserDTO getAssignedTo() {
		return assignedTo;
	}


	public void setAssignedTo(ChiraghUserDTO assignedTo) {
		this.assignedTo = assignedTo;
	}


	public ChiraghUserDTO getAssignedBy() {
		return assignedBy;
	}


	public void setAssignedBy(ChiraghUserDTO assignedBy) {
		this.assignedBy = assignedBy;
	}


	public Date getAssignedAt() {
		return assignedAt;
	}


	public void setAssignedAt(Date assignedAt) {
		this.assignedAt = assignedAt;
	}


	public Integer getDepartementId() {
		return departementId;
	}


	public void setDepartementId(Integer departementId) {
		this.departementId = departementId;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Date getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public Integer getArchive_by() {
		return archive_by;
	}


	public void setArchive_by(Integer archive_by) {
		this.archive_by = archive_by;
	}


	public PropertyBaseDTO getChiraghproperty() {
		return chiraghproperty;
	}


	public void setChiraghproperty(PropertyBaseDTO chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}


	public String getProcess() {
		return process;
	}


	public void setProcess(String process) {
		this.process = process;
	}


	public Date getUpdatedAt() {
		return updatedAt;
	}


	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}


	public Integer getForwardBy() {
		return forwardBy;
	}


	public void setForwardBy(Integer forwardBy) {
		this.forwardBy = forwardBy;
	}


	public Date getReceivedAtDepartment() {
		return receivedAtDepartment;
	}


	public void setReceivedAtDepartment(Date receivedAtDepartment) {
		this.receivedAtDepartment = receivedAtDepartment;
	}


	public Integer getVoucherId() {
		return voucherId;
	}


	public void setVoucherId(Integer voucherId) {
		this.voucherId = voucherId;
	}

	
}
