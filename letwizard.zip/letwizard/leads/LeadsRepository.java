package com.bestercapitalmedia.letwizard.leads;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.property.rentaldetails.PropertyRentalDetails;

public interface LeadsRepository extends CrudRepository<Leads, Integer> {
	
	@Query(value = "select * from leads where property_id=?1  ", nativeQuery = true)
	public Leads findByPropertyId(int propertyId);
	
	@Query(value = "select * from leads where departement_id=?1  ", nativeQuery = true)
	public List<Leads> findByDepartementId(int departementId);
	
	@Query(value = "select * from leads where property_id=?1  ", nativeQuery = true)
	public List<Leads> findLeadsByPropertyId(int propertyId);
	
	@Query(value = "SELECT * FROM leads WHERE property_id = ?1 AND departement_id = 3 AND (STATUS = 'in process') AND assigned_to IS NOT NULL ORDER BY created_at DESC LIMIT 1", nativeQuery = true)
	public Leads getBrokerageLeadToStart(int propertyId);
	
	@Query(value = "SELECT * FROM leads WHERE property_id = ?1 AND departement_id = 3 AND (STATUS = 'done' OR STATUS = 'not started') AND assigned_to IS NOT NULL ORDER BY created_at DESC LIMIT 1", nativeQuery = true)
	public Leads getBrokerageLeadForHOD(int propertyId);

	@Query(value = "SELECT * FROM leads WHERE property_id = ?1 AND departement_id =?2 AND PROCESS = 'approval' AND STATUS = 'in process' LIMIT 1", nativeQuery = true)
	public Leads findByPropertyIdAndDeptId(int propertyId , int deptId);

	@Query(value = "select * from leads where id=?1  ", nativeQuery = true)
	public Leads findByLeadId(int id);
}
