package com.bestercapitalmedia.letwizard.imageutill;

import org.imgscalr.Scalr;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.imgscalr.Scalr.*;

@Service
public class LetwizardImageUtill {


	/*
	public static File createThumbnail(MultipartFile file) {
		try {
			final BufferedImage image = convertToImage(file);
			// final BufferedImage thumb = pad(
			// resize(image, Method.SPEED, targetSize, OP_ANTIALIAS, OP_BRIGHTER), 2);
			BufferedImage thumbImg = Scalr.resize(image, Method.QUALITY, Mode.AUTOMATIC, 300, 200, Scalr.OP_ANTIALIAS);
			File outputfile = new File("image.jpg");
			ImageIO.write(thumbImg, "jpg", outputfile);
			return outputfile;
		} catch (IOException e) {
			return null;
		}

	}
	*/

	public static byte[] convert(MultipartFile file) throws IOException {
		validateFile(file);
		return file.getBytes();
	}

	public static String validateFile(MultipartFile file) {
		String contentType = file.getContentType();
		System.out.println("content type=" + contentType);
		if (!contentType.equals(MediaType.IMAGE_JPEG.toString())
				&& !contentType.equals(MediaType.IMAGE_PNG.toString())) {
			return "false";
		} else {
			return "true";
		}
	}

	private static BufferedImage convertToImage(MultipartFile file) {

		try {
			InputStream in = new ByteArrayInputStream(file.getBytes());
			return ImageIO.read(in);
		} catch (IOException e) {
			return null;

		}
	}

	private static byte[] convertToArray(BufferedImage image, String contentType) throws IOException {
		byte[] imageInByte;

		String typeName = "jpg";
		if (contentType.equals(MediaType.IMAGE_PNG))
			typeName = "png";

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(image, typeName, baos);
		baos.flush();
		imageInByte = baos.toByteArray();
		baos.close();

		return imageInByte;
	}

public static File createThumbnail(MultipartFile file) {
		
		try {
			File fileImg = convertMultiPartToFile(file);

			  BufferedImage img = new BufferedImage(300, 200, BufferedImage.TYPE_INT_RGB);
			  img.createGraphics().drawImage(ImageIO.read(fileImg).getScaledInstance(300, 200, Image.SCALE_SMOOTH),0,0,null);
			 //File outputFile=new File("image.jpg");
			  ImageIO.write(img, "jpg", fileImg);			  
			  return fileImg;
		}
		catch(Exception e) {
			System.out.println(e);
			return null;
		}

	}
	
	private static File convertMultiPartToFile(MultipartFile file) throws IOException {
		
		validateFile(file);
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}

}
