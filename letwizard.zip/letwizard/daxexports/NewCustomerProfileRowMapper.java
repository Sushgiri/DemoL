package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class NewCustomerProfileRowMapper implements RowMapper<NewCustomerProfileModel> {

	@Override
	public NewCustomerProfileModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		NewCustomerProfileModel model = new NewCustomerProfileModel();

		model.setAddress(rs.getString("Address"));
		model.setAddress_2(rs.getString("Address_2"));
		model.setAllow_Line_Disc(rs.getString("Allow_Line_Disc"));
		model.setApplication_Method(rs.getString("Application_Method"));
		model.setBalance_Due_LCY(rs.getString("Balance_Due_LCY"));
		model.setBalance_LCY(rs.getString("Balance_LCY"));
		model.setBase_Calendar_Code(rs.getString("Base_Calendar_Code"));
		model.setBill_to_Customer_No(rs.getString("Bill_to_Customer_No"));
		model.setBlock_Payment_Tolerance(rs.getString("Block_Payment_Tolerance"));
		model.setBlocked(rs.getString("Blocked"));
		model.setCash_Flow_Payment_Terms_Code(rs.getString("Cash_Flow_Payment_Terms_Code"));
		model.setCity(rs.getString("City"));
		model.setCombine_Shipments(rs.getString("Combine_Shipments"));
		model.setContactName(rs.getString("ContactName"));
		model.setCopy_Sell_to_Addr_to_Qte_From(rs.getString("Copy_Sell_to_Addr_to_Qte_From"));
		model.setCountry_Region_Code(rs.getString("Country_Region_Code"));
		model.setCountry(rs.getString("Country"));
		model.setCredit_Limit_LCY(rs.getString("Credit_Limit_LCY"));
		model.setCurrency_Code(rs.getString("Currency_Code"));
		model.setCustomer_Disc_Group(rs.getString("Customer_Disc_Group"));
		model.setCustomer_Posting_Group(rs.getString("Customer_Posting_Group"));
		model.setCustomer_Price_Group(rs.getString("Customer_Price_Group"));
		model.setDisable_Search_by_Name(rs.getString("Disable_Search_by_Name"));
		model.setDocument_Sending_Profile(rs.getString("Document_Sending_Profile"));
		model.setE_Mail(rs.getString("E_Mail"));
		model.setFax_No(rs.getString("Fax_No"));
		model.setFin_Charge_Terms_Code(rs.getString("Fin_Charge_Terms_Code"));
		model.setGen_Bus_Posting_Group(rs.getString("Gen_Bus_Posting_Group"));
		model.setGLN(rs.getString("GLN"));
		model.setHome_Page(rs.getString("Home_Page"));
		model.setIC_Partner_Code(rs.getString("IC_Partner_Code"));
		model.setInvoice_Copies(rs.getString("Invoice_Copies"));
		model.setInvoice_Disc_Code(rs.getString("Invoice_Disc_Code"));
		model.setLanguage_Code(rs.getString("Language_Code"));
		model.setLast_Date_Modified(rs.getString("Last_Date_Modified"));
		model.setLast_Statement_No(rs.getString("Last_Statement_No"));
		model.setLocation_Code(rs.getString("Location_Code"));
		model.setName(rs.getString("Name"));
		model.setName_2(rs.getString("Name_2"));
		model.setNo(rs.getString("No"));
		model.setPartner_Type(rs.getString("Partner_Type"));
		model.setPayment_Method_Code(rs.getString("Payment_Method_Code"));
		model.setPayment_Terms_Code(rs.getString("Payment_Terms_Code"));
		model.setPayments_LCY(rs.getString("Payments_LCY"));
		model.setPhone_No(rs.getString("Phone_No"));
		model.setPost_Code(rs.getString("Post_Code"));
		model.setPreferred_Bank_Account_Code(rs.getString("Preferred_Bank_Account_Code"));
		model.setPrepayment_Percent(rs.getString("Prepayment_Percent"));
		model.setPrice_Calculation_Method(rs.getString("Price_Calculation_Method"));
		model.setPrices_Including_VAT(rs.getString("Prices_Including_VAT"));
		model.setPrimary_Contact_No(rs.getString("Primary_Contact_No"));
		model.setPrint_Statements(rs.getString("Print_Statements"));
		model.setPrivacy_Blocked(rs.getString("Privacy_Blocked"));
		model.setReminder_Terms_Code(rs.getString("Reminder_Terms_Code"));
		model.setReserve(rs.getString("Reserve"));
		model.setResponsibility_Center(rs.getString("Responsibility_Center"));
		model.setSalesperson_Code(rs.getString("Salesperson_Code"));
		model.setSearch_Name(rs.getString("Search_Name"));
		model.setService_Zone_Code(rs.getString("Service_Zone_Code"));
		model.setShip_to_Code(rs.getString("Ship_to_Code"));
		model.setShipment_Method_Code(rs.getString("Shipment_Method_Code"));
		model.setShipping_Advice(rs.getString("Shipping_Advice"));
		model.setShipping_Agent_Code(rs.getString("Shipping_Agent_Code"));
		model.setShipping_Agent_Service_Code(rs.getString("Shipping_Agent_Service_Code"));
		model.setShipping_Time(rs.getString("Shipping_Time"));
		model.setTax_Area_Code(rs.getString("Tax_Area_Code"));
		model.setTax_Liable(rs.getString("Tax_Liable"));
		model.setUse_GLN_in_Electronic_Document(rs.getString("Use_GLN_in_Electronic_Document"));
		model.setVAT_Bus_Posting_Group(rs.getString("VAT_Bus_Posting_Group"));
		model.setVAT_Registration_No(rs.getString("VAT_Registration_No"));
		model.setMobilePhoneNo(rs.getString("MobilePhoneNo"));
		model.setEORI_Number(rs.getString("EORI_Number"));

		return model;

	}
}
