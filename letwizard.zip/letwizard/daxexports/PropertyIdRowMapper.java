package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class PropertyIdRowMapper implements RowMapper<PropertyIdModel> {

	@Override
	public PropertyIdModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		PropertyIdModel model = new PropertyIdModel();
		model.setCode(rs.getString("Code"));
		model.setDimension_Code(rs.getString("Dimension_Code"));
		model.setName(rs.getString("Name"));
		return model;

	}
}
