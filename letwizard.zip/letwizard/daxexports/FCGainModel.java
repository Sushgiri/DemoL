package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FCGainModel {

	private Date Posting_Date;
	private Date Document_Date;
	private String Document_Type;
	private String Document_No;
	private String Incoming_Document_Entry_No;
	private String External_Document_No;
	private String Applies_to_Ext_Doc_No;
	private String Account_Type;
	private String Account_No;
	private String Description;
	private String Payer_Information;
	private String Transaction_Information;
	private String Business_Unit_Code;
	private String Salespers_Purch_Code;
	private String Campaign_No;
	private String Currency_Code;
	private String EU_3_Party_Trade;
	private String Gen_Posting_Type;
	private String Gen_Bus_Posting_Group;
	private String Gen_Prod_Posting_Group;
	private String VAT_Bus_Posting_Group;
	private String VAT_Prod_Posting_Group;
	private String Quantity;
	private Double Amount;
	private String Amount_LCY;
	private String Debit_Amount;
	private String Credit_Amount;
	private String VAT_Amount;
	private String VAT_Difference;
	private String Bal_VAT_Amount;
	private String Bal_VAT_Difference;
	private String Bal_Account_Type;
	private String Bal_Account_No;
	private String Bal_Gen_Posting_Type;
	private String Bal_Gen_Bus_Posting_Group;
	private String Bal_Gen_Prod_Posting_Group;
	private String Deferral_Code;
	private String Job_Queue_Status;
	private String Bal_VAT_Bus_Posting_Group;
	private String Bal_VAT_Prod_Posting_Group;
	private String Bill_to_Pay_to_No;
	private String Ship_to_Order_Address_Code;
	private String Payment_Terms_Code;
	private String Applied_Automatically;
	private String Applies_to_Doc_Type;
	private String Applies_to_Doc_No;
	private String Applies_to_ID;
	private String On_Hold;
	private String Bank_Payment_Type;
	private String Reason_Code;
	private String Correction;
	private String Comment;
	private String Direct_Debit_Mandate_ID;
	private String Shortcut_Dimension_1_Code;
	private String Shortcut_Dimension_2_Code;
	private String Journal_Template_Name;
	private String Journal_Batch_Name;
	private String Line_No;

}
