package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class SalesJournalsRowMapper implements RowMapper<SalesJournalsModel> {

	@Override
	public SalesJournalsModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		SalesJournalsModel model = new SalesJournalsModel();

		model.setAccount_NO(rs.getString("Account_NO"));
		model.setAccount_Type(rs.getString("Account_Type"));
		model.setAmount(rs.getDouble("Amount"));
		model.setAmount_LCY(rs.getString("Amount_LCY"));
		model.setApplies_to_Doc_Type(rs.getString("Applies_to_Doc_Type"));
		model.setApplies_to_ID(rs.getString("Applies_to_ID"));
		model.setBal_Account_No(rs.getString("Bal_Account_No"));
		model.setBal_Account_Type(rs.getString("Bal_Account_Type"));
		model.setBal_Gen_Bus_Posting_Group(rs.getString("Bal_Gen_Bus_Posting_Group"));
		model.setBal_Gen_Posting_Type(rs.getString("Bal_Gen_Posting_Type"));
		model.setBal_Gen_Prod_Posting_Group(rs.getString("Bal_Gen_Prod_Posting_Group"));
		model.setBal_VAT_Amount(rs.getString("Bal_VAT_Amount"));
		model.setBal_VAT_Bus_Posting_Group(rs.getString("Bal_VAT_Bus_Posting_Group"));
		model.setBal_VAT_Difference(rs.getString("Bal_VAT_Difference"));
		model.setBal_VAT_Prod_Posting_Group(rs.getString("Bal_VAT_Prod_Posting_Group"));
		model.setCampaign_No(rs.getString("Campaign_No"));
		model.setCorrection(rs.getString("Correction"));
		model.setCredit_Amount(rs.getString("Credit_Amount"));
		model.setCurrency_Code(rs.getString("Currency_Code"));
		model.setDebit_Amount(rs.getString("Debit_Amount"));
		model.setDescription(rs.getString("Description"));
		model.setDocument_Date(rs.getDate("Document_Date"));
		model.setDocument_No(rs.getString("Document_No"));
		model.setDocument_Type(rs.getString("Document_Type"));
		model.setExternal_Document_No(rs.getString("External_Document_No"));
		model.setGen_Bus_Posting_Group(rs.getString("Gen_Bus_Posting_Group"));
		model.setGen_Posting_Type(rs.getString("Gen_Posting_Type"));
		model.setGen_Prod_Posting_Group(rs.getString("Gen_Prod_Posting_Group"));
		model.setIncoming_Document_Entry_No(rs.getString("Incoming_Document_Entry_No"));
		model.setJob_Queue_Status(rs.getString("Job_Queue_Status"));
		model.setJournal_Batch_Name(rs.getString("Journal_Batch_Name"));
		model.setJournal_Template_Name(rs.getString("Journal_Template_Name"));
		model.setLine_No(rs.getString("Line_No"));
		model.setPosting_Date(rs.getDate("Posting_Date"));
		model.setReason_Code(rs.getString("Reason_Code"));
		model.setSalespers_Purch_Code(rs.getString("Salespers_Purch_Code"));
		model.setShortcut_Dimension_1_Code(rs.getString("Shortcut_Dimension_1_Code"));
		model.setShortcut_Dimension_2_Code(rs.getString("Shortcut_Dimension_2_Code"));
		model.setVAT_Amount(rs.getString("VAT_Amount"));
		model.setVAT_Bus_Posting_Group(rs.getString("VAT_Bus_Posting_Group"));
		model.setVAT_Difference(rs.getString("VAT_Difference"));
		model.setVAT_Prod_Posting_Group(rs.getString("VAT_Prod_Posting_Group"));
		model.setTax_Liable(rs.getString("Tax_Liable"));
		model.setTax_Area_Code(rs.getString("Tax_Area_Code"));
		model.setTax_Group_Code(rs.getString("Tax_Group_Code"));
		model.setBill_to_Pay_to_No(rs.getString("Bill_to_Pay_to_No"));
		model.setShip_to_Order_Address_Code(rs.getString("Ship_to_Order_Address_Code"));
		model.setSales_Purch_LCY(rs.getString("Sales_Purch_LCY"));
		model.setProfit_LCY(rs.getString("Profit_LCY"));
		model.setInv_Discount_LCY(rs.getString("Inv_Discount_LCY"));
		model.setPayment_Terms_Code(rs.getString("Payment_Terms_Code"));
		model.setDue_Date(rs.getString("Due_Date"));
		model.setPmt_Discount_Date(rs.getString("Pmt_Discount_Date"));
		model.setPayment_Discount_Percent(rs.getString("Payment_Discount_Percent"));
		model.setApplies_to_Doc_No(rs.getString("Applies_to_Doc_No"));
		model.setOn_Hold(rs.getString("On_Hold"));
		model.setComment(rs.getString("Comment"));
		model.setDirect_Debit_Mandate_ID(rs.getString("Direct_Debit_Mandate_ID"));

		return model;

	}
}
