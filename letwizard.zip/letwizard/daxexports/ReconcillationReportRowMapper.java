package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class ReconcillationReportRowMapper implements RowMapper<ReconcillationReportModel> {

	@Override
	public ReconcillationReportModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		ReconcillationReportModel model = new ReconcillationReportModel();
		model.setAccount_NO(rs.getString("Account_NO"));
		model.setAccount_Type(rs.getString("Account_Type"));
		model.setAmount(rs.getDouble("Amount"));
		model.setCurrency_Code(rs.getString("Currency_Code"));
		model.setDescription(rs.getString("Description"));
		model.setDocument_Date(rs.getDate("Document_Date"));
		model.setDocument_Type(rs.getString("Document_Type"));
		model.setExternal_Document_No(rs.getString("External_Document_No"));
		model.setPayment_Method_Code(rs.getString("Payment_Method_Code"));
		model.setPosting_Date(rs.getDate("Posting_Date"));
		model.setProcessed_Date(rs.getDate("Processed_Date"));
		model.setRecipient_Bank_Account(rs.getString("Recipient_Bank_Account"));
		model.setShortcut_Dimension_1_Code(rs.getString("Shortcut_Dimension_1_Code"));
		model.setStatus(rs.getString("Status"));
		model.setTransaction_Type(rs.getString("Transaction_Type"));

		return model;

	}
}
