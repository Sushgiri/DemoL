package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class CommonModelRowMapper implements RowMapper<CommonModel> {

	@Override
	public CommonModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		CommonModel commonModel = new CommonModel();

		commonModel.setAccount_NO(rs.getString("Account_NO"));
		commonModel.setAccount_Type(rs.getString("Account_Type"));
		commonModel.setAmount(rs.getDouble("Amount"));
		commonModel.setAmount_LCY(rs.getString("Amount_LCY"));
		commonModel.setApplies_to_Doc_Type(rs.getString("Applies_to_Doc_Type"));
		commonModel.setApplies_to_Ext_Doc_No(rs.getString("Applies_to_Ext_Doc_No"));
		commonModel.setApplies_to_ID(rs.getString("Applies_to_ID"));
		commonModel.setAppliesToDocNo(rs.getString("AppliesToDocNo"));
		commonModel.setBal_Account_No(rs.getString("Bal_Account_No"));
		commonModel.setBal_Account_Type(rs.getString("Bal_Account_Type"));
		commonModel.setBal_Gen_Bus_Posting_Group(rs.getString("Bal_Gen_Bus_Posting_Group"));
		commonModel.setBal_Gen_Posting_Type(rs.getString("Bal_Gen_Posting_Type"));
		commonModel.setBal_Gen_Prod_Posting_Group(rs.getString("Bal_Gen_Prod_Posting_Group"));
		commonModel.setBal_VAT_Amount(rs.getString("Bal_VAT_Amount"));
		commonModel.setBal_VAT_Bus_Posting_Group(rs.getString("Bal_VAT_Bus_Posting_Group"));
		commonModel.setBal_VAT_Difference(rs.getString("Bal_VAT_Difference"));
		commonModel.setBal_VAT_Prod_Posting_Group(rs.getString("Bal_VAT_Prod_Posting_Group"));
		commonModel.setBank_Payment_Type(rs.getString("Bank_Payment_Type"));
		commonModel.setCampaign_No(rs.getString("Campaign_No"));
		commonModel.setCheck_Printed(rs.getString("Check_Printed"));
		commonModel.setCommentField(rs.getString("CommentField"));
		commonModel.setCorrection(rs.getString("Correction"));
		commonModel.setCredit_Amount(rs.getString("Credit_Amount"));
		commonModel.setCreditor_No(rs.getString("Creditor_No"));
		commonModel.setCurrency_Code(rs.getString("Currency_Code"));
		commonModel.setDebit_Amount(rs.getString("Debit_Amount"));
		commonModel.setDescription(rs.getString("Description"));
		commonModel.setDocument_Date(rs.getDate("Document_Date"));
		commonModel.setDocument_No(rs.getString("Document_No"));
		commonModel.setDocument_Type(rs.getString("Document_Type"));
		commonModel.setExported_to_Payment_File(rs.getString("Exported_to_Payment_File"));
		commonModel.setExternal_Document_No(rs.getString("External_Document_No"));
		commonModel.setGen_Bus_Posting_Group(rs.getString("Gen_Bus_Posting_Group"));
		commonModel.setGen_Posting_Type(rs.getString("Gen_Posting_Type"));
		commonModel.setGen_Prod_Posting_Group(rs.getString("Gen_Prod_Posting_Group"));
		commonModel.setHas_Payment_Export_Error(rs.getString("Has_Payment_Export_Error"));
		commonModel.setIncoming_Document_Entry_No(rs.getString("Incoming_Document_Entry_No"));
		commonModel.setJob_Queue_Status(rs.getString("Job_Queue_Status"));
		commonModel.setJournal_Batch_Name(rs.getString("Journal_Batch_Name"));
		commonModel.setJournal_Template_Name(rs.getString("Journal_Template_Name"));
		commonModel.setLine_No(rs.getString("Line_No"));
		commonModel.setMessage_to_Recipient(rs.getString("Message_to_Recipient"));
		commonModel.setPayment_Method_Code(rs.getString("Payment_Method_Code"));
		commonModel.setPayment_Reference(rs.getString("Payment_Reference"));
		commonModel.setPosting_Date(rs.getDate("Posting_Date"));
		commonModel.setReason_Code(rs.getString("Reason_Code"));
		commonModel.setRecipient_Bank_Account(rs.getString("Recipient_Bank_Account"));
		commonModel.setSalespers_Purch_Code(rs.getString("Salespers_Purch_Code"));
		commonModel.setShortcut_Dimension_1_Code(rs.getString("Shortcut_Dimension_1_Code"));
		commonModel.setShortcut_Dimension_2_Code(rs.getString("Shortcut_Dimension_2_Code"));
		commonModel.setVAT_Amount(rs.getString("VAT_Amount"));
		commonModel.setVAT_Bus_Posting_Group(rs.getString("VAT_Bus_Posting_Group"));
		commonModel.setVAT_Difference(rs.getString("VAT_Difference"));
		commonModel.setVAT_Prod_Posting_Group(rs.getString("VAT_Prod_Posting_Group"));

		return commonModel;

	}
}
