package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.Date;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CommonModel {

	private Date Posting_Date;
	private Date Document_Date;
	private String Document_Type;
	private String Document_No;
	private String Incoming_Document_Entry_No;
	private String External_Document_No;
	private String Applies_to_Ext_Doc_No;
	private String Account_Type;
	private String Account_NO;
	private String Recipient_Bank_Account;
	private String Message_to_Recipient;
	private String Description;
	private String Salespers_Purch_Code;
	private String Campaign_No;
	private String Currency_Code;
	private String Gen_Posting_Type;
	private String Gen_Bus_Posting_Group;
	private String Gen_Prod_Posting_Group;
	private String VAT_Bus_Posting_Group;
	private String VAT_Prod_Posting_Group;
	private String Payment_Method_Code;
	private String Payment_Reference;
	private String Creditor_No;
	private Double Amount;
	private String Amount_LCY;
	private String Debit_Amount;
	private String Credit_Amount;
	private String VAT_Amount;
	private String VAT_Difference;
	private String Bal_VAT_Amount;
	private String Bal_VAT_Difference;
	private String Bal_Account_Type;
	private String Bal_Account_No;
	private String Bal_Gen_Posting_Type;
	private String Bal_Gen_Bus_Posting_Group;
	private String Bal_Gen_Prod_Posting_Group;
	private String Bal_VAT_Bus_Posting_Group;
	private String Bal_VAT_Prod_Posting_Group;
	private String Applies_to_Doc_Type;
	private String AppliesToDocNo;
	private String Applies_to_ID;
	private String Bank_Payment_Type;
	private String Check_Printed;
	private String Reason_Code;
	private String Correction;
	private String CommentField;
	private String Exported_to_Payment_File;
	private String Has_Payment_Export_Error;
	private String Job_Queue_Status;
	private String Shortcut_Dimension_1_Code;
	private String Shortcut_Dimension_2_Code;
	private String Journal_Template_Name;
	private String Journal_Batch_Name;
	private String Line_No;

}
