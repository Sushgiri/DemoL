package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class FCGainRowMapper implements RowMapper<FCGainModel> {

	@Override
	public FCGainModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		FCGainModel fcgainModel = new FCGainModel();

		fcgainModel.setAccount_Type(rs.getString("Account_Type"));
		fcgainModel.setAmount(rs.getDouble("Amount"));
		fcgainModel.setAmount_LCY(rs.getString("Amount_LCY"));
		fcgainModel.setApplies_to_Doc_Type(rs.getString("Applies_to_Doc_Type"));
		fcgainModel.setApplies_to_Ext_Doc_No(rs.getString("Applies_to_Ext_Doc_No"));
		fcgainModel.setApplies_to_ID(rs.getString("Applies_to_ID"));
		fcgainModel.setBal_Account_No(rs.getString("Bal_Account_No"));
		fcgainModel.setBal_Account_Type(rs.getString("Bal_Account_Type"));
		fcgainModel.setBal_Gen_Bus_Posting_Group(rs.getString("Bal_Gen_Bus_Posting_Group"));
		fcgainModel.setBal_Gen_Posting_Type(rs.getString("Bal_Gen_Posting_Type"));
		fcgainModel.setBal_Gen_Prod_Posting_Group(rs.getString("Bal_Gen_Prod_Posting_Group"));
		fcgainModel.setBal_VAT_Amount(rs.getString("Bal_VAT_Amount"));
		fcgainModel.setBal_VAT_Bus_Posting_Group(rs.getString("Bal_VAT_Bus_Posting_Group"));
		fcgainModel.setBal_VAT_Difference(rs.getString("Bal_VAT_Difference"));
		fcgainModel.setBal_VAT_Prod_Posting_Group(rs.getString("Bal_VAT_Prod_Posting_Group"));
		fcgainModel.setBank_Payment_Type(rs.getString("Bank_Payment_Type"));
		fcgainModel.setCampaign_No(rs.getString("Campaign_No"));
		fcgainModel.setCorrection(rs.getString("Correction"));
		fcgainModel.setCredit_Amount(rs.getString("Credit_Amount"));
		fcgainModel.setCurrency_Code(rs.getString("Currency_Code"));
		fcgainModel.setDebit_Amount(rs.getString("Debit_Amount"));
		fcgainModel.setDescription(rs.getString("Description"));
		fcgainModel.setDocument_Date(rs.getDate("Document_Date"));
		fcgainModel.setDocument_No(rs.getString("Document_No"));
		fcgainModel.setDocument_Type(rs.getString("Document_Type"));
		fcgainModel.setExternal_Document_No(rs.getString("External_Document_No"));
		fcgainModel.setGen_Bus_Posting_Group(rs.getString("Gen_Bus_Posting_Group"));
		fcgainModel.setGen_Posting_Type(rs.getString("Gen_Posting_Type"));
		fcgainModel.setGen_Prod_Posting_Group(rs.getString("Gen_Prod_Posting_Group"));
		fcgainModel.setIncoming_Document_Entry_No(rs.getString("Incoming_Document_Entry_No"));
		fcgainModel.setJournal_Batch_Name(rs.getString("Journal_Batch_Name"));
		fcgainModel.setJournal_Template_Name(rs.getString("Journal_Template_Name"));
		fcgainModel.setLine_No(rs.getString("Line_No"));
		fcgainModel.setPosting_Date(rs.getDate("Posting_Date"));
		fcgainModel.setReason_Code(rs.getString("Reason_Code"));
		fcgainModel.setSalespers_Purch_Code(rs.getString("Salespers_Purch_Code"));
		fcgainModel.setShortcut_Dimension_1_Code(rs.getString("Shortcut_Dimension_1_Code"));
		fcgainModel.setShortcut_Dimension_2_Code(rs.getString("Shortcut_Dimension_2_Code"));
		fcgainModel.setVAT_Amount(rs.getString("VAT_Amount"));
		fcgainModel.setVAT_Bus_Posting_Group(rs.getString("VAT_Bus_Posting_Group"));
		fcgainModel.setVAT_Difference(rs.getString("VAT_Difference"));
		fcgainModel.setVAT_Prod_Posting_Group(rs.getString("VAT_Prod_Posting_Group"));
		fcgainModel.setAccount_No(rs.getString("Account_No"));
		fcgainModel.setPayer_Information(rs.getString("Payer_Information"));
		fcgainModel.setTransaction_Information(rs.getString("Transaction_Information"));
		fcgainModel.setBusiness_Unit_Code(rs.getString("Buisness_Unit_Code"));
		fcgainModel.setEU_3_Party_Trade(rs.getString("EU_3_Party_Trade"));
		fcgainModel.setQuantity(rs.getString("Quantity"));
		fcgainModel.setDeferral_Code(rs.getString("Deferral_Code"));
		fcgainModel.setJob_Queue_Status(rs.getString("Job_Queue_Status"));
		fcgainModel.setBill_to_Pay_to_No(rs.getString("Bill_to_Pay_to_No"));
		fcgainModel.setShip_to_Order_Address_Code(rs.getString("Ship_to_Order_Address_Code"));
		fcgainModel.setPayment_Terms_Code(rs.getString("Payment_Terms_Code"));
		fcgainModel.setApplied_Automatically(rs.getString("Applied_Automatically"));
		fcgainModel.setApplies_to_Doc_No(rs.getString("Applies_to_Doc_No"));
		fcgainModel.setOn_Hold(rs.getString("On_Hold"));
		fcgainModel.setComment(rs.getString("Comment"));
		fcgainModel.setDirect_Debit_Mandate_ID(rs.getString("Direct_Debit_Mandate_ID"));

		return fcgainModel;

	}
}
