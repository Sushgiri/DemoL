package com.bestercapitalmedia.letwizard.daxexports;

import java.io.File;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.bestercapialmedia.letwizard.sns.AmazonSnsClient;
import com.bestercapitalmedia.letwizard.s3.AmazonClient;

import net.lingala.zip4j.exception.ZipException;

@Service
public class DaxDataExportsService {

	@Autowired
	private DaxExportsDao daxExportsDao;

	private AmazonClient amazonClient;

	@Autowired
	public DaxDataExportsService(AmazonClient amazonClient) {
		this.amazonClient = amazonClient;

	}
	
	@Autowired
	private Environment environment;

	private static final Logger logger = LoggerFactory.getLogger(DaxDataExportsService.class);

	//@Scheduled(cron = "0 18 0 * * *")
	public void allDaxExports() {
		logger.info("Getting Dax Exports from database");
		List<CommonModel> auctionDepositBuyer = new ArrayList<>();
		List<CommonModel> auctionDepositSeller = new ArrayList<>();
		List<CommonModel> auctionRefund = new ArrayList<>();
		List<CommonModel> bankCharges = new ArrayList<>();
		List<CommissionModel> commission = new ArrayList<>();
		List<CustomerVirtualAccountModel> customerVirtualAccount = new ArrayList<>();
		List<FCGainModel> fcGain = new ArrayList<>();
		List<CommonModel> internalTransfer = new ArrayList<>();
		List<NewCustomerProfileModel> newCustomerProfile = new ArrayList<>();
		List<PropertyIdModel> propertyId = new ArrayList<>();
		List<ReconcillationReportModel> reconcillationReport = new ArrayList<>();
		List<SalesJournalsModel> salesJournals = new ArrayList<>();
		List<CommonModel> topUpBank = new ArrayList<>();
		List<CommonModel> topUpCard = new ArrayList<>();
		List<CommonModel> walletWithdrawal = new ArrayList<>();
		List<CommonModel> auctionDepositBuyerAEDOD = new ArrayList<>();
		List<CommonModel> auctionDepositSellerAEDOD = new ArrayList<>();
		List<CommonModel> jvExports =  new ArrayList<>();
		List<File> filesToAdd = new ArrayList<>();

		logger.info("Getting AuctionDepositBuyer");
		auctionDepositBuyer = daxExportsDao.getAuctionDepositBuyer();
		if (!auctionDepositBuyer.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("AuctionDepositBuyer" + ".csv", auctionDepositBuyer);
			filesToAdd.add(new File("AuctionDepositBuyer" + ".csv"));
		}
		
		logger.info("Getting AuctionDepositBuyer AEDOD");
		auctionDepositBuyerAEDOD = daxExportsDao.getAuctionDepositBuyerAEDOD();
		if (!auctionDepositBuyerAEDOD.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("AuctionDepositBuyerAEDOD" + ".csv", auctionDepositBuyerAEDOD);
			filesToAdd.add(new File("AuctionDepositBuyerAEDOD" + ".csv"));
		}

		logger.info("Getting AuctionDepositSeller");
		auctionDepositSeller = daxExportsDao.getAuctionDepositSeller();
		if (!auctionDepositSeller.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("AuctionDepositSeller" + ".csv", auctionDepositSeller);
			filesToAdd.add(new File("AuctionDepositSeller" + ".csv"));
		}
		logger.info("Getting AuctionDepositSellerAEDOD");
		auctionDepositSellerAEDOD = daxExportsDao.getAuctionDepositSellerAEDOD();
		if (!auctionDepositSellerAEDOD.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("AuctionDepositSellerAEDOD" + ".csv", auctionDepositSellerAEDOD);
			filesToAdd.add(new File("AuctionDepositSellerAEDOD" + ".csv"));
		}
		logger.info("Getting AuctionRefund");
		auctionRefund = daxExportsDao.getAuctionRefund();
		if (!auctionRefund.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("AuctionRefund" + ".csv", auctionRefund);
			filesToAdd.add(new File("AuctionRefund" + ".csv"));
		}
		logger.info("Getting JV reports");
		jvExports = daxExportsDao.getAllJVReportrs();
		if(!jvExports.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("JVExports"+ ".csv", jvExports);
			filesToAdd.add(new File("JVExports"+ ".csv"));
		}

		logger.info("Getting BankCharges");
		bankCharges = daxExportsDao.getBankCharges();
		if (!bankCharges.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("BankCharges" + ".csv", bankCharges);
			filesToAdd.add(new File("BankCharges" + ".csv"));
		}

		logger.info("Getting Commission");
		commission = daxExportsDao.getCommission();
		if (!commission.isEmpty()) {
			ListToCsvWriter.writeCommissionToCSVFile("Commission" + ".csv", commission);
			filesToAdd.add(new File("Commission" + ".csv"));
		}

		logger.info("Getting CustomerVirtualAccount");
		customerVirtualAccount = daxExportsDao.getCustomerVirtualAccount();
		if (!customerVirtualAccount.isEmpty()) {
			ListToCsvWriter.writeCustomerVirtualAccountToCSVFile("CustomerVirtualAccount" + ".csv",
					customerVirtualAccount);
			filesToAdd.add(new File("CustomerVirtualAccount" + ".csv"));
		}

	/*	logger.info("Getting FCGain");
		fcGain = daxExportsDao.getFCGain();
		if (!fcGain.isEmpty()) {
			ListToCsvWriter.writeFCGainToCSVFile("FCGain" + ".csv", fcGain);
			filesToAdd.add(new File("FCGain" + ".csv"));
		}*/

		logger.info("Getting InternalTransfer");
		internalTransfer = daxExportsDao.getInternalTransfer();
		if (!internalTransfer.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("InternalTransfer" + ".csv", internalTransfer);
			filesToAdd.add(new File("InternalTransfer" + ".csv"));
		}

		logger.info("Getting NewCustomerProfile");
		newCustomerProfile = daxExportsDao.getNewCustomerProfile();
		if (!newCustomerProfile.isEmpty()) {
			ListToCsvWriter.writeNewCustomerProfileToCSVFile("NewCustomerProfile" + ".csv", newCustomerProfile);
			filesToAdd.add(new File("NewCustomerProfile" + ".csv"));
		}

		logger.info("Getting PropertyId");
		propertyId = daxExportsDao.getPropertyId();
		if (!propertyId.isEmpty()) {
			ListToCsvWriter.writePropertyIdToCSVFile("PropertyId" + ".csv", propertyId);
			filesToAdd.add(new File("PropertyId" + ".csv"));

		}

		logger.info("Getting ReconcillationReport");
		reconcillationReport = daxExportsDao.getReconcillationReport();
		if (!reconcillationReport.isEmpty()) {
			ListToCsvWriter.writeReconcillationReportToCSVFile("ReconcillationReport" + ".csv", reconcillationReport);
			filesToAdd.add(new File("ReconcillationReport" + ".csv"));
		}

		logger.info("Getting SalesJournals");
		salesJournals = daxExportsDao.getSalesJournals();
		if (!salesJournals.isEmpty()) {
			ListToCsvWriter.writeSalesJournalsToCSVFile("SalesJournals" + ".csv", salesJournals);
			filesToAdd.add(new File("SalesJournals" + ".csv"));
		}

		logger.info("Getting TopupBank");
		topUpBank = daxExportsDao.getTopupBank();
		if (!topUpBank.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("TopupBank" + ".csv", topUpBank);
			filesToAdd.add(new File("TopupBank" + ".csv"));
		}

		logger.info("Getting TopupCard");
		topUpCard = daxExportsDao.getTopupCard();
		if (!topUpCard.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("TopupCard" + ".csv", topUpCard);
			filesToAdd.add(new File("TopupCard" + ".csv"));
		}

		logger.info("Getting WalletWithdrawal");
		walletWithdrawal = daxExportsDao.getWalletWithdrawal();
		if (!walletWithdrawal.isEmpty()) {
			ListToCsvWriter.writeCommonModelToCSVFile("WalletWithdrawal" + ".csv", walletWithdrawal);
			filesToAdd.add(new File("WalletWithdrawal" + ".csv"));
		}

		logger.info("Generating Password for Zip File");
		String password = generateRandomPassword(14);
		try {
			if (!filesToAdd.isEmpty()) {

				logger.info("Compressing Files Into Zip and adding password to it");
				DaxCsvFilesToZip.compressWithPassword(filesToAdd, password);

				File file = new File("DaxDataExports.zip");
				String fileName = getFileName(file);
				logger.info("Uploading Zip on amazon");
				String fileUrl = this.amazonClient.uploadFileToS3(fileName, file);
				logger.info("Deleting files from root folder");
				for (File files : filesToAdd) {
					files.delete();
				}
				file.delete();
				if (AmazonClient.isExported) {
					if("rentalstageInd".equals(this.environment.getProperty("spring.profiles.active"))) {

						logger.info("Data upload at chiragh-data-exports is complete 1");
						logger.info("Sending email with download link and password 1");
						logger.info("password: " + password);
						
						AmazonSnsClient.sendMessageToDAXPublishTopic(
								"Hello,\n" + "\n" + "Hoping that you are doing well, the download link for DaxExports for" + " "
										+ getyesterdayDate() + " " + "is provided below along with the password for zip file.\n" + "\n"
										+ "Download Link: " + fileUrl + "\n" + "Password for File: " + password + "\n" + "\n"
										+ "Best Regards,\n" + "letWizard Development Team");
						logger.info("Email Dispatched");
						AmazonClient.isExported = false;
					}
					else if ("prod".equals(this.environment.getProperty("spring.profiles.active")) ||"dr".equals(this.environment.getProperty("spring.profiles.active"))) {

						logger.info("Data upload at chiragh-data-exports is complete 2");
						logger.info("Sending email with download link and password 2");
						AmazonSnsClient.sendMessageToProdTopic("Hello,\n" + "\n"
								+ "Hoping that you are doing well, the download link for DaxExports for" + " "
								+ getyesterdayDate() + " " + "is provided below along with the password for zip file.\n"
								+ "\n" + "Download Link: " + fileUrl+ "\n" + "Password for File: " + password + "\n" + "\n"
								+ "Best Regards,\n" + "letWizard Development Team");
						logger.info("Email Dispatched");
						AmazonClient.isExported = false;
					}
					else if(false) {
						logger.info("Data upload at chiragh-data-exports is complete 3");
						logger.info("Sending email with download link and password 3");
						AmazonSnsClient.sendMessageToDAXRentalBizPublishTopic("Hello,\n" + "\n"
								+ "Hoping that you are doing well, the download link for DaxExports for" + " "
								+ getyesterdayDate() + " " + "is provided below along with the password for zip file.\n"
								+ "\n" + "Download Link: " + fileUrl + "\n" + "Password for File: " + password + "\n" + "\n"
								+ "Best Regards,\n" + "letWizard Development Team");
						logger.info("Email Dispatched");
						AmazonClient.isExported = false;
					}
				}
			}
			else {
				if("stage".equals(this.environment.getProperty("spring.profiles.active"))) {
					AmazonSnsClient.sendMessageToDAXPublishTopic(
							"Hello,\n" + "\n" + "Hoping that you are doing well, there is no data to be exported for" + " "
									+ getyesterdayDate()+"."+ "\n"+"Best Regards,\n" + "letWizard Development Team");
				}
				else if ("prod".equals(this.environment.getProperty("spring.profiles.active")) || "dr".equals(this.environment.getProperty("spring.profiles.active"))) {
					AmazonSnsClient.sendMessageToProdTopic(
							"Hello,\n" + "\n" + "Hoping that you are doing well, there is no data to be exported for" + " "
									+ getyesterdayDate()+"."+ "\n"+"Best Regards,\n" + "letWizard Development Team");

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("Error while Dax Exports", e.getStackTrace());
		}
	}

	
	private String getyesterdayDate() {
		String yesterdayDate = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
		yesterdayDate = dateFormat.format(cal.getTime());
		return yesterdayDate;
	}

	private String getFileName(File multiPart) {

		return new Date().getTime() + "-" + multiPart.getName();

	}

	private static String generateRandomPassword(int len) {
		// ASCII range - alphanumeric (0-9, a-z, A-Z)
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		SecureRandom random = new SecureRandom();
		StringBuilder sb = new StringBuilder();

		// each iteration of loop choose a character randomly from the given ASCII range
		// and append it to StringBuilder instance

		for (int i = 0; i < len; i++) {
			int randomIndex = random.nextInt(chars.length());
			sb.append(chars.charAt(randomIndex));
		}

		return sb.toString();
	}

}
