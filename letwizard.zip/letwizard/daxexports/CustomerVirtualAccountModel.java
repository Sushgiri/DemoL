package com.bestercapitalmedia.letwizard.daxexports;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CustomerVirtualAccountModel {

	private String Customer_No;
	private String Code;
	private String Name;
	private String Bank_Account_No;
	private String Currency_Code;
	private String Language_Code;
	private String IBAN;

}
