package com.bestercapitalmedia.letwizard.daxexports;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class DaxExportsDaoImpl implements DaxExportsDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<CommonModel> getAuctionDepositBuyer() {
		try {

			return jdbcTemplate.query(DaxExportsDao.AUCTION_DEPOSIT_BUYER, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getTopupCard() {

		try {

			return jdbcTemplate.query(DaxExportsDao.TOP_UP_CARD, new CommonModelRowMapper());

		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getTopupBank() {

		try {
			return jdbcTemplate.query(DaxExportsDao.TOP_UP_BANK, new CommonModelRowMapper());

		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getAuctionRefund() {

		try {
			return jdbcTemplate.query(DaxExportsDao.AUCTION_REFUND, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getAuctionDepositSeller() {
		try {
			return jdbcTemplate.query(DaxExportsDao.AUCTION_DEPOSIT_SELLER, new CommonModelRowMapper());

		} catch (Exception e) {

			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getBankCharges() {

		try {
			return jdbcTemplate.query(DaxExportsDao.BANK_CHARGES, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getInternalTransfer() {

		try {
			return jdbcTemplate.query(DaxExportsDao.INTERNAL_TRANSFERv2, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getWalletWithdrawal() {

		try {
			return jdbcTemplate.query(DaxExportsDao.WALLET_WITHDRAWAL, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommissionModel> getCommission() {

		try {
			return jdbcTemplate.query(DaxExportsDao.COMMISSION, new CommissionRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CustomerVirtualAccountModel> getCustomerVirtualAccount() {

		try {
			return jdbcTemplate.query(DaxExportsDao.CUSTOMER_VIRTUAL_ACCOUNT, new CustomerVirtualAccountRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	/*@Override
	public List<FCGainModel> getFCGain() {

		try {
			return jdbcTemplate.query(DaxExportsDao.FCGAIN, new FCGainRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}*/

	@Override
	public List<NewCustomerProfileModel> getNewCustomerProfile() {
		try {
			return jdbcTemplate.query(DaxExportsDao.NEW_CUSTOMER_PROFILE, new NewCustomerProfileRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<PropertyIdModel> getPropertyId() {
		try {
			return jdbcTemplate.query(DaxExportsDao.PROPERTY_ID, new PropertyIdRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<ReconcillationReportModel> getReconcillationReport() {
		try {
			return jdbcTemplate.query(DaxExportsDao.RECONCILLATION_REPORT, new ReconcillationReportRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<SalesJournalsModel> getSalesJournals() {
		try {
			return jdbcTemplate.query(DaxExportsDao.SALES_JOURNALS, new SalesJournalsRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

	@Override
	public List<CommonModel> getAuctionDepositBuyerAEDOD() {
		try {
			return jdbcTemplate.query(DaxExportsDao.AUCTION_DEPOSIT_BUYER_AEDOD, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	
	}

	@Override
	public List<CommonModel> getAuctionDepositSellerAEDOD() {
		try {
			return jdbcTemplate.query(DaxExportsDao.AUCTION_DEPOSIT_SELLER_AEDOD, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}

	}

	@Override
	public List<CommonModel> getAllJVReportrs() {
		try {
			return jdbcTemplate.query(DaxExportsDao.JV_EXPORTS, new CommonModelRowMapper());
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
		
	}

}
