package com.bestercapitalmedia.letwizard.daxexports;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class NewCustomerProfileModel {

	private String No;
	private String Name;
	private String Name_2;
	private String Search_Name;
	private String IC_Partner_Code;
	private String Balance_LCY;
	private String Balance_Due_LCY;
	private String Credit_Limit_LCY;
	private String Blocked;
	private String Privacy_Blocked;
	private String Salesperson_Code;
	private String Responsibility_Center;
	private String Service_Zone_Code;
	private String Document_Sending_Profile;
	private String Last_Date_Modified;
	private String Disable_Search_by_Name;
	private String Address;
	private String Address_2;
	private String Country_Region_Code;
	private String City;
	private String Country;
	private String Post_Code;
	private String Primary_Contact_No;
	private String ContactName;
	private String Phone_No;
	private String E_Mail;
	private String Fax_No;
	private String Home_Page;
	private String Language_Code;
	private String Bill_to_Customer_No;
	private String VAT_Registration_No;
	private String GLN;
	private String Use_GLN_in_Electronic_Document;
	private String Copy_Sell_to_Addr_to_Qte_From;
	private String Tax_Liable;
	private String Tax_Area_Code;
	private String Invoice_Copies;
	private String Gen_Bus_Posting_Group;
	private String VAT_Bus_Posting_Group;
	private String Customer_Posting_Group;
	private String Currency_Code;
	private String Price_Calculation_Method;
	private String Customer_Price_Group;
	private String Customer_Disc_Group;
	private String Allow_Line_Disc;
	private String Invoice_Disc_Code;
	private String Prices_Including_VAT;
	private String Prepayment_Percent;
	private String Application_Method;
	private String Partner_Type;
	private String Payment_Terms_Code;
	private String Payment_Method_Code;
	private String Reminder_Terms_Code;
	private String Fin_Charge_Terms_Code;
	private String Cash_Flow_Payment_Terms_Code;
	private String Print_Statements;
	private String Last_Statement_No;
	private String Block_Payment_Tolerance;
	private String Preferred_Bank_Account_Code;
	private String Ship_to_Code;
	private String Location_Code;
	private String Combine_Shipments;
	private String Reserve;
	private String Shipping_Advice;
	private String Shipment_Method_Code;
	private String Shipping_Agent_Code;
	private String Shipping_Agent_Service_Code;
	private String Shipping_Time;
	private String Base_Calendar_Code;
	private String Payments_LCY;
	private String MobilePhoneNo;
	private String EORI_Number;

}
