package com.bestercapitalmedia.letwizard.daxexports;

import java.io.File;
import java.util.List;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.EncryptionMethod;

public class DaxCsvFilesToZip {

	public static void compressWithPassword(List<File> files, String password) throws ZipException {

		String destPath = "DaxDataExports" + ".zip";

		// Setting parameters
		ZipParameters zipParameters = new ZipParameters();
		zipParameters.setEncryptFiles(true);
		zipParameters.setEncryptionMethod(EncryptionMethod.AES);
		zipParameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);

		ZipFile zipFile = new ZipFile(destPath, password.toCharArray());
		zipFile.addFiles(files, zipParameters);
	}

}
