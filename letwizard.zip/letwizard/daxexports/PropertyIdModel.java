package com.bestercapitalmedia.letwizard.daxexports;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PropertyIdModel {

	private String Dimension_Code;
	private String Code;
	private String Name;

}
