package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerVirtualAccountRowMapper implements RowMapper<CustomerVirtualAccountModel> {

	@Override
	public CustomerVirtualAccountModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		CustomerVirtualAccountModel model = new CustomerVirtualAccountModel();

		model.setBank_Account_No(rs.getString("Bank_Account_No"));
		model.setCode(rs.getString("Code"));
		model.setCurrency_Code(rs.getString("Currency_Code"));
		model.setCustomer_No(rs.getString("Customer_No"));
		model.setIBAN(rs.getString("IBAN"));
		model.setLanguage_Code(rs.getString("Language_Code"));
		model.setName(rs.getString("Name"));

		return model;

	}
}
