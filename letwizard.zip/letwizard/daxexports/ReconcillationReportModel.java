package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ReconcillationReportModel {

	private Date Posting_Date;
	private Date Document_Date;
	private Date Processed_Date;
	private String Document_Type;
	private String External_Document_No;
	private String Account_Type;
	private String Account_NO;
	private String Recipient_Bank_Account;
	private String Description;
	private String Currency_Code;
	private String Payment_Method_Code;
	private Double Amount;
	private String Shortcut_Dimension_1_Code;
	private String Transaction_Type;
	private String Status;
}
