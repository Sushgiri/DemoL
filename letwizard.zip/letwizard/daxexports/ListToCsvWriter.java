package com.bestercapitalmedia.letwizard.daxexports;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

public class ListToCsvWriter {

	static final Logger logger = LoggerFactory.getLogger(ListToCsvWriter.class);

	static void writeCommonModelToCSVFile(String csvFileName, List<CommonModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Posting_Date", "Document_Date", "Document_Type", "Document_No",
					"Incoming_Document_Entry_No", "External_Document_No", "Applies_to_Ext_Doc_No", "Account_Type",
					"Account_NO", "Recipient_Bank_Account", "Message_to_Recipient", "Description",
					"Salespers_Purch_Code", "Campaign_No", "Currency_Code", "Gen_Posting_Type", "Gen_Bus_Posting_Group",
					"Gen_Prod_Posting_Group", "VAT_Bus_Posting_Group", "VAT_Prod_Posting_Group", "Payment_Method_Code",
					"Payment_Reference", "Creditor_No", "Amount", "Amount_LCY", "Debit_Amount", "Credit_Amount",
					"VAT_Amount", "VAT_Difference", "Bal_VAT_Amount", "Bal_VAT_Difference", "Bal_Account_Type",
					"Bal_Account_No", "Bal_Gen_Posting_Type", "Bal_Gen_Bus_Posting_Group", "Bal_Gen_Prod_Posting_Group",
					"Bal_VAT_Bus_Posting_Group", "Bal_VAT_Prod_Posting_Group", "Applies_to_Doc_Type", "AppliesToDocNo",
					"Applies_to_ID", "Bank_Payment_Type", "Check_Printed", "Reason_Code", "Correction", "CommentField",
					"Exported_to_Payment_File", "Has_Payment_Export_Error", "Job_Queue_Status",
					"Shortcut_Dimension_1_Code", "Shortcut_Dimension_2_Code", "Journal_Template_Name",
					"Journal_Batch_Name", "Line_No"

			};
			beanWriter.writeHeader(header);

			for (CommonModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

	static void writeCommissionToCSVFile(String csvFileName, List<CommissionModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Posting_Date", "Document_Date", "Document_Type", "Document_No",
					"Incoming_Document_Entry_No", "External_Document_No", "Account_Type", "Account_NO", "Description",
					"Salespers_Purch_Code", "Campaign_No", "Currency_Code", "Gen_Posting_Type", "Gen_Bus_Posting_Group",
					"Gen_Prod_Posting_Group", "VAT_Bus_Posting_Group", "VAT_Prod_Posting_Group", "Amount", "Amount_LCY",
					"Debit_Amount", "Credit_Amount", "Tax_Liable", "Tax_Area_Code", "Tax_Group_Code", "VAT_Amount",
					"VAT_Difference", "Bal_VAT_Amount", "Bal_VAT_Difference", "Bal_Account_Type", "Bal_Account_No",
					"Bal_Gen_Posting_Type", "Bal_Gen_Bus_Posting_Group", "Bal_Gen_Prod_Posting_Group",
					"Bal_VAT_Bus_Posting_Group", "Bal_VAT_Prod_Posting_Group", "Bill_to_Pay_to_No",
					"Ship_to_Order_Address_Code", "Sales_Purch_LCY", "Profit_LCY", "Inv_Discount_LCY",
					"Payment_Terms_Code", "Due_Date", "Pmt_Discount_Date", "Payment_Discount_Percent",
					"Applies_to_Doc_Type", "Applies_to_Doc_No", "Applies_to_ID", "On_Hold", "Reason_Code", "Correction",
					"Comment", "Direct_Debit_Mandate_ID", "Job_Queue_Status", "Shortcut_Dimension_1_Code",
					"Shortcut_Dimension_2_Code", "Journal_Template_Name", "Journal_Batch_Name", "Line_No"

			};
			beanWriter.writeHeader(header);

			for (CommissionModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

	static void writeCustomerVirtualAccountToCSVFile(String csvFileName, List<CustomerVirtualAccountModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Customer_No", "Code", "Name", "Bank_Account_No", "Currency_Code", "Language_Code",
					"IBAN"

			};
			beanWriter.writeHeader(header);

			for (CustomerVirtualAccountModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

	static void writeFCGainToCSVFile(String csvFileName, List<FCGainModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Posting_Date", "Document_Date", "Document_Type", "Document_No",
					"Incoming_Document_Entry_No", "External_Document_No", "Applies_to_Ext_Doc_No", "Account_Type",
					"Account_No", "Description", "Payer_Information", "Transaction_Information", "Business_Unit_Code",
					"Salespers_Purch_Code", "Campaign_No", "Currency_Code", "EU_3_Party_Trade", "Gen_Posting_Type",
					"Gen_Bus_Posting_Group", "Gen_Prod_Posting_Group", "VAT_Bus_Posting_Group",
					"VAT_Prod_Posting_Group", "Quantity", "Amount", "Amount_LCY", "Debit_Amount", "Credit_Amount",
					"VAT_Amount", "VAT_Difference", "Bal_VAT_Amount", "Bal_VAT_Difference", "Bal_Account_Type",
					"Bal_Account_No", "Bal_Gen_Posting_Type", "Bal_Gen_Bus_Posting_Group", "Bal_Gen_Prod_Posting_Group",
					"Deferral_Code", "Job_Queue_Status", "Bal_VAT_Bus_Posting_Group", "Bal_VAT_Prod_Posting_Group",
					"Bill_to_Pay_to_No", "Ship_to_Order_Address_Code", "Payment_Terms_Code", "Applied_Automatically",
					"Applies_to_Doc_Type", "Applies_to_Doc_No", "Applies_to_ID", "On_Hold", "Bank_Payment_Type",
					"Reason_Code", "Correction", "Comment", "Direct_Debit_Mandate_ID", "Shortcut_Dimension_1_Code",
					"Shortcut_Dimension_2_Code", "Journal_Template_Name", "Journal_Batch_Name", "Line_No"

			};
			beanWriter.writeHeader(header);

			for (FCGainModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

	static void writeNewCustomerProfileToCSVFile(String csvFileName, List<NewCustomerProfileModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "No", "Name", "Name_2", "Search_Name", "IC_Partner_Code", "Balance_LCY",
					"Balance_Due_LCY", "Credit_Limit_LCY", "Blocked", "Privacy_Blocked", "Salesperson_Code",
					"Responsibility_Center", "Service_Zone_Code", "Document_Sending_Profile", "Last_Date_Modified",
					"Disable_Search_by_Name", "Address", "Address_2", "Country_Region_Code", "City", "Country",
					"Post_Code", "Primary_Contact_No", "ContactName", "Phone_No","MobilePhoneNo","EORI_Number","E_Mail", "Fax_No", "Home_Page",
					"Language_Code", "Bill_to_Customer_No", "VAT_Registration_No", "GLN",
					"Use_GLN_in_Electronic_Document", "Copy_Sell_to_Addr_to_Qte_From", "Tax_Liable", "Tax_Area_Code",
					"Invoice_Copies", "Gen_Bus_Posting_Group", "VAT_Bus_Posting_Group", "Customer_Posting_Group",
					"Currency_Code", "Price_Calculation_Method", "Customer_Price_Group", "Customer_Disc_Group",
					"Allow_Line_Disc", "Invoice_Disc_Code", "Prices_Including_VAT", "Prepayment_Percent",
					"Application_Method", "Partner_Type", "Payment_Terms_Code", "Payment_Method_Code",
					"Reminder_Terms_Code", "Fin_Charge_Terms_Code", "Cash_Flow_Payment_Terms_Code", "Print_Statements",
					"Last_Statement_No", "Block_Payment_Tolerance", "Preferred_Bank_Account_Code", "Ship_to_Code",
					"Location_Code", "Combine_Shipments", "Reserve", "Shipping_Advice", "Shipment_Method_Code",
					"Shipping_Agent_Code", "Shipping_Agent_Service_Code", "Shipping_Time", "Base_Calendar_Code",
					"Payments_LCY"

			};
			beanWriter.writeHeader(header);

			for (NewCustomerProfileModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

	static void writePropertyIdToCSVFile(String csvFileName, List<PropertyIdModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Dimension_Code", "Code", "Name" };
			beanWriter.writeHeader(header);

			for (PropertyIdModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

	static void writeReconcillationReportToCSVFile(String csvFileName, List<ReconcillationReportModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Posting_Date", "Document_Date", "Processed_Date", "Document_Type",
					"External_Document_No", "Account_Type", "Account_NO", "Recipient_Bank_Account", "Description",
					"Currency_Code", "Payment_Method_Code", "Amount", "Shortcut_Dimension_1_Code", "Transaction_Type",
					"Status" };
			beanWriter.writeHeader(header);

			for (ReconcillationReportModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

	static void writeSalesJournalsToCSVFile(String csvFileName, List<SalesJournalsModel> list) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Posting_Date", "Document_Date", "Document_Type", "Document_No",
					"Incoming_Document_Entry_No", "External_Document_No", "Account_Type", "Account_NO", "Description",
					"Salespers_Purch_Code", "Campaign_No", "Currency_Code", "Gen_Posting_Type", "Gen_Bus_Posting_Group",
					"Gen_Prod_Posting_Group", "VAT_Bus_Posting_Group", "VAT_Prod_Posting_Group", "Amount", "Amount_LCY",
					"Debit_Amount", "Credit_Amount", "Tax_Liable", "Tax_Area_Code", "Tax_Group_Code", "VAT_Amount",
					"VAT_Difference", "Bal_VAT_Amount", "Bal_VAT_Difference", "Bal_Account_Type", "Bal_Account_No",
					"Bal_Gen_Posting_Type", "Bal_Gen_Bus_Posting_Group", "Bal_Gen_Prod_Posting_Group",
					"Bal_VAT_Bus_Posting_Group", "Bal_VAT_Prod_Posting_Group", "Bill_to_Pay_to_No",
					"Ship_to_Order_Address_Code", "Sales_Purch_LCY", "Profit_LCY", "Inv_Discount_LCY",
					"Payment_Terms_Code", "Due_Date", "Pmt_Discount_Date", "Payment_Discount_Percent",
					"Applies_to_Doc_Type", "Applies_to_Doc_No", "Applies_to_ID", "On_Hold", "Reason_Code", "Correction",
					"Comment", "Direct_Debit_Mandate_ID", "Job_Queue_Status", "Shortcut_Dimension_1_Code",
					"Shortcut_Dimension_2_Code", "Journal_Template_Name", "Journal_Batch_Name", "Line_No"

			};
			beanWriter.writeHeader(header);

			for (SalesJournalsModel aBook : list) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

}
