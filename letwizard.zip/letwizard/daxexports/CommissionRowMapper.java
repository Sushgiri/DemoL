package com.bestercapitalmedia.letwizard.daxexports;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CommissionRowMapper implements RowMapper<CommissionModel> {

	@Override
	public CommissionModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		CommissionModel commissionModel = new CommissionModel();

		commissionModel.setAccount_NO(rs.getString("Account_NO"));
		commissionModel.setAccount_Type(rs.getString("Account_Type"));
		commissionModel.setAmount(rs.getDouble("Amount"));
		commissionModel.setAmount_LCY(rs.getString("Amount_LCY"));
		commissionModel.setApplies_to_Doc_Type(rs.getString("Applies_to_Doc_Type"));
		commissionModel.setApplies_to_ID(rs.getString("Applies_to_ID"));
		commissionModel.setBal_Account_No(rs.getString("Bal_Account_No"));
		commissionModel.setBal_Account_Type(rs.getString("Bal_Account_Type"));
		commissionModel.setBal_Gen_Bus_Posting_Group(rs.getString("Bal_Gen_Bus_Posting_Group"));
		commissionModel.setBal_Gen_Posting_Type(rs.getString("Bal_Gen_Posting_Type"));
		commissionModel.setBal_Gen_Prod_Posting_Group(rs.getString("Bal_Gen_Prod_Posting_Group"));
		commissionModel.setBal_VAT_Amount(rs.getString("Bal_VAT_Amount"));
		commissionModel.setBal_VAT_Bus_Posting_Group(rs.getString("Bal_VAT_Bus_Posting_Group"));
		commissionModel.setBal_VAT_Difference(rs.getString("Bal_VAT_Difference"));
		commissionModel.setBal_VAT_Prod_Posting_Group(rs.getString("Bal_VAT_Prod_Posting_Group"));
		commissionModel.setCampaign_No(rs.getString("Campaign_No"));
		commissionModel.setCorrection(rs.getString("Correction"));
		commissionModel.setCredit_Amount(rs.getString("Credit_Amount"));
		commissionModel.setCurrency_Code(rs.getString("Currency_Code"));
		commissionModel.setDebit_Amount(rs.getString("Debit_Amount"));
		commissionModel.setDescription(rs.getString("Description"));
		commissionModel.setDocument_Date(rs.getDate("Document_Date"));
		commissionModel.setDocument_No(rs.getString("Document_No"));
		commissionModel.setDocument_Type(rs.getString("Document_Type"));
		commissionModel.setExternal_Document_No(rs.getString("External_Document_No"));
		commissionModel.setGen_Bus_Posting_Group(rs.getString("Gen_Bus_Posting_Group"));
		commissionModel.setGen_Posting_Type(rs.getString("Gen_Posting_Type"));
		commissionModel.setGen_Prod_Posting_Group(rs.getString("Gen_Prod_Posting_Group"));
		commissionModel.setIncoming_Document_Entry_No(rs.getString("Incoming_Document_Entry_No"));
		commissionModel.setJob_Queue_Status(rs.getString("Job_Queue_Status"));
		commissionModel.setJournal_Batch_Name(rs.getString("Journal_Batch_Name"));
		commissionModel.setJournal_Template_Name(rs.getString("Journal_Template_Name"));
		commissionModel.setLine_No(rs.getString("Line_No"));
		commissionModel.setPosting_Date(rs.getDate("Posting_Date"));
		commissionModel.setReason_Code(rs.getString("Reason_Code"));
		commissionModel.setSalespers_Purch_Code(rs.getString("Salespers_Purch_Code"));
		commissionModel.setShortcut_Dimension_1_Code(rs.getString("Shortcut_Dimension_1_Code"));
		commissionModel.setShortcut_Dimension_2_Code(rs.getString("Shortcut_Dimension_2_Code"));
		commissionModel.setVAT_Amount(rs.getString("VAT_Amount"));
		commissionModel.setVAT_Bus_Posting_Group(rs.getString("VAT_Bus_Posting_Group"));
		commissionModel.setVAT_Difference(rs.getString("VAT_Difference"));
		commissionModel.setVAT_Prod_Posting_Group(rs.getString("VAT_Prod_Posting_Group"));
		commissionModel.setTax_Liable(rs.getString("Tax_Liable"));
		commissionModel.setTax_Area_Code(rs.getString("Tax_Area_Code"));
		commissionModel.setTax_Group_Code(rs.getString("Tax_Group_Code"));
		commissionModel.setBill_to_Pay_to_No(rs.getString("Bill_to_Pay_to_No"));
		commissionModel.setShip_to_Order_Address_Code(rs.getString("Ship_to_Order_Address_Code"));
		commissionModel.setSales_Purch_LCY(rs.getString("Sales_Purch_LCY"));
		commissionModel.setProfit_LCY(rs.getString("Profit_LCY"));
		commissionModel.setInv_Discount_LCY(rs.getString("Inv_Discount_LCY"));
		commissionModel.setPayment_Terms_Code(rs.getString("Payment_Terms_Code"));
		commissionModel.setDue_Date(rs.getString("Due_Date"));
		commissionModel.setPmt_Discount_Date(rs.getString("Pmt_Discount_Date"));
		commissionModel.setPayment_Discount_Percent(rs.getString("Payment_Discount_Percent"));
		commissionModel.setApplies_to_Doc_No(rs.getString("Applies_to_Doc_No"));
		commissionModel.setOn_Hold(rs.getString("On_Hold"));
		commissionModel.setComment(rs.getString("Comment"));
		commissionModel.setDirect_Debit_Mandate_ID(rs.getString("Direct_Debit_Mandate_ID"));

		return commissionModel;

	}
}
