package com.bestercapitalmedia.letwizard.fxoprates;

import java.math.BigDecimal;
import java.sql.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FxopModel {

	private String Currency_Code;
	private Date Starting_Date;
	private BigDecimal Exchange_Rate_Amount;
	private BigDecimal Adjustement_Exch_Rate_Amount;
	private String Relational_Currency_Code;
	private BigDecimal Relational_Exch_Rate_Amount;
	private String Fix_Exchange_Rate_Amount;
	private BigDecimal Relational_Adjmt_Exch_Rate_Amt;

}
