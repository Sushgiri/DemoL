package com.bestercapitalmedia.letwizard.fxoprates;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class FxopRowMapper implements RowMapper<FxopModel> {

	@Override
	public FxopModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		FxopModel fxopModel = new FxopModel();

		fxopModel.setAdjustement_Exch_Rate_Amount(rs.getBigDecimal("Adjustement_Exch_Rate_Amount"));
		fxopModel.setCurrency_Code(rs.getString("Currency_Code"));
		fxopModel.setExchange_Rate_Amount(rs.getBigDecimal("Exchange_Rate_Amount"));
		fxopModel.setFix_Exchange_Rate_Amount(rs.getString("Fix_Exchange_Rate_Amount"));
		fxopModel.setRelational_Adjmt_Exch_Rate_Amt(rs.getBigDecimal("Relational_Adjmt_Exch_Rate_Amt"));
		fxopModel.setRelational_Currency_Code(rs.getString("Relational_Currency_Code"));
		fxopModel.setRelational_Exch_Rate_Amount(rs.getBigDecimal("Relational_Exch_Rate_Amount"));
		fxopModel.setStarting_Date(rs.getDate("Starting_Date"));

		return fxopModel;
	}

}
