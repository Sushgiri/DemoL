package com.bestercapitalmedia.letwizard.fxoprates;

import java.io.File;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.bestercapialmedia.letwizard.sns.AmazonSnsClient;
import com.bestercapitalmedia.letwizard.s3.AmazonClient;

import net.lingala.zip4j.exception.ZipException;

@Service
public class FxopService {

	@Autowired
	private FxopDao fxopDao;

	private AmazonClient amazonClient;

	@Autowired
	public FxopService(AmazonClient amazonClient) {
		this.amazonClient = amazonClient;

	}

	@Autowired
	private Environment environment;

	private static final Logger logger = LoggerFactory.getLogger(FxopService.class);

	//@Scheduled(cron = "0 10 0 * * *")
	public void getFxopRates() {
		logger.info("Getting all exchange rates from database");
		List<FxopModel> list = fxopDao.getFxopRates();
		if (!list.isEmpty()) {

			logger.info("Writing data into CSV file");
			FxopDataToCsv.writeCSVFile("FxopRates" + ".csv", list);
			logger.info("Generating Password for Zip File");
			String password = generateRandomPassword(14);
			File balances = new File("FxopRates" + ".csv");
			try {
				logger.info("Compressing Files Into Zip and adding password to it");
				FxopCsvToZip.compressWithPassword(balances, password);
			} catch (ZipException e) {
				e.printStackTrace();
			}
			File file = new File("FxopRates.zip");
			String fileName = getFileName(file);
			logger.info("Uploading Zip on amazon");
			String fileUrl = this.amazonClient.uploadFileToS3(fileName, file);
			logger.info("Deleting files from root folder");
			balances.delete();
			file.delete();
			if (AmazonClient.isExported) {

				logger.info("Data upload at chiragh-data-exports is complete");
				logger.info("Sending email with download link and password");
				if ("stage".equals(this.environment.getProperty("spring.profiles.active"))) {
					AmazonSnsClient.sendMessageToDAXPublishTopic("Hello,\n" + "\n"
							+ "Hoping that you are doing well, the download link for FXOP Rates for" + " " + getDate()
							+ " " + "is provided below along with the password for zip file.\n" + "\n"
							+ "Download Link: " +fileUrl+ "\n" + "Password for File: " + password + "\n" + "\n"
							+ "Best Regards,\n" + "letWizard Development Team");
					logger.info("Email Dispatched");
					AmazonClient.isExported = false;
				}
				else if ("prod".equals(this.environment.getProperty("spring.profiles.active")) || "dr".equals(this.environment.getProperty("spring.profiles.active"))){
					AmazonSnsClient.sendMessageToProdTopic("Hello,\n" + "\n"
							+ "Hoping that you are doing well, the download link for FXOP Rates for" + " " + getDate()
							+ " " + "is provided below along with the password for zip file.\n" + "\n"
							+ "Download Link: " + fileUrl+ "\n" + "Password for File: " + password + "\n" + "\n"
							+ "Best Regards,\n" + "letWizard Development Team");
					logger.info("Email Dispatched");
					AmazonClient.isExported = false;
				}
			}
		}

	}

	private String getDate() {
		String yesterdayDate = null;
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
		yesterdayDate = dateFormat.format(cal.getTime());
		return yesterdayDate;
	}

	private String getFileName(File multiPart) {

		return new Date().getTime() + "-" + multiPart.getName();

	}

	private static String generateRandomPassword(int len) {
		// ASCII range - alphanumeric (0-9, a-z, A-Z)
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		SecureRandom random = new SecureRandom();
		StringBuilder sb = new StringBuilder();

		// each iteration of loop choose a character randomly from the given ASCII range
		// and append it to StringBuilder instance

		for (int i = 0; i < len; i++) {
			int randomIndex = random.nextInt(chars.length());
			sb.append(chars.charAt(randomIndex));
		}

		return sb.toString();
	}

}
