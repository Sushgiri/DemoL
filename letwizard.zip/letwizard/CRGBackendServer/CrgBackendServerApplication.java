
package com.bestercapitalmedia.letwizard.CRGBackendServer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.Filter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.Ordered;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import org.springframework.web.filter.ShallowEtagHeaderFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@EnableAsync
@EnableJpaRepositories("com.bestercapitalmedia")
@EntityScan("com.bestercapitalmedia")
@PropertySource(value = { "classpath:application.properties" })
//@PropertySource(value = { "classpath:application.yaml" })
@EnableCaching
@EnableAutoConfiguration(exclude = { JmxAutoConfiguration.class })
@EnableScheduling
@ComponentScan(basePackages = { "com.bestercapitalmedia" })
@SpringBootApplication(scanBasePackages = { "com.bestercapitalmedia" })
public class CrgBackendServerApplication extends SpringBootServletInitializer {
	
	@Bean
	public Filter ShallowEtagHeaderFilter() {
		return new ShallowEtagHeaderFilter(); 
	}
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CrgBackendServerApplication.class);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(CrgBackendServerApplication.class, args);
	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedOrigins("*");

			}
		};
	}

	@Bean
	public FilterRegistrationBean<Filter> simpleCorsFilter() {
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowCredentials(true);
		// config.setAllowedOrigins(Collections.singletonList("*"));

		List<String> list = new ArrayList<String>();
		list.add("http://192.168.29.208:4200");
		// list.add("http://demo.chiragh.com");
		// list.add("http://demo.chiragh.com/admin");
		list.add("*");

		// config.setAllowedOrigins(Collections.singletonList("http://demo.chiragh.com"));
		config.setAllowedOrigins(list);
		config.setAllowedMethods(Collections.singletonList("*"));
		config.setAllowedHeaders(Collections.singletonList("*"));
		source.registerCorsConfiguration("/**", config);
		FilterRegistrationBean bean = new FilterRegistrationBean(new CorsFilter(source));
		bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
		return bean;
	}
	
	@Bean
	public CacheManager cacheManager() {
		SimpleCacheManager cacheManager = new SimpleCacheManager();
		List<Cache> caches = new ArrayList<Cache>();
		caches.add(new ConcurrentMapCache("banks"));
		caches.add(new ConcurrentMapCache("auctionProperties"));
		caches.add(new ConcurrentMapCache("adminProperties"));
		caches.add(new ConcurrentMapCache("oldauctionProperties"));
		cacheManager.setCaches(caches);
		return cacheManager;
	}
}