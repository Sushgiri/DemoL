package com.bestercapitalmedia.letwizard.city;

import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.country.Country;
import com.bestercapitalmedia.letwizard.country.CountryRepository;

// TODO: Auto-generated Javadoc
/**
 * The Class CityController.
 */
@RestController
//@RequestMapping("/api/city/")
public class CityController {

	/** The city repository. */
	@Autowired
	private CityRepository cityRepository;

	@Autowired
	private CityService cityService;

	/**
	 * List.
	 *
	 * @return the iterable
	 */
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/cities", method = RequestMethod.GET)
	public ResponseEntity getCities(HttpServletRequest httpServletRequest) {
		return cityService.getAllCities();
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/countries/{countryId}/cities", method = RequestMethod.GET)
	public ResponseEntity getCitiesbyCountryId(@PathVariable(value = "countryId") int countryId,
			HttpServletRequest httpServletRequest) {

		return cityService.getCitiesbyCountryId(countryId);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/cities/{cityId}", method = RequestMethod.PATCH)
	public ResponseEntity updateCity(@PathVariable(value = "cityId") int cityId,
			@RequestBody Map<String, Object> updateData, HttpServletRequest httpServletRequest) {
		return cityService.patch(updateData, cityId);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/v2/countries/{countryId}/cities", method = RequestMethod.GET)
	public ResponseEntity getCitiesbyCountryIdV2(@PathVariable(value = "countryId") int countryId,
			HttpServletRequest httpServletRequest) {

		return cityService.getCitiesbyCountryIdV2(countryId);
	}
	/**
	 * Creates the.
	 *
	 * @param users the users
	 * @return the city
	 */
//	@RequestMapping(value="/post")
//	public City create(City users) {
//		return cityRepository.save(users);
//	}

	/**
	 * Update.
	 *
	 * @param id     the id
	 * @param entity the entity
	 * @return the city
	 */
//	@RequestMapping(value = "/put/{id}", method = RequestMethod.PUT)
//	public City update(@PathVariable(value = "id") long id, @RequestBody City entity) {
//		return cityRepository.save(entity);
//	}

	/**
	 * Delete.
	 *
	 * @param id the id
	 */
//	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
//	public void delete(@PathVariable(value = "id") int id) {
//		cityRepository.deleteById(id);
//	}

	/**
	 * Gets the.
	 *
	 * @param id the id
	 * @return the optional
	 */
//	@RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
//	public Optional<City> get(@PathVariable(value = "id") int id) {
//		return cityRepository.findById(id);
//	}
}
