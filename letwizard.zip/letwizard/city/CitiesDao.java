package com.bestercapitalmedia.letwizard.city;

import java.util.List;

import org.springframework.http.ResponseEntity;

public interface CitiesDao {

	public static final String GET_CITIES_BY_COUNTRY_ID = "Select * from city where country_Id=? and is_active = 1 ORDER BY name ASC";

	public List<CityDTO> getCitiesbyCountryId(int countryId);

}
