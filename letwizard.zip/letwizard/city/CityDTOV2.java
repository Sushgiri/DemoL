package com.bestercapitalmedia.letwizard.city;

public class CityDTOV2 {
    private int cityId;
    private String name;
    private Boolean isActive;
    private int countryId;
    public int getCityId() {
        return cityId;
    }
    public void setCityId(int cityId) {
        this.cityId = cityId;
    }
    public int getCountryId() {
        return countryId;
    }
    public void SetCountryId(int countryId) {
        this.countryId = countryId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Boolean getIsActive() {
        return isActive;
    }
    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }
    public CityDTOV2 () {

    }
}

