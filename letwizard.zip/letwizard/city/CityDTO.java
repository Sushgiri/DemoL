package com.bestercapitalmedia.letwizard.city;

public class CityDTO {
	
	private int cityId;
	private String name;
	private Boolean isActive;

	public int getCityId() {
		return cityId;
	}
	public void setCityId(int cityId) {
		this.cityId = cityId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
    public Boolean getIsActive() {
		return isActive;
	}
	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	public CityDTO () {
	 
   }
}
