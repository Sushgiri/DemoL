package com.bestercapitalmedia.letwizard.city;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bestercapitalmedia.letwizard.property.Chiraghproperty;

/**
 * The Interface CityRepository.
 */
public interface CityRepository extends CrudRepository<City, Integer> {
	
	
	@Query(value = "Select * from city where city_id > 0 and is_active = 1", nativeQuery = true)
	public List<City> getAllCities();
	
	@Query(value = "Select * from city where country_Id=?1 and is_active = 1", nativeQuery = true)
	public List<City> getCitiesByCountryId(int countryId);
	
	@Query(value = "Select * from city where city_Id=?1 and is_active = 1", nativeQuery = true)
	public City getByCityId(int cityId);
	
	// For City Search
	
			@Query(value = "{call getCityById (:cityId)}", nativeQuery = true)
			public City getCityById(@Param("cityId") Integer cityId);

}
