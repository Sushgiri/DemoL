package com.bestercapitalmedia.letwizard.city;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CitiesRowMapper implements RowMapper<CityDTO> {

	@Override
	public CityDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

		CityDTO cityDTO = new CityDTO();
		cityDTO.setCityId(rs.getInt("city_Id"));
		cityDTO.setName(rs.getString("name"));
		cityDTO.setIsActive(rs.getBoolean("is_active"));

		return cityDTO;
	}

}
