package com.bestercapitalmedia.letwizard.city;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.utill.NullAwareBeanUtilsBean;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CityService {

	@Autowired
	private CityRepository cityRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private NullAwareBeanUtilsBean beanUtils;

	@Autowired
	private CitiesDao citiesDao;

	public ResponseEntity getAllCities() {

		try {
			ModelMapper mapper = new ModelMapper();
//			List<City> citylist = cityRepository.getAllCities();

			List<CityDTO> citylist = cityRepository.getAllCities().stream().map(s -> mapper.map(s, CityDTO.class))
					.collect(Collectors.toList());
			System.out.println("All cities" + citylist);
			if (citylist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						citylist);
			}
		} catch (Exception e) {

			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	public ResponseEntity getCitiesbyCountryId(int countryId) {

		try {
			ModelMapper mapper = new ModelMapper();
			// List<City> citylist = cityRepository.getCitiesByCountryId(countryId);
			List<CityDTO> citylist = cityRepository.getCitiesByCountryId(countryId).stream()
					.map(s -> mapper.map(s, CityDTO.class)).collect(Collectors.toList());

			if (citylist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						citylist);
			}
		} catch (Exception e) {

			e.printStackTrace();
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	public ResponseEntity patch(Map<String, Object> updateData, Integer cityId) {
		try {
			ModelMapper mapper = new ModelMapper();
			ObjectMapper objectMapper = new ObjectMapper();
			City toBePathced = objectMapper.convertValue(updateData, City.class);
			City dbObject = cityRepository.getByCityId(cityId);
			beanUtils.copyProperties(dbObject, toBePathced);
			City newCity = cityRepository.save(dbObject);
			if (newCity == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				CityDTO cityDto = mapper.map(newCity, CityDTO.class);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(cityDto).collect(Collectors.toList()));
			}
		} catch (Exception e) {

			e.printStackTrace();
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	public ResponseEntity getCitiesbyCountryIdV2(int countryId) {

		try {
			List<CityDTO> citylist = citiesDao.getCitiesbyCountryId(countryId);

			if (citylist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						citylist);
			}
		} catch (Exception e) {

			e.printStackTrace();
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

}
