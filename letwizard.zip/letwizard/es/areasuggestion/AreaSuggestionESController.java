package com.bestercapitalmedia.letwizard.es.areasuggestion;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.ElasticsearchMessages;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/elasticsearch/evaluation")
public class AreaSuggestionESController {

	
	@Autowired
	private AreaSuggestionESService areaSuggestionESService;


	@Autowired
	private ResponseUtill responseUtill;
	  
	  @RequestMapping(value = "/suggestion/area", method = RequestMethod.POST)
	  public ResponseEntity gatAreaSuggestion(@RequestBody AreaSuggestionES areaSuggestionES) {
		  
		  Map<String,Object> areaSuggestion = null;
			try {	        
				areaSuggestion  =  areaSuggestionESService.getAreaSuggestion(areaSuggestionES.getArea());
			
				if(areaSuggestion == null) {
					return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_NOT_FOUND,
							null);
				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(areaSuggestion).collect(Collectors.toList()));
				
			} catch (Exception e) {
				return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
						ElasticsearchMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	  }
}
