package com.bestercapitalmedia.letwizard.es.areasuggestion;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;

@Service
public class AreaSuggestionESService {

	
	public Map<String,Object> getAreaSuggestion(String keywords) throws JsonParseException, JsonMappingException, IOException {
		
		RestClient restClient = RestClient.builder(new HttpHost(LetwizardConstants.ES_HOST, LetwizardConstants.ES_PORT, "http")).build();
		 HttpEntity entity = new StringEntity("{" + 
		 		"\"_source\": \"area\"," + 
		 		"\"query\": {" + 
		 		"\"match\": {" + 
		 		"\"area\": {" + 
		 		"\"query\": \""+keywords+"\"" + 
		 		"}" + 
		 		"}" + 
		 		"}" + 
		 		"}", ContentType.APPLICATION_JSON);

		 Response getResponse = 
					restClient.performRequest("GET", LetwizardConstants.EVALUATION_SUGGESTION_SERVER_PATH,Collections.<String, String>emptyMap(), entity);
		       
	        HttpEntity httpEntity = getResponse.getEntity();
	        String result = null;
	        Map<String,Object> mapResponse = null;
	        if (entity != null) {
	            InputStream instream = getResponse.getEntity().getContent();
	            result = ChiragUtill.convertStreamToString(instream);
//	            JSONObject myObject = new JSONObject(result);
	            ObjectMapper mapper = new ObjectMapper();
//	            System.out.println("RESPONSE: " + result);						
				mapResponse = mapper.readValue(result, Map.class);
	        }
			 
			return mapResponse;
		
}

	
	
}