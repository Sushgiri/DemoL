package com.bestercapitalmedia.letwizard.es.areasuggestion;

public class AreaSuggestionES{

	 String area;
	
	public AreaSuggestionES() {
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}
	


}
 