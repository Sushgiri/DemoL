package com.bestercapitalmedia.letwizard.es.evaluation;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PropertyTypeBucket{

	@JsonProperty("key")
	 String key;
	
	public PropertyTypeBucket() {
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	

	
	

}
 