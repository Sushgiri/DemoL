package com.bestercapitalmedia.letwizard.es.evaluation;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Map;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;

import org.apache.commons.lang3.StringUtils;


@Service
public class EvaluationESService {

	public StringBuilder estimationQuery = new StringBuilder();
	public String finalQuery = "";
	public String evaluationQuery = "";

	
	public Map<String,Object> getPropertyTypesList() throws JsonParseException, JsonMappingException, IOException, JSONException  {
		
		RestClient restClient = RestClient.builder(new HttpHost(LetwizardConstants.ES_HOST, LetwizardConstants.ES_PORT, "http")).build();
			 HttpEntity entity = new StringEntity("{" + 
			 		"\"aggs\" : {" + 
			 		"\"propertyTypes\" : {" + 
			 		"\"terms\" : {" + 
			 		"\"field\" : \"property_type\"," + 
			 		"\"size\":50 " + 
			 		"\r\n" + 
			 		"}" + 
			 		"}}," + 
			 		"\"size\" : 0" + 
			 		"}", ContentType.APPLICATION_JSON);

			 Response getResponse = 
						restClient.performRequest("GET", LetwizardConstants.EVALUATION_GADGET_SERVER_PATH,Collections.<String, String>emptyMap(), entity);
			       
		        HttpEntity httpEntity = getResponse.getEntity();
		        String result = null;
		        Map<String,Object> mapResponse = null;
		        if (entity != null) {
		            InputStream instream = getResponse.getEntity().getContent();
		            result = ChiragUtill.convertStreamToString(instream);
//		            JSONObject myObject = new JSONObject(result);
		            ObjectMapper mapper = new ObjectMapper();
//		            System.out.println("RESPONSE: " + result);						
					mapResponse = mapper.readValue(result, Map.class);
		        }
				 
				return mapResponse;
	
	}
	

	public Map<String,Object> getEstimatedPropertyValue(EstimationESRequestDTO estimationESRequestDTO) {
		try {

			
			Map<String,Object> estimationResponse =  null;
			
//			if(estimationESRequestDTO.getSize_sqm() != null) {
//				estimationESRequestDTO.setSize_sqf(String.valueOf(Float.parseFloat(estimationESRequestDTO.getSize_sqm()) * 10.764)); 
//				System.out.println("Sqm :" + estimationESRequestDTO.getSize_sqm());
//				System.out.println("sqm to sqf: " + estimationESRequestDTO.getSize_sqf() );
//			}
		
	 	if (StringUtils.isEmpty(estimationESRequestDTO.getActivity()) && 
	 			StringUtils.isEmpty(estimationESRequestDTO.getArea()) && 
	 			StringUtils.isEmpty(estimationESRequestDTO.getCommunity())&& 
	 			StringUtils.isEmpty(estimationESRequestDTO.getProperty_type()) && 
	 			estimationESRequestDTO.getBeds() == null 
//	 			&& 
//	 			StringUtils.isEmpty(estimationESRequestDTO.getSize_sqf())
				) {

			return null;
		      }
	 	else if (!StringUtils.isEmpty(estimationESRequestDTO.getActivity()) && 
	 			 !StringUtils.isEmpty(estimationESRequestDTO.getArea()) && 
	 			 !StringUtils.isEmpty(estimationESRequestDTO.getCommunity())&& 
	 			 !StringUtils.isEmpty(estimationESRequestDTO.getProperty_type()) && 
	 			  estimationESRequestDTO.getBeds() != null 
//	 			  && 
//	 			 !StringUtils.isEmpty(estimationESRequestDTO.getSize_sqf()) 
                ) {

	 		
	 		estimationQuery.append("{" + 
	 				"\"query\": { " + 
	 				"\"bool\" : {" + 
	 				"\"must\" : [" +
	 				"{\"match\": { \"activity\":\""+estimationESRequestDTO.getActivity()+"\" }}," + 
	 				"{\"match\": { \"area\":\""+estimationESRequestDTO.getArea()+"\" }}," + 
	 				"{\"match\": { \"community\":\""+estimationESRequestDTO.getCommunity()+"\" }}," + 
	 				"{\"match\": { \"property_type\":\""+estimationESRequestDTO.getProperty_type()+"\" }}" );
	 		
	 		 		
	 		 		if(!StringUtils.isEmpty(estimationESRequestDTO.getOperator())) {
	 		 			estimationQuery.append(", { \"range\": { \"beds\":     {\"gt\":"+estimationESRequestDTO.getBeds()+"}  }}");
	 				}
	 		 		else {
	 		 			estimationQuery.append(", { \"term\": { \"beds\":       "+estimationESRequestDTO.getBeds()+" }}");
	 		 		}
	 		 		
	 		 		estimationQuery.append("]" + 
	 		 				"}" + 
	 		 				"}," + 
	 		 				"\"aggs\" : {" + 
	 		 				"\"max_estimation\" : { \"max\" : { \"field\" : \"price_aed\" } }," + 
	 		 				"\"min_estimation\" : { \"min\" : { \"field\" : \"price_aed\" } }," + 
	 		 				"\"avg_estimation\" : { \"avg\" : { \"field\" : \"price_aed\" } }," + 
	 		 				"\"median_estimation\": { \"percentiles\": {\"field\": \"price_aed\",\"percents\": [50]}}" + 
	 		 				"}" + 
	 		 				"}");
	 		 		
	 		 		evaluationQuery = estimationQuery.toString();
	 		 		String finalquery = evaluationQuery.replace("-#", " ");
			        estimationResponse = eventESCall(finalquery);

					if (estimationResponse == null) {

						return null;

					} else {
						return estimationResponse;
					}
				}

				else {
					

					if (!StringUtils.isEmpty(estimationESRequestDTO.getArea())) {
						if (evaluationQuery.length() == 0) {
							estimationQuery.append("{" + 
					 				"\"query\": { " + 
					 				"\"bool\" : {" + 
					 				"\"must\" : [" +
					 				"{\"match\": { \"area\":\""+estimationESRequestDTO.getArea()+"\" }}" );
						}
						else {
							estimationQuery.append(",{\"match\": { \"area\":\""+estimationESRequestDTO.getArea()+"\" }}");
						}
						evaluationQuery = estimationQuery.toString();
					}
					if (!StringUtils.isEmpty(estimationESRequestDTO.getActivity())) {
						
						if (evaluationQuery.length() == 0) {
							estimationQuery.append("{" + 
					 				"\"query\": { " + 
					 				"\"bool\" : {" + 
					 				"\"must\" : [" +
					 				"{\"match\": { \"activity\":\""+estimationESRequestDTO.getActivity()+"\" }}" );
						}
						else {
							estimationQuery.append(",{\"match\": { \"activity\":\""+estimationESRequestDTO.getActivity()+"\" }}");
						}
						evaluationQuery = estimationQuery.toString();
					}
					
					if (!StringUtils.isEmpty(estimationESRequestDTO.getCommunity())) {
						
						if (evaluationQuery.length() == 0) {
							estimationQuery.append("{" + 
					 				"\"query\": { " + 
					 				"\"bool\" : {" + 
					 				"\"must\" : [" +
					 				"{\"match\": { \"community\":\""+estimationESRequestDTO.getCommunity()+"\" }}" );
						}
						else{
							estimationQuery.append(",{\"match\": { \"community\":\""+estimationESRequestDTO.getCommunity()+"\" }}");
						}
						evaluationQuery = estimationQuery.toString();

					}
					if (!StringUtils.isEmpty(estimationESRequestDTO.getProperty_type())) {
						
						if (StringUtils.isEmpty(evaluationQuery)) {
							estimationQuery.append("{" + 
					 				"\"query\": { " + 
					 				"\"bool\" : {" + 
					 				"\"must\" : [" +
					 				"{\"match\": { \"property_type\":\""+estimationESRequestDTO.getProperty_type()+"\" }}" );
						}
						else{
							estimationQuery.append(",{\"match\": { \"property_type\":\""+estimationESRequestDTO.getProperty_type()+"\" }}");
						}
						evaluationQuery = estimationQuery.toString();

					}
					if (estimationESRequestDTO.getBeds() != null) {
						
						if(!StringUtils.isEmpty(estimationESRequestDTO.getOperator())) {
							if (evaluationQuery.length() == 0) {
								estimationQuery.append("{" + 
						 				"\"query\": { " + 
						 				"\"bool\" : {" + 
						 				"\"must\" : [" +
						 				"{ \"range\": { \"beds\":     {\"gt\":"+estimationESRequestDTO.getBeds()+"}  }}");
							}
							else{
								estimationQuery.append(", { \"range\": { \"beds\":     {\"gt\":"+estimationESRequestDTO.getBeds()+"}  }}");
							}
							evaluationQuery = estimationQuery.toString();

		 				}
						else {
							if (evaluationQuery.length() == 0) {
								estimationQuery.append("{" + 
						 				"\"query\": { " + 
						 				"\"bool\" : {" + 
						 				"\"must\" : [" +
						 				"{ \"term\": { \"beds\":       "+estimationESRequestDTO.getBeds()+" }}");
							}
							else{
								estimationQuery.append(", { \"term\": { \"beds\":       "+estimationESRequestDTO.getBeds()+" }}");
							}
							evaluationQuery = estimationQuery.toString();

						}
						
					}
					
					estimationQuery.append("]" + 
	 		 				"}" + 
	 		 				"}," + 
	 		 				"\"aggs\" : {" + 
	 		 				"\"max_estimation\" : { \"max\" : { \"field\" : \"price_aed\" } }," + 
	 		 				"\"min_estimation\" : { \"min\" : { \"field\" : \"price_aed\" } }," + 
	 		 				"\"avg_estimation\" : { \"avg\" : { \"field\" : \"price_aed\" } }," + 
	 		 				"\"median_estimation\": { \"percentiles\": {\"field\": \"price_aed\",\"percents\": [50]}}" + 
	 		 				"}" + 
	 		 				"}");
					evaluationQuery = estimationQuery.toString();
	 		 		String finalquery = evaluationQuery.replace("-#", " ");
			        estimationResponse = eventESCall(finalquery);

					if (estimationResponse == null) {

						return null;

					} else {
						
							return estimationResponse;

						}
					}
			
	} catch (Exception e) {
		return  null;
	}
}

	private Map<String,Object> eventESCall(String finalQuery) throws IOException {
	
		RestClient restClient = RestClient.builder(new HttpHost(LetwizardConstants.ES_HOST, LetwizardConstants.ES_PORT, "http")).build();

		 HttpEntity entity = new StringEntity(finalQuery, ContentType.APPLICATION_JSON);

			 Response getResponse = 
						restClient.performRequest("GET", LetwizardConstants.EVALUATION_GADGET_SERVER_PATH,Collections.<String, String>emptyMap(), entity);
			       
		        HttpEntity httpEntity = getResponse.getEntity();
		        String result = null;
		        Map<String,Object> mapResponse = null;
		        if (entity != null) {
		            InputStream instream = getResponse.getEntity().getContent();
		            result = ChiragUtill.convertStreamToString(instream);
//		            JSONObject myObject = new JSONObject(result);
		            ObjectMapper mapper = new ObjectMapper();
//		            System.out.println("RESPONSE: " + result);						
					mapResponse = mapper.readValue(result, Map.class);
		        }
		        return mapResponse;
	}
	
}