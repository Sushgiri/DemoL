package com.bestercapitalmedia.letwizard.es.evaluation;

public class EstimationESRequestDTO {

	 String activity;
	 String area;
	 String community;
	 String property_type;
	 Integer beds;
	 String size_sqf;
	 String size_sqm;
	 String unit;
	 String operator;

	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCommunity() {
		return community;
	}
	public void setCommunity(String community) {
		this.community = community;
	}
	public String getProperty_type() {
		return property_type;
	}
	public void setProperty_type(String property_type) {
		this.property_type = property_type;
	}
	public Integer getBeds() {
		return beds;
	}
	public void setBeds(Integer beds) {
		this.beds = beds;
	}
	public String getSize_sqf() {
		return size_sqf;
	}
	public void setSize_sqf(String size_sqf) {
		this.size_sqf = size_sqf;
	}
	public String getSize_sqm() {
		return size_sqm;
	}
	public void setSize_sqm(String size_sqm) {
		this.size_sqm = size_sqm;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	} 

}
