package com.bestercapitalmedia.letwizard.es.evaluation;

import java.util.List;

public class EstimationESResponseDTO {

		List<String> area;

		public EstimationESResponseDTO() {
		}

		public List<String> getArea() {
			return area;
		}

		public void setArea(List<String> area) {
			this.area = area;
		}
		
		
	    
	}
