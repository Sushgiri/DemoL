package com.bestercapitalmedia.letwizard.es.evaluation;

import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.ElasticsearchMessages;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/elasticsearch/evaluation")
public class EvaluationESController {

	private static final Logger log = LoggerFactory.getLogger(EvaluationESController.class);

	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private EvaluationESService evaluationESService;

	  @RequestMapping(value = "/propertytypes", method = RequestMethod.GET)
	  public ResponseEntity getPropertyTypes() {
			try {
				Map<String,Object> propertyTypesList  = evaluationESService.getPropertyTypesList();
			if( propertyTypesList == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_NOT_FOUND,
						null);
			}
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(propertyTypesList).collect(Collectors.toList()));
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
						ElasticsearchMessages.INTERNAL_SERVER_ERROR_MSG, null);
			}
	  }
	  

		@RequestMapping(value = "/estimations", method = RequestMethod.POST)
		public ResponseEntity getEstimantion(@RequestBody EstimationESRequestDTO estimationESRequestDTO,
				HttpServletRequest httpServletRequest) {
			try {

				Map<String,Object> estimationResponse = evaluationESService.getEstimatedPropertyValue(estimationESRequestDTO);
				if (estimationResponse == null) {
					return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_NOT_FOUND,
							null);
				}
				
				else {
					return  responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
							Stream.of(estimationResponse).collect(Collectors.toList()));
				}

			} catch (Exception e) {
				log.error(e.getMessage(), e);
				return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
						ElasticsearchMessages.INTERNAL_SERVER_ERROR_MSG, null);
			}
		}

}
