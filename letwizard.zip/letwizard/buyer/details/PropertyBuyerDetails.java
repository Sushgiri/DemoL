
package com.bestercapitalmedia.letwizard.buyer.details;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonBackReference;
import org.hibernate.envers.NotAudited;

import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcess;
import com.bestercapitalmedia.letwizard.company.representative.CompanyLegalRepresentative;

/**
 */

@Entity

@Table(name = "propertybuyerdetails")
public class PropertyBuyerDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "property_Buyer_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)	
	Integer propertyBuyerId;
	/**
	 */

	@Column(name = "first_Name", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String firstName;
	/**
	 */
	@Column(name = "telephone_Code")
	String telephoneCode;

	@Column(name = "mobile_Code")
	String mobileCode;

	@Column(name = "middle_Name", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String middleName;
	/**
	 */

	@Column(name = "poa_Status", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String poaStatus;

	
	@Column(name = "nationality_Other", length = 100)
	@Basic(fetch = FetchType.EAGER)

	
	String nationalityOther;
	@Column(name = "last_Name", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String lastName;
	/**
	 */


	@Column(name = "passport_No", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String passportNo;
	/**
	 */

	@Column(name = "telephone", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String telephone;
	/**
	 */

	@Column(name = "mobile", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String mobile;
	/**
	 */

	@Column(name = "address", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String address;
	/**
	 */

	@Column(name = "nationality", length = 25)
	@Basic(fetch = FetchType.EAGER)

	String nationality;
	

	//@Column(name = "poa_Clear_Deed_Upload", length = 25)
	//@Basic(fetch = FetchType.EAGER)

	
	//String poaClearDeedUpload;
	/**
	 */

	@Column(name = "id_Card_No", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String idCardNo;
	/**
	 */

	@Column(name = "id_Card_Expiration", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String idCardExpiration;
	/**
	 */

	@Column(name = "passport_Id_Document_Upload", length = 45)
	@Basic(fetch = FetchType.EAGER)


	String passportIdDocumentUpload;
	/**
	 */

	@Column(name = "passport_Expiry_Date", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String passportExpiryDate;
	/**
	 */

	@Column(name = "email", length = 45)
	@Basic(fetch = FetchType.EAGER)

	String email;
	/**
	 */

	@Column(name = "email_Verification_Code", length = 45)
	@Basic(fetch = FetchType.EAGER)

	String emailVerificationCode;
	/**
	 */

	@Column(name = "pobox", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String pobox;
	/**
	 */

	@Column(name = "passport_Copy_Upload", length = 45)
	@Basic(fetch = FetchType.EAGER)


	String passportCopyUpload;
	/**
	 */

	@Column(name = "id_Copy_Upload", length = 45)
	@Basic(fetch = FetchType.EAGER)


	String idCopyUpload;
	/**
	 */

	@Column(name = "owner_Type", length = 10)
	@Basic(fetch = FetchType.EAGER)


	String ownerType;
	/**
	 */

	@Column(name = "poa_Agreement_Expiry", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String poaAgreementExpiry;
	/**
	 */

	@Column(name = "poa_Property_Authority", length = 10)
	@Basic(fetch = FetchType.EAGER)

	String poaPropertyAuthority;
	/**
	 */

	//@Column(name = "title_Deed_Upload", length = 25)
	//@Basic(fetch = FetchType.EAGER)

	//String titleDeedUpload;
	/**
	 */

	@Column(name = "scanned_Notorized_Copy", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String scannedNotorizedCopy;
	/**
	 */

	@Column(name = "is_Poa_Accepted")
	@Basic(fetch = FetchType.EAGER)

	String isPoaAccepted;

	@Column(name = "specific_Property")
	@Basic(fetch = FetchType.EAGER)

	String specificProperty;
	
	@Column(name = "poa_Number")
	@Basic(fetch = FetchType.EAGER)

	String poaNumber;
	
	@Column(name = "other_document", length=100)
	@Basic(fetch = FetchType.EAGER)


	String otherDocument;
	
	

	@Column(name = "category")
	@Basic(fetch = FetchType.EAGER)

	String category;

	@Column(name = "company_name")
	@Basic(fetch = FetchType.EAGER)

	String companyName;

	@Column(name = "license_number")
	@Basic(fetch = FetchType.EAGER)

	String licenseNumber;

	@Column(name = "license_issued_by")
	@Basic(fetch = FetchType.EAGER)

	String licenseIssuedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "license_issue_date")
	@Basic(fetch = FetchType.EAGER)
	Date licenseIssueDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "license_expiry_date")
	@Basic(fetch = FetchType.EAGER)
	Date licenseExpiryDate;

	@Column(name = "year_established")
	@Basic(fetch = FetchType.EAGER)

	Date yearEstablished;

	@Column(name = "website")
	@Basic(fetch = FetchType.EAGER)

	String website;
	
	@Column(name = "company_document_license")
	@Basic(fetch = FetchType.EAGER)

	String companyDocumentLicense;

	@Column(name = "company_document_moa")
	@Basic(fetch = FetchType.EAGER)

	String companyDocumentMoa;

//	/** The chiraghuser. */
//	@ManyToOne(fetch = FetchType.LAZY)
//	@JoinColumns({ @JoinColumn(name = "user_Id", referencedColumnName = "user_Id") })
//	@JsonBackReference
//	@NotAudited
//	Chiraghuser chiraghuser;

//	/** The country. */
//	@NotAudited
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumns({ @JoinColumn(name = "country_id", referencedColumnName = "country_Id") })
//	@JsonBackReference
//	Country country;
//	

	@NotAudited
	@OneToMany(mappedBy = "propertyBuyerDetails", cascade = { CascadeType.REMOVE }, fetch = FetchType.LAZY)
	java.util.List<CompanyLegalRepresentative> companylegalrepresentatives;
	
	
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "buyer_Process_Id", referencedColumnName = "buyer_Process_Id") })
	@JsonBackReference
	BuyerProcess buyerprocess;

//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumns({ @JoinColumn(name = "country_id", referencedColumnName = "country_Id") })
//	@JsonBackReference
//	Country country;
//	
////	@Column(name="country_id",updatable=false,insertable=false)
////	int countryid;
//	
//	
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumns({ @JoinColumn(name = "city_id", referencedColumnName = "city_Id") })
//	@JsonBackReference
//	City city;
	
	@Column(name="country_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	Integer countryId;
	
//	@Column(name="country_id",updatable=false,insertable=false)
//	int countryid;
	
//	@NotAudited
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumns({ @JoinColumn(name = "city_id", referencedColumnName = "city_Id") })
//	@JsonBackReference
//	City city;
	
	@Column(name="city_id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	Integer cityId;
	
	@Column(name = "no_poa_expiry")
	Boolean noPoaExpiry;
	
	@Column(name = "category_other")
	@Basic(fetch = FetchType.EAGER)
	String categoryOther;
	
	@Column(name = "license_other")
	@Basic(fetch = FetchType.EAGER)
	String licenseOther;
	
	
	public void setPropertyBuyerId(Integer propertyBuyerId) {
		this.propertyBuyerId = propertyBuyerId;
	}

	/**
	 */
	public Integer getPropertyBuyerId() {
		return this.propertyBuyerId;
	}

	/**
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 */
	public String getMiddleName() {
		return this.middleName;
	}

	/**
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 */
	public String getLastName() {
		return this.lastName;
	}


	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	/**
	 */
	public String getPassportNo() {
		return this.passportNo;
	}

	/**
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 */
	public String getTelephone() {
		return this.telephone;
	}

	/**
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 */
	public String getMobile() {
		return this.mobile;
	}

	/**
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	/**
	 */
	public String getNationality() {
		return this.nationality;
	}
	/*public void setPoaClearDeedUpload(String poaClearDeedUpload) {
		this.poaClearDeedUpload = poaClearDeedUpload;
	}

	public String getPoaClearDeedUpload() {
		return this.poaClearDeedUpload;
	}
	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	} */
	
	public String getIdCardNo() {
		return this.idCardNo;
	}

	/**
	 */
	public void setIdCardExpiration(String idCardExpiration) {
		this.idCardExpiration = idCardExpiration;
	}

	/**
	 */
	public String getIdCardExpiration() {
		return this.idCardExpiration;
	}

	/**
	 */
	public void setPassportIdDocumentUpload(String passportIdDocumentUpload) {
		this.passportIdDocumentUpload = passportIdDocumentUpload;
	}

	/**
	 */
	public String getPassportIdDocumentUpload() {
		return this.passportIdDocumentUpload;
	}

	/**
	 */
	public void setPassportExpiryDate(String passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	/**
	 */
	public String getPassportExpiryDate() {
		return this.passportExpiryDate;
	}

	/**
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 */
	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	/**
	 */
	public String getEmailVerificationCode() {
		return this.emailVerificationCode;
	}

	/**
	 */
	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	/**
	 */
	public String getPobox() {
		return this.pobox;
	}

	/**
	 */
	public void setPassportCopyUpload(String passportCopyUpload) {
		this.passportCopyUpload = passportCopyUpload;
	}

	/**
	 */
	public String getPassportCopyUpload() {
		return this.passportCopyUpload;
	}

	/**
	 */
	public void setIdCopyUpload(String idCopyUpload) {
		this.idCopyUpload = idCopyUpload;
	}

	/**
	 */
	public String getIdCopyUpload() {
		return this.idCopyUpload;
	}

	/**
	 */
	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	/**
	 */
	public String getOwnerType() {
		return this.ownerType;
	}

	/**
	 */
	public void setPoaAgreementExpiry(String poaAgreementExpiry) {
		this.poaAgreementExpiry = poaAgreementExpiry;
	}

	/**
	 */
	public String getPoaAgreementExpiry() {
		return this.poaAgreementExpiry;
	}

	/**
	 */
	public void setPoaPropertyAuthority(String poaPropertyAuthority) {
		this.poaPropertyAuthority = poaPropertyAuthority;
	}

	/**
	 */
	public String getPoaPropertyAuthority() {
		return this.poaPropertyAuthority;
	}

	/*
	public void setTitleDeedUpload(String titleDeedUpload) {
		this.titleDeedUpload = titleDeedUpload;
	}

	public String getTitleDeedUpload() {
		return this.titleDeedUpload;
	}

	 */
	public void setScannedNotorizedCopy(String scannedNotorizedCopy) {
		this.scannedNotorizedCopy = scannedNotorizedCopy;
	}

	/**
	 */
	public String getScannedNotorizedCopy() {
		return this.scannedNotorizedCopy;
	}

	/**
	 */
	

	/**
	 */
	public void setBuyerProcess(BuyerProcess buyerprocess) {
		this.buyerprocess = buyerprocess;
	}

	/**
	 */
	public BuyerProcess getBuyerProcess() {
		return buyerprocess;
	}

	
	public PropertyBuyerDetails() {
	}

	public String getIsPoaAccepted() {
		return isPoaAccepted;
	}

	public void setIsPoaAccepted(String isPoaAccepted) {
		this.isPoaAccepted = isPoaAccepted;
	}

//	public BuyerProcess getBuyerprocess() {
//		return buyerprocess;
//	}
//
//	public void setBuyerprocess(BuyerProcess buyerprocess) {
//		this.buyerprocess = buyerprocess;
//	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}

	public String getSpecificProperty() {
		return specificProperty;
	}

	public void setSpecificProperty(String specificProperty) {
		this.specificProperty = specificProperty;
	}

	public String getPoaNumber() {
		return poaNumber;
	}

	public void setPoaNumber(String poaNumber) {
		this.poaNumber = poaNumber;
	}

	public String getNationalityOther() {
		return nationalityOther;
	}

	public void setNationalityOther(String nationalityOther) {
		this.nationalityOther = nationalityOther;
	}

	public String getPoaStatus() {
		return poaStatus;
	}

	public void setPoaStatus(String poaStatus) {
		this.poaStatus = poaStatus;
	}

	public String getTelephoneCode() {
		return telephoneCode;
	}

	public void setTelephoneCode(String telephoneCode) {
		this.telephoneCode = telephoneCode;
	}

	public String getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}

	

	public String getOtherDocument() {
		return otherDocument;
	}

	public void setOtherDocument(String otherDocument) {
		this.otherDocument = otherDocument;
	}

	public Integer getCountryId() {
		return countryId;
	}

	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	public Integer getCityId() {
		return cityId;
	}

	public void setCityId(Integer cityId) {
		this.cityId = cityId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public String getLicenseIssuedBy() {
		return licenseIssuedBy;
	}

	public void setLicenseIssuedBy(String licenseIssuedBy) {
		this.licenseIssuedBy = licenseIssuedBy;
	}

	public Date getLicenseIssueDate() {
		return licenseIssueDate;
	}

	public void setLicenseIssueDate(Date licenseIssueDate) {
		this.licenseIssueDate = licenseIssueDate;
	}

	public Date getLicenseExpiryDate() {
		return licenseExpiryDate;
	}

	public void setLicenseExpiryDate(Date licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}

	public Date getYearEstablished() {
		return yearEstablished;
	}

	public void setYearEstablished(Date yearEstablished) {
		this.yearEstablished = yearEstablished;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

//	public Chiraghuser getChiraghuser() {
//		return chiraghuser;
//	}
//
//	public void setChiraghuser(Chiraghuser chiraghuser) {
//		this.chiraghuser = chiraghuser;
//	}

	public java.util.List<CompanyLegalRepresentative> getCompanylegalrepresentatives() {
		return companylegalrepresentatives;
	}

	public void setCompanylegalrepresentatives(java.util.List<CompanyLegalRepresentative> companylegalrepresentatives) {
		this.companylegalrepresentatives = companylegalrepresentatives;
	}

	public BuyerProcess getBuyerprocess() {
		return buyerprocess;
	}

	public void setBuyerprocess(BuyerProcess buyerprocess) {
		this.buyerprocess = buyerprocess;
	}

	public String getCompanyDocumentLicense() {
		return companyDocumentLicense;
	}

	public void setCompanyDocumentLicense(String companyDocumentLicense) {
		this.companyDocumentLicense = companyDocumentLicense;
	}

	public String getCompanyDocumentMoa() {
		return companyDocumentMoa;
	}

	public void setCompanyDocumentMoa(String companyDocumentMoa) {
		this.companyDocumentMoa = companyDocumentMoa;
	}

	public Boolean isNoPoaExpiry() {
		return noPoaExpiry;
	}

	public void setNoPoaExpiry(Boolean noPoaExpiry) {
		this.noPoaExpiry = noPoaExpiry;
	}

	public String getCategoryOther() {
		return categoryOther;
	}

	public void setCategoryOther(String categoryOther) {
		this.categoryOther = categoryOther;
	}

	public String getLicenseOther() {
		return licenseOther;
	}

	public void setLicenseOther(String licenseOther) {
		this.licenseOther = licenseOther;
	}

	
	
	
	
	
}
