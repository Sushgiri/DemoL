package com.bestercapitalmedia.letwizard.buyer.details;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.seller.details.Propertysellerdetails;

public interface PropertyBuyerDetailsRepository extends CrudRepository<PropertyBuyerDetails, Integer> {

	@Query(value = "Select * from propertybuyerdetails;", nativeQuery = true)
	public List<PropertyBuyerDetails> getAll();
	
	
	@Query(value = "select * from propertybuyerdetails where buyer_Process_Id=?1 And owner_Type='owner'", nativeQuery = true)
	public List<PropertyBuyerDetails> findBuyerOwnerById(int buyerProcessId);
	
	@Query(value = "select * from propertybuyerdetails where buyer_Process_Id=?1 And owner_Type='poa'", nativeQuery = true)
	public List<PropertyBuyerDetails> findBuyerPOAByBId(int buyerProcessId);
		
	@Query(value = "Select * from propertybuyerdetails where buyer_Process_Id=?1", nativeQuery = true)
	public List<PropertyBuyerDetails> findBuyerByProcessId(int BuyerProcessId);
	
	@Query(value = "select * from propertybuyerdetails where property_Buyer_Id=?1 ", nativeQuery = true)
	public PropertyBuyerDetails findBuyerById(int property_Buyer_Id);

	@Query(value = "SELECT * FROM propertybuyerdetails WHERE buyer_Process_Id=(SELECT buyer_Process_Id FROM buyerprocess WHERE property_Id = ?1 AND user_Id = (SELECT user_Id FROM propertybidfinalize WHERE property_Id = ?1 AND seller_Confirm =1 AND buyer_Confirm =1))", nativeQuery = true)
	public List<PropertyBuyerDetails> findBuyerByPropertyId(int propertyId);
	
	@Query(value = "SELECT * FROM propertybuyerdetails WHERE property_Buyer_Id=?1 AND owner_Type='company'  ", nativeQuery = true)
	public PropertyBuyerDetails findCompanyById(int propertyBuyerId);
	
	@Query(value = "SELECT * FROM propertybuyerdetails WHERE buyer_Process_Id=?1 AND owner_Type='company'  ", nativeQuery = true)
	public List<PropertyBuyerDetails> findByCompanyByBuyerProcessId(int BuyerProcessId);

	@Query(value = "SELECT * FROM propertybuyerdetails WHERE buyer_Process_Id=(SELECT buyer_Process_Id FROM buyerprocess WHERE property_Id = ?1 AND user_Id = (SELECT user_Id FROM propertybidfinalize WHERE property_Id = ?1 AND seller_Confirm =1 AND buyer_Confirm =1 AND process_Type = 'buy_now' limit 1 ))", nativeQuery = true)
	public PropertyBuyerDetails findBuyNowUser(int propertyId);
	
	@Query(value = "Select * from propertybuyerdetails where buyer_Process_Id=?1 order by property_Buyer_Id desc limit 1", nativeQuery = true)
	public PropertyBuyerDetails findLatestBuyerByProcessId(int BuyerProcessId);

}
