package com.bestercapitalmedia.letwizard.buyer.details;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcess;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcessRepository;
import com.bestercapitalmedia.letwizard.constants.BuyerMessages;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.mail.MailService;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.bidprocess.BidProcessComposite;
import com.bestercapitalmedia.letwizard.property.bidprocess.BidProcessService;
import com.bestercapitalmedia.letwizard.property.bidprocess.PropertyBidDTO;
import com.bestercapitalmedia.letwizard.property.bidprocess.Propertybidprocess;
import com.bestercapitalmedia.letwizard.property.bidprocess.PropertybidprocessRepository;
import com.bestercapitalmedia.letwizard.seller.details.RequestPropertyCompanyDetailsDTO;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.Document;
import com.bestercapitalmedia.letwizard.utill.LogUtill;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin
@RequestMapping("/api/buyerdetails")
public class PropertyBuyerDetailsController {

	private static final Logger logger = LoggerFactory.getLogger(PropertyBuyerDetailsController.class);
	@Autowired
	private PropertyBuyerDetailsRepository propertybuyerdetailRepository;
	@Autowired
	private ChiragUtill chiragUtill;
	@Autowired
	private MailService mailService;
	@Autowired
	private PropertyRepository propertyRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PropertyBuyerDetailsService propertybuyerdetailsservice;
	@Autowired
	private LogUtill logUtill;
	@Autowired
	private BuyerProcessRepository buyerprocessRepository;
	@Autowired
	private Document document;
	@Autowired
	private ResponseUtill responseUtill;
	@Autowired
	private BidProcessService bidProcessService;
	@Autowired
	private PropertyRepository letWizardproperty;

	@Autowired
	private PropertybidprocessRepository propertybidprocessRepository;

	List<String> files = new ArrayList<String>();

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/propertyCompanyDetails", method = RequestMethod.PUT)
	public ResponseEntity updateCompantDetails(@RequestBody RequestPropertyCompanyDetailsDTO propertyCompanyDetailsDTO,
			HttpServletRequest httpServletRequest) {
		return propertybuyerdetailsservice.updatePropertyCompanyDetails(propertyCompanyDetailsDTO);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/propertyCompanyDetails", method = RequestMethod.POST)
	public ResponseEntity saveCompanyDetails(@RequestBody RequestPropertyCompanyDetailsDTO propertyCompanyDetailsDTO,
			HttpServletRequest httpServletRequest) {
		return propertybuyerdetailsservice.savePropertyCompanyDetails(propertyCompanyDetailsDTO);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/propertyCompanyDetails/{buyerProcessId}", method = RequestMethod.GET)
	public ResponseEntity getPropertyCompaniesDetails(@PathVariable(value = "buyerProcessId") int buyerProcessId,
			HttpServletRequest httpServletRequest) {
		return propertybuyerdetailsservice.getPropertyCompaniesDetails(buyerProcessId);
	}// end of getCompanyOwner

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{propertyBuyerId}", method = RequestMethod.DELETE)
	public ResponseEntity DeletePoa(@PathVariable(value = "propertyBuyerId") int propertyBuyerId,
			HttpServletRequest httpServletRequest) {
		try {
			PropertyBuyerDetails buyerinfo = propertybuyerdetailRepository.findBuyerById(propertyBuyerId);
			if (buyerinfo == null)
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.DATA_NOT_FOUND, null);
			else
				propertybuyerdetailRepository.delete(buyerinfo);
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, SellerMessages.RESOURCE_DELETED_SUCESSFULLY,
					null);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getOwnerBuyerDetails/{propertyId}/{userName}", method = RequestMethod.GET)
	public ResponseEntity getOwnerDetailsById(@PathVariable(value = "propertyId") int propertyId,
			@PathVariable(value = "userName") String userName, HttpServletRequest httpServletRequest) {
		try {
			userName = chiragUtill.getUserNameFromAuthentication();

			ModelMapper mapper = new ModelMapper();
			ObjectMapper objectMapper = new ObjectMapper();
			Chiraghuser chiraghuser1 = userRepository.findByUserName(userName);
			if (chiraghuser1 == null) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_RETRIEVED_FAILURE, null);
			}

			int userId = chiraghuser1.getUserId();
			System.out.println("user id" + userId);
			BuyerProcess buyerprocess = buyerprocessRepository.findBuyerExisting(userId, propertyId);

			if (buyerprocess == null) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_RETRIEVED_FAILURE, null);
			}

			else {

				int buyerhistory = buyerprocess.getBuyerProcessId();
				System.out.println("buyer process id " + buyerhistory);
				List<PropertyBuyerDetails> propertybuyerownerdetailsdto = new ArrayList<>();
				propertybuyerownerdetailsdto = propertybuyerdetailRepository.findBuyerOwnerById(buyerhistory);

				List<PropertyBuyerDetailDTO> propertybuyerownerdetailsDTO = ObjectMapperUtils
						.mapAll(propertybuyerownerdetailsdto, PropertyBuyerDetailDTO.class);

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_RETRIEVED_SUCCESS,
						propertybuyerownerdetailsDTO);
			}
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getPOABuyerDetails/{propertyId}/{userName}", method = RequestMethod.GET)
	public ResponseEntity getPOADetailsById(@PathVariable(value = "propertyId") int propertyId,
			@PathVariable(value = "userName") String userName, HttpServletRequest httpServletRequest) {
		try {
			userName = chiragUtill.getUserNameFromAuthentication();

			ModelMapper mapper = new ModelMapper();
			ObjectMapper objectMapper = new ObjectMapper();

			Chiraghuser chiraghuser1 = userRepository.findByUserName(userName);

			if (chiraghuser1 == null) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_RETRIEVED_FAILURE, null);
			}
			int userId = chiraghuser1.getUserId();

			BuyerProcess buyerprocess = buyerprocessRepository.findBuyerExisting(userId, propertyId);
			// BuyerProcess buyerprocess = buyerprocessRepository
			// .findBuyerByPropertyId(propertyId);

			if (buyerprocess == null) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_RETRIEVED_FAILURE, null);
			} else {
				int buyerhistory = buyerprocess.getBuyerProcessId();
				List<PropertyBuyerDetails> propertybuyerpoadetailsdto = propertybuyerdetailRepository
						.findBuyerPOAByBId(buyerhistory);

				List<PropertyBuyerDetailDTO> propertybuyerpoadetailsDTO = ObjectMapperUtils
						.mapAll(propertybuyerpoadetailsdto, PropertyBuyerDetailDTO.class);

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_RETRIEVED_SUCCESS,
						propertybuyerpoadetailsDTO);
			}
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}
//	@CrossOrigin(origins = "*")
//	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
//	public @ResponseBody ResponseEntity ownerlist(HttpServletRequest httpServletRequest) {
//		
//		try {
//			if (chiraghUtill.isValidSession(httpServletRequest) == false)
//				return new ResponseEntity(chiraghUtill.getMessageObject("Invalid Session!"), HttpStatus.OK);
//	
//			ObjectMapper mapper = new ObjectMapper();
//			
//			List<PropertyBuyerDetailsDTO> propertyownerdetailsdto = (List<PropertyBuyerDetailsDTO>) propertybuyerdetailsservice
//					.getPropertyBuyerDetailsList();
//			try {
//				logUtill.inputLog(httpServletRequest, chiraghUtill.getSessionUser(httpServletRequest),
//						"/api/buyerdetails/ownerdetails/getAll", mapper.writeValueAsString(""),
//						mapper.writeValueAsString(propertyownerdetailsdto));
//			} catch (Exception e) {
//				return new ResponseEntity(chiraghUtill.getMessageObject("Log not Generated"), HttpStatus.OK);
//			}
//			
//			return new ResponseEntity(propertyownerdetailsdto, HttpStatus.OK);
//             
//		} catch (Exception e) {
//			return new ResponseEntity(chiraghUtill.getMessageObject("Internal Server Error!" + e.getMessage()),
//					HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//		
//	}// end of list method*/

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/IsBuyerExist/{propertyId}/{userName}", method = RequestMethod.GET)
	public ResponseEntity IsBuyerExist(@PathVariable(value = "propertyId") int propertyId,
			@PathVariable(value = "userName") String userName, HttpServletRequest httpServletRequest) {
		try {

			ModelMapper mapper = new ModelMapper();
			ObjectMapper objectMapper = new ObjectMapper();

			Chiraghuser chiraghuser1 = userRepository.findByUserName(userName);
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
			Map<String, Boolean> map = new HashMap<>();
			Boolean IsBuyerExist = false;
			if (chiraghuser1 == null || chiraghproperty == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, BuyerMessages.BUYER_EXIST_FAILURE, null);
			}
			int userId = chiraghuser1.getUserId();

			// CD-1719
			BuyerProcess buyerprocess = buyerprocessRepository.findBuyerExistingWithProcessType(userId, propertyId);
			// BuyerProcess buyerprocess = buyerprocessRepository
			// .findBuyerByPropertyId(propertyId);

			if (buyerprocess == null) {
				IsBuyerExist = false;
				map.put("IsBuyerExist", IsBuyerExist);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.BUYER_NOTEXIST_SUCCESS,
						Stream.of(map).collect(Collectors.toList()));
			} else {
				IsBuyerExist = true;
				map.put("IsBuyerExist", IsBuyerExist);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.BUYER_EXIST_SUCCESS,
						Stream.of(map).collect(Collectors.toList()));
			}
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}

	@RequestMapping(value = "/hello")
	public String getMsg() {
		return DigestUtils.md5DigestAsHex("123".getBytes());
	}

	// create buyer lead

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/createBuyerLead", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createBuyerLead(@RequestBody PropertyBuyerDetailsDTO propertyBuyerDetailDTO,
			HttpServletRequest httpServletRequest) {
		try {

			ObjectMapper mapper = new ObjectMapper();
			ResponseEntity entity = propertybuyerdetailsservice.createbuyerlead(propertyBuyerDetailDTO,
					httpServletRequest);

			return entity;

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	
	// save buyer

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/post", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createOWNER(@Valid @RequestBody PropertyBuyerDetailsDTO propertyownerdetailsdto,
			HttpServletRequest httpServletRequest) {
		return propertybuyerdetailsservice.saveBuyerOwner(propertyownerdetailsdto, httpServletRequest);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/updateSameOwnerDetails", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity updateSameOWNERDetails(@RequestBody PropertyBuyerDetailsDTO propertyownerdetailsdto,
															   HttpServletRequest httpServletRequest) {
//		return propertybuyerdetailsservice.saveBuyerOwner(propertyownerdetailsdto, httpServletRequest);
		return propertybuyerdetailsservice.updateSameBuyerDetails(propertyownerdetailsdto, httpServletRequest);
	}


	// update buyer

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/UpdateBuyer", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity UpdateBuyer(@Valid @RequestBody PropertyBuyerDetailsDTO propertyownerdetailsdto,
			HttpServletRequest httpServletRequest) {
		return propertybuyerdetailsservice.saveBuyerOwner(propertyownerdetailsdto, httpServletRequest);
	}

	/*
	 * @RequestMapping(value = "/getAllFiles", method = RequestMethod.GET) public
	 * String getListFiles(PropertyBuyerDetails model) { String rtnObject = "";
	 * 
	 * try { // List<String> files = new ArrayList<String>(); ObjectMapper
	 * objectMapper = new ObjectMapper(); String msg = "";
	 * 
	 * List<String> fileNames = files.stream() .map(fileName ->
	 * MvcUriComponentsBuilder .fromMethodName(PropertyBuyerDetailsController.class,
	 * "getFile", fileName).build() .toString()) .collect(Collectors.toList());
	 * 
	 * rtnObject = objectMapper.writeValueAsString(fileNames);
	 * 
	 * msg = "success"; } catch (Exception ee) { throw new
	 * RuntimeException("FAIL!"); }
	 * 
	 * return rtnObject; }
	 */

	// @RequestMapping(value = "/files/{filename:.+}", method = RequestMethod.GET)
	// public Resource getFile(@PathVariable String filename) {
	//
	// Resource file = chiraghUtil.loadFile(filename);
	// return file;
	// }*/

	/**
	 * Save document.
	 *
	 * @param path               the path
	 * @param name               the name
	 * @param userName           the user name
	 * @param file               the file
	 * @param httpServletRequest the http servlet request
	 * @return the response entity
	 */
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/saveDocument/{path}/{name}/{userName}", method = RequestMethod.POST)
	public ResponseEntity saveDocument(@PathVariable(value = "path") String path,
			@PathVariable(value = "name") String name, @PathVariable(value = "userName") String userName,
			@RequestParam("file") MultipartFile file, HttpServletRequest httpServletRequest) {

		ObjectMapper mapper = new ObjectMapper();

		String fileName = document.saveMultipartFile(LetwizardConstants.IMAGE_PATH + path, name, file);
		if (fileName.equals("") || fileName.equals(null))
			return null;
		return new ResponseEntity(fileName, HttpStatus.OK);

	}

}
