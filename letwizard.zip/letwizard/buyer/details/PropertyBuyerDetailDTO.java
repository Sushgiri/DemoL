package com.bestercapitalmedia.letwizard.buyer.details;

import java.util.Date;
import java.util.List;

import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyBuyerDto;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyDto;
import com.bestercapitalmedia.letwizard.company.representative.ResponseCompanyLegalRepresentativeDTO;


public class PropertyBuyerDetailDTO {
	
	private Integer propertyBuyerId;
	private String firstName;
	private String telephoneCode;
	private String mobileCode;
	private String middleName;
	private String poaStatus;
	private String nationalityOther;
	private String lastName;
	private String passportNo;
	private String telephone;
	private String mobile;
	private String address;
	private String nationality;
	private String idCardNo;
	private String idCardExpiration;
	private String passportIdDocumentUpload;
	private String passportExpiryDate;
	private String email;
	private String emailVerificationCode;
	private String pobox;
	private String passportCopyUpload;
	private String idCopyUpload;
	private String ownerType;
	private String poaAgreementExpiry;
	private String poaPropertyAuthority;
	private String scannedNotorizedCopy;
	private String isPoaAccepted;
	private String specificProperty;
	private String poaNumber;
	private String otherDocument;
	private int buyerprocessId;
	private int countryId;
	private int cityId;
	private String category;
	private String companyName;
	private String licenseNumber;
	private String licenseIssuedBy;
	private Date licenseIssueDate;
	private Date licenseExpiryDate;
	private Date yearEstablished;
	private String website;
	private String companyDocumentLicense;
	private String companyDocumentMoa;
	private List<ResponseCompanyLegalRepresentativeDTO> companylegalrepresentatives;
	private BrokerageAgencyBuyerDto buyerBrokerageAgency;
	private String categoryOther;
	private String licenseOther;
	private Boolean noPoaExpiry;
	
	public PropertyBuyerDetailDTO() {
	}

	public Integer getPropertyBuyerId() {
		return propertyBuyerId;
	}

	public void setPropertyBuyerId(Integer propertyBuyerId) {
		this.propertyBuyerId = propertyBuyerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getTelephoneCode() {
		return telephoneCode;
	}

	public void setTelephoneCode(String telephoneCode) {
		this.telephoneCode = telephoneCode;
	}

	public String getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getPoaStatus() {
		return poaStatus;
	}

	public void setPoaStatus(String poaStatus) {
		this.poaStatus = poaStatus;
	}

	public String getNationalityOther() {
		return nationalityOther;
	}

	public void setNationalityOther(String nationalityOther) {
		this.nationalityOther = nationalityOther;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getIdCardNo() {
		return idCardNo;
	}

	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}

	public String getIdCardExpiration() {
		return idCardExpiration;
	}

	public void setIdCardExpiration(String idCardExpiration) {
		this.idCardExpiration = idCardExpiration;
	}

	public String getPassportIdDocumentUpload() {
		return passportIdDocumentUpload;
	}

	public void setPassportIdDocumentUpload(String passportIdDocumentUpload) {
		this.passportIdDocumentUpload = passportIdDocumentUpload;
	}

	public String getPassportExpiryDate() {
		return passportExpiryDate;
	}

	public void setPassportExpiryDate(String passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmailVerificationCode() {
		return emailVerificationCode;
	}

	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	public String getPobox() {
		return pobox;
	}

	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	public String getPassportCopyUpload() {
		return passportCopyUpload;
	}

	public void setPassportCopyUpload(String passportCopyUpload) {
		this.passportCopyUpload = passportCopyUpload;
	}

	public String getIdCopyUpload() {
		return idCopyUpload;
	}

	public void setIdCopyUpload(String idCopyUpload) {
		this.idCopyUpload = idCopyUpload;
	}

	public String getOwnerType() {
		return ownerType;
	}

	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	public String getPoaAgreementExpiry() {
		return poaAgreementExpiry;
	}

	public void setPoaAgreementExpiry(String poaAgreementExpiry) {
		this.poaAgreementExpiry = poaAgreementExpiry;
	}

	public String getPoaPropertyAuthority() {
		return poaPropertyAuthority;
	}

	public void setPoaPropertyAuthority(String poaPropertyAuthority) {
		this.poaPropertyAuthority = poaPropertyAuthority;
	}

	public String getScannedNotorizedCopy() {
		return scannedNotorizedCopy;
	}

	public void setScannedNotorizedCopy(String scannedNotorizedCopy) {
		this.scannedNotorizedCopy = scannedNotorizedCopy;
	}

	public String getIsPoaAccepted() {
		return isPoaAccepted;
	}

	public void setIsPoaAccepted(String isPoaAccepted) {
		this.isPoaAccepted = isPoaAccepted;
	}

	public String getSpecificProperty() {
		return specificProperty;
	}

	public void setSpecificProperty(String specificProperty) {
		this.specificProperty = specificProperty;
	}

	public String getPoaNumber() {
		return poaNumber;
	}

	public void setPoaNumber(String poaNumber) {
		this.poaNumber = poaNumber;
	}

	public String getOtherDocument() {
		return otherDocument;
	}

	public void setOtherDocument(String otherDocument) {
		this.otherDocument = otherDocument;
	}

//	public int getBuyerprocess() {
//		return buyerprocess;
//	}
//
//	public void setBuyerprocess(int buyerprocess) {
//		this.buyerprocess = buyerprocess;
//	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public int getBuyerprocessId() {
		return buyerprocessId;
	}

	public void setBuyerprocessId(int buyerprocessId) {
		this.buyerprocessId = buyerprocessId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public String getLicenseIssuedBy() {
		return licenseIssuedBy;
	}

	public void setLicenseIssuedBy(String licenseIssuedBy) {
		this.licenseIssuedBy = licenseIssuedBy;
	}

	public Date getLicenseIssueDate() {
		return licenseIssueDate;
	}

	public void setLicenseIssueDate(Date licenseIssueDate) {
		this.licenseIssueDate = licenseIssueDate;
	}

	public Date getLicenseExpiryDate() {
		return licenseExpiryDate;
	}

	public void setLicenseExpiryDate(Date licenseExpiryDate) {
		this.licenseExpiryDate = licenseExpiryDate;
	}

	public Date getYearEstablished() {
		return yearEstablished;
	}

	public void setYearEstablished(Date yearEstablished) {
		this.yearEstablished = yearEstablished;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getCompanyDocumentLicense() {
		return companyDocumentLicense;
	}

	public void setCompanyDocumentLicense(String companyDocumentLicense) {
		this.companyDocumentLicense = companyDocumentLicense;
	}

	public String getCompanyDocumentMoa() {
		return companyDocumentMoa;
	}

	public void setCompanyDocumentMoa(String companyDocumentMoa) {
		this.companyDocumentMoa = companyDocumentMoa;
	}

	public List<ResponseCompanyLegalRepresentativeDTO> getCompanylegalrepresentatives() {
		return companylegalrepresentatives;
	}

	public void setCompanylegalrepresentatives(List<ResponseCompanyLegalRepresentativeDTO> companylegalrepresentatives) {
		this.companylegalrepresentatives = companylegalrepresentatives;
	}

	public Boolean isNoPoaExpiry() {
		return noPoaExpiry;
	}

	public void setNoPoaExpiry(Boolean noPoaExpiry) {
		this.noPoaExpiry = noPoaExpiry;
	}

	public BrokerageAgencyBuyerDto getBuyerBrokerageAgency() {
		return buyerBrokerageAgency;
	}

	public void setBuyerBrokerageAgency(BrokerageAgencyBuyerDto buyerBrokerageAgency) {
		this.buyerBrokerageAgency = buyerBrokerageAgency;
	}

	public String getCategoryOther() {
		return categoryOther;
	}

	public void setCategoryOther(String categoryOther) {
		this.categoryOther = categoryOther;
	}

	public String getLicenseOther() {
		return licenseOther;
	}

	public void setLicenseOther(String licenseOther) {
		this.licenseOther = licenseOther;
	}
	
}
