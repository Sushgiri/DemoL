package com.bestercapitalmedia.letwizard.buyer.details;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bestercapitalmedia.letwizard.admin.activitylogs.AdminActivityLogsService;
import com.bestercapitalmedia.letwizard.admin.checklist.CheckListRepository;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationsService;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.PropertyCheckListPivotRepository;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.Propertychecklist;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.appointments.Appointments;
import com.bestercapitalmedia.letwizard.appointments.AppointmentsDTO;
import com.bestercapitalmedia.letwizard.appointments.AppointmentsRepository;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgency;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyBuyerDto;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyRepository;
import com.bestercapitalmedia.letwizard.buyer.leads.BuyerLeads;
import com.bestercapitalmedia.letwizard.buyer.leads.BuyerLeadsRepository;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcess;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcessRepository;
import com.bestercapitalmedia.letwizard.city.CityRepository;
import com.bestercapitalmedia.letwizard.company.representative.CompanyLegalRepresentative;
import com.bestercapitalmedia.letwizard.company.representative.CompanyLegalRepresentativeRepository;
import com.bestercapitalmedia.letwizard.company.representative.RequestCompanyLegalRepresentativeDTO;
import com.bestercapitalmedia.letwizard.company.representative.ResponseCompanyLegalRepresentativeDTO;
import com.bestercapitalmedia.letwizard.constants.BuyerMessages;
import com.bestercapitalmedia.letwizard.constants.CheckListConstants;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.country.CountryRepository;
import com.bestercapitalmedia.letwizard.imageutill.StorageService;
import com.bestercapitalmedia.letwizard.leads.LeadUtils;
import com.bestercapitalmedia.letwizard.mail.MailManager;
import com.bestercapitalmedia.letwizard.openhouse.OpenHouseService;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.seller.details.RequestPropertyCompanyDetailsDTO;
import com.bestercapitalmedia.letwizard.seller.details.ResponsePropertyCompanyDetailDTO;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.PusherUtil;
import com.bestercapitalmedia.letwizard.utill.ValidatedInput;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class PropertyBuyerDetailsService {

	private static final Logger logger = LoggerFactory.getLogger(PropertyBuyerDetailsService.class);

	@Autowired
	private PropertyBuyerDetailsRepository propertybuyerdetailsRepository;
	@Autowired
	private ValidatedInput validatedInput;
	@Autowired
	private ChiragUtill chiragUtill;
	@Autowired
	private BuyerProcessRepository buyerprocessRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PropertyRepository propertyRepository;
	@Autowired
	private StorageService storageService;

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private CityRepository cityRepository;

	@Autowired
	private BuyerLeadsRepository buyerLeadsRepository;

	@Autowired
	private ResponseUtill responseUtil;

	@Autowired
	private MailManager mailManager;

	@Autowired
	private NotificationsService notificationService;

	@Autowired
	private AdminActivityLogsService adminActivityLogsService;

	@Autowired
	private OpenHouseService openHouseService;

	@Autowired
	private AppointmentsRepository appointmentsRepository;

	private static Boolean isFound;

	@Autowired
	private CompanyLegalRepresentativeRepository companyLegalRepresentativeRepository;

	@Autowired
	private BuyerProcessRepository buyerProcessRepository;

	@Autowired 
	private BrokerageAgencyRepository brokerageAgencyRepository;
	
	@Autowired
	private PropertyCheckListPivotRepository propertyCheckListRepo;
	
	@Autowired
	private CheckListRepository checkListRepo;
	
	@Autowired
	private ResponseUtill responseUtill;
	
	// List<String> files = new ArrayList<String>();
	// private static String UPLOADED_FOLDER = "C:\\Users\\hp\\";
	public ResponseEntity updatePropertyCompanyDetails(RequestPropertyCompanyDetailsDTO propertyCompanyDetailsDTO) {
		try {

			List<ResponseCompanyLegalRepresentativeDTO> representativelist = new ArrayList<ResponseCompanyLegalRepresentativeDTO>();
			ModelMapper mapper = new ModelMapper();
			BuyerProcess buyerprocess = buyerProcessRepository
					.findBuyerProcessById(propertyCompanyDetailsDTO.getBuyerProcessId());
			if (buyerprocess == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.PROPERTY_RESOURCE_NOT_FOUND,
						null);
			}
			PropertyBuyerDetails propertyBuyerDetails = propertybuyerdetailsRepository
					.findCompanyById(propertyCompanyDetailsDTO.getPropertyBuyerId());
			if (propertyBuyerDetails == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.COMPANY_RESOURCE_NOT_FOUND,
						null);
			}
			propertyBuyerDetails = mapper.map(propertyCompanyDetailsDTO, PropertyBuyerDetails.class);
			
			// ----add brokerage Agency-----
			//  Ref : CD-1907 commenting checks
			if (propertyCompanyDetailsDTO.getBuyerBrokerageAgency() != null) {
//				BrokerageAgency brokerageAgency = brokerageAgencyRepository.getByReraNumberAndUserId(
//						propertyCompanyDetailsDTO.getBuyerBrokerageAgency().getReraNumber(),
//						buyerprocess.getChiraghuser().getUserId());
//
//				if (brokerageAgency != null) { // user agency already exist -> update agency data
//
//					updateBuyerBrokerageAgency(propertyCompanyDetailsDTO.getBuyerBrokerageAgency(), buyerprocess,
//							brokerageAgency);
//
//				} else {
//					BrokerageAgency reraNumberExist = brokerageAgencyRepository
//							.getByReraNumber(propertyCompanyDetailsDTO.getBuyerBrokerageAgency().getReraNumber());
//
//					if (reraNumberExist == null) { // rera number not exit -> add user new agency with that rera
//													// number
						saveBuyerBrokerageAgency(propertyCompanyDetailsDTO.getBuyerBrokerageAgency(), buyerprocess,
								mapper);
//					} else {
//						return responseUtil.getApiResponse(ResponseCodes.FAILURE,
//								PropertyMessages.BROKERAGE_AGENCY_ALREADY_EXIST, null);
//					}
//				}
			}
			// -------------------------------
						
			
			propertyBuyerDetails.setBuyerProcess(buyerprocess);
			propertyBuyerDetails.getBuyerProcess()
					.setChiraghuser(propertyBuyerDetails.getBuyerProcess().getChiraghuser());
			PropertyBuyerDetails propertyBuyerDetailsNew = propertybuyerdetailsRepository.save(propertyBuyerDetails);

			ResponsePropertyCompanyDetailDTO propertyBuyerDetailsResponseDTO = mapper.map(propertyBuyerDetailsNew,
					ResponsePropertyCompanyDetailDTO.class);

			List<CompanyLegalRepresentative> MatchLegalRepresentative = new ArrayList<CompanyLegalRepresentative>();
			if (propertyCompanyDetailsDTO.getCompanyRepresentativeList().size() > 0) {
				for (RequestCompanyLegalRepresentativeDTO companyRepresentative : propertyCompanyDetailsDTO
						.getCompanyRepresentativeList()) {
					isFound = false;
					if (companyRepresentative.getCompanyLegalRepresentativeId() != null
							&& companyRepresentative.getCompanyLegalRepresentativeId() != 0) {

						CompanyLegalRepresentative isValidLegalRepresenatative = companyLegalRepresentativeRepository
								.getCompanyLegalRepresentativeById(
										companyRepresentative.getCompanyLegalRepresentativeId());
						if (isValidLegalRepresenatative == null) {
							System.out.println("Illegal Representative");
							return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND,
									SellerMessages.DATA_UPDATE_FAILURE, null);
						}

						List<CompanyLegalRepresentative> company = companyLegalRepresentativeRepository
								.getAllCompanyLegalRepresentativeByBuyerId(propertyCompanyDetailsDTO.getPropertyBuyerId());
						company.forEach(s -> {
							if (!isFound) {
								if (companyRepresentative.getCompanyLegalRepresentativeId() == s
										.getCompanyLegalRepresentativeId()) {
									System.out.println("Match Representative");
									CompanyLegalRepresentative legalrepresenatative = companyLegalRepresentativeRepository
											.getCompanyLegalRepresentativeById(s.getCompanyLegalRepresentativeId());
									legalrepresenatative = mapper.map(companyRepresentative,
											CompanyLegalRepresentative.class);
									legalrepresenatative.setPropertyBuyerDetails(propertyBuyerDetailsNew);
									CompanyLegalRepresentative legalrepresenatative2 = companyLegalRepresentativeRepository
											.save(legalrepresenatative);
									ResponseCompanyLegalRepresentativeDTO representativedto = mapper
											.map(legalrepresenatative2, ResponseCompanyLegalRepresentativeDTO.class);
									representativelist.add(representativedto);
									MatchLegalRepresentative.add(s);
									isFound = true;
								}
							} else {

								isFound = false;
							}
						});

					} else {

						System.out.println("Null Representative");
						CompanyLegalRepresentative newlegalrepresenatative = mapper.map(companyRepresentative,
								CompanyLegalRepresentative.class);
						newlegalrepresenatative.setPropertyBuyerDetails(propertyBuyerDetailsNew);
						CompanyLegalRepresentative legalrepresenatative2 = companyLegalRepresentativeRepository
								.save(newlegalrepresenatative);
						ResponseCompanyLegalRepresentativeDTO representativedto = mapper.map(legalrepresenatative2,
								ResponseCompanyLegalRepresentativeDTO.class);
						MatchLegalRepresentative.add(legalrepresenatative2);
						representativelist.add(representativedto);
					}
				}
				if (MatchLegalRepresentative.size() > 0) {
					List<CompanyLegalRepresentative> finallist = companyLegalRepresentativeRepository
							.getAllCompanyLegalRepresentativeByBuyerId(propertyCompanyDetailsDTO.getPropertyBuyerId());
					for (CompanyLegalRepresentative match : MatchLegalRepresentative) {
						if (finallist.contains(match)) {
							finallist.remove(match);
						}
					}
					finallist.forEach(s -> {
						companyLegalRepresentativeRepository.deleteById(s.getCompanyLegalRepresentativeId());
					});
				}
				propertyBuyerDetailsResponseDTO.setCompanylegalrepresentatives(representativelist);

			}

//			buyerprocess.getChiraghproperty().setSavedState(propertyCompanyDetailsDTO.getSavedState());
//			propertyRepository.save(buyerprocess.getChiraghproperty());

			return responseUtil.getApiResponse(ResponseCodes.SUCCESS, SellerMessages.DATA_UPDATE_SUCCESS,
					Stream.of(propertyBuyerDetailsResponseDTO).collect(Collectors.toList()));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity savePropertyCompanyDetails(RequestPropertyCompanyDetailsDTO propertyCompanyDetailsDTO) {
		try {

			List<ResponseCompanyLegalRepresentativeDTO> representativelist = new ArrayList<ResponseCompanyLegalRepresentativeDTO>();
			ModelMapper mapper = new ModelMapper();
			PropertyBuyerDetails propertyBuyerDetails = mapper.map(propertyCompanyDetailsDTO,
					PropertyBuyerDetails.class);
			int propertyId = propertyCompanyDetailsDTO.getPropertyId();
			String username = propertyCompanyDetailsDTO.getUserName();

			Chiraghuser chiraghuser1 = userRepository.findByUserName(username);
			Chiraghproperty propertyexist = propertyRepository.findByPropertyId(propertyId);

			if (chiraghuser1 == null || propertyexist == null) {
				return null;
			}

			int userId = chiraghuser1.getUserId();
			BuyerProcess buyerprocess = buyerprocessRepository.findBuyerExisting(userId, propertyId);
			PropertyBuyerDetails newpropertybuyerdetails = null;
			BuyerProcess savedBuyerProcess = null;

			if (buyerprocess == null) {
				// Creating buyer first time

				BuyerProcess newbuyerprocess = new BuyerProcess();
				Chiraghuser chiraghuser = userRepository.findByUserId(userId);
				newbuyerprocess.setChiraghuser(chiraghuser);
				Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
				newbuyerprocess.setChiraghproperty(chiraghproperty);
				newbuyerprocess.setBidReferenceNo(chiragUtill.genearteRandomNo("BidReferenceNo"));
//				newbuyerprocess.setProcessType(propertyownerdetailsDTO.getProcessType());
//				newbuyerprocess.setProposedDate(propertyCompanyDetailsDTO.getProposedDate());
//				create Appointment

				savedBuyerProcess = buyerprocessRepository.save(newbuyerprocess);
				propertyBuyerDetails.setBuyerProcess(savedBuyerProcess);
//				propertyBuyerDetails.setCountry(countryRepository.getByCountryId(propertyownerdetailsDTO.getCountryId()));
//				propertyBuyerDetails.setCity(cityRepository.getByCityId(propertyownerdetailsDTO.getCityId()));

//				propertyBuyerDetails.setCountryId(propertyownerdetailsDTO.getCountryId());
//				propertyBuyerDetails.setCityId(propertyownerdetailsDTO.getCityId());
//			

//				newpropertybuyerdetails = propertybuyerdetailsRepository.save(propertyBuyerDetails);

			} else {
				savedBuyerProcess = buyerprocess;
			}
			
			// ----add brokerage Agency-----
			//  Ref : CD-1907 commenting checks
			if (propertyCompanyDetailsDTO.getBuyerBrokerageAgency() != null) {
//				BrokerageAgency brokerageAgency = brokerageAgencyRepository.getByReraNumberAndUserId(
//						propertyCompanyDetailsDTO.getBuyerBrokerageAgency().getReraNumber(),
//						savedBuyerProcess.getChiraghuser().getUserId());
//
//				if (brokerageAgency != null) { // user agency already exist -> update agency data
//
//					updateBuyerBrokerageAgency(propertyCompanyDetailsDTO.getBuyerBrokerageAgency(), savedBuyerProcess,
//							brokerageAgency);
//
//				} else {
//					BrokerageAgency reraNumberExist = brokerageAgencyRepository
//							.getByReraNumber(propertyCompanyDetailsDTO.getBuyerBrokerageAgency().getReraNumber());
//
//					if (reraNumberExist == null) { // rera number not exit -> add user new agency with that rera
//													// number
						saveBuyerBrokerageAgency(propertyCompanyDetailsDTO.getBuyerBrokerageAgency(), savedBuyerProcess,
								mapper);
//					} else {
//						return responseUtil.getApiResponse(ResponseCodes.FAILURE,
//								PropertyMessages.BROKERAGE_AGENCY_ALREADY_EXIST, null);
//					}
//				}
			}
			// -------------------------------

//				create new buyer process
			propertyBuyerDetails.setBuyerProcess(savedBuyerProcess);
//			propertyBuyerDetails.getBuyerProcess()
//					.setChiraghuser(userRepository.findByUserName(propertyCompanyDetailsDTO.getUserName()));

			PropertyBuyerDetails propertyBuyerDetailsNew = propertybuyerdetailsRepository.save(propertyBuyerDetails);

			ResponsePropertyCompanyDetailDTO propertyBuyerDetailsResponseDTO = mapper.map(propertyBuyerDetailsNew,
					ResponsePropertyCompanyDetailDTO.class);
			int propertyBuyerId = propertyBuyerDetailsNew.getPropertyBuyerId();

			if (propertyCompanyDetailsDTO.getCompanyRepresentativeList().size() > 0) {
				for (RequestCompanyLegalRepresentativeDTO companyRepresentative : propertyCompanyDetailsDTO
						.getCompanyRepresentativeList()) {

					logger.info("Proeprty Buyer Id" + propertyBuyerId);
					CompanyLegalRepresentative legalrepresenatative = mapper.map(companyRepresentative,
							CompanyLegalRepresentative.class);
					legalrepresenatative.setPropertyBuyerDetails(propertyBuyerDetailsNew);
					CompanyLegalRepresentative legalrepresenatative2 = companyLegalRepresentativeRepository
							.save(legalrepresenatative);
					ResponseCompanyLegalRepresentativeDTO representativedto = mapper.map(legalrepresenatative2,
							ResponseCompanyLegalRepresentativeDTO.class);
					representativelist.add(representativedto);

				}
				propertyBuyerDetailsResponseDTO.setCompanylegalrepresentatives(representativelist);
			}
			return responseUtil.getApiResponse(ResponseCodes.SUCCESS, SellerMessages.DATA_SAVED_SUCCESS,
					Stream.of(propertyBuyerDetailsResponseDTO).collect(Collectors.toList()));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}

	public ResponseEntity getPropertyCompaniesDetails(int buyerProcessId) {
		ModelMapper modelMapper = new ModelMapper();
		try {

			List<ResponsePropertyCompanyDetailDTO> companydetailDTO = new ArrayList();

			List<PropertyBuyerDetails> list = propertybuyerdetailsRepository
					.findByCompanyByBuyerProcessId(buyerProcessId);
			if (list.isEmpty()) {

				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.PROPERTY_RESOURCE_NOT_FOUND,
						null);
			}
			list.stream().forEach(s -> {
				ResponsePropertyCompanyDetailDTO response = modelMapper.map(s, ResponsePropertyCompanyDetailDTO.class);

				companydetailDTO.add(response);
			});
//				//response.setCompanylegalrepresentatives(s.getCompanylegalrepresentatives());
//				List<ResponsePropertyCompanyDetailDTO> companyDetailDTOs = new ArrayList<>();
//				List<ResponseCompanyLegalRepresentativeDTO> responseList = new ArrayList();
//				list.stream().forEach(a->{
//					ResponseCompanyLegalRepresentativeDTO dto=modelMapper.map(a.getCompanylegalrepresentatives(),ResponseCompanyLegalRepresentativeDTO.class);
//					responseList.add(dto);
//				});

//				for (int i=0; i < s.getCompanylegalrepresentatives().size(); i ++ ) {
//					ResponseCompanyLegalRepresentativeDTO dto=modelMapper.map(s.getCompanylegalrepresentatives().get(i),ResponseCompanyLegalRepresentativeDTO.class);
//					responseList.add(dto);
//					
//					
//				}
//				response.setCompanylegalrepresentatives(responseList);
//				companydetailDTO.add(response);

//			list.stream().forEach(s -> {
//				ResponsePropertyCompanyDetailDTO companyDTO = new ResponsePropertyCompanyDetailDTO();
//				companyDTO = modelMapper.map(s, ResponsePropertyCompanyDetailDTO.class);
//				List<CompanyLegalRepresentative> legalrepresenatative = companyLegalRepresentativeRepository
//						.getAllCompanyLegalRepresentativeById(s.getSellerId());
//				ResponseCompanyLegalRepresentativeDTO legalrepresenatativelist=modelMapper.map(s.getCompanylegalrepresentatives().indexOf(s),ResponseCompanyLegalRepresentativeDTO.class);
//				companyDTO.setCompanyRepresentativeList(Stream.of(legalrepresenatativelist).collect(Collectors.toList()));
//				companydetailDTO.add(companyDTO);
//			});

			if (companydetailDTO.isEmpty())
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, SellerMessages.DATA_RETRIVED_FAILURE, null);
			else
				return responseUtil.getApiResponse(ResponseCodes.SUCCESS, SellerMessages.DATA_RETRIVED_SUCCESS,
						companydetailDTO);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}// end of getCompanyOwner

	public boolean validateMultipartFiles(MultipartFile idcard, MultipartFile passport,
			MultipartFile scannedNotorizedPoa, String ownerType) {
		if (ownerType.equals("owner") && idcard != null && passport != null && chiragUtill.checkMineType(idcard)
				&& chiragUtill.checkMineType(passport)) {
			return true;
		} else if (ownerType.equals("poa") && idcard != null && passport != null && scannedNotorizedPoa != null
				&& chiragUtill.checkMineType(idcard) && chiragUtill.checkMineType(passport)
				&& chiragUtill.checkMineType(scannedNotorizedPoa)) {
			return true;
		} else
			return false;
	}

	public List<PropertyBuyerDetailsDTO> getPropertyBuyerDetailsList() {
		ModelMapper modelMapper = new ModelMapper();
		return propertybuyerdetailsRepository.getAll().stream()
				.map(temp -> modelMapper.map(temp, PropertyBuyerDetailsDTO.class)).collect(Collectors.toList());

	}

	public int getPropertyIdFromSession(HttpServletRequest httpServletRequest) {
		try {
			return Integer.parseInt(httpServletRequest.getSession(false).getAttribute("propertyId").toString());
		} catch (Exception e) {
			return 0;
		}
	}

	public ResponseEntity createbuyerlead(PropertyBuyerDetailsDTO propertyBuyerDetailDTO,
			HttpServletRequest httpServletRequest) {
		try {

			ModelMapper modelmapper = new ModelMapper();
			int propertyId = propertyBuyerDetailDTO.getPropertyId();
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser1 = userRepository.findByUserName(userName);
			Chiraghproperty propertyexist = propertyRepository.findByPropertyId(propertyId);

			if (chiraghuser1 == null || propertyexist == null) {
				return null;
			}

			BuyerProcess buyerprocess = buyerprocessRepository
					.findBuyerProcessById(propertyBuyerDetailDTO.getBuyerprocess());

			if (propertyBuyerDetailDTO.getProcessType() != null
					&& propertyBuyerDetailDTO.getProcessType().equalsIgnoreCase("open_house")) {
				createOpenHouseAppointment(chiraghuser1, propertyBuyerDetailDTO.getProposedDate(),
						buyerprocess.getBuyerProcessId());
				buyerprocess.setProposedDate(propertyBuyerDetailDTO.getProposedDate());
			}

			buyerprocess.setProcessType(propertyBuyerDetailDTO.getProcessType());

			if (propertyexist.getRentalProperty() != null) {
				buyerprocess.setIsRentalMod(true);
			}

			buyerprocess = buyerprocessRepository.save(buyerprocess);
			// CD-1196 : restrict multiple buyer lead on double click
			BuyerLeads buyerLeadByIds = buyerLeadsRepository.findLeadByProcessIdAndPropertyId(propertyBuyerDetailDTO.getPropertyId(), propertyBuyerDetailDTO.getBuyerprocess());
			
			if (buyerLeadByIds != null) { // lead exist
				return responseUtil.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);

			}
			if (null != buyerprocess.getBuyerBrokerageAgency()) {
				// add checklist 
				
				addBrokerageAgencyTaggedCheckList(buyerprocess, chiraghuser1);
				
			}
			// CD-1196 : end 

			BuyerLeads buyerLead = new BuyerLeads();
			buyerLead.setChiraghproperty(propertyexist);
			buyerLead.setBuyer_process_id(buyerprocess);
			buyerLead.setDepartementId(1);
			buyerLead.setCreatedAt(new Date());
			buyerLead.setUpdatedAt(new Date());
			buyerLead.setStatus("not started");
			if (propertyexist.getRentalProperty() != null) {
				buyerLead.setIsRentalMod(true);
			}

			BuyerLeads savedLead = buyerLeadsRepository.save(buyerLead);

			// Implement pusher
			Map<String, String> map = new HashMap<>();
			map.put("leadId", savedLead.getId().toString());
			map.put("userId", chiraghuser1.getUserId().toString());
			PusherUtil.getDefault().push("new-buyer-leads", "created", map);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return responseUtil.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS, null);
	}

	public void addBrokerageAgencyTaggedCheckList(BuyerProcess buyerprocess, Chiraghuser user) {
		
		Propertychecklist propertychecklist = propertyCheckListRepo.findBuyerAlreadyVerified(buyerprocess.getBuyerProcessId(), CheckListConstants.CheckListIds.BROKERAGE_AGENCY_TAGGED); // brokerage agency tagged checklist
		if (propertychecklist == null) {
			propertychecklist = new Propertychecklist();
			Checklist checklist = checkListRepo.findCheckListById(CheckListConstants.CheckListIds.BROKERAGE_AGENCY_TAGGED);
			propertychecklist.setBuyerProcessId(buyerprocess.getBuyerProcessId());
			propertychecklist.setChiraghuser(user);
			propertychecklist.setChecklist(checklist);
			propertychecklist.setDate(DateUtils.getDefault().getNowCalender());
			propertyCheckListRepo.save(propertychecklist);

		}
	}

	@Transactional
	public ResponseEntity updateSameBuyerDetails(PropertyBuyerDetailsDTO propertyBuyerDetailsDTO, HttpServletRequest httpServletRequest){

		if (propertyBuyerDetailsDTO.getUserName() == null) {
			logger.error("Error Occures username not provided in request payload");
			return responseUtill.getApiResponse(HttpStatus.BAD_REQUEST.value(),
					"Username not provided", null);
		}
		ModelMapper modelmapper = new ModelMapper();
		PropertyBuyerDetailDTO buyerDetailDTO = null;
		String username = propertyBuyerDetailsDTO.getUserName();
		int propertyId = propertyBuyerDetailsDTO.getPropertyId();

		Chiraghuser chiraghuser1 = userRepository.findByUserName(username);
		Chiraghproperty propertyexist = propertyRepository.findByPropertyId(propertyId);

		if (chiraghuser1 == null || propertyexist == null) {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, BuyerMessages.DATA_SAVED_FAILURE, null);
		}

		int userId = chiraghuser1.getUserId();
		BuyerProcess buyerprocess = buyerprocessRepository.findBuyerExisting(userId, propertyId);
		PropertyBuyerDetails newpropertybuyerdetails = null;
		modelmapper.addMappings(new PropertyMap<Chiraghuser, PropertyBuyerDetails>() {
			@Override
			protected void configure() {
				map().setAddress(source.getBuildingAddress());
				map().setMobile(source.getMobileNo());
			}
		});
		PropertyBuyerDetails propertyBuyerDetails = modelmapper.map(chiraghuser1,
				PropertyBuyerDetails.class);

		if (buyerprocess == null) {
			BuyerProcess newbuyerprocess = new BuyerProcess();
			Chiraghuser chiraghuser = userRepository.findByUserId(userId);
			newbuyerprocess.setChiraghuser(chiraghuser);
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
			newbuyerprocess.setChiraghproperty(chiraghproperty);
			newbuyerprocess.setBidReferenceNo(chiragUtill.genearteRandomNo("BidReferenceNo"));
			newbuyerprocess.setProcessType(propertyBuyerDetailsDTO.getProcessType());



			if (propertyBuyerDetailsDTO.getBuyerBrokerageAgency() != null) {
				saveBuyerBrokerageAgency(propertyBuyerDetailsDTO.getBuyerBrokerageAgency(),
						newbuyerprocess, modelmapper);
			}

			BuyerProcess new2buyerprocess = buyerprocessRepository.save(newbuyerprocess);
			propertyBuyerDetails.setBuyerProcess(new2buyerprocess);

			if(chiraghuser.getPassportExpiryDate() !=null){
				String formattedDate = chiragUtill.convertGregorianToDate(chiraghuser.getPassportExpiryDate());
				propertyBuyerDetails.setPassportExpiryDate(formattedDate);
			}

			newpropertybuyerdetails = propertybuyerdetailsRepository.save(propertyBuyerDetails);

		}
		else {
			int buyerprocessId = buyerprocess.getBuyerProcessId();
			if ("owner".equals(propertyBuyerDetailsDTO.getOwnerType())) {

				if (propertyBuyerDetailsDTO.getBuyerBrokerageAgency() != null) {

					saveBuyerBrokerageAgency(propertyBuyerDetailsDTO.getBuyerBrokerageAgency(),
							buyerprocess, modelmapper);

				}
				else {
					buyerprocess.setBuyerBrokerageAgency(null);
				}
			}

			propertyBuyerDetails.setBuyerProcess(buyerprocess);
			if(chiraghuser1.getPassportExpiryDate() !=null){
				String formattedDate = chiragUtill.convertGregorianToDate(chiraghuser1.getPassportExpiryDate());
				propertyBuyerDetails.setPassportExpiryDate(formattedDate);
			}
			newpropertybuyerdetails = propertybuyerdetailsRepository.save(propertyBuyerDetails);

		}

		buyerDetailDTO = modelmapper.map(newpropertybuyerdetails,
				PropertyBuyerDetailDTO.class);
		buyerDetailDTO.setBuyerprocessId(newpropertybuyerdetails.getBuyerProcess().getBuyerProcessId());

		return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_SAVED_SUCCESS,
				Stream.of(buyerDetailDTO).collect(Collectors.toList()));
	}

	@Transactional
	public ResponseEntity saveBuyerOwner(PropertyBuyerDetailsDTO propertyownerdetailsDTO,
			HttpServletRequest httpServletRequest) {

		try {

			ModelMapper modelmapper = new ModelMapper();
			ObjectMapper objectMapper = new ObjectMapper();
			PropertyBuyerDetails propertyBuyerDetails = modelmapper.map(propertyownerdetailsDTO,
					PropertyBuyerDetails.class);
			PropertyBuyerDetailDTO buyerDetailDTO = null;
			int propertyId = propertyownerdetailsDTO.getPropertyId();
			String username = propertyownerdetailsDTO.getUserName();

			Chiraghuser chiraghuser1 = userRepository.findByUserName(username);
			Chiraghproperty propertyexist = propertyRepository.findByPropertyId(propertyId);

			if (chiraghuser1 == null || propertyexist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, BuyerMessages.DATA_SAVED_FAILURE, null);
			}

			int userId = chiraghuser1.getUserId();
			BuyerProcess buyerprocess = buyerprocessRepository.findBuyerExisting(userId, propertyId);
			PropertyBuyerDetails newpropertybuyerdetails = null;

			if (buyerprocess == null) {
				// Creating buyer first time

				BuyerProcess newbuyerprocess = new BuyerProcess();
				Chiraghuser chiraghuser = userRepository.findByUserId(userId);
				newbuyerprocess.setChiraghuser(chiraghuser);
				Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
				newbuyerprocess.setChiraghproperty(chiraghproperty);
				newbuyerprocess.setBidReferenceNo(chiragUtill.genearteRandomNo("BidReferenceNo"));
//				newbuyerprocess.setProcessType(propertyownerdetailsDTO.getProcessType());
				newbuyerprocess.setProposedDate(propertyownerdetailsDTO.getProposedDate());
//				create Appointment
				// ----add brokerage Agency-----
				//  Ref : CD-1907 commenting checks
				if (propertyownerdetailsDTO.getBuyerBrokerageAgency() != null) {
//					BrokerageAgency brokerageAgency = brokerageAgencyRepository.getByReraNumberAndUserId(
//							propertyownerdetailsDTO.getBuyerBrokerageAgency().getReraNumber(),
//							userId);
//
//					if (brokerageAgency != null) { // user agency already exist -> update agency data
//
//						updateBuyerBrokerageAgency(propertyownerdetailsDTO.getBuyerBrokerageAgency(),
//								newbuyerprocess, brokerageAgency);
//
//					} else {
//						BrokerageAgency reraNumberExist = brokerageAgencyRepository
//								.getByReraNumber(propertyownerdetailsDTO.getBuyerBrokerageAgency().getReraNumber());
//
//						if (reraNumberExist == null) { // rera number not exit -> add user new agency with that rera
//														// number
							saveBuyerBrokerageAgency(propertyownerdetailsDTO.getBuyerBrokerageAgency(),
									newbuyerprocess, modelmapper);
//						} else {
//							return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.BROKERAGE_AGENCY_ALREADY_EXIST, null);
//						}
//					}
				}
				// -------------------------------
				BuyerProcess new2buyerprocess = buyerprocessRepository.save(newbuyerprocess);
				propertyBuyerDetails.setBuyerProcess(new2buyerprocess);
//				propertyBuyerDetails.setCountry(countryRepository.getByCountryId(propertyownerdetailsDTO.getCountryId()));
//				propertyBuyerDetails.setCity(cityRepository.getByCityId(propertyownerdetailsDTO.getCityId()));

//				propertyBuyerDetails.setCountryId(propertyownerdetailsDTO.getCountryId());
//				propertyBuyerDetails.setCityId(propertyownerdetailsDTO.getCityId());
//			

				newpropertybuyerdetails = propertybuyerdetailsRepository.save(propertyBuyerDetails);
				/****************************************/
//				BuyerLeads buyerLead = new BuyerLeads();
//				buyerLead.setChiraghproperty(chiraghproperty);
//				buyerLead.setBuyer_process_id(new2buyerprocess);
//				buyerLead.setDepartementId(1);
//				buyerLead.setCreatedAt(new Date());
//				buyerLead.setUpdatedAt(new Date());
//				buyerLead.setStatus("not started");
//
//				BuyerLeads savedLead = buyerLeadsRepository.save(buyerLead);
//
//				// Implement pusher
//				Map<String, String> map = new HashMap<>();
//				map.put("leadId", savedLead.getId().toString());
//				map.put("userId", chiraghuser1.getUserId().toString());
//				PusherUtil.getDefault().push("new-buyer-leads", "created", map);
//				
				/****************************************/
				/*
				 * // saving images of buyer String path = "/" +
				 * new2buyerbiddinghistory.getBidReferenceNo() + "/Buyer"; String fileName =
				 * chiraghproperty.getPropertyReferenceNo() + "," +
				 * newpropertybuyerdetails.getPropertyBuyerId()();
				 * storageService.store(idCopyUpload, path, fileName + ",idCopyUpload");
				 * storageService.store(passportCopyUpload, path, fileName +
				 * ",passportCopyUpload"); storageService.store( scannedNotorizedCopy, path,
				 * fileName + ",scannedNotorizedCopy");
				 * 
				 * // updating buyer file info newpropertybuyerdetails.setIdCopyUpload(fileName
				 * + ",idCopyUpload"); newpropertybuyerdetails.setPassportCopyUpload(fileName +
				 * ",passportCopyUpload");
				 * newpropertybuyerdetails.setScannedNotorizedCopy(fileName +
				 * ",scannedNotorizedCopy");
				 * propertybuyerdetailsRepository.save(newpropertybuyerdetails);
				 */

				// PropertyBuyerDetailsDTO obj = modelmapper.map(newpropertybuyerdetails,
				// PropertyBuyerDetailsDTO.class);
				// List<PropertyBuyerDetailsDTO> list = new
				// ArrayList<PropertyBuyerDetailsDTO>();
				// list.add(obj);
				// return list;

			}

			else {

				// int buyerBiddingHistoryId
				// =chiraghUtill.getSessionBuyer(httpServletRequest).getBuyerBiddingHistoryId();
				int buyerprocessId = buyerprocess.getBuyerProcessId();
				if ("owner".equals(propertyownerdetailsDTO.getOwnerType())) {
					
					// ----add brokerage Agency-----
//					 Ref : CD-1907 commenting checks
					if (propertyownerdetailsDTO.getBuyerBrokerageAgency() != null) {
//						BrokerageAgency brokerageAgency = brokerageAgencyRepository.getByReraNumberAndUserId(
//								propertyownerdetailsDTO.getBuyerBrokerageAgency().getReraNumber(),
//								buyerprocess.getChiraghuser().getUserId());
//
//						if (brokerageAgency != null) { // user agency already exist -> update agency data
//
//							updateBuyerBrokerageAgency(propertyownerdetailsDTO.getBuyerBrokerageAgency(),
//									buyerprocess, brokerageAgency);
//
//						} else {
//							BrokerageAgency reraNumberExist = brokerageAgencyRepository
//									.getByReraNumber(propertyownerdetailsDTO.getBuyerBrokerageAgency().getReraNumber());
//
//							if (reraNumberExist == null) { // rera number not exit -> add user new agency with that rera
//															// number
								saveBuyerBrokerageAgency(propertyownerdetailsDTO.getBuyerBrokerageAgency(),
										buyerprocess, modelmapper);
//							} else {
//								return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.BROKERAGE_AGENCY_ALREADY_EXIST, null);
//
//							}
//						}
					}
					// -------------------------------
					else {
						buyerprocess.setBuyerBrokerageAgency(null);
					}
				}
				
				propertyBuyerDetails.setBuyerProcess(buyerprocess);

//				propertyBuyerDetails.setCountryId(propertyownerdetailsDTO.getCountryId());
//				propertyBuyerDetails.setCityId(propertyownerdetailsDTO.getCityId());
				newpropertybuyerdetails = propertybuyerdetailsRepository.save(propertyBuyerDetails);

				// PropertyBuyerDetail list1 = propertybuyerdetailsRepository
				// .findBuyerByBiddingHistoryId(buyerBiddingHistoryId);
				// return list1.stream().map(temp -> modelmapper.map(temp,
				// PropertyBuyerDetailsDTO.class))
				// .collect(Collectors.toList());
//				return modelmapper.map(newpropertybuyerdetails, PropertyBuyerDetailDTO.class);

			}

			 buyerDetailDTO = modelmapper.map(newpropertybuyerdetails,
					PropertyBuyerDetailDTO.class);
			buyerDetailDTO.setBuyerprocessId(newpropertybuyerdetails.getBuyerProcess().getBuyerProcessId());

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BuyerMessages.DATA_SAVED_SUCCESS,
					Stream.of(buyerDetailDTO).collect(Collectors.toList()));

		} catch (Exception e) {
			logger.error("Error Occures while added/updat buyer details: ", e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);

		}

	}

	private AppointmentsDTO createOpenHouseAppointment(Chiraghuser chiraghuser1, Date date, Integer buyerProcessId) {
		try {

			BuyerProcess buyerProcess = buyerprocessRepository.findBuyerProcess(buyerProcessId);
			Chiraghuser chiraghuser = chiraghuser1;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			Appointments appointment = new Appointments();
			appointment.setTitle("Open house meeting");
			appointment.setDescription("Open House Schedule proposed by Buyer");
			appointment.setDated(date);
			appointment.setDepartmentId(LeadUtils.Department.BROKERAGE);
			appointment.setCreatedAt(DateUtils.getDefault().getNowTime());
			appointment.setUpdatedAt(DateUtils.getDefault().getNowTime());
			appointment.setIsBuyer(true);
			appointment.setBuyerConfirm(true);
			appointment.setBuyerProcess(buyerProcess);
//			appointment.setBuyerProcessId(buyerProcessId);

			appointment = appointmentsRepository.save(appointment);
			openHouseService.sendAdminNotificationToBuyer(chiraghuser, buyerProcess.getBuyerProcessId());
			AppointmentsDTO appointmentsDTO = ObjectMapperUtils.map(appointment, AppointmentsDTO.class);
			return appointmentsDTO;
		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return null;
		}

	}

	public ResponseEntity reScheduleOpenHouse(int buyerProcessId, PropertyBuyerDetailsDTO propertyBuyerDetailsDTO) {
		try {

			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtil.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
			}
			AppointmentsDTO appointmentsDTO = createOpenHouseAppointment(chiraghuser,
					propertyBuyerDetailsDTO.getProposedDate(), buyerProcessId);
			if (appointmentsDTO == null) {
				return responseUtil.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
			} else {
				return responseUtil.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(appointmentsDTO).collect(Collectors.toList()));
			}

		} catch (Exception e) {
			e.printStackTrace();
			return responseUtil.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
		}
	}
	
	public void saveBuyerBrokerageAgency(BrokerageAgencyBuyerDto brokerageAgencyRequest,  BuyerProcess buyerprocess,
			ModelMapper mapper) {
		try {
			BrokerageAgency brokerageAgency;
			brokerageAgency = mapper.map(brokerageAgencyRequest, BrokerageAgency.class);
			brokerageAgency.setUserId(buyerprocess.getChiraghuser().getUserId());
			brokerageAgency.setCreatedAt(DateUtils.getDefault().getNowTime());
			brokerageAgency.setUpdatedAt(DateUtils.getDefault().getNowTime());
			brokerageAgencyRepository.save(brokerageAgency);
			buyerprocess.setBuyerBrokerageAgency(brokerageAgency);

			buyerProcessRepository.save(buyerprocess);
		} catch (Exception e) {
			logger.error("error occures while saving Buyer brokerage agency ", e);

		}
	}

	public void updateBuyerBrokerageAgency(BrokerageAgencyBuyerDto brokerageAgencyRequest, BuyerProcess buyerprocess,
			BrokerageAgency brokerageAgency) {
		try {
			brokerageAgency.setApprovalBForm(brokerageAgencyRequest.getApprovalBForm());
			brokerageAgency.setBrokerageLicense(brokerageAgencyRequest.getBrokerageLicense());
			brokerageAgency.setCompanyName(brokerageAgencyRequest.getCompanyName());
			brokerageAgency.setContactName(brokerageAgencyRequest.getContactName());
			brokerageAgency.setContactNumber(brokerageAgencyRequest.getContactNumber());
			brokerageAgency.setReraNumber(brokerageAgencyRequest.getReraNumber());
			brokerageAgency.setUpdatedAt(DateUtils.getDefault().getNowTime());
			brokerageAgencyRepository.save(brokerageAgency);

			buyerprocess.setBuyerBrokerageAgency(brokerageAgency);

			buyerProcessRepository.save(buyerprocess);
		} catch (Exception e) {
			logger.error("error occures while updating Buyer brokerage agency ", e);

		}
	}

}
