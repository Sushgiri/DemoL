package com.bestercapitalmedia.letwizard.buyer.details;

import java.util.Date;

import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyBuyerDto;

public class PropertyBuyerDetailsDTO {

	int countryId;
	int cityId;
	String otherDocument;
	String telephoneCode;
	String mobileCode;
	private String poaStatus;
	private String nationalityOther;
	private int propertyBuyerId;
	// @Size(min=3,max=15)
	// @Pattern(regexp = "[a-zA-Z_.]*")
	private String firstName;
	// @Size(min=3,max=15)
	// @Pattern(regexp = "[a-zA-Z_.]*")
	private String middleName;
	// @Size(min=3,max=15)
	// @Pattern(regexp = "[a-zA-Z_.]*")
	private String lastName;
	// @Size(min=8,max=15)
	// @Pattern(regexp = "[0-9-+]*")
	private String mobile;
	// @Pattern(regexp = "[a-zA-Z0-9_.,#]*")
	// @Size(min=8,max=25)
	private String streetAddress;
	// @Size(min=8,max=25)
	// @Pattern(regexp = "[a-zA-Z0-9_.,#]*")
	private String buildingAddress;
	// @Size(min=8,max=25)
	private String passportNo;
	// @Size(min=8,max=25)
	private String telephone;
	// @Size(min=8,max=25)
	private String address;
	// @Size(min=8,max=25)
	private String nationality;
	// @Size(min=8,max=25)
	private String idCardNo;
	// @Size(min=8,max=25)
	private String idCardExpiration;
	// @Size(min=8,max=25)
	private String passportExpiryDate;
	// @Email
	// @NotEmpty
	// @NotEmpty
	private String email;
	// @Size(min=4,max=6)
	private String emailVerificationCode;
	// @Size(min=4,max=5)
	private String pobox;
	// @Size(min=8,max=25)
	private String passportCopyUpload;
	// @Size(min=8,max=25)
	private String idCopyUpload;
	// @Size(min=3,max=5)
	private String ownerType;
	// @Size(min=8,max=25)
	private String poaPropertyAuthority;
	// @Size(min=8,max=25)
	private String titleDeedUpload;
	// @Size(min=8,max=25)
	private String poaAgreementExpiry;
	// @Size(min=8,max=25)
	private String poaClearDeedUpload;
	// @Size(min=8,max=25)
	private String scannedNotorizedCopy;
	// @Size(min=1,max=1)
	private String isPoaAccepted;
	// @Size(min=8,max=25)
	private String poaNumber;
	private String specificProperty;

	private Boolean noPoaExpiry;
	String userName;
	int propertyId;
	// Personal Details

	private int buyerprocess;

	private String processType;
	private Date proposedDate;
	private BrokerageAgencyBuyerDto buyerBrokerageAgency;

	public String getFirstName() {
		return firstName;
	}

	public String getTitleDeedUpload() {
		return titleDeedUpload;
	}

	public void setTitleDeedUpload(String titleDeedUpload) {
		this.titleDeedUpload = titleDeedUpload;
	}

	public String getPoaClearDeedUpload() {
		return poaClearDeedUpload;
	}

	public void setPoaClearDeedUpload(String poaClearDeedUpload) {
		this.poaClearDeedUpload = poaClearDeedUpload;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getBuildingAddress() {
		return buildingAddress;
	}

	public void setBuildingAddress(String buildingAddress) {
		this.buildingAddress = buildingAddress;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getIdCardNo() {
		return idCardNo;
	}

	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}

	public String getIdCardExpiration() {
		return idCardExpiration;
	}

	public void setIdCardExpiration(String idCardExpiration) {
		this.idCardExpiration = idCardExpiration;
	}

	public String getPassportExpiryDate() {
		return passportExpiryDate;
	}

	public void setPassportExpiryDate(String passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmailVerificationCode() {
		return emailVerificationCode;
	}

	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	public String getPobox() {
		return pobox;
	}

	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	public String getPassportCopyUpload() {
		return passportCopyUpload;
	}

	public void setPassportCopyUpload(String passportCopyUpload) {
		this.passportCopyUpload = passportCopyUpload;
	}

	public String getIdCopyUpload() {
		return idCopyUpload;
	}

	public void setIdCopyUpload(String idCopyUpload) {
		this.idCopyUpload = idCopyUpload;
	}

	public String getOwnerType() {
		return ownerType;
	}

	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	public String getPoaPropertyAuthority() {
		return poaPropertyAuthority;
	}

	public void setPoaPropertyAuthority(String poaPropertyAuthority) {
		this.poaPropertyAuthority = poaPropertyAuthority;
	}

	public String getPoaAgreementExpiry() {
		return poaAgreementExpiry;
	}

	public void setPoaAgreementExpiry(String poaAgreementExpiry) {
		this.poaAgreementExpiry = poaAgreementExpiry;
	}

	public String getScannedNotorizedCopy() {
		return scannedNotorizedCopy;
	}

	public void setScannedNotorizedCopy(String scannedNotorizedCopy) {
		this.scannedNotorizedCopy = scannedNotorizedCopy;
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public int getPropertyBuyerId() {
		return propertyBuyerId;
	}

	public void setPropertyBuyerId(int propertyBuyerId) {
		this.propertyBuyerId = propertyBuyerId;
	}

	public PropertyBuyerDetailsDTO() {

	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIsPoaAccepted() {
		return isPoaAccepted;
	}

	public void setIsPoaAccepted(String isPoaAccepted) {
		this.isPoaAccepted = isPoaAccepted;
	}

	public String getPoaNumber() {
		return poaNumber;
	}

	public void setPoaNumber(String poaNumber) {
		this.poaNumber = poaNumber;
	}

	public String getSpecificProperty() {
		return specificProperty;
	}

	public void setSpecificProperty(String specificProperty) {
		this.specificProperty = specificProperty;
	}

	public String getNationalityOther() {
		return nationalityOther;
	}

	public void setNationalityOther(String nationalityOther) {
		this.nationalityOther = nationalityOther;
	}

	public String getPoaStatus() {
		return poaStatus;
	}

	public void setPoaStatus(String poaStatus) {
		this.poaStatus = poaStatus;
	}

	public String getTelephoneCode() {
		return telephoneCode;
	}

	public void setTelephoneCode(String telephoneCode) {
		this.telephoneCode = telephoneCode;
	}

	public String getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public String getOtherDocument() {
		return otherDocument;
	}

	public void setOtherDocument(String otherDocument) {
		this.otherDocument = otherDocument;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public int getBuyerprocess() {
		return buyerprocess;
	}

	public void setBuyerprocess(int buyerprocess) {
		this.buyerprocess = buyerprocess;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public Date getProposedDate() {
		return proposedDate;
	}

	public void setProposedDate(Date proposedDate) {
		this.proposedDate = proposedDate;
	}

	public Boolean isNoPoaExpiry() {
		return noPoaExpiry;
	}

	public void setNoPoaExpiry(Boolean noPoaExpiry) {
		this.noPoaExpiry = noPoaExpiry;
	}

	public BrokerageAgencyBuyerDto getBuyerBrokerageAgency() {
		return buyerBrokerageAgency;
	}

	public void setBuyerBrokerageAgency(BrokerageAgencyBuyerDto buyerBrokerageAgency) {
		this.buyerBrokerageAgency = buyerBrokerageAgency;
	}

	
}
