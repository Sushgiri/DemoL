package com.bestercapitalmedia.letwizard.buyer.process;

import javax.validation.constraints.Size;

import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyDto;
import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;

public class BuyerProcessDTO {
	
	private Integer buyerProcessId;
	private String biddingStatus;
	private ChiraghUserDTO chiraghuser;
	private int propertyId;
	private String processType;
	private BrokerageAgencyDto brokerageAgency;
	
	public void setBiddingStatus(String biddingStatus) {
		this.biddingStatus = biddingStatus;
	}
	public String getBiddingStatus() {
		return this.biddingStatus;
	}
	
	public int getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}
	
	
	public BuyerProcessDTO() {
		
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public ChiraghUserDTO getChiraghuser() {
		return chiraghuser;
	}
	public void setChiraghuser(ChiraghUserDTO chiraghuser) {
		this.chiraghuser = chiraghuser;
	}
	public Integer getBuyerProcessId() {
		return buyerProcessId;
	}
	public void setBuyerProcessId(Integer buyerProcessId) {
		this.buyerProcessId = buyerProcessId;
	}
	public BrokerageAgencyDto getBrokerageAgency() {
		return brokerageAgency;
	}
	public void setBrokerageAgency(BrokerageAgencyDto brokerageAgency) {
		this.brokerageAgency = brokerageAgency;
	}
	
	

}
