package com.bestercapitalmedia.letwizard.buyer.process;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetailsDTO;
import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetailsService;
import com.bestercapitalmedia.letwizard.openhouse.OpenHousescheduleDTO;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyController;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.type.Propertytype;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.LogUtill;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin
@RequestMapping("/api/buyerprocess")
public class BuyerProcessController {

	private static final Logger log = LoggerFactory.getLogger(PropertyController.class);
	
	@Autowired
	UserRepository userRepository;
	@Autowired
	private PropertyRepository propertyRepository;
	@Autowired
	private BuyerProcessRepository buyerprocessRepository;
	@Autowired
	private BuyerProcessService buyerprocessService;
	@Autowired
	private LogUtill logUtill;
	@Autowired
	private ChiragUtill chiraghUtill;
	@Autowired
	private PropertyBuyerDetailsService propertybuyerdetailsservice;
	

	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getAll(HttpServletRequest httpServletRequest) {

		try {
//			if (chiraghUtill.isValidSession(httpServletRequest) == false)
//				return new ResponseEntity(chiraghUtill.getMessageObject("Invalid Session!"), HttpStatus.OK);

			ObjectMapper mapper = new ObjectMapper();
			List<Map<String,String>> buyerprocess = buyerprocessRepository.getAll();
//					
//			try {
//				logUtill.inputLog(httpServletRequest, chiraghUtill.getSessionUser(httpServletRequest),
//						"/api/buyerprocess/getAll", mapper.writeValueAsString(""),
//						mapper.writeValueAsString(buyerprocess));
//			} catch (Exception e) {
//				return new ResponseEntity(chiraghUtill.getMessageObject("Log not Generated"), HttpStatus.OK);
//			}

			return new ResponseEntity(buyerprocess, HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseEntity(chiraghUtill.getMessageObject("Internal Server Error!" + e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}// end of list method*/


	// for testing purpose
	@RequestMapping(value = "/post", method = RequestMethod.POST)
	public @ResponseBody BuyerProcessDTO create(@Valid @RequestBody BuyerProcessDTO data,
												HttpServletRequest httpServletRequest) {
		ObjectMapper mapper = new ObjectMapper();
		ModelMapper modelMapper = new ModelMapper();
		BuyerProcess buyerprocess = buyerprocessService.save(data);

		BuyerProcessDTO buyerprocessDTO=modelMapper.map(buyerprocess, BuyerProcessDTO.class);

		try {
			logUtill.inputLog(httpServletRequest,
					userRepository.findByUserId(buyerprocess.getChiraghuser().getUserId()),
					"/api/buyerprocess", mapper.writeValueAsString(data), mapper.writeValueAsString(buyerprocessDTO));
		} catch (JsonProcessingException e) {
			log.error(e.getMessage(), e);
		}
		return buyerprocessDTO ;
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{buyerProcessId}/buyers", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getBuyers(@PathVariable(value = "buyerProcessId") int buyerProcessId, HttpServletRequest httpServletRequest) {
		return buyerprocessService.getBuyers(buyerProcessId);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{propertyId}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getBuyerProcess(@PathVariable(value = "propertyId") int propertyId, HttpServletRequest httpServletRequest) {
		return buyerprocessService.getBuyerProcess(propertyId);
	}


	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/mine", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getPropertiesForInProcess(@RequestParam(name = "isRentalMod", required = false) Boolean isRentalMod,@PageableDefault(value=Integer.MAX_VALUE, page=0) Pageable pageable,HttpServletRequest httpServletRequest) {
		return buyerprocessService.getPropertiesForInProcess(pageable.getPageNumber(),pageable.getPageSize(),isRentalMod);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/open/house", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getOpenHouseProperties(@RequestParam(name = "isRentalMod", required = false) Boolean isRentalMod,
															   @PageableDefault(value=Integer.MAX_VALUE, page=0) Pageable pageable, HttpServletRequest httpServletRequest) {
		return buyerprocessService.getOpenHouseProperties(pageable.getPageNumber(),pageable.getPageSize(),isRentalMod);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{buyerProcessId}/open/house/reschdule", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity reScheduleOpenHouse(@PathVariable(value = "buyerProcessId") int buyerProcessId,
			@RequestBody PropertyBuyerDetailsDTO propertyBuyerDetailsDTO, Authentication authentication,
			HttpServletRequest httpServletRequest) {
		return propertybuyerdetailsservice.reScheduleOpenHouse(buyerProcessId, propertyBuyerDetailsDTO);
	}
	
	
}
