package com.bestercapitalmedia.letwizard.buyer.process;

import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyBuyerDto;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyDetailsDTO;
import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;

public class BuyerProcessDTO2 {

	private Integer buyerProcessId;
	private String bidReferenceNo;
	private String biddingStatus;
	private ChiraghUserDTO chiraghuser;
	private ChiraghPropertyDetailsDTO chiraghproperty;
	private String processType;
	private Boolean paymentStatus;
	private String openHouseNotes;
	private BrokerageAgencyBuyerDto buyerBrokerageAgency;
	private Boolean isRentalMod;

	public BuyerProcessDTO2() {
//		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getBuyerProcessId() {
		return buyerProcessId;
	}

	public void setBuyerProcessId(Integer buyerProcessId) {
		this.buyerProcessId = buyerProcessId;
	}

	public String getBidReferenceNo() {
		return bidReferenceNo;
	}

	public void setBidReferenceNo(String bidReferenceNo) {
		this.bidReferenceNo = bidReferenceNo;
	}

	public String getBiddingStatus() {
		return biddingStatus;
	}

	public void setBiddingStatus(String biddingStatus) {
		this.biddingStatus = biddingStatus;
	}

	public ChiraghUserDTO getChiraghuser() {
		return chiraghuser;
	}

	public void setChiraghuser(ChiraghUserDTO chiraghuser) {
		this.chiraghuser = chiraghuser;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public Boolean getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(Boolean paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getOpenHouseNotes() {
		return openHouseNotes;
	}

	public void setOpenHouseNotes(String openHouseNotes) {
		this.openHouseNotes = openHouseNotes;
	}

	public ChiraghPropertyDetailsDTO getChiraghproperty() {
		return chiraghproperty;
	}

	public void setChiraghproperty(ChiraghPropertyDetailsDTO chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}

	public BrokerageAgencyBuyerDto getBuyerBrokerageAgency() {
		return buyerBrokerageAgency;
	}

	public void setBuyerBrokerageAgency(BrokerageAgencyBuyerDto buyerBrokerageAgency) {
		this.buyerBrokerageAgency = buyerBrokerageAgency;
	}

	public Boolean getIsRentalMod() {
		return isRentalMod;
	}

	public void setIsRentalMod(Boolean isRentalMod) {
		this.isRentalMod = isRentalMod;
	}
	
}
