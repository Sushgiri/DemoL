package com.bestercapitalmedia.letwizard.buyer.process;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgency;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 */

@Entity

@Table(name = "buyerprocess")
public class BuyerProcess implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "buyer_Process_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer buyerProcessId;
	/**
	 */

	@Column(name = "bid_Reference_No")
	@Basic(fetch = FetchType.EAGER)

	String bidReferenceNo;
	/**
	 */

	@Column(name = "bidding_Status", length = 25)
	@Basic(fetch = FetchType.EAGER)

	String biddingStatus;

	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "user_Id", referencedColumnName = "user_Id") })
	@JsonBackReference
	Chiraghuser chiraghuser;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "property_Id", referencedColumnName = "property_Id") })
	@JsonBackReference
	Chiraghproperty chiraghproperty;

	@Column(name = "process_Type", length = 25)
	@Basic(fetch = FetchType.EAGER)
	private String processType;

	@Column(name = "proposed_Date", length = 25)
	@Basic(fetch = FetchType.EAGER)
	private Date proposedDate;

	@Column(name = "payment_Status")
	private Boolean paymentStatus;

	@ManyToOne(fetch = FetchType.LAZY, cascade = { CascadeType.REMOVE })
	@JoinColumn(name = "brokerage_Agency_Id", referencedColumnName = "id", nullable = false)
	private BrokerageAgency buyerBrokerageAgency;

	@Column(name = "is_rental_mod")
    private Boolean isRentalMod;

	public void setBidReferenceNo(String bidReferenceNo) {
		this.bidReferenceNo = bidReferenceNo;
	}

	/**
	 */
	public String getBidReferenceNo() {
		return this.bidReferenceNo;
	}

	public Integer getBuyerProcessId() {
		return buyerProcessId;
	}

	public void setBuyerProcessId(Integer buyerProcessId) {
		this.buyerProcessId = buyerProcessId;
	}

	/**
	 */
	public void setBiddingStatus(String biddingStatus) {
		this.biddingStatus = biddingStatus;
	}

	/**
	 */
	public String getBiddingStatus() {
		return this.biddingStatus;
	}

	/**
	 */
	public void setChiraghuser(Chiraghuser chiraghuser) {
		this.chiraghuser = chiraghuser;
	}

	/**
	 */
	public Chiraghuser getChiraghuser() {
		return chiraghuser;
	}

	/**
	 */
	public void setChiraghproperty(Chiraghproperty chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}

	/**
	 */
	public Chiraghproperty getChiraghproperty() {
		return chiraghproperty;
	}

	public BuyerProcess() {
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public Boolean getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(Boolean paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Date getProposedDate() {
		return proposedDate;
	}

	public void setProposedDate(Date proposedDate) {
		this.proposedDate = proposedDate;
	}

	public BrokerageAgency getBuyerBrokerageAgency() {
		return buyerBrokerageAgency;
	}

	public void setBuyerBrokerageAgency(BrokerageAgency buyerBrokerageAgency) {
		this.buyerBrokerageAgency = buyerBrokerageAgency;
	}

	public Boolean getIsRentalMod() {
		return isRentalMod;
	}

	public void setIsRentalMod(Boolean isRentalMod) {
		this.isRentalMod = isRentalMod;
	}
}
