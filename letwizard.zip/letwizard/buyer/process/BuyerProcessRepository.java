package com.bestercapitalmedia.letwizard.buyer.process;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;

public interface BuyerProcessRepository extends PagingAndSortingRepository<BuyerProcess, Integer> {

	@Query(value = "select * from buyerprocess where property_Id=?1  ", nativeQuery = true)
	public BuyerProcess findBuyerByPropertyId(int propertyId);

	@Query(value = "Select * from buyerprocess;", nativeQuery = true)
	public List<Map<String, String>> getAll();

	// @Query(value = "Select * from buyerbiddinghistory;", nativeQuery = true)
	// public BuyerBiddingHistory findByBidReferenceNo(String bidreferenceno);

	@Query(value = "select * from buyerprocess where  user_Id=?1 And property_Id=?2", nativeQuery = true)
	public BuyerProcess findBuyerExisting(int userId, int propertyId);

	@Query(value = "SELECT  * FROM buyerprocess bp JOIN chiraghproperty cp ON bp.`property_Id` = cp.`property_Id` WHERE bp.user_Id=?1 AND bp.property_Id NOT IN (SELECT  DISTINCT property_Id FROM propertybidprocess WHERE user_Id=?1) AND cp.`auction_Status` <> 'completed' AND cp.`auction_Status` <> 'archived' AND cp.rental_property_id IS NULL order by bp.date_Created desc ", countQuery = "SELECT  * FROM buyerprocess bp JOIN chiraghproperty cp ON bp.`property_Id` = cp.`property_Id` WHERE bp.user_Id=?1 AND bp.property_Id NOT IN (SELECT  DISTINCT property_Id FROM propertybidprocess WHERE user_Id=?1 AND cp.rental_property_id IS NULL)", nativeQuery = true)
	public Page<BuyerProcess> getInProcessPropertiesForBuySell(int userId, Pageable pageable);

	@Query(value = "SELECT  * FROM buyerprocess bp JOIN chiraghproperty cp ON bp.`property_Id` = cp.`property_Id` WHERE bp.user_Id=?1 AND bp.property_Id NOT IN (SELECT  DISTINCT property_Id FROM propertybidprocess WHERE user_Id=?1) AND cp.`auction_Status` <> 'completed' AND cp.`auction_Status` <> 'archived' AND cp.rental_property_id IS NOT NULL order by bp.date_Created desc ", countQuery = "SELECT  * FROM buyerprocess bp JOIN chiraghproperty cp ON bp.`property_Id` = cp.`property_Id` WHERE bp.user_Id=?1 AND bp.property_Id NOT IN (SELECT  DISTINCT property_Id FROM propertybidprocess WHERE user_Id=?1 AND cp.rental_property_id IS NOT NULL)", nativeQuery = true)
	public Page<BuyerProcess> getInProcessPropertiesForRental(int userId, Pageable pageable);

	@Query(value = "SELECT  * FROM buyerprocess WHERE user_Id=?1 AND process_Type = 'open_house' AND is_rental_mod IS NULL order by date_Created desc", countQuery = "SELECT  * FROM buyerprocess WHERE user_Id=?1 AND process_Type = 'open_house' AND is_rental_mod IS NULL order by date_Created desc", nativeQuery = true)
	public Page<BuyerProcess> getOpenHousePropertiesForBuySell(int userId, Pageable pageable);

	@Query(value = "SELECT  * FROM buyerprocess WHERE user_Id=?1 AND process_Type = 'open_house' AND is_rental_mod = 1 order by date_Created desc", countQuery = "SELECT  * FROM buyerprocess WHERE user_Id=?1 AND process_Type = 'open_house' AND is_rental_mod = 1 order by date_Created desc", nativeQuery = true)
	public Page<BuyerProcess> getOpenHousePropertiesForRental(int userId, Pageable pageable);

	@Query(value = "select * from buyerprocess where  buyer_Process_Id=?1", nativeQuery = true)
	public BuyerProcess findBuyerProcess(int processID);

	@Query(value = "select * from buyerprocess where buyer_Process_Id=?1", nativeQuery = true)
	public BuyerProcess findBuyerProcessById(int buyerProcessId);

	@Query(value = "SELECT * FROM buyerprocess WHERE property_Id=?1 AND user_Id=?2  order by date_Created desc LIMIT 1 ", nativeQuery = true)
	public BuyerProcess findByPropertyAndUserId(int propertyId, int userId);

	// CD-1719
	@Query(value = "select * from buyerprocess where  user_Id = ?1 And property_Id = ?2 AND process_type IS NOT NULL", nativeQuery = true)
	public BuyerProcess findBuyerExistingWithProcessType(Integer userId, Integer propertyId);

	public BuyerProcess findByChiraghuserAndChiraghproperty(Chiraghuser chiraghuser, Chiraghproperty chiraghproperty);

	@Query(value = "select * from buyerprocess where property_Id=?1 order by date_Created desc limit 1", nativeQuery = true)
	public List<BuyerProcess> findBuyerProcessByPropertyID(int propertyId);

	@Query(value = "select property_Id from buyerprocess bp where process_Type=?1 AND payment_Status = 1 AND DATEDIFF(CURDATE(),bp.date_Created) < 3 order by date_Created desc", nativeQuery = true)
	public List<Integer> findBuyerProcessByRentalProcessType(String process_Type);

	@Query(value = "select property_Id from buyerprocess bp where process_Type='buy_now' AND payment_Status = 1 AND DATEDIFF(CURDATE(),bp.date_Created) < 3", nativeQuery = true)
	public List<Integer> fetchBuyerProcessIsBuyNow();

}