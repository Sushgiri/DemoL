package com.bestercapitalmedia.letwizard.buyer.process;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.bestercapitalmedia.letwizard.api.response.PaginatedResponseDTO;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.appointments.Appointments;
import com.bestercapitalmedia.letwizard.appointments.AppointmentsRepository;
import com.bestercapitalmedia.letwizard.bank.accounts.BankAccounts;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgency;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyBuyerDto;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyDto;
import com.bestercapitalmedia.letwizard.brokerage.agency.BrokerageAgencyRepository;
import com.bestercapitalmedia.letwizard.brokerage.proposal.BrokerageProposal;
import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetailDTO;
import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetails;
import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetailsDTO;
import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetailsRepository;
import com.bestercapitalmedia.letwizard.constants.BuyerMessages;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.TransactionConstants;
import com.bestercapitalmedia.letwizard.constants.TransactionMessages;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyDetailsDTO3;
import com.bestercapitalmedia.letwizard.property.LetwizardPropertyService;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.bidprocess.PropertybidprocessRepository;
import com.bestercapitalmedia.letwizard.transaction.TransactionStatus;
import com.bestercapitalmedia.letwizard.transaction.Transactions;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.StringValidationUtils;
import com.bestercapitalmedia.letwizard.vouchers.Voucher;
import com.bestercapitalmedia.letwizard.vouchers.VoucherDTO;
import com.bestercapitalmedia.letwizard.vouchers.VoucherDetails;
import com.bestercapitalmedia.letwizard.vouchers.VoucherRepository;

@Service
public class BuyerProcessService {

	private static final Logger logger = LoggerFactory.getLogger(BuyerProcessService.class);

	@Autowired
	UserRepository userRepository;
	@Autowired
	private PropertyRepository propertyRepository;
	@Autowired
	private BuyerProcessRepository buyerprocessRepository;
	@Autowired
	private PropertyBuyerDetailsRepository propertyBuyerDetailsRepo;
	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private VoucherRepository voucherRepository;
	@Autowired
	private AppointmentsRepository appointmentsRepository;

	@Autowired
	private BrokerageAgencyRepository brokerageAgencyRepo;

	@Autowired
	private BuyerProcessRepository buyerProcessRepo;

	@Autowired
	private PropertybidprocessRepository bidProcessRepository;

	// for only manually testing purpose

	public BuyerProcess save(BuyerProcessDTO buyerprocessDTO) {

		ModelMapper mapper = new ModelMapper();

		BuyerProcess buyerprocess = new BuyerProcess();
		Chiraghuser chiraghuser = userRepository.findByUserId(buyerprocessDTO.getChiraghuser().getUserId());
		buyerprocess.setChiraghuser(chiraghuser);
		Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(buyerprocessDTO.getPropertyId());
		buyerprocess.setChiraghproperty(chiraghproperty);
		buyerprocess.setProcessType(buyerprocessDTO.getProcessType());
		buyerprocess.setBidReferenceNo(chiragUtill.genearteRandomNo("BidReferenceNo"));

		BuyerProcess newbuyerprocess = buyerprocessRepository.save(buyerprocess);

		return newbuyerprocess;

	}

	public ResponseEntity getBuyers(int buyerProcessId) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();

			List<PropertyBuyerDetails> propertyBuyerDetails = propertyBuyerDetailsRepo
					.findBuyerByProcessId(buyerProcessId);
			List<PropertyBuyerDetailDTO> propertyBuyerDetailsDTOs = new ArrayList();
			if (propertyBuyerDetails != null) {
				propertyBuyerDetailsDTOs = ObjectMapperUtils.mapAll(propertyBuyerDetails, PropertyBuyerDetailDTO.class);
			}

			if (propertyBuyerDetailsDTOs == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				BuyerProcess buyerProcess = buyerProcessRepo.findBuyerProcessById(buyerProcessId);
				if (buyerProcess.getBuyerBrokerageAgency() != null) {
					BrokerageAgency brokerageAgency = brokerageAgencyRepo
							.getByid(buyerProcess.getBuyerBrokerageAgency().getBrokerageAgencyId());
					if (brokerageAgency != null) {
						BrokerageAgencyBuyerDto brokerageAgencyDto = ObjectMapperUtils.map(brokerageAgency,
								BrokerageAgencyBuyerDto.class);

						for (int i = 0; i < propertyBuyerDetailsDTOs.size(); i++) {
							propertyBuyerDetailsDTOs.get(i).setBuyerBrokerageAgency(brokerageAgencyDto);
						}
					}

				}
				if (buyerProcess.getBuyerBrokerageAgency() == null) {
					for (int i = 0; i < propertyBuyerDetailsDTOs.size(); i++) {
						propertyBuyerDetailsDTOs.get(i).setBuyerprocessId(buyerProcessId);
					}
				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						propertyBuyerDetailsDTOs);
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity getPropertiesForInProcess(int pageNumber, int pageSize, Boolean isRentalMod) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();

			List<BuyerProcess> buyerProcess = new ArrayList<>();
			Page<BuyerProcess> paginatedData;
			if (isRentalMod != null && isRentalMod) {
				paginatedData = buyerprocessRepository.getInProcessPropertiesForRental(chiraghuser.getUserId(),
						PageRequest.of(pageNumber, pageSize));
			} else {
				paginatedData = buyerprocessRepository.getInProcessPropertiesForBuySell(chiraghuser.getUserId(),
						PageRequest.of(pageNumber, pageSize));
			}
			buyerProcess = paginatedData.getContent();
			List<BuyerProcessDTO2> propertyBuyerDetailsDTOs = new ArrayList();
			if (buyerProcess != null) {

//				propertyBuyerDetailsDTOs = ObjectMapperUtils.mapAll(buyerProcess, BuyerProcessDTO2.class);

				paginatedData.getContent().stream().forEach(buyerProcessDetails -> {
					BuyerProcessDTO2 chiraghBuyerProcessDetails = mapper.map(buyerProcessDetails,
							BuyerProcessDTO2.class);

					BrokerageProposal brokerageProposal = buyerProcessDetails.getChiraghproperty()
							.getBrokerageProposal();
					if (brokerageProposal != null
							&& StringValidationUtils.isNotZero(brokerageProposal.getFeeVoucherId())
							&& StringValidationUtils.isNotZero(brokerageProposal.getDepositVoucherId())) {

						Voucher auctionFeeVoucher = voucherRepository
								.getVouchersByVoucherId(brokerageProposal.getFeeVoucherId());
						Voucher auctionDepositVoucher = voucherRepository
								.getVouchersByVoucherId(brokerageProposal.getDepositVoucherId());
						if (auctionFeeVoucher != null && auctionDepositVoucher != null) {
							if (!StringValidationUtils.isNotZero(auctionFeeVoucher.getUnpaid())
									&& !StringValidationUtils.isNotZero(auctionDepositVoucher.getUnpaid())) {
								chiraghBuyerProcessDetails.getChiraghproperty().getBrokerageProposal()
										.setIsAuctionFeeCompleted(true);
							} else {
								chiraghBuyerProcessDetails.getChiraghproperty().getBrokerageProposal()
										.setIsAuctionFeeCompleted(false);
							}
						}
					}
					propertyBuyerDetailsDTOs.add(chiraghBuyerProcessDetails);

				});

			}

			if (propertyBuyerDetailsDTOs == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				PaginatedResponseDTO paginatedResponse = new PaginatedResponseDTO(paginatedData,
						propertyBuyerDetailsDTOs);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(paginatedResponse).collect(Collectors.toList()));
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity getBuyersByProperty(int propertyId) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();

			List<PropertyBuyerDetails> propertyBuyerDetails = propertyBuyerDetailsRepo
					.findBuyerByPropertyId(propertyId);
			List<PropertyBuyerDetailDTO> propertyBuyerDetailsDTOs = new ArrayList();
			if (propertyBuyerDetails != null) {
				propertyBuyerDetailsDTOs = ObjectMapperUtils.mapAll(propertyBuyerDetails, PropertyBuyerDetailDTO.class);
			}

			if (propertyBuyerDetailsDTOs == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						propertyBuyerDetailsDTOs);
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity getBuyerProcess(int propertyId) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();

			BuyerProcess buyerprocess = buyerprocessRepository.findBuyerExisting(chiraghuser.getUserId(), propertyId);

			if (buyerprocess == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, BuyerMessages.DATA_RETRIEVED_FAILURE, null);
			}

			BuyerProcessDTO2 buyerProcessDTO2 = ObjectMapperUtils.map(buyerprocess, BuyerProcessDTO2.class);

			if (buyerProcessDTO2 == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(buyerProcessDTO2).collect(Collectors.toList()));
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity getOpenHouseProperties(int pageNumber, int pageSize, Boolean isRentalMod) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();

			List<BuyerProcess> buyerProcess = new ArrayList<>();
			Page<BuyerProcess> paginatedData;
			if (isRentalMod != null && isRentalMod) {
				paginatedData = buyerprocessRepository.getOpenHousePropertiesForRental(chiraghuser.getUserId(),
						PageRequest.of(pageNumber, pageSize));
			} else {
				paginatedData = buyerprocessRepository.getOpenHousePropertiesForBuySell(chiraghuser.getUserId(),
						PageRequest.of(pageNumber, pageSize));
			}

			buyerProcess = paginatedData.getContent();
			List<BuyerProcessDTO2> propertyBuyerDetailsDTOs = null;
			if (buyerProcess != null) {

				propertyBuyerDetailsDTOs = ObjectMapperUtils.mapAll(buyerProcess, BuyerProcessDTO2.class);

				// add bid count to the response
				propertyBuyerDetailsDTOs.forEach(buyerDetail -> {
					long i = 0;
					i = bidProcessRepository.findTotalBidPlaced(buyerDetail.getChiraghproperty().getPropertyId());
					buyerDetail.getChiraghproperty().setBidCount(i);

				});
				// end
//				paginatedData.getContent().stream().forEach(buyerProcessDetails -> {
//					BuyerProcessDTO2 chiraghBuyerProcessDetails = mapper.map(buyerProcessDetails, BuyerProcessDTO2.class);
//
//					BrokerageProposal brokerageProposal = buyerProcessDetails.getChiraghproperty().getBrokerageProposal();
//					if (brokerageProposal != null && StringValidationUtils.isNotZero(brokerageProposal.getFeeVoucherId()) && StringValidationUtils.isNotZero(brokerageProposal.getDepositVoucherId())) {
//
//						Voucher auctionFeeVoucher = voucherRepository
//								.getVouchersByVoucherId(brokerageProposal.getFeeVoucherId());
//						Voucher auctionDepositVoucher = voucherRepository
//								.getVouchersByVoucherId(brokerageProposal.getDepositVoucherId());
//						if (auctionFeeVoucher != null && auctionDepositVoucher != null) {
//							if (!StringValidationUtils.isNotZero(auctionFeeVoucher.getUnpaid())
//									&& !StringValidationUtils.isNotZero(auctionDepositVoucher.getUnpaid())) {
//								chiraghBuyerProcessDetails.getChiraghproperty().getBrokerageProposal().setIsAuctionFeeCompleted(true);
//							} else {
//								chiraghBuyerProcessDetails.getChiraghproperty().getBrokerageProposal().setIsAuctionFeeCompleted(false);
//							}
//						}
//					}
//					propertyBuyerDetailsDTOs.add(chiraghBuyerProcessDetails);
//					
//				});
//				

			}

			if (propertyBuyerDetailsDTOs == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				PaginatedResponseDTO paginatedResponse = new PaginatedResponseDTO(paginatedData,
						propertyBuyerDetailsDTOs);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(paginatedResponse).collect(Collectors.toList()));
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

}
