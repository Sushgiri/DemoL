package com.bestercapitalmedia.letwizard.buyer.leads;

public class RequestForChangeDTO {
	private String title;
	private String note;
	private String metadata;
	private Integer isRefferedToSeller;
	private Integer leadId;
	


	public RequestForChangeDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public Integer getIsRefferedToSeller() {
		return isRefferedToSeller;
	}

	public void setIsRefferedToSeller(Integer isRefferedToSeller) {
		this.isRefferedToSeller = isRefferedToSeller;
	}

	public Integer getLeadId() {
		return leadId;
	}

	public void setLeadId(Integer leadId) {
		this.leadId = leadId;
	}
	
	
}

