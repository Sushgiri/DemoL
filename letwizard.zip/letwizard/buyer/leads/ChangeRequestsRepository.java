package com.bestercapitalmedia.letwizard.buyer.leads;

import org.springframework.data.repository.CrudRepository;

public interface ChangeRequestsRepository extends CrudRepository<ChangeRequests, Integer>{

//	@Query(value = "select * from adminactivitylogs where property_id=?1", nativeQuery = true)
//	public List<ChangeRequests> findActivityLogsByPropertyId(int propertyId);

}
