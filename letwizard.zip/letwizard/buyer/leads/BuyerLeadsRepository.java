package com.bestercapitalmedia.letwizard.buyer.leads;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface BuyerLeadsRepository extends CrudRepository<BuyerLeads, Integer>{

	@Query(value = "select * from buyer_leads where id=?1  ", nativeQuery = true)
	public BuyerLeads findByLeadId(int leadId);
	
	@Query(value = "select * from buyer_leads where departement_id=?1 AND assigned_to IS NULL and assigned_by is null and status = 'not started' order by updated_at desc", nativeQuery = true)
	public List<BuyerLeads> findByDepartementIdForUser(int departementId);
	
	@Query(value = "select * from buyer_leads where departement_id=?1 and assigned_by is not null and (status = 'in process' or status = 'not started' or status = 'request for change') order by updated_at desc", nativeQuery = true)
	public List<BuyerLeads> findByAssignedtoDepartementIdForHOD(int departementId,int userId);
	
	@Query(value = "select * from buyer_leads where departement_id=?1 AND (assigned_to=?2 or assigned_by=?2) and (status = 'in process' or status = 'not started' or status = 'request for change') order by updated_at desc", nativeQuery = true)
	public List<BuyerLeads> findByAssignedtoDepartementId(int departementId,int userId);
	
	@Query(value = "select * from buyer_leads where departement_id=?1 and id=?2 AND assigned_to IS NULL and status = 'not started' order by updated_at desc", nativeQuery = true)
	public BuyerLeads findUnassignedByDepartementId(int departementId, int leadId);
	
	@Query(value = "select * from buyer_leads where departement_id=?1 AND status=?2 order by updated_at desc", nativeQuery = true)
	public List<BuyerLeads> findByStatustoDepartment(int departementId, String status);
	
	@Query(value = "select * from buyer_leads where id=?1 AND assigned_to=?2 order by updated_at desc", nativeQuery = true)
	public BuyerLeads findByAssignedUser(int leadId, int userId);
	
	@Query(value = "select * from buyer_leads where departement_id=?1 and assigned_to IS NULL AND STATUS = 'done' AND PROCESS = 'approval' order by updated_at desc", nativeQuery = true)
	public List<BuyerLeads> findApprovedLeads(int departementId,int userId);

	@Query(value = "select * from buyer_leads where property_id = ?1 and buyer_process_id = ?2 and departement_id=3 and assigned_to IS Not NULL AND STATUS = 'in process' order by updated_at desc", nativeQuery = true)
	public BuyerLeads findLeadForOpenHouse(int propertyId ,int buyerProcessId);
	
	@Query(value = "SELECT * FROM buyer_leads WHERE property_id = ?1 AND buyer_process_id = ?2 LIMIT 1", nativeQuery = true)
	public BuyerLeads findLeadByProcessIdAndPropertyId(int propertyId ,int buyerProcessId);
}
