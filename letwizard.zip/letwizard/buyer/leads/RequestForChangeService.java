package com.bestercapitalmedia.letwizard.buyer.leads;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.brokerage.proposal.BrokerageProposal;
import com.bestercapitalmedia.letwizard.brokerage.proposal.BrokerageProposalRepository;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.leads.Leads;
import com.bestercapitalmedia.letwizard.leads.LeadsRepository;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.DateUtils;

@Service
public class RequestForChangeService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	ResponseUtill responseUtill;

	@Autowired
	private BrokerageProposalRepository brokerageProposalRepository;

	@Autowired
	private ChangeRequestsRepository changeRequestsRepository;

	public ResponseEntity requestForChange(Authentication authentication, int buyerProcessId, RequestForChangeDTO dto) {

		try {
			User user = (User) authentication.getPrincipal();
			Chiraghuser chiraghuser = userRepository.findByUserNameAndRole(user.getUsername());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			BrokerageProposal proposal = brokerageProposalRepository.findProposalByPropertyId(dto.getLeadId());
//			BuyerLeads lead = buyerLeadsRepository.findByLeadId(dto.getLeadId());
			System.out.println("proposal  " + proposal.getAction());

					// saving the change for request
					ChangeRequests changeRequest = new ChangeRequests();
					changeRequest.setTitle(dto.getTitle());
					changeRequest.setBuyerProcessId(proposal.getId());
					changeRequest.setCreatedAt(DateUtils.getDefault().getNowTime());
					changeRequest.setMetadata(dto.getMetadata());
					changeRequest.setNote(dto.getNote());
					changeRequest.setStatus("pending");
					changeRequest.setPropertyId(proposal.getChiraghproperty().getPropertyId());
					changeRequest.setUpdatedAt(DateUtils.getDefault().getNowTime());
					changeRequest = changeRequestsRepository.save(changeRequest);

					return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
							Stream.of(changeRequest).collect(Collectors.toList()));
			

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

}
