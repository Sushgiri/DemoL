package com.bestercapitalmedia.letwizard.buyer.leads;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcess;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "buyer_leads")
public class BuyerLeads implements Serializable {
	private Integer id;
	private BuyerProcess buyer_process_id;
	private Chiraghproperty chiraghproperty;
	private Chiraghuser assignedTo;
	private Chiraghuser assignedBy;
	private Date assignedAt;
	//private ChangeRequests changeRequest;
	private Integer departementId;
	private String status;
	private Date startedAt;
	private Date createdAt;
	private Date updatedAt;
	private String remarks;
	private Integer archive_by;
	private String process;
	private Boolean isRentalMod;
	
	public BuyerLeads() {
	}
	

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", length = 26)
	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "started_at", length = 26)
	public Date getStartedAt() {
		return startedAt;
	}

	public void setStartedAt(Date startedAt) {
		this.startedAt = startedAt;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "property_id")
	public Chiraghproperty getChiraghproperty() {
		return this.chiraghproperty;
	}

	public void setChiraghproperty(Chiraghproperty chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "assigned_to")
	public Chiraghuser getAssignedTo() {
		return this.assignedTo;
	}

	public void setAssignedTo(Chiraghuser assignedTo) {
		this.assignedTo = assignedTo;
	}

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "assigned_by")
	public Chiraghuser getAssignedBy() {
		return this.assignedBy;
	}

	public void setAssignedBy(Chiraghuser assignedBy) {
		this.assignedBy = assignedBy;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "assigned_at", length = 26)
	public Date getAssignedAt() {
		return this.assignedAt;
	}

	public void setAssignedAt(Date assignedAt) {
		this.assignedAt = assignedAt;
	}

//	@Column(name = "process_id")
//	public Integer getProcessId() {
//		return this.processId;
//	}
//
//	public void setProcessId(Integer processId) {
//		this.processId = processId;
//	}

	@Column(name = "departement_id")
	public Integer getDepartementId() {
		return this.departementId;
	}

	public void setDepartementId(Integer departementId) {
		this.departementId = departementId;
	}

	@Column(name = "status", length = 20)
	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", length = 26)
	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	@Column(name = "remarks", length = 250)
	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Column(name = "archive_by")
	public Integer getArchive_by() {
		return archive_by;
	}

	public void setArchive_by(Integer archive_by) {
		this.archive_by = archive_by;
	}
	
//	@JsonIgnore
//	@OneToOne(fetch = FetchType.LAZY)
//	@JoinColumn(name = "process_id")
//	public ChangeRequests getChangeRequest() {
//		return changeRequest;
//	}
//
//	public void setChangeRequest(ChangeRequests changeRequest) {
//		this.changeRequest = changeRequest;
//	}

	@Column(name = "process")
	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "buyer_Process_Id")
	public BuyerProcess getBuyer_process_id() {
		return buyer_process_id;
	}


	public void setBuyer_process_id(BuyerProcess buyer_process_id) {
		this.buyer_process_id = buyer_process_id;
	}

	@Column(name = "is_rental_mod")
	public Boolean getIsRentalMod() {
		return isRentalMod;
	}

	public void setIsRentalMod(Boolean isRentalMod) {
		this.isRentalMod = isRentalMod;
	}
	
	
}
