package com.bestercapitalmedia.letwizard.buyer.dashboard;

public class RequestDtoForPaginatedWatchList {
	
	int page;
	int maxResult;
	String userName;
	Boolean isRentalMod;
	
	
	
	public int getPage() {
		return page;
	}



	public void setPage(int page) {
		this.page = page;
	}



	public int getMaxResult() {
		return maxResult;
	}



	public void setMaxResult(int maxResult) {
		this.maxResult = maxResult;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public RequestDtoForPaginatedWatchList() {
		
	}

	public Boolean getIsRentalMod() {
		return isRentalMod;
	}

	public void setIsRentalMod(Boolean isRentalMod) {
		this.isRentalMod = isRentalMod;
	}
}
