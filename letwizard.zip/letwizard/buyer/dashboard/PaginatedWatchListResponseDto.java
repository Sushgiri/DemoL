package com.bestercapitalmedia.letwizard.buyer.dashboard;

import java.util.List;

import com.bestercapitalmedia.letwizard.property.BuyerWatchListDTO;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyDetailsDTO2;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyDetailsDTO3;

public class PaginatedWatchListResponseDto {

	List<ChiraghPropertyDetailsDTO3> propertiesList;
	int totalPages;
	int pageNumber;
	int numberOfElements;
	long totalRecords;

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getNumberOfElements() {
		return numberOfElements;
	}

	public void setNumberOfElements(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public List<ChiraghPropertyDetailsDTO3> getPropertiesList() {
		return propertiesList;
	}

	public void setPropertiesList(List<ChiraghPropertyDetailsDTO3> propertiesList) {
		this.propertiesList = propertiesList;
	}

	public PaginatedWatchListResponseDto() {

	}
}
