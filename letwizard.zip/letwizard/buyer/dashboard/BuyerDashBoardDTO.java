package com.bestercapitalmedia.letwizard.buyer.dashboard;

public class BuyerDashBoardDTO {
	
	
	//only for code testing propose 
	// property id must be get from frontend in the form of hidden field
	// when buyer click on ADD wish list button
	
	private int propertyId;
	
	// type yes or null in lower case 
    private String metaKey;
  
	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}



	public String getMetaKey() {
		return metaKey;
	}



	public void setMetaKey(String metaKey) {
		this.metaKey = metaKey;
	}



	public BuyerDashBoardDTO() {
		
	}

}
