package com.bestercapitalmedia.letwizard.buyer.dashboard;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity

@Table(name = "buyerdashboard")
public class BuyerDashBoard  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Column(name = "buyer_dash_board_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)	
	Integer buyerdashboardId;
	
	
	@Column(name = "meta_Key", length = 25)
	@Basic(fetch = FetchType.EAGER)
	String metaKey;
	
	@Column(name = "date", length = 100)
	@Basic(fetch = FetchType.EAGER)
	Date date;
	
	@Column(name = "is_deleted", length = 6)
	@Basic(fetch = FetchType.EAGER)
	String isdeleted;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "user_Id", referencedColumnName = "user_Id") })
	@JsonBackReference
	Chiraghuser chiraghuser;
	/**
	 */
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "property_Id", referencedColumnName = "property_Id") })
	@JsonBackReference
	Chiraghproperty chiraghproperty;
	
	public Integer getBuyerdashboardId() {
		return buyerdashboardId;
	}



	public void setBuyerdashboardId(Integer buyerdashboardId) {
		this.buyerdashboardId = buyerdashboardId;
	}



	public String getMetaKey() {
		return metaKey;
	}



	public void setMetaKey(String metaKey) {
		this.metaKey = metaKey;
	}



	public Chiraghuser getChiraghuser() {
		return chiraghuser;
	}



	public void setChiraghuser(Chiraghuser chiraghuser) {
		this.chiraghuser = chiraghuser;
	}



	public Chiraghproperty getChiraghproperty() {
		return chiraghproperty;
	}



	public void setChiraghproperty(Chiraghproperty chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public Date getDate() {
		return date;
	}



	public void setDate(Date date2) {
		this.date = date2;
	}



	public String getIsdeleted() {
		return isdeleted;
	}



	public void setIsdeleted(String isdeleted) {
		this.isdeleted = isdeleted;
	}
	
	public BuyerDashBoard() {
		
	 }
	
	
}