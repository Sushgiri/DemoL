package com.bestercapitalmedia.letwizard.buyer.dashboard;

public class BuyerDto {

	int propertyId;
	String userName;
	
	public int getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public BuyerDto() {
	}
	
}
