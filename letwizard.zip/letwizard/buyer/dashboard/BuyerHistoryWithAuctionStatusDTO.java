package com.bestercapitalmedia.letwizard.buyer.dashboard;

import java.util.List;

import com.bestercapitalmedia.letwizard.property.images.Propertyimages;

public class BuyerHistoryWithAuctionStatusDTO {

	int propertyId;
	String projectName;
	String auctionStatus;
	private String address;
	private String propertyTitle;
	private String grossArea;
	private String areaUnit;
	private int noOfBaths;
	private int noOfBedrooms;
	private Integer carParks;
	List<Propertyimages> images;

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getAuctionStatus() {
		return auctionStatus;
	}

	public void setAuctionStatus(String auctionStatus) {
		this.auctionStatus = auctionStatus;
	}

	public BuyerHistoryWithAuctionStatusDTO() {

	}

	public List<Propertyimages> getImages() {
		return images;
	}

	public void setImages(List<Propertyimages> images) {
		this.images = images;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPropertyTitle() {
		return propertyTitle;
	}

	public void setPropertyTitle(String propertyTitle) {
		this.propertyTitle = propertyTitle;
	}

	public String getGrossArea() {
		return grossArea;
	}

	public void setGrossArea(String grossArea) {
		this.grossArea = grossArea;
	}

	public String getAreaUnit() {
		return areaUnit;
	}

	public void setAreaUnit(String areaUnit) {
		this.areaUnit = areaUnit;
	}

	public int getNoOfBaths() {
		return noOfBaths;
	}

	public void setNoOfBaths(int noOfBaths) {
		this.noOfBaths = noOfBaths;
	}

	public int getNoOfBedrooms() {
		return noOfBedrooms;
	}

	public void setNoOfBedrooms(int noOfBedrooms) {
		this.noOfBedrooms = noOfBedrooms;
	}

	public Integer getCarParks() {
		return carParks;
	}

	public void setCarParks(Integer carParks) {
		this.carParks = carParks;
	}

}
