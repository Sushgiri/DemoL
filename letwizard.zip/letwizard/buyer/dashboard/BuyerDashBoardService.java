package com.bestercapitalmedia.letwizard.buyer.dashboard;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.buyer.details.PropertyBuyerDetails;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.events.EventsService;
import com.bestercapitalmedia.letwizard.property.BuyerHistoryResponse;
import com.bestercapitalmedia.letwizard.property.BuyerWatchListDTO;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyDetailsDTO2;
import com.bestercapitalmedia.letwizard.property.ChiraghPropertyDetailsDTO3;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyPaginationRepo;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.images.PropertyImagesDTO;
import com.bestercapitalmedia.letwizard.seller.dashboard.SellerDashBoard;
import com.bestercapitalmedia.letwizard.seller.dashboard.SellingBuyingHistoryDTO;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;




@Service
public class BuyerDashBoardService {

	private static final Logger logger = LoggerFactory.getLogger(BuyerDashBoardService.class);
	@Autowired
	private ChiragUtill chiragUtill;
	@Autowired
	private PropertyRepository propertyRepository;
	@Autowired
	private BuyerDashBoardRepository buyerdashboardRepository;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BuyerDashBoardPaginationRepo paginationRepo;
	
	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired 
	private EventsService eventsService;
	
	public String msg;
	public String historymsg;
	public String deletehistory;
	public String deletewatchlist;

	@Autowired
	private Environment env;
	// get history 
	
	
	public ResponseEntity getPaginatedBuyerHistoryProperty(RequestDtoForPaginatedPropertyHistoryList dto) {
		if (dto.getIsRentalMod() != null && dto.getIsRentalMod()) {
			return propertyHistoryForRental(dto);
		} else {
			return propertyHistoryForBuySell(dto);
		}
	}

	private ResponseEntity propertyHistoryForBuySell(RequestDtoForPaginatedPropertyHistoryList dto) {
		try {
		List<ChiraghPropertyDetailsDTO3> auctionStatusDTOList = new ArrayList();
		PaginatedHistoryListResponseDto responsedto = new PaginatedHistoryListResponseDto();
		Chiraghuser chiraghuser = userRepository.findByUserName(dto.getUserName());
		int userId = chiraghuser.getUserId();
		logger.info("Above status");
		Page<BuyerDashBoard> historylist = paginationRepo.getPaginatedHistoryByUserId(userId,PageRequest.of(dto.getPage(), dto.getMaxResult()));
		historylist.stream().forEach(s -> {
			if (s.getChiraghproperty().getRentalProperty() == null) {
				ChiraghPropertyDetailsDTO3 auctionStatusDTO = ObjectMapperUtils.map(s.getChiraghproperty(), ChiraghPropertyDetailsDTO3.class);
				List<PropertyImagesDTO> propertyImages = ObjectMapperUtils.mapAll(s.getChiraghproperty().getImages(), PropertyImagesDTO.class);
				auctionStatusDTO.setImages(propertyImages.stream()
						.filter(d -> d.getImageName().equals("ordinary")||d.getImageName().equals("main-ordinary")).collect(Collectors.toList()));
				auctionStatusDTOList.add(auctionStatusDTO);
			}
		});

		responsedto.setPropertiesList(auctionStatusDTOList);
		responsedto.setPageNumber(historylist.getNumber());
		responsedto.setNumberOfElements(historylist.getNumberOfElements());
		responsedto.setTotalPages(historylist.getTotalPages());
		responsedto.setTotalRecords(historylist.getTotalElements());

		if (responsedto == null) {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
					null);
		} else {
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(responsedto).collect(Collectors.toList()));
		}
	} catch (Exception e) {
		return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
				SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
	}
	}

	private ResponseEntity propertyHistoryForRental(RequestDtoForPaginatedPropertyHistoryList dto) {
		try {
			List<ChiraghPropertyDetailsDTO3> auctionStatusDTOList = new ArrayList();
			PaginatedHistoryListResponseDto responsedto = new PaginatedHistoryListResponseDto();
			Chiraghuser chiraghuser = userRepository.findByUserName(dto.getUserName());
			int userId = chiraghuser.getUserId();


			logger.info("Above status");
			Page<BuyerDashBoard> historylist = paginationRepo.getPaginatedHistoryByUserId(userId,PageRequest.of(dto.getPage(), dto.getMaxResult()));
			historylist.stream().forEach(s -> {
				if (s.getChiraghproperty().getRentalProperty() != null) {
					ChiraghPropertyDetailsDTO3 auctionStatusDTO = ObjectMapperUtils.map(s.getChiraghproperty(), ChiraghPropertyDetailsDTO3.class);
					List<PropertyImagesDTO> propertyImages = ObjectMapperUtils.mapAll(s.getChiraghproperty().getImages(), PropertyImagesDTO.class);
					auctionStatusDTO.setImages(propertyImages.stream()
							.filter(d -> d.getImageName().equals("ordinary")||d.getImageName().equals("main-ordinary")).collect(Collectors.toList()));
					auctionStatusDTOList.add(auctionStatusDTO);
				}
			});

			responsedto.setPropertiesList(auctionStatusDTOList);
			responsedto.setPageNumber(historylist.getNumber());
			responsedto.setNumberOfElements(historylist.getNumberOfElements());
			responsedto.setTotalPages(historylist.getTotalPages());
			responsedto.setTotalRecords(historylist.getTotalElements());

			if (responsedto == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(responsedto).collect(Collectors.toList()));
			}
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
	// get watch list
	@CrossOrigin(origins = "*")
	public ResponseEntity getBuyerWatchlistProperty(RequestDtoForPaginatedWatchList dto) {
		if (dto.getIsRentalMod() != null && dto.getIsRentalMod()) {
			return getBuyerWatchListPropertyForRental(dto);
		} else {
			return getBuyerWatchListPropertyForBuySell(dto);
		}
	}

	private ResponseEntity getBuyerWatchListPropertyForBuySell(RequestDtoForPaginatedWatchList dto) {
		try {
			ModelMapper mapper = new ModelMapper();
			Chiraghuser chiraghuser = userRepository.findByUserName(dto.getUserName());
			int userId = chiraghuser.getUserId();
			logger.info("userId :"+userId );
			PaginatedWatchListResponseDto paginatedWatchListResponse = new PaginatedWatchListResponseDto();
			List<ChiraghPropertyDetailsDTO3> buyerwatchlistDTOList=new ArrayList();
			Page<BuyerDashBoard> list =paginationRepo.getPaginatedWatchListPropertiesByUserIdwithDeletedFlag(userId,
					PageRequest.of(dto.getPage(), dto.getMaxResult()));


			logger.info("List of watch list :"+list.toString());
			if(list == null)
			{
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.BUYER_WATCH_LIST,
						null);
			}
			else {
				list.getContent().stream().forEach(s -> {
					ChiraghPropertyDetailsDTO3 buyerwatchlistDTO=new ChiraghPropertyDetailsDTO3 ();
					buyerwatchlistDTO = ObjectMapperUtils.map(s.getChiraghproperty(), ChiraghPropertyDetailsDTO3.class);
					if (s.getChiraghproperty().getRentalProperty() == null) {
						buyerwatchlistDTOList.add(buyerwatchlistDTO);
					}
				});
				// set is watchlist key
				buyerwatchlistDTOList.forEach(s -> {
					try {
						logger.info("Property for each" + s.getPropertyId());
						if (chiraghuser == null) {
							s.setIsWatchedList("");
						} else {
							Integer chiraghuserId = chiraghuser.getUserId();
							BuyerDashBoard obj = buyerdashboardRepository.getPropertiesByUserIdAndPropertyId(userId,
									s.getPropertyId());
							if (obj == null) {
								s.setIsWatchedList("false");
							} else {
								s.setIsWatchedList("true");
							}
						}
					} catch (Exception e) {
						logger.error(e.getMessage(), e);
					}
				});
				paginatedWatchListResponse.setPropertiesList(buyerwatchlistDTOList);
				paginatedWatchListResponse.setPageNumber(list.getNumber());
				paginatedWatchListResponse.setNumberOfElements(list.getNumberOfElements());
				paginatedWatchListResponse.setTotalPages(list.getTotalPages());
				paginatedWatchListResponse.setTotalRecords(list.getTotalElements());
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(paginatedWatchListResponse).collect(Collectors.toList()));

			}


		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	private ResponseEntity getBuyerWatchListPropertyForRental(RequestDtoForPaginatedWatchList dto) {
		try {
			ModelMapper mapper = new ModelMapper();
			Chiraghuser chiraghuser = userRepository.findByUserName(dto.getUserName());
			int userId = chiraghuser.getUserId();
			logger.info("userId :"+userId );
			PaginatedWatchListResponseDto paginatedWatchListResponse = new PaginatedWatchListResponseDto();
			List<ChiraghPropertyDetailsDTO3> buyerwatchlistDTOList=new ArrayList();
			Page<BuyerDashBoard> list =paginationRepo.getPaginatedWatchListPropertiesByUserIdwithDeletedFlag(userId,
					PageRequest.of(dto.getPage(), dto.getMaxResult()));


			logger.info("List of watch list :"+list.toString());
			if(list == null)
			{
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.BUYER_WATCH_LIST,
						null);
			}
			else {
				list.getContent().stream().forEach(s -> {
					ChiraghPropertyDetailsDTO3 buyerwatchlistDTO=new ChiraghPropertyDetailsDTO3 ();
					buyerwatchlistDTO = ObjectMapperUtils.map(s.getChiraghproperty(), ChiraghPropertyDetailsDTO3.class);
					if (s.getChiraghproperty().getRentalProperty() != null) {
						buyerwatchlistDTOList.add(buyerwatchlistDTO);
					}
				});
				// set is watchlist key
				buyerwatchlistDTOList.forEach(s -> {
					try {
						logger.info("Property for each" + s.getPropertyId());
						if (chiraghuser == null) {
							s.setIsWatchedList("");
						} else {
							Integer chiraghuserId = chiraghuser.getUserId();
							BuyerDashBoard obj = buyerdashboardRepository.getPropertiesByUserIdAndPropertyId(userId,
									s.getPropertyId());
							if (obj == null) {
								s.setIsWatchedList("false");
							} else {
								s.setIsWatchedList("true");
							}
						}
					} catch (Exception e) {
						logger.error(e.getMessage(), e);
					}
				});
				paginatedWatchListResponse.setPropertiesList(buyerwatchlistDTOList);
				paginatedWatchListResponse.setPageNumber(list.getNumber());
				paginatedWatchListResponse.setNumberOfElements(list.getNumberOfElements());
				paginatedWatchListResponse.setTotalPages(list.getTotalPages());
				paginatedWatchListResponse.setTotalRecords(list.getTotalElements());
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(paginatedWatchListResponse).collect(Collectors.toList()));

			}


		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}


	// Save to History

	public String saveHistory(int propertyId, String userName, HttpServletRequest httpServletRequest) {

		try {


			Chiraghuser userexit = userRepository.findByUserName(userName);
			int userId =userexit .getUserId();
			//Chiraghproperty chiraghpropertyexist= propertyRepository.findByPropertyId(propertyId);
			//int propertyId1=chiraghpropertyexist.getPropertyId();
			BuyerDashBoard dashboard= buyerdashboardRepository.IsHistoryExist(propertyId,userId);
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
			if(dashboard==null)

			{
				BuyerDashBoard buyerdashboard = new BuyerDashBoard();
				Chiraghuser chiraghuser = userRepository.findByUserName(userName);
				buyerdashboard.setChiraghuser(chiraghuser);
				
				buyerdashboard.setChiraghproperty(chiraghproperty);
				buyerdashboard.setMetaKey("History");
				buyerdashboard.setDate(new Date());
				buyerdashboard.setIsdeleted("false");
				BuyerDashBoard newbuyerdashboard = buyerdashboardRepository.save(buyerdashboard);

				historymsg = "Property Added to Histroy Sucessfully!";
			}

			else {

				historymsg = "Property Already Exist in History!";
			}
			if (userexit != null) {
				if(env.getProperty("recommendation.engine.enable").equals("true")) {
				 //eventsService.propertyViewed(chiraghproperty,userexit);
				}
			}
			
			

		}

		catch (Exception e) {
			logger.error(e.getMessage(), e);

			historymsg = "Something Went Wrong";

		}

		return historymsg;
	}

	// Save to Watch List

	public String saveWatchList(int propertyId, String userName, HttpServletRequest httpServletRequest) {

		try {




			Chiraghuser userexist= userRepository.findByUserName(userName);
			int userId=userexist.getUserId();

			BuyerDashBoard dashboard= buyerdashboardRepository.IsWactchListExist(propertyId,userId);

			if(dashboard == null) // property came for first time in db

			{
				BuyerDashBoard buyerdashboard = new BuyerDashBoard();
				// so add it in wishlist
				Chiraghuser chiraghuser = userRepository.findByUserName(userName);
				buyerdashboard.setChiraghuser(chiraghuser);
				Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);

				// chiraghproperty.setAmount(amount);

				//chiraghproperty.setAmount(amount);


				buyerdashboard.setChiraghproperty(chiraghproperty);
				buyerdashboard.setMetaKey("Watch List");
				buyerdashboard.setDate(new Date());
				buyerdashboard.setIsdeleted("false");
				BuyerDashBoard newbuyerdashboard = buyerdashboardRepository.save(buyerdashboard);

				msg = "Property Added to Watch List Sucessfully!";
			} else {

				String softdelete = dashboard.getIsdeleted();
				if (softdelete.equals("false")) {

					dashboard.setIsdeleted("true");
					dashboard.setDate(new Date());
					BuyerDashBoard newbuyerdashboard = buyerdashboardRepository.save(dashboard);
					msg = "Property Removed From Watch List!";
				}

				else {
					BuyerDashBoard dashboardbuyer = new BuyerDashBoard();
					Chiraghuser chiraghuser = userRepository.findByUserName(userName);
					dashboardbuyer.setChiraghuser(chiraghuser);
					Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
					dashboardbuyer.setChiraghproperty(chiraghproperty);
					dashboardbuyer.setMetaKey("Watch List");
					dashboardbuyer.setDate(new Date());
					dashboardbuyer.setIsdeleted("false");
					BuyerDashBoard newbuyerdashboard = buyerdashboardRepository.save(dashboardbuyer);
					msg = "Property Added to Watch List Sucessfully!";
				}

			}
		}

		catch (Exception e) {
			logger.error(e.getMessage(), e);

			msg = "Something Went Wrong";

		}

		return msg;
	}

	// delete from history

	public String deletefromHistory(int propertyId, String userName, HttpServletRequest httpServletRequest) {

		try {





			Chiraghuser userexist= userRepository.findByUserName(userName);
			int userId=userexist.getUserId();

			BuyerDashBoard dashboard= buyerdashboardRepository.IsHistoryExist(propertyId,userId);

			if(dashboard==null)


			{
				// this scenrio never happen coz always deleteable properties are called
			}

			else {
				dashboard.setDate(new Date());
				dashboard.setIsdeleted("true");
				BuyerDashBoard newbuyerdashboard = buyerdashboardRepository.save(dashboard);

				deletehistory = "Property Delete From History Sucessfully!";
			}

		}

		catch (Exception e) {
			logger.error(e.getMessage(), e);

			deletehistory = "Something Went Wrong";

		}

		return deletehistory;
	}

	// delete from watch list

	public String deletefromWatchList(int propertyId, String userName, HttpServletRequest httpServletRequest) {

		try {




			Chiraghuser userexist= userRepository.findByUserName(userName);
			int userId=userexist.getUserId();
			BuyerDashBoard dashboard= buyerdashboardRepository.IsWactchListExist(propertyId,userId);

			if(dashboard==null)


			{
				// this scenrio never happen coz always deleteable properties are called
			}

			else {
				dashboard.setDate(new Date());
				dashboard.setIsdeleted("true");
				BuyerDashBoard newbuyerdashboard = buyerdashboardRepository.save(dashboard);

				deletewatchlist = "Property Delete From Watch List Sucessfully!";
			}

		}

		catch (Exception e) {
			logger.error(e.getMessage(), e);

			deletewatchlist = "Something Went Wrong";

		}

		return deletewatchlist;
	}

}
