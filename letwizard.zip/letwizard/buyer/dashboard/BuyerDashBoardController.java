package com.bestercapitalmedia.letwizard.buyer.dashboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.property.BuyerHistoryResponse;
import com.bestercapitalmedia.letwizard.property.BuyerWatchListDTO;
import com.bestercapitalmedia.letwizard.property.LetwizardPropertyService;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.SearchDTO;
import com.bestercapitalmedia.letwizard.property.type.PropertytypeRepository;
import com.bestercapitalmedia.letwizard.seller.dashboard.SellerDashBoardController;
import com.bestercapitalmedia.letwizard.seller.dashboard.SellingBuyingHistoryDTO;
import com.bestercapitalmedia.letwizard.seller.details.PropertySellerDetailDTO;
import com.bestercapitalmedia.letwizard.seller.details.Propertysellerdetails;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.LogUtill;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@CrossOrigin
@RequestMapping("/api/buyersdashboard")
public class BuyerDashBoardController {

	private static final Logger log = LoggerFactory.getLogger(SellerDashBoardController.class);
	@Autowired
	ChiragUtill chiraghUtill;
	@Autowired
	private BuyerDashBoardService buyerdashboardService;
	@Autowired
	private LogUtill logUtill;
	@Autowired
	private BuyerDashBoardRepository buyerdashboardRepository;
	@Autowired
	PropertyRepository propertyRepository;
	/** The chiragh util. */
	@Autowired
	private ChiragUtill chiraghUtil;
	@Autowired
	private ResponseUtill responseUtill;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private LetwizardPropertyService propertyService;
	String status = "";

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/v2/getHistoryListProperty", method = RequestMethod.POST)
	public ResponseEntity getPaginatedHistoryProperty(@RequestBody RequestDtoForPaginatedPropertyHistoryList dto,
			HttpServletRequest httpServletRequest) {
		return buyerdashboardService.getPaginatedBuyerHistoryProperty(dto);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/v2/getBuyerWatchListProperty", method = RequestMethod.POST)
	public ResponseEntity getBuyerWatchlistProperty(@RequestBody RequestDtoForPaginatedWatchList dto,
			HttpServletRequest httpServletRequest) {
		return buyerdashboardService.getBuyerWatchlistProperty(dto);
	}

	// Save to watch list

	@CrossOrigin(origins = "*")
	@CachePut(value = "auctionProperties")
	@RequestMapping(value = "/AddToWatchList", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity WatchListSave(@RequestBody BuyerDto dto,
			HttpServletRequest httpServletRequest) {

		try {

			String msg = buyerdashboardService.saveWatchList(dto.getPropertyId(), dto.getUserName(),
					httpServletRequest);

			if (msg.equals("Property Removed From Watch List!")) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.WATCH_LIST_EXIST, null);
			}

			else if (msg.equals("Property Added to Watch List Sucessfully!")) {

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.WATCH_LIST_ADDED, null);
			}

			else {
				return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
						PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
			}

		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	// Save to History

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/AddToHistory", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity HistorySave(@RequestBody BuyerDto dto, HttpServletRequest httpServletRequest) {

		try {

			Chiraghuser chiraghuser = userRepository.findByUserName(dto.getUserName());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, 
						PropertyMessages.USER_NOT_FOUND_AGAINST_USER_NAME, null);
			}
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(dto.getPropertyId());
	//			if(!(chiraghproperty.getAuctionStatus().equalsIgnoreCase("live") || chiraghproperty.getAuctionStatus().equalsIgnoreCase("waiting"))) {
	//				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND,
	//						PropertyMessages.DATA_RETRIVED_FAILURE, null);
	//
	//			}
			BuyerDashBoard dashboard = buyerdashboardRepository.IsHistoryExist(dto.getPropertyId(),
					chiraghuser.getUserId());
			if (dashboard == null) {
				
				buyerdashboardService.saveHistory(dto.getPropertyId(), dto.getUserName(),
						httpServletRequest);

			} else {
				buyerdashboardRepository.delete(dashboard);
				buyerdashboardService.saveHistory(dto.getPropertyId(), dto.getUserName(),
						httpServletRequest);

				
			}

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.HISTORY_ADDED, null);

		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	// delete from history

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/DeleteFromHistory/{propertyId}/{userName}", method = RequestMethod.DELETE)
	public @ResponseBody ResponseEntity HistoryDelete(@PathVariable(value = "propertyId") int propertyId,
			@PathVariable(value = "userName") String userName, HttpServletRequest httpServletRequest) {

		try {

			String msg = buyerdashboardService.deletefromHistory(propertyId, userName, httpServletRequest);

			if (msg.equals("Property Delete From History Sucessfully!")) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.HISTORY_DELETE, null);
			}

			else {
				return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
						PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
			}

		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	// delete from watch list

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/DeleteFromWatchList/{propertyId}/{userName}", method = RequestMethod.DELETE)
	public @ResponseBody ResponseEntity WatchListDelete(@PathVariable(value = "propertyId") int propertyId,
			@PathVariable(value = "userName") String userName, HttpServletRequest httpServletRequest) {

		try {

			String msg = buyerdashboardService.deletefromWatchList(propertyId, userName, httpServletRequest);

			if (msg.equals("Property Delete From Watch List Sucessfully!")) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.WATCH_LIST_DELETE, null);
			}

			else {
				return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
						PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
			}

		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	// @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	// public @ResponseBody ResponseEntity removefromlist(@Valid @RequestBody
	// BuyerDashBoardDTO buyerdashboardDTO,
	// HttpServletRequest httpServletRequest) {
	// try {
	//
	// if (chiraghUtill.isValidSession(httpServletRequest) == false)
	// return new ResponseEntity(chiraghUtill.getMessageObject("Invalid Session!"),
	// HttpStatus.BAD_REQUEST);
	//
	// ModelMapper mapper = new ModelMapper();
	// ObjectMapper objectMapper = new ObjectMapper();
	//
	// String key=buyerdashboardDTO.getMetaKey();
	// int pId=buyerdashboardDTO.getPropertyId();
	//
	//
	// if(key.equals("History"))
	// {
	// Chiraghproperty chiraghproperty=propertyRepository.findByPropertyId(pId);
	// if(chiraghproperty==null)
	// {
	// return new ResponseEntity(chiraghUtill.getMessageObject("Property Not
	// exist!"), HttpStatus.OK);
	// }
	//
	// BuyerDashBoard dashboard= buyerdashboardRepository.SearchHistoryByPid(pId);
	// if(dashboard==null)
	// return new ResponseEntity(chiraghUtill.getMessageObject("Property Already
	// Deleted From History List!"), HttpStatus.BAD_REQUEST);
	// else
	// buyerdashboardRepository.delete(dashboard);
	// }
	//
	// else {
	//
	// BuyerDashBoard dashboard=buyerdashboardRepository.SearchWishListByPid(pId);
	// if(dashboard==null) {
	//
	// return new ResponseEntity(chiraghUtill.getMessageObject("Property Already
	// Deleted From WishList!"), HttpStatus.BAD_REQUEST);
	// }
	// else
	// buyerdashboardRepository.delete(dashboard);
	//
	// }
	// try {
	// logUtill.inputLog(httpServletRequest,
	// chiraghUtill.getSessionUser(httpServletRequest),
	// "/api/buyersdashboard/delete",
	// objectMapper.writeValueAsString(buyerdashboardDTO),
	// objectMapper.writeValueAsString("Property Removed From List Sucessfully"));
	// } catch (Exception e) {
	// return new ResponseEntity(chiraghUtill.getMessageObject("Log Generation
	// Fail!"), HttpStatus.BAD_REQUEST);
	// }
	//
	// return new ResponseEntity(chiraghUtill.getMessageObject("Property Removed
	// From List Sucessfully"),
	// HttpStatus.OK);
	// } catch (Exception e) {
	// return new ResponseEntity(chiraghUtill.getMessageObject("Internal Server
	// Error!" + e.getMessage()),
	// HttpStatus.INTERNAL_SERVER_ERROR);
	// }
	//
	// }

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getBuyerWishListProperty/{userName}", method = RequestMethod.GET)
	public ResponseEntity getBuyerWishlistProperty(@PathVariable(value = "userName") String userName,
			HttpServletRequest httpServletRequest) {
		try {
			userName = chiraghUtill.getUserNameFromAuthentication();

			ModelMapper modelMapper = new ModelMapper();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			int userId = chiraghuser.getUserId();
			log.info("userId" + userId);

			List<BuyerWatchListDTO> buyerwatchlistDTOList = new ArrayList();
			List<BuyerDashBoard> list = buyerdashboardRepository.getWatchListPropertiesByUserIdwithDeletedFlag(userId);

			if (list == null) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.BUYER_WATCH_LIST, null);
			} else {
				list.stream().forEach(s -> {
					BuyerWatchListDTO buyerwatchlistDTO = new BuyerWatchListDTO();
					buyerwatchlistDTO.setProjectName(s.getChiraghproperty().getProjectName());
					buyerwatchlistDTO.setPropertyId(s.getChiraghproperty().getPropertyId());
					buyerwatchlistDTO.setGrossArea(s.getChiraghproperty().getGrossArea());
					buyerwatchlistDTO.setAreaUnit(s.getChiraghproperty().getAreaUnit());
					buyerwatchlistDTO.setAskingPrice(s.getChiraghproperty().getAskingPrice());
					buyerwatchlistDTO.setNoOfBedrooms(s.getChiraghproperty().getNoOfBedrooms());
					buyerwatchlistDTO.setNoOfBaths(s.getChiraghproperty().getNoOfBaths());
					buyerwatchlistDTO.setLocation(s.getChiraghproperty().getLocation());
					buyerwatchlistDTO.setMapLocation(s.getChiraghproperty().getMapLocation());
					buyerwatchlistDTO.setImages(s.getChiraghproperty().getImages().stream()
							.filter(d -> d.getImageName().equals("ordinary")).collect(Collectors.toList()));

					buyerwatchlistDTOList.add(buyerwatchlistDTO);
				});
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						buyerwatchlistDTOList);
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	String getAuctionStatus(List<BuyerHistoryResponse> list, Integer propertyId) {
		list.stream().filter(p -> p.getPropertyId() == propertyId).forEach(s -> setStatus(s.getAuctionStatus()));
		return getStatus();
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getBuyerHistoryProperty/{userName}", method = RequestMethod.GET)
	public ResponseEntity getBuyerHistoryProperty(@PathVariable(value = "userName") String userName,
			HttpServletRequest httpServletRequest) {
		try {
			userName = chiraghUtill.getUserNameFromAuthentication();
			List<BuyerHistoryWithAuctionStatusDTO> auctionStatusDTOList = new ArrayList();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			int userId = chiraghuser.getUserId();

			List<BuyerHistoryResponse> status1 = propertyService.getBuyerPropertyHistory(userId);
			log.info("Above status");
			List<BuyerDashBoard> list = buyerdashboardRepository.getPropertiesByUserIdwithDeletedFlag(userId);
			list.stream().forEach(s -> {
				BuyerHistoryWithAuctionStatusDTO auctionStatusDTO = new BuyerHistoryWithAuctionStatusDTO();
				auctionStatusDTO.setAuctionStatus(getAuctionStatus(status1, s.getChiraghproperty().getPropertyId()));
				auctionStatusDTO.setProjectName(s.getChiraghproperty().getProjectName());
				auctionStatusDTO.setPropertyId(s.getChiraghproperty().getPropertyId());
				auctionStatusDTO.setImages(s.getChiraghproperty().getImages().stream()
						.filter(d -> d.getImageName().equals("ordinary") || d.getImageName().equals("main-ordinary"))
						.collect(Collectors.toList()));
				auctionStatusDTOList.add(auctionStatusDTO);
			});

			// List<Map<String, String>> chiraghproperty =
			// propertyRepository.getBuyerHistoryProperty(userId);
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					auctionStatusDTOList);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}