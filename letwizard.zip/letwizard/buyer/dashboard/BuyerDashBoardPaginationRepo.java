package com.bestercapitalmedia.letwizard.buyer.dashboard;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;


public interface BuyerDashBoardPaginationRepo extends PagingAndSortingRepository<BuyerDashBoard, Integer> {
	
	@Query(value = " Select * from buyerdashboard where user_Id=?1 AND is_deleted='false' AND meta_Key Like '%Watch List%' ORDER BY buyerdashboard.date DESC",
			countQuery = "Select count(*) from buyerdashboard where user_Id=?1 AND is_deleted='false' AND meta_Key Like '%Watch List%' ORDER BY buyerdashboard.date DESC",
			nativeQuery = true)
	public Page<BuyerDashBoard> getPaginatedWatchListPropertiesByUserIdwithDeletedFlag(int userId,Pageable pageable);

	
	@Query(value = "Select * from buyerdashboard where user_Id=?1 AND meta_Key LIKE '%History%' AND is_deleted='false' ORDER BY buyerdashboard.date DESC",
			countQuery ="Select count(*) from buyerdashboard where user_Id=?1 AND meta_Key LIKE '%History%' AND is_deleted='false' ORDER BY buyerdashboard.date DESC",
			nativeQuery = true)
	public Page<BuyerDashBoard> getPaginatedHistoryByUserId(int userId,Pageable pageable);
}
