package com.bestercapitalmedia.letwizard.buyer.dashboard;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface BuyerDashBoardRepository extends  CrudRepository<BuyerDashBoard,Integer> {

	
	@Query(value = "Select * from buyerdashboard where property_Id=?1 AND user_Id=?2 AND meta_Key LIKE '%Watch List%' AND is_deleted='false';", nativeQuery = true)
	public BuyerDashBoard IsWactchListExist(int propertyId,int userId);
	
	@Query(value = "Select * from buyerdashboard where property_Id=?1 AND user_Id=?2 AND meta_Key LIKE '%History%' AND is_deleted='false';", nativeQuery = true)
	public BuyerDashBoard IsHistoryExist(int propertyId,int userId);
	
	@Query(value = "Select * from buyerdashboard where property_Id=?1 AND meta_Key LIKE '%History%' ;", nativeQuery = true)
	public BuyerDashBoard SearchHistoryByPid(int propertyId);
	
	@Query(value = " Select * from buyerdashboard where property_Id=?1 AND meta_Key LIKE '%Watch List%';", nativeQuery = true)
	public BuyerDashBoard SearchWishListByPid(int propertyId);
	
	@Query(value = " Select count(user_Id) As Total_Viewed from buyerdashboard where property_Id=?1 AND meta_Key LIKE '%History%';", nativeQuery = true)
	public List<Map<String,String>> FindTotalViewedOnProperty(int propertyId);


	@Query(value = " Select * from buyerdashboard where user_Id=?1", nativeQuery = true)
	public List<BuyerDashBoard> getPropertiesByUserId(int userId);
	
	@Query(value = " Select * from buyerdashboard WHERE meta_Key Like '%History%' AND is_deleted Like '%false%' AND user_Id=?1 ", nativeQuery = true)
	public List<BuyerDashBoard> getPropertiesByUserIdwithDeletedFlag(int userId);

	@Query(value = " Select * from buyerdashboard WHERE meta_Key Like '%Watch List%' AND is_deleted Like '%false%' AND user_Id=?1 ", nativeQuery = true)
	public List<BuyerDashBoard> getWatchListPropertiesByUserIdwithDeletedFlag(int userId);
	   
	@Query(value = "Select * from buyerdashboard where user_Id=?1 AND is_deleted='false' AND meta_Key LIKE '%Watch List%';", nativeQuery = true)
	public List<BuyerDashBoard> PropertyExistInWatchList(int userId);

	@Query(value = " Select * from buyerdashboard where is_deleted='false' AND meta_Key ='Watch List' AND user_Id=?1 AND property_Id=?2", nativeQuery = true)
	public BuyerDashBoard getPropertiesByUserIdAndPropertyId(int userId,int propertyId);
	
	@Query(value = " Select count(*) from buyerdashboard where meta_Key ='History' AND property_Id=?1", nativeQuery = true)
	public Integer getPropertyHistoryCountByPropertyId(Integer propertyId);
	
	@Query(value = "SELECT  * FROM buyerdashboard WHERE meta_Key = 'History' AND is_deleted = 'false' AND property_Id IN (SELECT property_Id FROM chiraghproperty WHERE auction_status = 'live' OR auction_status ='waiting')", nativeQuery = true)
	public List<BuyerDashBoard> getLivePropertiesHistory();
	
}
