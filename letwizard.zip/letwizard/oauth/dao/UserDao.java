package com.bestercapitalmedia.letwizard.oauth.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.bestercapitalmedia.letwizard.oauth.model.User;

// TODO: Auto-generated Javadoc
/**
 * The Interface UserDao.
 */
@Repository
public interface UserDao extends CrudRepository<User, Long> {
    
    /**
     * Find by username.
     *
     * @param username the username
     * @return the user
     */
	@Query(value = "select * from Chiraghuser where user_Name=?1  AND status='activated' ", nativeQuery = true)
    User findByUserName(String username);
}
