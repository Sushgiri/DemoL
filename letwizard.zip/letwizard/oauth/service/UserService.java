package com.bestercapitalmedia.letwizard.oauth.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.oauth.model.User;

// TODO: Auto-generated Javadoc
/**
 * The Interface UserService.
 */
@Service
public interface UserService {

    /**
     * Save.
     *
     * @param user the user
     * @return the user
     */
    User save(User user);
    
    /**
     * Find all.
     *
     * @return the list
     */
    List<User> findAll();
    
    /**
     * Delete.
     *
     * @param id the id
     */
    void delete(long id);
}
