package com.bestercapitalmedia.letwizard.oauth.config;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.error.OAuth2AccessDeniedHandler;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.filter.CorsFilter;

// TODO: Auto-generated Javadoc
/**
 * The Class ResourceServerConfig.
 */
@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {

	/** The Constant RESOURCE_ID. */
	private static final String RESOURCE_ID = "resource_id";

	@Autowired
	private TokenStore tokenStore;

	@Autowired
	private CorsFilter corsFilter;

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.oauth2.config.annotation.web.configuration.
	 * ResourceServerConfigurerAdapter#configure(org.springframework.security.oauth2
	 * .config.annotation.web.configurers.ResourceServerSecurityConfigurer)
	 */
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) {
		// resources.resourceId(RESOURCE_ID).stateless(false);
		resources.resourceId(RESOURCE_ID).tokenStore(tokenStore);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.oauth2.config.annotation.web.configuration.
	 * ResourceServerConfigurerAdapter#configure(org.springframework.security.config
	 * .annotation.web.builders.HttpSecurity)
	 */
	@Override
	public void configure(HttpSecurity http) throws Exception {
		// http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).and().anonymous().disable()
		// .authorizeRequests().antMatchers("/api/**").access("hasRole('ADMIN')").and().exceptionHandling()
		// .accessDeniedHandler(new OAuth2AccessDeniedHandler());
		//

		// http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).and().anonymous().disable()
		// .authorizeRequests().antMatchers(HttpMethod.GET,
		// "/**").access("#oauth2.hasScope('read')")
		// .antMatchers(HttpMethod.POST, "/**").access("#oauth2.hasScope('write')")
		// .antMatchers(HttpMethod.PATCH, "/**").access("#oauth2.hasScope('write')")
		// .antMatchers(HttpMethod.PUT, "/**").access("#oauth2.hasScope('write')")
		// .antMatchers(HttpMethod.DELETE,
		// "/**").access("#oauth2.hasScope('write')").and()
		// .antMatcher("/jsa-stomp-endpoint*").authorizeRequests();
		// .exceptionHandling()
		// .accessDeniedHandler(new OAuth2AccessDeniedHandler());
		// .and().antMatcher("/jsa-stomp-endpoint*")
		// .authorizeRequests();

		// .headers().addHeaderWriter((request, response) -> {
		// response.addHeader("Access-Control-Allow-Origin", "*");
		// if (request.getMethod().equals("OPTIONS")) {
		// response.setHeader("Access-Control-Allow-Methods",
		// request.getHeader("Access-Control-Request-Method"));
		// response.setHeader("Access-Control-Allow-Headers",
		// request.getHeader("Access-Control-Request-Headers"));
		// }
		// });
		http.exceptionHandling()
				.authenticationEntryPoint(
						(request, response, authException) -> response.sendError(HttpServletResponse.SC_UNAUTHORIZED))
				.and().csrf().disable().addFilterBefore(corsFilter, UsernamePasswordAuthenticationFilter.class)
				.headers().frameOptions().disable().and().sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().authorizeRequests()
				.antMatchers("/api/user/registerUser").permitAll().antMatchers("/api/activate").permitAll()
				.antMatchers("api/user/register/gmail/true").permitAll()
				.antMatchers("/api/authenticate").permitAll().antMatchers("/api/user/resetPasswordRequest").permitAll()
				.antMatchers("/api/mortgage/eligibility/save").permitAll().antMatchers("/api/user/resetPassword")
				.permitAll().antMatchers("/api/**").authenticated()
				.antMatchers("/management/health").permitAll().antMatchers("/management/**").hasAuthority("ROLE_ADMIN")
				.antMatchers("/v2/api-docs/**").permitAll().antMatchers("/swagger-resources/configuration/ui")
				.permitAll().antMatchers("/swagger-ui/index.html").hasAuthority("ROLE_ADMIN");
	}

}