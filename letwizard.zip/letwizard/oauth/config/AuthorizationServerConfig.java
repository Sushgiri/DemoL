package com.bestercapitalmedia.letwizard.oauth.config;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.security.oauth2.provider.token.TokenEnhancerChain;
import org.springframework.security.oauth2.provider.token.TokenStore;

// TODO: Auto-generated Javadoc
/**
 * The Class AuthorizationServerConfig.
 */
@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter implements ApplicationContextAware {

	/** The Constant CLIEN_ID. */
	static final String CLIEN_ID = "chiragh-client";
	static final String CLIEN_ID2 = "chiragh-client2";
	
	static final String CLIEN_ID_Register = "chiragh";

	/** The Constant CLIENT_SECRET. */
	static final String CLIENT_SECRET = "$2a$04$e/c1/RfsWuThaWFCrcCuJeoyvwCV0URN/6Pn9ZFlrtIWaU/vj/BfG";// devglan-secret
	// static final String CLIENT_SECRET =
	// "$2b$10$jiuop9vfGU4fkvwJNMvPUuOlFOmMZdoOnKeuOmP7Mo5Ml7vmlKGX";//password

	/** The Constant GRANT_TYPE_PASSWORD. */
	static final String GRANT_TYPE_PASSWORD = "password";

	static final String GRANT_TYPE_CLIENT_CREDENTIAL = "client_credentials";

	/** The Constant AUTHORIZATION_CODE. */
	static final String AUTHORIZATION_CODE = "authorization_code";

	/** The Constant REFRESH_TOKEN. */
	static final String REFRESH_TOKEN = "refresh_token";

	/** The Constant IMPLICIT. */
	static final String IMPLICIT = "implicit";

	/** The Constant SCOPE_READ. */
	static final String SCOPE_READ = "read";

	/** The Constant SCOPE_WRITE. */
	static final String SCOPE_WRITE = "write";

	/** The Constant TRUST. */
	static final String TRUST = "trust";

	/** The Constant ACCESS_TOKEN_VALIDITY_SECONDS. */
	static final int ACCESS_TOKEN_VALIDITY_SECONDS_USER = 2 * 24 * 60 * 60;
//	static final int ACCESS_TOKEN_VALIDITY_SECONDS_GUEST = 7 * 24 * 60 * 60;
	static final int ACCESS_TOKEN_VALIDITY_SECONDS_GUEST = 0;
//	static final int ACCESS_TOKEN_VALIDITY_SECONDS = 5 * 60;
	
		/** The Constant REFRESH_TOKEN_VALIDITY_SECONDS. */
	static final int REFRESH_TOKEN_VALIDITY_SECONDS_USER = 2 * 24 * 60 * 60;
	static final int REFRESH_TOKEN_VALIDITY_SECONDS_GUEST = 0;
//	static final int FREFRESH_TOKEN_VALIDITY_SECONDS = 10 * 60;
	
	/** The token store. */
	@Autowired
	private TokenStore tokenStore;

	/** The authentication manager. */
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private ApplicationContext applicationContext;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	@Override
	public void configure(ClientDetailsServiceConfigurer configurer) throws Exception {
		// configurer.inMemory()
		// .withClient(CLIEN_ID)
		// .secret(CLIENT_SECRET)
		// .authorizedGrantTypes(GRANT_TYPE_CLIENT_CREDENTIAL,AUTHORIZATION_CODE,GRANT_TYPE_PASSWORD,
		// AUTHORIZATION_CODE,REFRESH_TOKEN, IMPLICIT)
		// .scopes(SCOPE_READ, SCOPE_WRITE,
		// TRUST).accessTokenValiditySeconds(ACCESS_TOKEN_VALIDITY_SECONDS)
		// .refreshTokenValiditySeconds(FREFRESH_TOKEN_VALIDITY_SECONDS);

		/*
		 * For a better client design, this should be done by a ClientDetailsService
		 * (similar to UserDetailsService).
		 */
		
		configurer
		.inMemory()
		.withClient(CLIEN_ID2)
		.secret(CLIENT_SECRET)
		.scopes("openid")
		.autoApprove(true)
				.authorizedGrantTypes("implicit", "refresh_token", "password", "authorization_code")
				.accessTokenValiditySeconds(ACCESS_TOKEN_VALIDITY_SECONDS_USER)
				.refreshTokenValiditySeconds(REFRESH_TOKEN_VALIDITY_SECONDS_USER).and()
				.withClient(CLIEN_ID)
				.secret(CLIENT_SECRET).scopes("web-app").authorities("ROLE_ADMIN").autoApprove(true)
				.authorizedGrantTypes("client_credentials").accessTokenValiditySeconds(ACCESS_TOKEN_VALIDITY_SECONDS_GUEST)
				.refreshTokenValiditySeconds(REFRESH_TOKEN_VALIDITY_SECONDS_GUEST);

	}

	@Override
	public void configure(AuthorizationServerSecurityConfigurer oauthServer) throws Exception {
		// oauthServer.allowFormAuthenticationForClients();
		oauthServer.tokenKeyAccess("permitAll()").checkTokenAccess("isAuthenticated()");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.security.oauth2.config.annotation.web.configuration.
	 * AuthorizationServerConfigurerAdapter#configure(org.springframework.security.
	 * oauth2.config.annotation.web.configurers.
	 * AuthorizationServerEndpointsConfigurer)
	 */
	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
//		 endpoints.tokenStore(tokenStore).authenticationManager(authenticationManager);
		Collection<TokenEnhancer> tokenEnhancers = applicationContext.getBeansOfType(TokenEnhancer.class).values();
		TokenEnhancerChain tokenEnhancerChain = new TokenEnhancerChain();
		tokenEnhancerChain.setTokenEnhancers(new ArrayList<>(tokenEnhancers));
		endpoints.authenticationManager(authenticationManager).tokenStore(tokenStore).tokenEnhancer(tokenEnhancerChain)
				.reuseRefreshTokens(false);
	}
	
    @Bean
    @Primary
    public DefaultTokenServices tokenServices() {
        DefaultTokenServices tokenServices = new DefaultTokenServices();
        tokenServices.setSupportRefreshToken(true);
        tokenServices.setTokenStore(this.tokenStore);
        return tokenServices;
    }
}
