package com.bestercapitalmedia.letwizard.chat.model;

import javax.persistence.Column;

public class ChatRequestDto {

	String userName;
	String msg;
	int propertyId;
	String role;
	Boolean isChat;
	Boolean isChecklist;
	Boolean isDone;
	int chatId;
	String sendTo;
	String sendBy;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public ChatRequestDto() {
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}



	public Boolean getIsChecklist() {
		return isChecklist;
	}

	public void setIsChecklist(Boolean isChecklist) {
		this.isChecklist = isChecklist;
	}

	public Boolean getIsChat() {
		return isChat;
	}

	public void setIsChat(Boolean isChat) {
		this.isChat = isChat;
	}

	public Boolean getIsDone() {
		return isDone;
	}

	public void setIsDone(Boolean isDone) {
		this.isDone = isDone;
	}

	public int getChatId() {
		return chatId;
	}

	public void setChatId(int chatId) {
		this.chatId = chatId;
	}

	public String getSendTo() {
		return sendTo;
	}

	public void setSendTo(String sendTo) {
		this.sendTo = sendTo;
	}

	public String getSendBy() {
		return sendBy;
	}

	public void setSendBy(String sendBy) {
		this.sendBy = sendBy;
	}

}
