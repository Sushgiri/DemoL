package com.bestercapitalmedia.letwizard.chat;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface ChatRepository extends CrudRepository<Chat, Integer> {
	
	@Query(value = "SELECT * FROM chat WHERE property_Id=?1 AND (send_To IS NULL OR send_To =?2 OR user_Id =?2) AND department_Id IS NULL AND is_Chat = 1 ORDER BY created_At DESC", nativeQuery = true)
	public List<Chat> findByPropertyId(int propertyId, int userId);
	
	@Query(value = "select * from chat where property_Id=?1 and (department_Id=?3 or department_Id=2) and (send_To is null or send_To = ?2 or user_Id = ?2) and is_Chat = 1 order by created_At desc", nativeQuery = true)
	public List<Chat> findByPropertyIdAndDepartment(int propertyId, int userId, int departmentId);
	
	@Query(value = "select * from chat where buyer_Process_Id=?1 AND (send_To IS NULL OR send_To =?2 OR user_Id =?2) AND department_Id IS NULL AND is_Chat = 1 ORDER BY created_At DESC;", nativeQuery = true)
	public List<Chat> findByBuyerProcessId(int buyerProcessId, int userId);
	
}
