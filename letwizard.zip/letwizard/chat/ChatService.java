package com.bestercapitalmedia.letwizard.chat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.fcmpushnotifications.firebase.FCMService;
import com.bestercapitalmedia.fcmpushnotifications.model.PushNotificationRequest;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationConstants;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationsService;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcess;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcessRepository;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.bidprocess.BidProcessServiceImpl;
import com.bestercapitalmedia.letwizard.property.bidprocess.Propertybidprocess;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.PusherUtil;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;


@Service
public class ChatService {
	
	private static final Logger logger = LoggerFactory.getLogger(ChatService.class);
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private ChatRepository chatRepository;
	
	@Autowired
	NotificationsService notificationService;

	@Autowired
	private BuyerProcessRepository buyerProcessRepository;
	
	@Autowired
	PropertyRepository propertyRepository;
	
	@Autowired
	private FCMService fcmService;
	
	public ResponseEntity createChat(Authentication authentication, ChatDTO dto) {
		try {
			
			ModelMapper mapper = new ModelMapper();
			User user = (User) authentication.getPrincipal();
			Chiraghuser chiraghuser = userRepository
					.findByUserName(user.getUsername());
			
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			
			Chat chat = new Chat();
			chat = mapper.map(dto, Chat.class);
			chat.setCreatedAt(DateUtils.getDefault().getNowTime());
			chat.setChiraghuser(chiraghuser);
//			chat.setPropertyId(598);
//			chat.setMsg("asdfasdfasdf");
			chat.setIsChat(1);
			chat.setIsChecklist(0);
			chat.setIsDone(0);
			
			chat = chatRepository.save(chat);
			ChatDTO chatDTO = mapper.map(chat, ChatDTO.class);
			
			Chiraghproperty chiraghProperty = propertyRepository.findByPropertyId(chatDTO.getPropertyId());
			Chiraghuser chiragUser = userRepository.findByUserId(chatDTO.getSendTo());
			
			if(chat == null || chiraghProperty == null || chiragUser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}else {
				if(chatDTO.getSendTo()!= null) {
					String msgSubject = null, msgDescription = null;
					int subjectId = 0;
					if(dto.getPropertyId() != null && dto.getPropertyId() > 0) {
						msgSubject = NotificationConstants.Subject.message_buyer;
						msgDescription = NotificationConstants.Description.message_buyer;
						BuyerProcess buyerProcess = buyerProcessRepository.findBuyerExisting(dto.getSendTo(), dto.getPropertyId());
						subjectId = buyerProcess.getBuyerProcessId();
					} else {
						msgSubject = NotificationConstants.Subject.message_seller;
						msgDescription = NotificationConstants.Description.message_seller;
						BuyerProcess buyerProcess = buyerProcessRepository.findBuyerProcess(dto.getBuyerProcessId());
						subjectId = buyerProcess.getChiraghproperty().getPropertyId();
					}
					PusherUtil.getDefault().push("user-"+chatDTO.getSendTo(), "new-message", chatDTO);
					notificationService.createNotification(
							msgDescription, 
						msgSubject, 
						subjectId,
						chatDTO.getSendTo(),
						propertyRepository.findByPropertyId(chatDTO.getPropertyId())
					);
					
					newMessageRecievedPushNotification(chiraghProperty, null, chiragUser,
						NotificationConstants.NotificationId.outBidded, NotificationConstants.Title.newMessageRecieved,
						NotificationConstants.Topic.outBidded, NotificationConstants.PNDescription.newMessageRecieved,
						NotificationConstants.Type.newMessageRecieved);
				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS, Stream.of(chatDTO).collect(Collectors.toList()));
			}
			
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
	
	public ResponseEntity getChat(Authentication authentication, Integer propertyId) {
		try {
			ModelMapper mapper = new ModelMapper();
			User user = (User) authentication.getPrincipal();
			Chiraghuser chiraghuser = userRepository.findByUserNameAndRole(user.getUsername());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			List<Chat> chat = new ArrayList();
//			if(chiraghuser.getDepartements().getId() == 7) {
//				chat = chatRepository.findByPropertyIdAndDepartment(propertyId, chiraghuser.getUserId(), chiraghuser.getDepartements().getId());
//			}else {
				chat = chatRepository.findByPropertyId(propertyId, chiraghuser.getUserId());
//			}
			
			
			if (chat.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			//System.out.println(chat.get(0).getCreatedAt().toString());
			List<ChatDTO> chatDTO = ObjectMapperUtils.mapAll(chat, ChatDTO.class);
			//System.out.println(chatDTO.get(0).getCreatedAt().toString());
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS, chatDTO);

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}
	
	public ResponseEntity getBuyerChat(Authentication authentication, Integer buyerProcessId) {
		try {
			ModelMapper mapper = new ModelMapper();
			User user = (User) authentication.getPrincipal();
			Chiraghuser chiraghuser = userRepository.findByUserNameAndRole(user.getUsername());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			
			List<Chat> chat = chatRepository.findByBuyerProcessId(buyerProcessId, chiraghuser.getUserId());
			if (chat.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			//System.out.println(chat.get(0).getCreatedAt().toString());
			List<ChatDTO> chatDTO = ObjectMapperUtils.mapAll(chat, ChatDTO.class);
			//System.out.println(chatDTO.get(0).getCreatedAt().toString());
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS, chatDTO);
			
		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
		
	}
	
	public void newMessageRecievedPushNotification(Chiraghproperty chiraghProperty, 
			Propertybidprocess bidProcess, Chiraghuser chiraghUser, String messageId,
			String messageTitle, String messageTopic, String messageDescription, String type) {

		logger.info("ChatService : newMessageRecievedPushNotification");
		
		if (chiraghProperty != null && chiraghUser != null && 
				chiraghUser.getFirebaseToken() != null && !chiraghUser.getFirebaseToken().isEmpty()) {
			
			try {
				// Build notification payload
				Notification notification = new Notification(messageTitle, messageDescription);
				
				// Build data payload
				Map<String, String> data = new HashMap<>();
				data.put("message_id", messageId);
				data.put("title", messageTitle);
				data.put("message", messageDescription);
				data.put("notification_type", type);
				
				data.put("property_id", chiraghProperty.getPropertyId() + "");
				data.put("user_id", chiraghUser.getUserId() + "");
				data.put("property_title", chiraghProperty.getPropertyTitle());
				data.put("property_type", chiraghProperty.getPropertyType());
				data.put("seller_user_name", chiraghProperty.getSellerUserName());
				data.put("status", chiraghProperty.getStatus());
				
				if (bidProcess != null) {
					data.put("bid_id", bidProcess.getProcessComposite().getBidId() + "");
					data.put("bid_amount", bidProcess.getBidAmount() + "");
					data.put("bid_status", bidProcess.getBidStatus());
				}
				
				// Build the message
				Message message = Message.builder().setToken(chiraghUser.getFirebaseToken()) // FCM Token
						.setNotification(notification) // Notification object for foreground/background
						.putAllData(data) // Data payload for additional info
						.build();
				
				logger.info("Data in message to be sent : " + data);

				// Send the message using FirebaseMessaging
				String response = FirebaseMessaging.getInstance().send(message);
				
				logger.info("Successfully sent message : " + response);
				
			} catch (Exception e) {
				logger.error("Exception in ChatService : newMessageRecievedPushNotification : " + e.getMessage(), e);
			}
		}
	}
	
}