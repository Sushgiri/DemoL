package com.bestercapitalmedia.letwizard.chat;


import java.util.Date;

import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;
import com.bestercapitalmedia.letwizard.user.UserDTO;


public class ChatDTO {

	private Integer chatId;
	private ChiraghUserDTO chiraghuser;
	private String msg;
	private Date createdAt;
	private Integer propertyId;
	private Integer isChat;
	private Integer isChecklist;
	private Integer isDone;
	private Integer sendTo;
//	private Integer departmentId;
	private Integer buyerProcessId;
	
	public ChatDTO() {
	}
	public Integer getChatId() {
		return chatId;
	}
	public void setChatId(Integer chatId) {
		this.chatId = chatId;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Integer getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}
	public Integer getIsChat() {
		return isChat;
	}
	public void setIsChat(Integer isChat) {
		this.isChat = isChat;
	}
	public Integer getIsChecklist() {
		return isChecklist;
	}
	public void setIsChecklist(Integer isChecklist) {
		this.isChecklist = isChecklist;
	}
	public Integer getIsDone() {
		return isDone;
	}
	public void setIsDone(Integer isDone) {
		this.isDone = isDone;
	}
	public Integer getSendTo() {
		return sendTo;
	}
	public void setSendTo(Integer sendTo) {
		this.sendTo = sendTo;
	}
//	public Integer getDepartmentId() {
//		return departmentId;
//	}
//	public void setDepartmentId(Integer departmentId) {
//		this.departmentId = departmentId;
//	}
	public Integer getBuyerProcessId() {
		return buyerProcessId;
	}
	public void setBuyerProcessId(Integer buyerProcessId) {
		this.buyerProcessId = buyerProcessId;
	}
	public ChiraghUserDTO getChiraghuser() {
		return chiraghuser;
	}
	public void setChiraghuser(ChiraghUserDTO chiraghuser) {
		this.chiraghuser = chiraghuser;
	}
	

}
