package com.bestercapitalmedia.letwizard.admin.notifications;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.buyer.dashboard.RequestDtoForPaginatedWatchList;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("api/notification")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class NotificationsController {
	
	@Autowired
	private NotificationsService notificationsService;

	@Autowired
	private ResponseUtill responseUtil;
	
	@Autowired 
	private PropertyRepository propertyRepository;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/all", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity getAllNotifications(@RequestBody RequestDtoForPaginatedWatchList dto, Authentication authentication, HttpServletRequest httpServletRequest) {
		return notificationsService.getAllNotifications(dto);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{notificationId}/read", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity readNotification(@PathVariable(value = "notificationId") int notificationId,  Authentication authentication, HttpServletRequest httpServletRequest) {
		return notificationsService.readNotification(notificationId);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/new", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createNotification(@RequestBody NewNotificationDTO notificationDTO,
			Authentication authentication, HttpServletRequest httpServletRequest) {
		return notificationsService.createNotification(notificationDTO);
	}
	
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/property/{propertyId}/read", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity readPropertyNotification(@PathVariable(value = "propertyId") int propertyId,  Authentication authentication, HttpServletRequest httpServletRequest) {
		return notificationsService.readPropertyNotification(propertyId);
	}

}
