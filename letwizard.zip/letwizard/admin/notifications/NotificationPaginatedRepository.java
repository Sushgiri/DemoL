package com.bestercapitalmedia.letwizard.admin.notifications;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.bestercapitalmedia.letwizard.buyer.dashboard.BuyerDashBoard;

public interface NotificationPaginatedRepository extends PagingAndSortingRepository<Notifications, Integer> {
	
	@Query(value = "SELECT * FROM notifications WHERE user_to =?1 ORDER BY is_read, created_at DESC",
			countQuery = "SELECT count(*) FROM notifications WHERE user_to =?1 ORDER BY is_read, created_at DESC",
			nativeQuery = true)
	public Page<Notifications> getAllNotifications(int userId, Pageable pageable);

}