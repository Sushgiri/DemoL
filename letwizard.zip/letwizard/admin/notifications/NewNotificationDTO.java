package com.bestercapitalmedia.letwizard.admin.notifications;

import java.util.Date;

public class NewNotificationDTO {
	
	private String description;
	private String subjectType;
	private Integer subjectId;
	private Integer userTo;
	private Integer propertyId;
	private Boolean isRead;
	private Date createdAt;
	public NewNotificationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSubjectType() {
		return subjectType;
	}
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	public Integer getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}
	public Integer getUserTo() {
		return userTo;
	}
	public void setUserTo(Integer userTo) {
		this.userTo = userTo;
	}
	public Integer getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}
	public Boolean getIsRead() {
		return isRead;
	}
	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	
	

}
