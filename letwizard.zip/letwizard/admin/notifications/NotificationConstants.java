package com.bestercapitalmedia.letwizard.admin.notifications;

public class NotificationConstants {

	public class Description {
		public static final String message = "There is a new message for you";
		public static final String message_seller = "There is a new message for you";
		public static final String message_buyer = "There is a new message for you";
		public static final String task = "There is a new task assigned to you";
		public static final String lead = "You have been assigned a new lead";
		public static final String property = "Property listing closed";
		public static final String bid = "Your bid has been placed";
		public static final String bid_accept = "Congratulations! Buyer has agreed to proceed with the bid on your property";
		public static final String seller_accept_bid = "Congratulations! Seller has accepted your bid";
		public static final String seller_accept_bid_rental = "Congratulations! Landlord has accepted your bid";
		public static final String dldMeeting = "DLD meeting scheduled";
		public static final String ophMeeting = "Open House meeting scheduled";
		public static final String ophMeetingRental = "Open House Visit scheduled";
		public static final String depositForfeit = "Your participation guarantee has been forfeited";
		public static final String depositForfeited = "Bidding deposit has been forfeited";
		public static final String sellerSecurityForfeit = "Your seller security deposit has been forfeited";
		public static final String sellerSecurityForfeitRental = "Your landlord security deposit has been forfeited";
		public static final String sellerSecurityForfeited = "Seller security has been forfeited";
		public static final String sellerSecurityForfeitedRental = "Landlord security has been forfeited";
		public static final String outBidded = "You're no longer the highest bidder.";
		public static final String buyerAuctionDepositRefund = "Congratulations! You’re the winning bidder.  Your participation guarantee (if any) will be refunded into your eWallet.";
		public static final String auctionDepositRefund = "Your participation guarantee has been refunded.";
		public static final String sellerSecurityRefund = "Your seller security deposit has been refunded.";
		public static final String sellerSecurityRefundRental = "Your landlord security deposit has been refunded.";
		public static final String reAuction = "Your property has been submitted for Re-Listing";
		public static final String reAuctionRental = "Your rental property has been submitted for Re-Listing";
		public static final String reAuctionSeller = "Your Seller property has been submitted for Re-Listing";
		public static final String brokerageProposalChange = "Bidding specifications has been changed by the Seller.";
		public static final String brokerageProposalAgreed = "Bidding specifications has been confirmed by the Seller.";
		public static final String contact_us = "New 'Contact Us' lead has been created.";
		public static final String propertyLive = "Your property is Live";
		public static final String propertyLiveRental = "Your rental property is Live";
		public static final String propertySave = "Your property has been submitted successfully";
		public static final String propertySaveRental = "Your Rental Property Has Been Submitted Successfully!";
		public static final String sellerReject = "Seller has rejected your bid";
		public static final String sellerRejectRental = "Landlord has rejected your bid";
		public static final String buyerReject = "Buyer has withdrawn the bid";
		public static final String buyerRejectRental = "Tenant has withdrawn the bid";
		public static final String successfulBidder = "Congratulations! You're the winning bidder.  Your participation guarantee (if any) will be refunded into your eWallet.";
		public static final String offerAccepted = "Congratulations! Your offer has been accepted.";
		public static final String unsold_property = "Your property is marked as unsold and already been moved to unsold tab.";
		public static final String unsold_property_rental = "Your property is marked vacant and already been moved to vacant tab.";
		public static final String topupCreated = "A Top-up request has been created.";
		public static final String topupAutoApproved = "Top-up Request has been auto-approved.";
		public static final String topupAutoApprovedAdmin = "A Top-up Request has been auto-approved.";
		public static final String transferCreated = "A Transfer request(Within letWizard) has been created.";
		public static final String transferCompleted = "A Transfer request(Within letWizard) has been completed.";
		public static final String withdrawCreated = "A Transfer request(Outside letWizard) has been created.";
		public static final String securityAlert = "Your letWizard account was signed in from a new device. Please check your email for further details.";
		public static final String odCreated = "An Overdarft request has been created.";
		public static final String cancelOdCreated = "A Cancel OD request has been created.";
		public static final String kycSubmit = "Your KYC application has been submitted";
		public static final String kycApprove = "Your KYC application has been approved";
		public static final String onHold = "Your bid is put on hold by landlord";
		public static final String offerRejected = "Sorry, Your bidding has been rejected";
		public static final String rentalBidNotification = "Congratulations! Your bid has been placed.";
		public static final String ownerReceiveRejectionMessage = "Someone bidded on your property has been rejected";
		public static final String ownerReceivesNewBiddingConfirmation = "Right now someone bidded on your property";
		public static final String bidderBidAutoRejected = "Your's bid auto-rejected by the system.";
		public static final String ownerAutoRejectedBidMessage = "Some-one bidded on your property has been auto-rejected.";
		public static final String ownerBidPlaced = "Congratulations! Someone has placed bid for your property.";
		public static final String listingSaved = "Your property listing saved under pending";
	}

	public static class Descriptions {
		public static String OverdraftSubmitted(String currencyCode) {
			// return currencyCode+" Facility Request Submitted";
			return "Credit Facility " + currencyCode + " Request Submitted";
		}

		public static String OverdraftCnlSubmitted(String currencyCode) {
			// return "Your " +currencyCode+ " Cancellation Request has been submitted";
			return "Your Credit Facility Cancellation Request has been submitted";
		}
	}

	public class Subject {
		public static final String message = "message";
		public static final String message_seller = "message_seller";
		public static final String message_buyer = "message_buyer";
		public static final String task = "task";
		public static final String lead = "lead";
		public static final String property = "property";
		public static final String bid = "bid";
		public static final String bid_accept = "bid accept";
		public static final String seller_accept_bid = "seller_accept_bid";
		public static final String dldMeeting = "meeting";
		public static final String ophMeeting = "open_house_meeting";
		public static final String depositForfeit = "deposit_forfeit";
		public static final String sellerSecurityForfeit = "seller_security_forfeit";
		public static final String outBidded = "out_Bid";
		public static final String auctionDepositRefund = "bidding_deposit_refund";
		public static final String sellerSecurityRefund = "seller_security_refund";
		public static final String depositRefund = "bidding_deposit_refund";
		public static final String reAuction = "re_bidding";
		public static final String brokerageProposalChange = "brokerage_proposals_change";
		public static final String brokerageProposalAgreed = "brokerage_proposals_agreed";
		public static final String contact_us = "contact_us";
		public static final String propertyLive = "property_lived";
		public static final String propertySave = "property_saved";
		public static final String sellerReject = "seller_reject";
		public static final String buyerReject = "buyer_reject";
		public static final String successfulBidder = "successful_bidder";
		public static final String offerAccepted = "offer_accepted";
		public static final String unsold_property = "unsold_property";
		public static final String topup = "Top-up";
		public static final String od = "overdraft";
		public static final String cancelOd = "cancel_overdraft";
		public static final String transfer = "transfer";
		public static final String withdraw = "withdraw";
		public static final String securityAlert = "security_alert";
		public static final String kycSubmite = "kyc_submit";
		public static final String kycApprove = "kyc_approved";
		public static final String onHold = "on_hold";
		public static final String autoRejected = "auto-rejected";
		public static final String rentalBidSubject = "Your bid has been placed";
		public static final String ownerReceivesNewBid = "new-bidding-for-owner";
		public static final String bidderBidAutoRejected = "Your bid has been auto-rejcted";
		public static final String ownerAutoRejectedBidMessage = "Some-one bidded on your property has been auto-rejected.";
	}

	public class NotificationId{
		public static final String propertySaved = "101";
		public static final String propertyLive = "103";
		public static final String brokerageProposalChange = "201";
		public static final String sellerAcceptBid = "301";
		public static final String auctionDepositRefund = "304";
		public static final String outBidded = "305";
		public static final String bidAutoRejected = "306";
		public static final String bidPlaced = "307";
		public static final String bidSellerRejected = "308";
		public static final String kycSubmit = "401";
		public static final String sellerSecurityRefund = "309";
		public static final String sellerSecurityForfeit = "310";
		public static final String onHold = "311";
		public static final String odCreated = "501";
		public static final String listingSaved = "102";
		public static final String offerAccepted = "312";
		public static final String unsoldProperty = "103";
		public static final String reAuction = "104";
		public static final String unsoldPropertyVacant = "105";
		public static final String listingClosed = "106";
	}
	
	public class Topic{
		public static final String propertySaved = "PropertySavedSuccessfully";
		public static final String propertyLive = "PropertyLiveSuccessfully";
		public static final String brokerageProposalChange = "";
		public static final String sellerAcceptBid = "SellerAcceptedBidSuccessfully";
		public static final String auctionDepositRefund = "BiddingDepositRefundedSuccessfully";
		public static final String outBidded = "OutBiddedSuccessfully";
		public static final String bidAutoRejected = "BidAutoRejectedSuccessfully";
		public static final String bidPlaced = "BidPlacedSuccessfully";
		public static final String bidSellerRejected = "SellerRejectedBidSuccessfully";
		public static final String kycSubmit = "KYCSubmittedSuccessfully";
		public static final String sellerSecurityRefund = "SellerSecurityRefundedSuccessfully";
		public static final String sellerSecurityForfeit = "SellerSecurityForfeitedSuccessfully";
		public static final String onHold = "OnHoldSuccessfully";
		public static final String odCreated = "OverDraftSubmittedSuccessfully";
		public static final String listingSaved = "ListingSavedSuccessfully";
		public static final String offerAccepted = "OfferAcceptedSuccessfully";
		public static final String unsoldProperty = "UnSoldPropertyReListingSuccessfully";
		public static final String reAuction = "PropertyReListedSuccessfully";
		public static final String unsoldPropertyVacant = "UnSoldPropertyVacantSuccessfully";
		public static final String listingClosed = "PropertyListingClosedSuccessfully";
	}
	
	public class Title{
		public static final String rentalPropertySubmittedSuccessfully = "Rental Property Submitted Successfully";
		public static final String propertySubmittedSuccessfully = "Property Sale Successfully Submitted";
		public static final String biddingSpecificationsChangedAssignedTo = "bidding_specifications_changed_assigned_to";
		public static final String biddingSpecificationsChangedAssignedBy = "bidding_specifications_changed_assigned_by";
		public static final String propertyBidFinalizePropertyListingClosed = "Property Listing Closed";
		public static final String bidderBidPlacedSuccessfully = "Your Bid Has Been Placed";
		public static final String sellerSomeonePlacedBidOnYourProperty = "New Bid Alert!";
		public static final String yourBidAutoRejectedBySystem = "Bid rejected by System";
		public static final String ownerBidAutoRejectedBySystem = "Someone's Bid on your Property Rejected by System";
		public static final String yourParticipationGuaranteeRefunded = "Participation Guarantee Refunded for your Rental Property";
		public static final String yourParticipationGuaranteeRefundedSellProperty = "Participation Guarantee Refunded for Property Sale";
		public static final String sellerRejectedYourBid = "The seller rejected your bid.";
		public static final String sellerAcceptedYourBid = "Congrats! Seller Accepted Your Bid";
		public static final String landlordRejectedYourBid = "Bid Rejected by Landlord";
		public static final String landlordAcceptedYourBid = "Congrats! Bid Accepted by Landlord";
		public static final String yourBidPutOnHoldBySeller = "Bid on Hold by Seller";
		public static final String youAreNoLongerHighestBidder = "You're No Longer the Highest Bidder!";
		public static final String sellerSecurityDepositForfeited = "Security Deposit is Forfeited";
		public static final String sellerSecurityDepositRefunded = "Seller Security Deposit Refunded";
		public static final String landlordSecurityDepositForfeited = "Security Deposit is Forfeited";
		public static final String landlordSecurityDepositRefunded = "Landlord Security Deposit Refunded";
		public static final String rentalPropertyMarkedVacantMovedToVacantTab = "Your property is Marked Vacant";
		public static final String propertyMarkedUnSoldMovedToUnSoldTab = "Property Marked as Unsold!";
		public static final String rentalPropertySubmittedForReListing = "Rental Property Re-Listed";
		public static final String sellerPropertySubmittedForReListing = "Your property sale listing is pending";
		public static final String propertySavedSuccessfully = "your_property_saved_successfully";
		public static final String rentalPropertySavedSuccessfully = "your_rental_property_saved_successfully";
		public static final String yourKYCApplicationSubmittedSuccessfully = "KYC Application Submitted! What Happens Next?";
		public static final String yourPropertyLive = "Property Now Live for Sale!";
		public static final String yourRentalPropertyLive = "Your Rental Property is Now Live!";
		public static final String yourPropertyListingSavedPending = "Property Sale Listing Saved as Pending";
		public static final String yourPropertyListingSavedPendingRental = "Rental Property Listing Saved as Pending";
		public static final String overDraftRequestCreated = "Over Draft Request Created";
		public static final String overDraftCancellationRequestCreated = "Credit Facility Cancellation Submitted";
		public static final String yourOfferAutoAccepted = "Congrats! Offer Accepted!";
		public static final String yourOfferAutoAcceptedRental = "Offer Accepted! Congrats on Your New Rental";
		public static final String yourKYCApplicationApprovedSuccessfully = "KYC Approved! You're Good to Go";
		public static final String offerOnYourPropertyAccepted = "Congratulations! Offer on your Property Accepted";
		public static final String newMessageRecieved = "New Message Received";
		public static final String topupAutoApproved = "Auto-Approved Top-Up!";
		public static final String newDeviceSignInAlert = "New Device Sign-In Alert!";
		public static final String openHouseMeetingScheduledBuyer = "Open House Meeting Scheduled!";
		public static final String brokerageProposalChange = "Brokerage Proposal Changed";
	}
	
	public class Type{
		public static final String dailyRentalPropertySubmittedSuccessfully = "daily_rental_property_submitted_successfully";
		public static final String rentalPropertySubmittedSuccessfully = "rental_property_submitted_successfully";
		public static final String propertySubmittedSuccessfully = "property_submitted_successfully";
		public static final String biddingSpecificationsChangedAssignedTo = "bidding_specifications_changed_assigned_to";
		public static final String biddingSpecificationsChangedAssignedBy = "bidding_specifications_changed_assigned_by";
		public static final String propertyBidFinalizePropertyListingClosed = "property_bid_finalize_property_listing_closed";
		public static final String bidderBidPlacedSuccessfully = "bidder_bid_placed_successfully";
		public static final String sellerSomeonePlacedBidOnYourProperty = "seller_someone_placed_bid_on_your_property";
		public static final String yourBidAutoRejectedBySystem = "your_bid_auto_rejected_by_system";
		public static final String ownerBidAutoRejectedBySystem = "someone_bidded_on_your_property_auto_rejected_by_system";
		public static final String yourParticipationGuaranteeRefunded = "your_participation_guarantee_refunded";
		public static final String yourParticipationGuaranteeRefundedSellProperty = "your_participation_guarantee_refunded_sell_property";
		public static final String sellerRejectedYourBid = "seller_rejected_your_bid";
		public static final String sellerAcceptedYourBid = "seller_accepted_your_bid";
		public static final String landlordRejectedYourBid = "landlord_rejected_your_bid";
		public static final String landlordAcceptedYourBid = "landlord_accepted_your_bid";
		public static final String yourBidPutOnHoldBySeller = "your_bid_put_onhold_by_seller";
		public static final String youAreNoLongerHighestBidder = "you_are_no_longer_highest_bidder";
		public static final String sellerSecurityDepositForfeited = "seller_security_deposit_forfeited";
		public static final String sellerSecurityDepositRefunded = "seller_security_deposit_refunded";
		public static final String landlordSecurityDepositForfeited = "landlord_security_deposit_forfeited";
		public static final String landlordSecurityDepositRefunded = "landlord_security_deposit_refunded";
		public static final String rentalPropertyMarkedVacantMovedToVacantTab = "rental_property_marked_vacant_moved_to_vacant_tab";
		public static final String propertyMarkedUnSoldMovedToUnSoldTab = "property_marked_unsold_moved_to_unsold_tab";
		public static final String rentalPropertySubmittedForReListing = "rental_property_submitted_for_re_listing";
		public static final String sellerPropertySubmittedForReListing = "seller_property_submitted_for_re_listing";
		public static final String propertySavedSuccessfully = "your_property_saved_successfully";
		public static final String rentalPropertySavedSuccessfully = "your_rental_property_saved_successfully";
		public static final String yourKYCApplicationSubmittedSuccessfully = "your_kyc_application_submitted_successfully";
		public static final String yourPropertyLive = "your_property_live";
		public static final String yourRentalPropertyLive = "your_rental_property_live";
		public static final String yourPropertyListingSavedPending = "your_property_listing_saved_pending";
		public static final String yourPropertyListingSavedPendingRental = "your_property_listing_saved_pending_rental";
		public static final String overDraftRequestCreated = "over_draft_request_created";
		public static final String overDraftCancellationRequestCreated = "over_draft_cancellation_request_created";
		public static final String yourOfferAutoAccepted = "your_offer_Auto_Accepted";
		public static final String yourOfferAutoAcceptedRental = "your_offer_Auto_Accepted_Rental";
		public static final String yourKYCApplicationApprovedSuccessfully = "your_kyc_application_approved_successfully";
		public static final String offerOnYourPropertyAccepted = "offer_on_your_property_accepted";
		public static final String newMessageRecieved = "new_message_recieved";
		public static final String topupAutoApproved = "top_up_auto_approved";
		public static final String newDeviceSignInAlert = "new_device_sign_in_alert";
		public static final String openHouseMeetingScheduledBuyer = "open_house_meeting_scheduled_buyer";
		public static final String brokerageProposalChange = "brokerage_proposal_change";
	}
	
	public class PNDescription{
		public static final String rentalPropertySubmittedSuccessfully = "Your rental property has been successfully submitted. Get ready for potential tenants!";
		public static final String propertySubmittedSuccessfully = "Your property listing for sale has been submitted successfully. Stay tuned for further notifications.";
		public static final String biddingSpecificationsChangedAssignedTo = "bidding_specifications_changed_assigned_to";
		public static final String biddingSpecificationsChangedAssignedBy = "bidding_specifications_changed_assigned_by";
		public static final String propertyBidFinalizePropertyListingClosed = "Your property listing has been successfully closed. Thank you for using Letwizard!";
		public static final String bidderBidPlacedSuccessfully = "Your bid has been successfully placed.";
		public static final String sellerSomeonePlacedBidOnYourProperty = "Someone just placed a bid on your property. Check it out now!";
		public static final String yourBidAutoRejectedBySystem = "Unfortunately, your bid is rejected by System.";
		public static final String ownerBidAutoRejectedBySystem = "Unfortunately, someone's bid on your property is auto-rejected by System";
		public static final String yourParticipationGuaranteeRefunded = "Your participation guarantee for the rental property has been refunded. Verify your account now.";
		public static final String yourParticipationGuaranteeRefundedSellProperty = "Your participation guarantee for the sale of the property has been refunded. Check your account for details.";
		public static final String sellerRejectedYourBid = "Unfortunately, the seller has rejected your bid. Consider revising your offer or exploring other options.";
		public static final String sellerAcceptedYourBid = "Your bid has been accepted by the seller. Time to close the deal!";
		public static final String landlordRejectedYourBid = "Unfortunately, the landlord has rejected your bid.";
		public static final String landlordAcceptedYourBid = "Well done. The landlord has accepted your bid.";
		public static final String yourBidPutOnHoldBySeller = "Your bid has been put on hold by the seller. Stay tuned!";
		public static final String youAreNoLongerHighestBidder = "Someone has outbid you on the property. Check now";
		public static final String sellerSecurityDepositRefunded = "Your seller security deposit has been refunded to your account.";
		public static final String sellerSecurityDepositForfeited = "Your seller security deposit has been forfeited.";
		public static final String landlordSecurityDepositForfeited = "Your seller security deposit has been forfeited.";
		public static final String landlordSecurityDepositRefunded = "Your landlord security deposit has been refunded to your account.";
		public static final String rentalPropertyMarkedVacantMovedToVacantTab = "Your property has been marked as vacant and moved to the vacant tab. Update your listing as needed.";
		public static final String propertyMarkedUnSoldMovedToUnSoldTab = "Your property is now listed under the 'Unsold' tab.";
		public static final String rentalPropertySubmittedForReListing = "Your rental property has been submitted for re-listing.";
		public static final String sellerPropertySubmittedForReListing = "Your sale listing has been saved and is pending approval.";
		public static final String propertySavedSuccessfully = "your_property_saved_successfully";
		public static final String rentalPropertySavedSuccessfully = "your_rental_property_saved_successfully";
		public static final String yourKYCApplicationSubmittedSuccessfully = "We've received your KYC application. We'll notify you when it's reviewed.";
		public static final String yourPropertyLive = "Your property is officially live on the market for sale.";
		public static final String yourRentalPropertyLive = "Great news! Your rental property is live and available for potential tenants to view.";
		public static final String yourPropertyListingSavedPending = "Your property listing is saved and currently pending for sale.";
		public static final String yourPropertyListingSavedPendingRental = "Your property listing is saved and pending for rental.";
		public static final String overDraftRequestCreated = "Over draft request created successfully";
		public static final String overDraftCancellationRequestCreated = "Your request to cancel the credit facility has been successfully submitted. Track its progress now.";
		public static final String yourOfferAutoAccepted = "Your offer on the property has been accepted. Time to celebrate!";
		public static final String yourOfferAutoAcceptedRental = "Your offer has been accepted! Time to finalize your rental.";
		public static final String yourKYCApplicationApprovedSuccessfully = "Your KYC form just got approved! You're all set to proceed.";
		public static final String offerOnYourPropertyAccepted = "An Offer on your Property is Accepted. Time to celebrate!";
		public static final String newMessageRecieved = "You've got a new message from a sale or landlord. Check it out!";
		public static final String topupAutoApproved = "Great news! Your top-up request has been automatically approved.";
		public static final String newDeviceSignInAlert = "We noticed a sign-in from a new device. Check your email for details.";
		public static final String openHouseMeetingScheduledBuyer = "Your buyer's open house meeting is set. Don't miss it!";
		public static final String brokerageProposalChange = "Bidding specifications has been changed by the Seller.";
	}
	
	public static class Subjects {
		public static String OverdraftSubmitted(String currencyCode) {
			return currencyCode.toLowerCase() + "_submit";

		}
	}
}