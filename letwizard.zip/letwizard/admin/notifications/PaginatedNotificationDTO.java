package com.bestercapitalmedia.letwizard.admin.notifications;

import java.util.List;

public class PaginatedNotificationDTO {
	
	int totalPages;
	int pageNumber;
	int numberOfElements;
	long totalRecords;
	int unReadCount;
	List<NotificationsDTO> notifications;
	
	public PaginatedNotificationDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getNumberOfElements() {
		return numberOfElements;
	}

	public void setNumberOfElements(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public int getUnReadCount() {
		return unReadCount;
	}

	public void setUnReadCount(int unReadCount) {
		this.unReadCount = unReadCount;
	}

	public List<NotificationsDTO> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<NotificationsDTO> notifications) {
		this.notifications = notifications;
	}
	
}
