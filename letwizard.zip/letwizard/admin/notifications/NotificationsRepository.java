package com.bestercapitalmedia.letwizard.admin.notifications;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.annotations.SQLUpdate;
import org.hibernate.envers.ModifiedEntityNames;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;


public interface NotificationsRepository extends CrudRepository<Notifications, Integer> {

	@Query(value = "SELECT * FROM notifications WHERE user_to =?1 ORDER BY is_read, created_at DESC",nativeQuery = true)
	public List<Notifications> getAllNotifications(int userId);

	@Query(value = "select * from notifications where id =?1", nativeQuery = true)
	public Notifications getNotificationById(int notificationId);

	@Query(value = "select * from notifications where user_to = ?1 and is_read=0 ORDER BY created_at DESC", nativeQuery = true)
	public List<Notifications> getUnReadNotificationsByUserId(int userId);
	
	@Query(value = "SELECT COUNT(*) FROM notifications WHERE user_to = ?1 AND is_read = 0", nativeQuery = true)
	public Integer getUnreadCount(int userId);

	@Transactional
	@Modifying
	@Query(value = "UPDATE notifications SET is_read = 1 WHERE property_id =?1 AND is_read = 0", nativeQuery = true)
	public Integer updatePropertyNotification(int propertyId);
	
}
