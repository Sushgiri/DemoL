package com.bestercapitalmedia.letwizard.admin.notifications;

import com.bestercapitalmedia.letwizard.city.CityDTO;
import com.bestercapitalmedia.letwizard.country.CountryDTO;
import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;
import com.fasterxml.jackson.annotation.JsonProperty;

public class PropertyNotificationDTO {

	private Integer propertyId;
	private String propertyTitle;
	private ChiraghUserDTO chiraghuser;
	@JsonProperty("country")
	private CountryDTO countryId = new CountryDTO();
	@JsonProperty("city")
	private CityDTO cityId = new CityDTO();
	
	public Integer getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}
	public String getPropertyTitle() {
		return propertyTitle;
	}
	public void setPropertyTitle(String propertyTitle) {
		this.propertyTitle = propertyTitle;
	}
	public CountryDTO getCountryId() {
		return countryId;
	}
	public void setCountryId(CountryDTO countryId) {
		this.countryId = countryId;
	}
	public CityDTO getCityId() {
		return cityId;
	}
	public void setCityId(CityDTO cityId) {
		this.cityId = cityId;
	}
	public ChiraghUserDTO getChiraghuser() {
		return chiraghuser;
	}
	public void setChiraghuser(ChiraghUserDTO chiraghuser) {
		this.chiraghuser = chiraghuser;
	}
	
	
}
