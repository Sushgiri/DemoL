package com.bestercapitalmedia.letwizard.admin.notifications;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.buyer.dashboard.RequestDtoForPaginatedWatchList;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.systemevents.CreateNotificationEvent;
import com.bestercapitalmedia.letwizard.systemevents.PushNotificationEvent;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.LogUtill;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.PusherUtil;


@Service
public class NotificationsService implements ApplicationEventPublisherAware {

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private NotificationsRepository notificationRepo;

	@Autowired
	private NotificationPaginatedRepository notificationPaginatedRepository;

	@Autowired
	private ChiragUtill chiraghUtil;

	@Autowired
	private LogUtill logUtill;

	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private ApplicationEventPublisher publisher;

	public ResponseEntity getAllNotifications(RequestDtoForPaginatedWatchList dto) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
//			System.out.println(user.getDepartements().getDepartementsId());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
//			PageRequest pageRequest = ;
			List<Notifications> leads = new ArrayList<Notifications>();
			Page<Notifications> paginatedData = null;
			
			List<Notifications> notifications = new ArrayList();
			paginatedData = notificationPaginatedRepository.getAllNotifications(chiraghuser.getUserId(), PageRequest.of(dto.getPage(), dto.getMaxResult()));
			notifications = paginatedData.getContent();
			
			if (notifications ==  null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

			List<NotificationsDTO> notificationsDTOs = ObjectMapperUtils.mapAll(notifications, NotificationsDTO.class);
			
			Integer unreadCount = notificationRepo.getUnreadCount(chiraghuser.getUserId());

			PaginatedNotificationDTO notification = new PaginatedNotificationDTO();
			notification.setNotifications(notificationsDTOs);
			notification.setPageNumber(paginatedData.getNumber());
			notification.setNumberOfElements(paginatedData.getNumberOfElements());
			notification.setTotalPages(paginatedData.getTotalPages());
			notification.setTotalRecords(paginatedData.getTotalElements());
			notification.setUnReadCount(unreadCount);
			
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(notification).collect(Collectors.toList()));
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity readNotification(int notificationId) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			Notifications notification = notificationRepo.getNotificationById(notificationId);

			if (notification == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			notification.setIsRead(true);

			notification = notificationRepo.save(notification);
//			List<NotificationsDTO> notificationsDTOs = ObjectMapperUtils.mapAll(notifications, NotificationsDTO.class);

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(mapper.map(notification, NotificationsDTO.class)).collect(Collectors.toList()));

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity createNotification(NewNotificationDTO notificationDTO) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			Notifications notification = new Notifications();
			notification.setDescription(notification.getDescription());
			notification.setSubjectType(notificationDTO.getSubjectType());
			notification.setSubjectId(notification.getSubjectId());
			notification.setUserTo(notificationDTO.getUserTo());
//			notification.setPropertyId(notificationDTO.getPropertyId());
//			
//			notification.setUserFrom(chiraghuser.getUserId());
			notification.setIsRead(false);
			notification.setCreatedAt(DateUtils.getDefault().getNowTime());
			notification = notificationRepo.save(notification);

			if (notification == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(notification).collect(Collectors.toList()));
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}
	
	public void createNotification(String description, String subject, int subjectId, int forwardToId,
			Chiraghproperty propertyId) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return;
			}
			publisher.publishEvent(new CreateNotificationEvent(this, description, subject, subjectId, forwardToId,
					propertyId, null, chiraghuser, "notification"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createNotificationWithUserType(String description, String subject, int subjectId, int forwardToId,
			Chiraghproperty propertyId, String userType) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return;
			}
			publisher.publishEvent(new CreateNotificationEvent(this, description, subject, subjectId, forwardToId,
					propertyId, userType, chiraghuser, "userType"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void createNotificationForSystem(String description, String subject, int subjectId, int forwardToId,
			Chiraghproperty propertyId) {
		try {
			publisher.publishEvent(new CreateNotificationEvent(this, description, subject, subjectId, forwardToId,
					propertyId, null, null, "system"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void createNotificationForBid(String description, String subject, int subjectId, int forwardToId,
			Chiraghproperty propertyId, String userType) {
		try {
			publisher.publishEvent(new CreateNotificationEvent(this, description, subject, subjectId, forwardToId,
					propertyId, userType, null, "bid"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ResponseEntity readPropertyNotification(int propertyId) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			Integer notification = notificationRepo.updatePropertyNotification(propertyId);

			if (notification == 0) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					null);

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	@Async
	public ResponseEntity createOverdraftNotification(Chiraghuser chiraghuser, String description, String subject, int subjectId, int forwardToId) {
		return createFinanceNotification(chiraghuser, description, subject, subjectId, forwardToId);
	}
	
	@Async
	public ResponseEntity createKycNotification(Chiraghuser chiraghuser, String description, String subject, int subjectId, int forwardToId) {
		return createFinanceNotification(chiraghuser, description, subject, subjectId, forwardToId);
	}
	
	@Async
	public ResponseEntity createFinanceNotification(Chiraghuser chiraghuser, String description, String subject, int subjectId,
			int forwardToId) {
		try {
			ModelMapper mapper = new ModelMapper();
//			String userName = chiragUtill.getUserNameFromAuthentication();
//			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			Notifications notification = new Notifications();
			notification.setDescription(description);
			notification.setSubjectType(subject);
			notification.setSubjectId(subjectId);
			notification.setUserTo(forwardToId);
			
			notification.setUserFrom(chiraghuser);
			notification.setIsRead(false);
			notification.setCreatedAt(DateUtils.getDefault().getNowTime());
			notification = notificationRepo.save(notification);

			if (notification == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				NotificationsDTO notificationDTO = ObjectMapperUtils.map(notification, NotificationsDTO.class);
				
				PusherUtil.getDefault().push("user-" + forwardToId, "notifications", notificationDTO);
				
				// CD-551 :send push notification to devices 
				Chiraghuser chiraghuserFwrdTo = userRepository.findByUserId(forwardToId);
				if (!"".equals(chiraghuserFwrdTo.getDeviceToken()) && null != chiraghuserFwrdTo.getDeviceToken()) {
					publisher.publishEvent(
							new PushNotificationEvent(this, notificationDTO, chiraghuserFwrdTo, description, subject));
				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(notificationDTO).collect(Collectors.toList()));
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity createNotification(Chiraghuser chiraghuser,String description, String subject, int subjectId, int forwardToId, Chiraghproperty propertyId, String userType) {
		try {
			ModelMapper mapper = new ModelMapper();
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			Notifications notification = new Notifications();
			notification.setDescription(description);
			notification.setSubjectType(subject);
			notification.setSubjectId(subjectId);
			notification.setUserTo(forwardToId);
			notification.setChiraghproperty(propertyId);
			notification.setUserType(userType);
			notification.setUserFrom(chiraghuser);
			notification.setIsRead(false);
			notification.setCreatedAt(DateUtils.getDefault().getNowTime());
			notification = notificationRepo.save(notification);

			if (notification == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				NotificationsDTO notificationDTO = ObjectMapperUtils.map(notification, NotificationsDTO.class);

				PusherUtil.getDefault().push("user-" + forwardToId, "notifications", notificationDTO);

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(notificationDTO).collect(Collectors.toList()));
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}
	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;

	}
}
