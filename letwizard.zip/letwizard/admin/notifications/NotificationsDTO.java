package com.bestercapitalmedia.letwizard.admin.notifications;

import java.util.Date;

public class NotificationsDTO {
	
	private Integer id;
	private String description;
	private String subjectType;
	private Integer subjectId;
	private Integer userTo;
//	private Integer userFrom;
	private UserNotificationDTO userFrom;
	//private Integer propertyId;
	private PropertyNotificationDTO chiraghproperty;
	private Byte isRead;
	private Date createdAt;
	private Date updatedAt;
	private String userType;
	private Boolean isRental;

	public NotificationsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSubjectType() {
		return subjectType;
	}
	public void setSubjectType(String subjectType) {
		this.subjectType = subjectType;
	}
	public Integer getSubjectId() {
		return subjectId;
	}
	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}
	public Integer getUserTo() {
		return userTo;
	}
	public void setUserTo(Integer userTo) {
		this.userTo = userTo;
	}
	public UserNotificationDTO getUserFrom() {
		return userFrom;
	}
	public void setUserFrom(UserNotificationDTO userFrom) {
		this.userFrom = userFrom;
	}
	public Byte getIsRead() {
		return isRead;
	}
	public void setIsRead(Byte isRead) {
		this.isRead = isRead;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public PropertyNotificationDTO getChiraghproperty() {
		return chiraghproperty;
	}
	public void setChiraghproperty(PropertyNotificationDTO chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public Boolean getRental() {
		return isRental;
	}
	public void setRental(Boolean rental) {
		isRental = rental;
	}
}
