package com.bestercapitalmedia.letwizard.admin.propertychecklist;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.admin.checklist.CheckListDto;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;

@Service
public interface PropertyCheckListService  {

	public ResponseEntity save(PropertyCheckListDto list);
	public List<CheckListDto> getPropertyCheckListByPropertyId(int propertyId);
	
}
