package com.bestercapitalmedia.letwizard.admin.propertychecklist;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;
import com.bestercapitalmedia.letwizard.bank.Bank;

public interface PropertyCheckListRepository  extends CrudRepository<Propertychecklist, Integer>{

	
	@Query(value = "Select * FROM propertychecklist WHERE property_Id=?1", nativeQuery = true)
	public List<Propertychecklist> getPropertyCheckListByPropertyId(int propertyId);
	
	@Query(value = "Select * FROM propertychecklist WHERE checklist_Id=?1 && user_Id=?2 && property_Id=?3", nativeQuery = true)
	public Propertychecklist getPropertyCheckListByChecklistId(int checklistId,int userId,int propertyId);
	
	
	@Query(value = "Select * FROM propertychecklist WHERE checklist_Id=?1 && user_Id=?2 && property_Id=?3", nativeQuery = true)
	public Propertychecklist getPropertyListingprice(int checklistId,int userId,int propertyId);
	
	
	@Query(value = "select * from checklist where checklist_Id = ?1", nativeQuery = true)
	public Checklist findCheckListById(int checkListId);
	
	
}
