package com.bestercapitalmedia.letwizard.admin.propertychecklist;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.jfree.util.Log;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.admin.checklist.CheckListDto;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.LetwizardMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.LetwizardPropertyService;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.user.ChiraghUserService;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;

@Service
public class PropertyCheckListServiceImpl implements PropertyCheckListService {

	@Autowired
	private PropertyCheckListService propertyCheckListService;
	@Autowired
	private PropertyRepository propertyRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PropertyCheckListRepository propertyCheckListRepository;

	Chiraghproperty chiraghproperty = null;
	Chiraghuser chiraghuser = null;

	@Autowired
	private ResponseUtill responseUtill;

	@Override
	public ResponseEntity save(PropertyCheckListDto dto) {
		try {
			ModelMapper mapper = new ModelMapper();
			chiraghproperty = propertyRepository.findByPropertyId(dto.getPropertyId());
			chiraghuser = userRepository.findByUserName(dto.getUserName());
			try {
				Optional<CheckListDto> listingPriceObj = dto.getListingCheckList().stream()
						.filter(s -> s.getChecklistField().equals("Property Listings price is finalized? "))
						.findFirst();
				Optional<CheckListDto> reservedPriceObj = dto.getListingCheckList().stream()
						.filter(s -> s.getChecklistField().equals("Property reserved price is finalized? "))
						.findFirst();

				if (listingPriceObj.isPresent() && reservedPriceObj.isPresent()) {
					float listingPrice = Float.parseFloat(listingPriceObj.get().getUserInput());
					float reservedPrice = Float.parseFloat(reservedPriceObj.get().getUserInput());
					System.out.println(listingPrice);
					System.out.println(reservedPrice);
					if (reservedPrice < listingPrice) {
						return responseUtill.getApiResponse(ResponseCodes.FAILURE,
								"Listing price must be less than reserved price!!", null);
					}
				}

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			dto.getListingCheckList().stream().forEach(s -> {
				Log.info("" + s.getChecklistField() + "   -----" + s.getIsChecked());
				Propertychecklist obj = new Propertychecklist();
				obj.setChiraghproperty(chiraghproperty);
				obj.setChiraghuser(chiraghuser);
				Checklist checklist = mapper.map(s, Checklist.class);
				obj.setChecklist(checklist);
				obj.setUserInput(s.getUserInput());
				obj.setDate(Calendar.getInstance());
				propertyCheckListRepository.save(obj);

			});
			String dept = dto.getDept();
			System.out.println("Save Dept:" + dept);
			checklistVerified(chiraghproperty, dept);
			chiraghproperty = null;
			chiraghuser = null;
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, LetwizardMessages.CHECKLIST_SAVED_SUCCESS, null);
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					LetwizardMessages.CHECKLIST_SAVED_FAILURE, null);

		}
	}

	@Override
	public List<CheckListDto> getPropertyCheckListByPropertyId(int propertyId) {
		ModelMapper mapper = new ModelMapper();
		List<CheckListDto> list = new ArrayList<>();
		propertyCheckListRepository.getPropertyCheckListByPropertyId(propertyId).stream().forEach(s -> {
			CheckListDto checkListDto = mapper.map(s.getChecklist(), CheckListDto.class);
			checkListDto.setUserInput(s.getUserInput());
			list.add(checkListDto);
		});
		return list;
	}

	public void checklistVerified(Chiraghproperty chiraghproperty, String dept) {
		switch (dept) {
		case "Verification":
			chiraghproperty.setVerificationChecklistConfirm(true);
			propertyRepository.save(chiraghproperty);
			break;
		case "Valuation":
			chiraghproperty.setValuationChecklistConfirm(true);
			propertyRepository.save(chiraghproperty);
			break;
		case "Brokerage":
			chiraghproperty.setBrokerageChecklistConfirm(true);
			propertyRepository.save(chiraghproperty);
			break;
		case "Finance":
			chiraghproperty.setFinanceChecklistConfirm(true);
			propertyRepository.save(chiraghproperty);
			break;
		case "Listing":
			chiraghproperty.setListingChecklistConfirm(true);
			propertyRepository.save(chiraghproperty);
			break;
		default:
			break;
		}

	}
}
