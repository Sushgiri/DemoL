package com.bestercapitalmedia.letwizard.admin.propertychecklist;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface PropertyCheckListPivotRepository extends CrudRepository<Propertychecklist, Integer>{
	
	@Query(value = "select * from propertychecklist where property_Id = ?1 and checklist_Id =?2", nativeQuery = true)
	public Propertychecklist findAlreadyVerified(int propertyId, int checkListId);
	
	@Query(value = "select * from propertychecklist where buyer_Process_Id = ?1 and checklist_Id =?2", nativeQuery = true)
	public Propertychecklist findBuyerAlreadyVerified(int buyerProcessId, int checkListId);

}
