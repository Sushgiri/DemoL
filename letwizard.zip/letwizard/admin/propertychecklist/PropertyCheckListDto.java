package com.bestercapitalmedia.letwizard.admin.propertychecklist;

import java.util.List;

import com.bestercapitalmedia.letwizard.admin.checklist.CheckListDto;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;

public class PropertyCheckListDto {

	List<CheckListDto> listingCheckList;
	int propertyId;
	String userName;
	String userInput;
	String dept;
	

	
	
	
	public int getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public PropertyCheckListDto() {
	}
	public List<CheckListDto> getListingCheckList() {
		return listingCheckList;
	}
	public void setListingCheckList(List<CheckListDto> listingCheckList) {
		this.listingCheckList = listingCheckList;
	}
	public String getUserInput() {
		return userInput;
	}
	public void setUserInput(String userInput) {
		this.userInput = userInput;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	
	
	
}
