package com.bestercapitalmedia.letwizard.admin.propertychecklist;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.admin.checklist.CheckListDto;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.BasicErrorMessages;
import com.bestercapitalmedia.letwizard.constants.LetwizardMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;

@CrossOrigin
@RequestMapping("/api/propertychecklist")
@RestController
public class PropertyCheckListController {

	@Autowired
	private PropertyCheckListService propertyCheckListServcie;
	@Autowired
	private ResponseUtill responseUtill;

	@CrossOrigin(origins = "*")
	@PostMapping(value = "/save")
	public @ResponseBody ResponseEntity getCheckListByDepartment(@RequestBody PropertyCheckListDto checkListDto,
			HttpServletRequest httpServletRequest) {
		return propertyCheckListServcie.save(checkListDto);
	}

	@CrossOrigin(origins = "*")
	@GetMapping(value = "/getCheckListByPropertyId/{propertyId}")
	public @ResponseBody ResponseEntity getCheckListByDepartment(@PathVariable(value = "propertyId") int propertyId,
			HttpServletRequest httpServletRequest) {
		try {
			List<CheckListDto> list = propertyCheckListServcie.getPropertyCheckListByPropertyId(propertyId);
			if (list == null)
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_NOT_FOUND, null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_RETRIVED_SUCCESS,
						list);
		} catch (Exception e) {
			e.printStackTrace();
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}
	}
}
