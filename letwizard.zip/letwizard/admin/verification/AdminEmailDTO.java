package com.bestercapitalmedia.letwizard.admin.verification;

public class AdminEmailDTO {

	String adminUser;
	String userName;
	String role;
	String email;
	String subject;
	String data;
	String user;
	String checkListConfirmed;
	int propertyId;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getAdminUser() {
		return adminUser;
	}

	public void setAdminUser(String adminUser) {
		this.adminUser = adminUser;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getCheckListConfirmed() {
		return checkListConfirmed;
	}

	public void setCheckListConfirmed(String checkListConfirmed) {
		this.checkListConfirmed = checkListConfirmed;
	}

	public int getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}

}
