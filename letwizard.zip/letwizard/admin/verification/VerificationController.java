package com.bestercapitalmedia.letwizard.admin.verification;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.mail.MailService;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/verification")
public class VerificationController {

	private static final Logger logger = LoggerFactory.getLogger(VerificationController.class);
	@Autowired
	private MailService mailService;
	@Autowired
	private ChiragUtill chiraghUtil;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PropertyRepository propertyRepository;

	@CrossOrigin(origins = "*")
//	@Async
	@RequestMapping(value = "/sentEmail", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity confirmEmailRequest(@RequestBody AdminEmailDTO adminEmailDTO,
															HttpServletRequest httpServletRequest) {
		try {
			String status="";
			String email="";
			Chiraghuser sellerUser= null;
			logger.info("Check List Confirmed:"+adminEmailDTO.getCheckListConfirmed());
			logger.info(adminEmailDTO.getData());
			logger.info(adminEmailDTO.getRole());

			Chiraghuser chiraghUser=null;
			chiraghUser=userRepository.findAdminUserByUserNameNRole(adminEmailDTO.getAdminUser(),adminEmailDTO.getRole());
			if(chiraghUser==null)
				return new ResponseEntity(chiraghUtil.getMessageObject("User Not Found!"),
						HttpStatus.OK);
			if(adminEmailDTO.getRole().equals("VerificationUser")&&adminEmailDTO.getCheckListConfirmed().equals("false")) {
				sellerUser=  userRepository.findByUserName(adminEmailDTO.getUserName());
				email=sellerUser.getUserEmail();
			}
			else if(adminEmailDTO.getRole().equals("VerificationUser")&&adminEmailDTO.getCheckListConfirmed().equals("true")) {
				logger.info("Inside Verification USer If");
				sellerUser= userRepository.findByRole("VerificationHod");
				email=sellerUser.getUserEmail();
				logger.info(email);
			}
			else if(adminEmailDTO.getRole().equals("ValuationUser")) {
				sellerUser=  userRepository.findByRole("ValuationHod");
				email=sellerUser.getUserEmail();
			}
			else if(adminEmailDTO.getRole().equals("BrokerageUser")) {
				sellerUser=  userRepository.findByRole("BrokerageHod");
				email=sellerUser.getUserEmail();
			}
			else if(adminEmailDTO.getRole().equals("FinanceUser")) {
				sellerUser=  userRepository.findByRole("FinanceHod");
				email=sellerUser.getUserEmail();
			}
			else if(adminEmailDTO.getRole().equals("FinanceHod")&&adminEmailDTO.getData().equals("Finance Hod Approved")) {
				sellerUser=  userRepository.findByRole("SuperAdmin");
				email=sellerUser.getUserEmail();

			}
			else if((!adminEmailDTO.getData().equals("verificationhodapproved"))&&(adminEmailDTO.getRole().equals("VerificationHod")||adminEmailDTO.getRole().equals("ValuationHod")||adminEmailDTO.getRole().equals("BrokerageHod")||adminEmailDTO.getRole().equals("FinanceHod"))){
				logger.info("Inside this");
				sellerUser=  userRepository.findByUserName(adminEmailDTO.getUser());
				email=sellerUser.getUserEmail();
			}
			else if(adminEmailDTO.getData().equals("verificationhodapproved")) {
				logger.info("THis pId"+adminEmailDTO.getPropertyId());
				Chiraghproperty chiraghproperty= propertyRepository.findByPropertyId(adminEmailDTO.getPropertyId());
				if(chiraghproperty==null) {
					return new ResponseEntity(chiraghUtil.getMessageObject("Property not Found!!"),
							HttpStatus.OK);
				}
				userRepository.getHods()
						.stream()
						.forEach(u->
								mailService.sendMail(u.getUserEmail(), adminEmailDTO.getSubject(),"Chiragh Verification Department\n Property Successfully Verified \n Property Details: \n Property Id:"+chiraghproperty.getPropertyId()+"\n Address:"+chiraghproperty.getAddress()+" \n Project Name:"+chiraghproperty.getProjectName())
						);
			}

			logger.info(email);
			if(sellerUser!=null)
				status= mailService.sendMail(email, adminEmailDTO.getSubject(),adminEmailDTO.getData());

			return new ResponseEntity(chiraghUtil.getMessageObject(status),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new ResponseEntity(chiraghUtil.getMessageObject("Internal Server Error!" + e.getMessage()),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



}//end of class
