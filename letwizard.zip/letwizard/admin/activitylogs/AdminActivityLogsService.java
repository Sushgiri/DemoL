package com.bestercapitalmedia.letwizard.admin.activitylogs;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.user.Chiraghuser;


@Service
public class AdminActivityLogsService {

	@Autowired
	private AdminActivityLogsRepository adminActivityLogsRepository;
	
	@Autowired
	private HttpServletRequest request;
	
	public void logAction(String actionPerform, Chiraghuser chiraghuser, Integer propertyId) {
		try {
			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			Adminactivitylogs adminactivitylogs = new Adminactivitylogs();

			adminactivitylogs.setActionPerformed(actionPerform);
			adminactivitylogs.setChiraghuser(chiraghuser);
			adminactivitylogs.setDepartmentId(chiraghuser.getDepartements().getDepartementsId());
			adminactivitylogs.setPropertyId(propertyId);
			adminactivitylogs.setActionPerformedDatetime(new java.sql.Timestamp(now.getTime()));
			
			adminActivityLogsRepository.save(adminactivitylogs);
			
		} catch (Exception e) {
			
		}
	}
	
	public void logBuyerAction(String actionPerform, Chiraghuser chiraghuser, Integer buyerProcessId) {
		try {
			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			Adminactivitylogs adminactivitylogs = new Adminactivitylogs();
			
			adminactivitylogs.setActionPerformed(actionPerform);
			adminactivitylogs.setChiraghuser(chiraghuser);
			adminactivitylogs.setDepartmentId(chiraghuser.getDepartements().getDepartementsId());
			adminactivitylogs.setBuyerProcessId(buyerProcessId);
			adminactivitylogs.setActionPerformedDatetime(new java.sql.Timestamp(now.getTime()));
			
			adminActivityLogsRepository.save(adminactivitylogs);
			
		} catch (Exception e) {
			
		}
	}
	
	public void logAction(String actionPerform, Chiraghuser chiraghuser, Integer propertyId, String additionaldata) {
		try {
			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			Adminactivitylogs adminactivitylogs = new Adminactivitylogs();

			adminactivitylogs.setActionPerformed(actionPerform);
			adminactivitylogs.setChiraghuser(chiraghuser);
			adminactivitylogs.setDepartmentId(chiraghuser.getDepartements().getDepartementsId());
			adminactivitylogs.setPropertyId(propertyId);
			adminactivitylogs.setAdditionalData(additionaldata);
			adminactivitylogs.setActionPerformedDatetime(new java.sql.Timestamp(now.getTime()));
			
			adminActivityLogsRepository.save(adminactivitylogs);
			
		} catch (Exception e) {
			
		}
	}
	
	public void logAction(String actionPerform, Chiraghuser chiraghuser, Integer propertyId, String additionaldata, String subject) {
		try {
			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			Adminactivitylogs adminactivitylogs = new Adminactivitylogs();

			adminactivitylogs.setActionPerformed(actionPerform);
			adminactivitylogs.setChiraghuser(chiraghuser);
			adminactivitylogs.setPropertyId(propertyId);
			adminactivitylogs.setAdditionalData(additionaldata);
			adminactivitylogs.setSubject(subject);
			adminactivitylogs.setRemoteIpAddress(request.getRemoteAddr());
			adminactivitylogs.setActionPerformedDatetime(new java.sql.Timestamp(now.getTime()));
			
			adminActivityLogsRepository.save(adminactivitylogs);
			
		} catch (Exception e) {
			
		}
	}
}
