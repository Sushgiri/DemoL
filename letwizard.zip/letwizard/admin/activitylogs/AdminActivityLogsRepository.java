package com.bestercapitalmedia.letwizard.admin.activitylogs;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface AdminActivityLogsRepository extends CrudRepository<Adminactivitylogs, Integer>{
	
	@Query(value = "select * from adminactivitylogs where property_Id=?1 ORDER BY action_Performed_Datetime desc", nativeQuery = true)
	public List<Adminactivitylogs> findActivityLogsByPropertyId(int propertyId);
	
	@Query(value = "select * from adminactivitylogs where buyer_process_id=?1 ORDER BY action_Performed_Datetime desc", nativeQuery = true)
	public List<Adminactivitylogs> findActivityLogsByBuyerProcessId(int buyerProcessId);

	@Query(value = "select * from adminactivitylogs where property_Id=?1 and department_Id=?2  ORDER BY action_Performed_Datetime desc", nativeQuery = true)
	public List<Adminactivitylogs> findDepartmentActivityLogsByPropertyId(int propertyID, Integer departmentId);
	
	


}
