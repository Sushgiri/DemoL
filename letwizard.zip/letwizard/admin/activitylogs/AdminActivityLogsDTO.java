package com.bestercapitalmedia.letwizard.admin.activitylogs;

import java.util.Date;

import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;


public class AdminActivityLogsDTO {
	private Integer adminActivityLogsId;
	private String actionPerformed;
	private ChiraghUserDTO chiraghuser;
	private Date actionPerformedDatetime;
	private String remoteIpAddress;
	private Integer propertyId;
	private String additionalData;
	private String subject;
	private Integer departmentId;
	
	public AdminActivityLogsDTO() {
	}
	
	
	public Integer getAdminActivityLogsId() {
		return adminActivityLogsId;
	}
	public void setAdminActivityLogsId(Integer adminActivityLogsId) {
		this.adminActivityLogsId = adminActivityLogsId;
	}
	public String getActionPerformed() {
		return actionPerformed;
	}
	public void setActionPerformed(String actionPerformed) {
		this.actionPerformed = actionPerformed;
	}
	public ChiraghUserDTO getChiraghuser() {
		return chiraghuser;
	}
	public void setChiraghuser(ChiraghUserDTO chiraghuser) {
		this.chiraghuser = chiraghuser;
	}
	public Date getActionPerformedDatetime() {
		return actionPerformedDatetime;
	}
	public void setActionPerformedDatetime(Date actionPerformedDatetime) {
		this.actionPerformedDatetime = actionPerformedDatetime;
	}
	public String getRemoteIpAddress() {
		return remoteIpAddress;
	}
	public void setRemoteIpAddress(String remoteIpAddress) {
		this.remoteIpAddress = remoteIpAddress;
	}
	public Integer getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}


	public String getAdditionalData() {
		return additionalData;
	}


	public void setAdditionalData(String additionalData) {
		this.additionalData = additionalData;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}


	public Integer getDepartmentId() {
		return departmentId;
	}


	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	
	
	
	
}
