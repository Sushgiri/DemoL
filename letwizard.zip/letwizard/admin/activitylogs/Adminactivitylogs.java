package com.bestercapitalmedia.letwizard.admin.activitylogs;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bestercapitalmedia.letwizard.user.Chiraghuser;

// TODO: Auto-generated Javadoc
/**
 * The Class Adminactivitylogs.
 */

@Entity
@Table(name = "adminactivitylogs")
public class Adminactivitylogs implements java.io.Serializable {

	private Integer adminActivityLogsId;
	private String actionPerformed;
	private Chiraghuser chiraghuser;
	private Date actionPerformedDatetime;
	private String remoteIpAddress;
	private Integer propertyId;
	private Integer buyerProcessId;
	private String additionalData;
	private String subject;
	private Integer departmentId;
	

	public Adminactivitylogs() {
	}

//	public Adminactivitylogs(String actionPerformed, Integer adminUsersId, Date actionPerformedDatetime,
//			String remoteIpAddress, Integer propertyId) {
//		this.actionPerformed = actionPerformed;
//		this.adminUsersId = adminUsersId;
//		this.actionPerformedDatetime = actionPerformedDatetime;
//		this.remoteIpAddress = remoteIpAddress;
//		this.propertyId = propertyId;
//	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "admin_Activity_Logs_Id", unique = true, nullable = false)
	public Integer getAdminActivityLogsId() {
		return this.adminActivityLogsId;
	}

	public void setAdminActivityLogsId(Integer adminActivityLogsId) {
		this.adminActivityLogsId = adminActivityLogsId;
	}

	@Column(name = "action_Performed", length = 100)
	public String getActionPerformed() {
		return this.actionPerformed;
	}

	public void setActionPerformed(String actionPerformed) {
		this.actionPerformed = actionPerformed;
	}

	
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "admin_Users_Id")
	public Chiraghuser getChiraghuser() {
		return chiraghuser;
	}

	public void setChiraghuser(Chiraghuser chiraghuser) {
		this.chiraghuser = chiraghuser;
	}

	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "action_Performed_Datetime", length = 26)
	public Date getActionPerformedDatetime() {
		return this.actionPerformedDatetime;
	}

	public void setActionPerformedDatetime(Date actionPerformedDatetime) {
		this.actionPerformedDatetime = actionPerformedDatetime;
	}

	@Column(name = "remote_Ip_Address", length = 50)
	public String getRemoteIpAddress() {
		return this.remoteIpAddress;
	}

	public void setRemoteIpAddress(String remoteIpAddress) {
		this.remoteIpAddress = remoteIpAddress;
	}

	@Column(name = "property_Id")
	public Integer getPropertyId() {
		return this.propertyId;
	}

	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	@Column(name = "additional_data")
	public String getAdditionalData() {
		return additionalData;
	}

	public void setAdditionalData(String additionalData) {
		this.additionalData = additionalData;
	}

	@Column(name = "subject")
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	@Column(name = "buyer_process_id")
	public Integer getBuyerProcessId() {
		return buyerProcessId;
	}

	public void setBuyerProcessId(Integer buyerProcessId) {
		this.buyerProcessId = buyerProcessId;
	}
	
	@Column(name = "department_Id")
	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	
	
	
	

}
