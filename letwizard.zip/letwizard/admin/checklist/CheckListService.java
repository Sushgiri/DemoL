package com.bestercapitalmedia.letwizard.admin.checklist;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface CheckListService {

	ResponseEntity	getCheckListByDepartment(CurrentPropertyCheckListDto department);
}
