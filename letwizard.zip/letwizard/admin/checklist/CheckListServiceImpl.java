package com.bestercapitalmedia.letwizard.admin.checklist;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.bestercapitalmedia.letwizard.admin.propertychecklist.PropertyCheckListRepository;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.Propertychecklist;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.BasicErrorMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.user.ChiraghUserService;

@Service
public class CheckListServiceImpl implements CheckListService {

	private CheckListRepository checkListRepository;

	@Autowired
	ChiraghUserService chiraghUserService;

	@Autowired
	private PropertyCheckListRepository propertyCheckListRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	public CheckListServiceImpl(CheckListRepository checkListRepository) {
		this.checkListRepository = checkListRepository;
	}

	@Override
	public ResponseEntity getCheckListByDepartment(CurrentPropertyCheckListDto dto) {
		try {
			ModelMapper mapper = new ModelMapper();
			List<CheckListDto> response = new ArrayList<>();
			List<Checklist> list = null;

			if (dto.getDepartment().equals("Listing") || dto.getDepartment().equals("Brokerage")) {
				list = checkListRepository.getCheckListByDepartment(dto.getDepartment());
			} else {
				list = checkListRepository.getCheckListByDepartmentName(dto.getDepartment());
			}

			list.stream().filter(Objects::nonNull).forEach(s -> {
				System.out.println(dto.getUserName());
				System.out.println(dto.getDepartment());
				System.out.println(dto.getPropertyId());
				CheckListDto checklist = mapper.map(s, CheckListDto.class);
				System.out.println("Input checklist" + s.getIsInput());
				try {
					if (s.getIsInput()) {
						Propertychecklist obj = propertyCheckListRepository.getPropertyCheckListByChecklistId(
								s.getChecklistId(), chiraghUserService.getUserByName(dto.getUserName()).getUserId(),
								dto.getPropertyId());
						if (obj != null) {
							checklist.setUserInput(obj.getUserInput());
						}
					}
				} catch (Exception e) {
//					e.printStackTrace();
				}
				response.add(checklist);
			});

			if (response == null)
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_NOT_FOUND, null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_RETRIVED_SUCCESS,
						response);
		} catch (Exception e) {
			e.printStackTrace();
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}
	}

}
