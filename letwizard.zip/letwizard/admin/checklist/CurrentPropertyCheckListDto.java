package com.bestercapitalmedia.letwizard.admin.checklist;

public class CurrentPropertyCheckListDto {

	int propertyId;
	String userName;
	String department;
	public int getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public CurrentPropertyCheckListDto() {
		
	}
}
