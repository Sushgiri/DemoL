
package com.bestercapitalmedia.letwizard.admin.checklist;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.bestercapitalmedia.letwizard.admin.propertychecklist.Propertychecklist;

/**
 */

@Entity

@Table(name = "checklist")
public class Checklist implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "checklist_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer checklistId;
	
	@Column(name = "checklist", length = 200)
	@Basic(fetch = FetchType.EAGER)
	String checklistField;
	
	@Column(name = "department", length = 200)
	@Basic(fetch = FetchType.EAGER)
	String department;

	@Column(name = "is_Visible")
	@Basic(fetch = FetchType.EAGER)
	Boolean isVisible;

	@Column(name = "is_Mandatory")
	@Basic(fetch = FetchType.EAGER)
	Boolean isMandatory;
	
	@Column(name = "is_Input")
	@Basic(fetch = FetchType.EAGER)
	Boolean isInput;
	
	
	
	
	@OneToMany(mappedBy = "checklist", fetch = FetchType.LAZY)
	java.util.Set<Propertychecklist> propertychecklists;

	/**
	 */
	public void setChecklistId(Integer checklistId) {
		this.checklistId = checklistId;
	}

	/**
	 */
	public Integer getChecklistId() {
		return this.checklistId;
	}

	/**
	 */
	public void setChecklistField(String checklistField) {
		this.checklistField = checklistField;
	}

	/**
	 */
	public String getChecklistField() {
		return this.checklistField;
	}

	/**
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 */
	public String getDepartment() {
		return this.department;
	}

	/**
	 */
	public void setIsVisible(Boolean isVisible) {
		this.isVisible = isVisible;
	}

	/**
	 */
	public Boolean getIsVisible() {
		return this.isVisible;
	}

	/**
	 */
	public void setIsMandatory(Boolean isMandatory) {
		this.isMandatory = isMandatory;
	}

	/**
	 */
	public Boolean getIsMandatory() {
		return this.isMandatory;
	}


	/**
	 */
	public Checklist() {
	}

	public java.util.Set<Propertychecklist> getPropertychecklists() {
		return propertychecklists;
	}

	public void setPropertychecklists(java.util.Set<Propertychecklist> propertychecklists) {
		this.propertychecklists = propertychecklists;
	}

	public Boolean getIsInput() {
		return isInput;
	}

	public void setIsInput(Boolean isInput) {
		this.isInput = isInput;
	}

	
}
