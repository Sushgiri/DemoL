package com.bestercapitalmedia.letwizard.admin.checklist;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface CheckListRepository extends CrudRepository<Checklist, Integer> {
	
	@Query(value = "Select * FROM checklist WHERE department=?1 || department='shared'", nativeQuery = true)
	public List<Checklist> getCheckListByDepartment(String department);
	
	@Query(value = "Select * FROM checklist WHERE department=?1", nativeQuery = true)
	public List<Checklist> getCheckListByDepartmentName(String department);
	
	@Query(value = "Select * FROM checklist WHERE checklist like%?1%", nativeQuery = true)
	public Checklist getCheckListByCheckList(String checklist);
	
	@Query(value = "Select * FROM checklist WHERE department='shared' AND checklist='Property Listings price is finalized? ' ", nativeQuery = true)
	public Checklist getByDepartmentId();
	
	@Query(value = "select * from checklist where checklist_Id = ?1", nativeQuery = true)
	public Checklist findCheckListById(int checkListId);

	@Query(value = "SELECT * FROM checklist WHERE department_Id = 3 AND (is_buyer IS NULL OR is_buyer = 0)", nativeQuery = true)
	public List<Checklist> getBrokerageSellerChecklist();
}
