package com.bestercapitalmedia.letwizard.auditing.seller;

import java.io.Serializable;
import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;

import com.ibm.icu.util.Calendar;

@Entity
@Table(name = "myrevision")
@RevisionEntity(MyRevisionListener.class)
public class MyRevision extends DefaultRevisionEntity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;

	@Column(name = "userName")
	private String userName;

	@Column(name = "dateTime")
	private Date dateTime;

	@OneToMany(mappedBy = "myrevision", fetch = FetchType.LAZY)
	java.util.Set<ChiraghpropertyAud> chiraghpropertyAuds;

	@OneToMany(mappedBy = "myrevision", fetch = FetchType.LAZY)
	java.util.Set<PropertysellerdetailsAud> propertysellerdetailsAuds;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public int getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public java.util.Set<ChiraghpropertyAud> getChiraghpropertyAuds() {
		return chiraghpropertyAuds;
	}

	public void setChiraghpropertyAuds(java.util.Set<ChiraghpropertyAud> chiraghpropertyAuds) {
		this.chiraghpropertyAuds = chiraghpropertyAuds;
	}

	public java.util.Set<PropertysellerdetailsAud> getPropertysellerdetailsAuds() {
		return propertysellerdetailsAuds;
	}

	public void setPropertysellerdetailsAuds(java.util.Set<PropertysellerdetailsAud> propertysellerdetailsAuds) {
		this.propertysellerdetailsAuds = propertysellerdetailsAuds;
	}

}
