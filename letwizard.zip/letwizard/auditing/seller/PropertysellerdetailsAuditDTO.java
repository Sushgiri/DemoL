
package com.bestercapitalmedia.letwizard.auditing.seller;

import java.io.Serializable;
import java.util.Date;

/**
 */
public class PropertysellerdetailsAuditDTO implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	String otherDocument;
	Integer sellerId;
	/**
	 */

	Integer revisionId;
	/**
	 */

	Boolean revisionType;
	/**
	 */

	String address;
	/**
	 */

	String email;
	/**
	 */

	String emailVerificationCode;
	/**
	 */

	String fax;
	/**
	 */

	String firstName;

	String idCardExpiration;

	String idCardNo;

	String isPersonalDetailsVerified;

	String isPoaAccepted;

	String lastName;

	String middleName;

	String mobile;

	String nationality;

	String ownerType;

	String passportCopyUpload;

	String passportExpiryDate;

	Integer passportIdDocumentUpload;

	String passportNo;

	String poaAgreementExpiry;

	String poaNumber;

	String poaPropertyAuthority;

	String pobox;

	String propertyDocument1Upload;

	String propertyDocument2Upload;

	String propertyDocument3Upload;

	String propertyDocument4Upload;

	String scannedIdCopy;

	String scannedNotorizedCopy;

	String sellerProfilepic;

	String specificProperty;

	String telephone;
	String titleDeedUpload;

	Integer propertyId;

	String userName;
	
	Date revDate;
	Integer countryid;
	Integer cityid;
	
	

	public Integer getCountryid() {
		return countryid;
	}

	public void setCountryid(Integer countryid) {
		this.countryid = countryid;
	}

	public Integer getCityid() {
		return cityid;
	}

	public void setCityid(Integer cityid) {
		this.cityid = cityid;
	}

	/**
	 */
	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	/**
	 */
	public Integer getRevisionId() {
		return this.revisionId;
	}

	/**
	 */
	public void setRevisionType(Boolean revisionType) {
		this.revisionType = revisionType;
	}

	/**
	 */
	public Boolean getRevisionType() {
		return this.revisionType;
	}

	/**
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 */
	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	/**
	 */
	public String getEmailVerificationCode() {
		return this.emailVerificationCode;
	}

	/**
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 */
	public String getFax() {
		return this.fax;
	}

	/**
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 */
	public void setIdCardExpiration(String idCardExpiration) {
		this.idCardExpiration = idCardExpiration;
	}

	/**
	 */
	public String getIdCardExpiration() {
		return this.idCardExpiration;
	}

	/**
	 */
	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}

	/**
	 */
	public String getIdCardNo() {
		return this.idCardNo;
	}

	/**
	 */
	public void setIsPersonalDetailsVerified(String isPersonalDetailsVerified) {
		this.isPersonalDetailsVerified = isPersonalDetailsVerified;
	}

	/**
	 */
	public String getIsPersonalDetailsVerified() {
		return this.isPersonalDetailsVerified;
	}

	/**
	 */
	public void setIsPoaAccepted(String isPoaAccepted) {
		this.isPoaAccepted = isPoaAccepted;
	}

	/**
	 */
	public String getIsPoaAccepted() {
		return this.isPoaAccepted;
	}

	/**
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 */
	public String getMiddleName() {
		return this.middleName;
	}

	/**
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 */
	public String getMobile() {
		return this.mobile;
	}

	/**
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	/**
	 */
	public String getNationality() {
		return this.nationality;
	}

	/**
	 */
	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	/**
	 */
	public String getOwnerType() {
		return this.ownerType;
	}

	/**
	 */
	public void setPassportCopyUpload(String passportCopyUpload) {
		this.passportCopyUpload = passportCopyUpload;
	}

	/**
	 */
	public String getPassportCopyUpload() {
		return this.passportCopyUpload;
	}

	/**
	 */
	public void setPassportExpiryDate(String passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	/**
	 */
	public String getPassportExpiryDate() {
		return this.passportExpiryDate;
	}

	/**
	 */
	public void setPassportIdDocumentUpload(Integer passportIdDocumentUpload) {
		this.passportIdDocumentUpload = passportIdDocumentUpload;
	}

	/**
	 */
	public Integer getPassportIdDocumentUpload() {
		return this.passportIdDocumentUpload;
	}

	/**
	 */
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	/**
	 */
	public String getPassportNo() {
		return this.passportNo;
	}

	/**
	 */
	public void setPoaAgreementExpiry(String poaAgreementExpiry) {
		this.poaAgreementExpiry = poaAgreementExpiry;
	}

	/**
	 */
	public String getPoaAgreementExpiry() {
		return this.poaAgreementExpiry;
	}

	/**
	 */
	public void setPoaNumber(String poaNumber) {
		this.poaNumber = poaNumber;
	}

	/**
	 */
	public String getPoaNumber() {
		return this.poaNumber;
	}

	/**
	 */
	public void setPoaPropertyAuthority(String poaPropertyAuthority) {
		this.poaPropertyAuthority = poaPropertyAuthority;
	}

	/**
	 */
	public String getPoaPropertyAuthority() {
		return this.poaPropertyAuthority;
	}

	/**
	 */
	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	/**
	 */
	public String getPobox() {
		return this.pobox;
	}

	/**
	 */
	public void setPropertyDocument1Upload(String propertyDocument1Upload) {
		this.propertyDocument1Upload = propertyDocument1Upload;
	}

	/**
	 */
	public String getPropertyDocument1Upload() {
		return this.propertyDocument1Upload;
	}

	/**
	 */
	public void setPropertyDocument2Upload(String propertyDocument2Upload) {
		this.propertyDocument2Upload = propertyDocument2Upload;
	}

	/**
	 */
	public String getPropertyDocument2Upload() {
		return this.propertyDocument2Upload;
	}

	/**
	 */
	public void setPropertyDocument3Upload(String propertyDocument3Upload) {
		this.propertyDocument3Upload = propertyDocument3Upload;
	}

	/**
	 */
	public String getPropertyDocument3Upload() {
		return this.propertyDocument3Upload;
	}

	/**
	 */
	public void setPropertyDocument4Upload(String propertyDocument4Upload) {
		this.propertyDocument4Upload = propertyDocument4Upload;
	}

	/**
	 */
	public String getPropertyDocument4Upload() {
		return this.propertyDocument4Upload;
	}

	/**
	 */
	public void setScannedIdCopy(String scannedIdCopy) {
		this.scannedIdCopy = scannedIdCopy;
	}

	/**
	 */
	public String getScannedIdCopy() {
		return this.scannedIdCopy;
	}

	/**
	 */
	public void setScannedNotorizedCopy(String scannedNotorizedCopy) {
		this.scannedNotorizedCopy = scannedNotorizedCopy;
	}

	/**
	 */
	public String getScannedNotorizedCopy() {
		return this.scannedNotorizedCopy;
	}

	/**
	 */
	public void setSellerProfilepic(String sellerProfilepic) {
		this.sellerProfilepic = sellerProfilepic;
	}

	/**
	 */
	public String getSellerProfilepic() {
		return this.sellerProfilepic;
	}

	/**
	 */
	public void setSpecificProperty(String specificProperty) {
		this.specificProperty = specificProperty;
	}

	/**
	 */
	public String getSpecificProperty() {
		return this.specificProperty;
	}

	/**
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 */
	public String getTelephone() {
		return this.telephone;
	}

	/**
	 */
	public void setTitleDeedUpload(String titleDeedUpload) {
		this.titleDeedUpload = titleDeedUpload;
	}

	/**
	 */
	public String getTitleDeedUpload() {
		return this.titleDeedUpload;
	}

	/**
	 */
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	/**
	 */
	public Integer getPropertyId() {
		return this.propertyId;
	}

	/**
	 */
	public PropertysellerdetailsAuditDTO() {
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getRevDate() {
		return revDate;
	}

	public void setRevDate(Date revDate) {
		this.revDate = revDate;
	}

	public String getOtherDocument() {
		return otherDocument;
	}

	public void setOtherDocument(String otherDocument) {
		this.otherDocument = otherDocument;
	}

	
}
