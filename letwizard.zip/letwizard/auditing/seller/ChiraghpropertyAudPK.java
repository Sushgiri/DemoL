
package com.bestercapitalmedia.letwizard.auditing.seller;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class ChiraghpropertyAudPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public ChiraghpropertyAudPK() {
	}

	/**
	 */

	@Column(name = "property_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	public Integer propertyId;
	/**
	 */

	@Column(name = "REVISION_ID", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	public Integer revisionId;

	/**
	 */
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	/**
	 */
	public Integer getPropertyId() {
		return this.propertyId;
	}

	/**
	 */
	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	/**
	 */
	public Integer getRevisionId() {
		return this.revisionId;
	}

	/**
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (int) (prime * result + ((propertyId == null) ? 0 : propertyId.hashCode()));
		result = (int) (prime * result + ((revisionId == null) ? 0 : revisionId.hashCode()));
		return result;
	}

	/**
	 */
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if (!(obj instanceof ChiraghpropertyAudPK))
			return false;
		ChiraghpropertyAudPK equalCheck = (ChiraghpropertyAudPK) obj;
		if ((propertyId == null && equalCheck.propertyId != null) || (propertyId != null && equalCheck.propertyId == null))
			return false;
		if (propertyId != null && !propertyId.equals(equalCheck.propertyId))
			return false;
		if ((revisionId == null && equalCheck.revisionId != null) || (revisionId != null && equalCheck.revisionId == null))
			return false;
		if (revisionId != null && !revisionId.equals(equalCheck.revisionId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("ChiraghpropertyAudPK");
		sb.append(" propertyId: ").append(getPropertyId());
		sb.append(" revisionId: ").append(getRevisionId());
		return sb.toString();
	}
}
