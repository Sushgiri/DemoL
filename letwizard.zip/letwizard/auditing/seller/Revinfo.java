
package com.bestercapitalmedia.letwizard.auditing.seller;

import java.io.Serializable;

/**
 */

//@Entity
//@Table(name = "revinfo")
public class Revinfo implements Serializable {
	private static final long serialVersionUID = 1L;
//
//	/**
//	 */
//
//	@Column(name = "REV", nullable = false)
//	@Basic(fetch = FetchType.EAGER)
//
//	@Id
//	
//	Integer rev;
//	/**
//	 */
//
//	@Column(name = "REVTSTMP")
//	@Basic(fetch = FetchType.EAGER)
//
//	
//	Integer revtstmp;
//
//	/**
//	 */
////	@OneToMany(mappedBy = "revinfo", fetch = FetchType.LAZY)
////	java.util.Set<ChiraghpropertyAud> chiraghpropertyAuds;
//	/**
//	 */
//	@OneToMany(mappedBy = "revinfo", fetch = FetchType.LAZY)
//
//	
//	java.util.Set<PropertysellerdetailsAud> propertysellerdetailsAuds;
//
//	/**
//	 */
//	public void setRev(Integer rev) {
//		this.rev = rev;
//	}
//
//	/**
//	 */
//	public Integer getRev() {
//		return this.rev;
//	}
//
//	/**
//	 */
//	public void setRevtstmp(Integer revtstmp) {
//		this.revtstmp = revtstmp;
//	}
//
//	/**
//	 */
//	public Integer getRevtstmp() {
//		return this.revtstmp;
//	}


	
}
