
package com.bestercapitalmedia.letwizard.auditing.seller;

import java.io.Serializable;

import javax.persistence.Id;

import javax.persistence.*;

/**
 */
public class PropertysellerdetailsAudPK implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */
	public PropertysellerdetailsAudPK() {
	}

	/**
	 */

	@Column(name = "property_Seller_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	public Integer sellerId;
	/**
	 */

	@Column(name = "REVISION_ID", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	public Integer revisionId;

	/**
	 */
	

	/**
	 */
	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	/**
	 */
	public Integer getRevisionId() {
		return this.revisionId;
	}

	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	
}
