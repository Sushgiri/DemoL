
package com.bestercapitalmedia.letwizard.auditing.seller;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

/**
 */
@IdClass(com.bestercapitalmedia.letwizard.auditing.seller.ChiraghpropertyAudPK.class)
@Entity
@Table(name = "chiraghproperty_aud")
public class ChiraghpropertyAud implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "property_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	
	Integer propertyId;
	/**
	 */

	@Column(name = "REVISION_ID", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	
	Integer revisionId;
	/**
	 */

	@Column(name = "REVISION_TYPE")
	@Basic(fetch = FetchType.EAGER)

	
	Boolean revisionType;
	/**
	 */

	@Column(name = "action_Performed_By", length = 200)
	@Basic(fetch = FetchType.EAGER)

	
	String actionPerformedBy;
	/**
	 */

	@Column(name = "address")
	@Basic(fetch = FetchType.EAGER)

	
	String address;
	/**
	 */

	@Column(name = "agree_Vat_Commission")
	@Basic(fetch = FetchType.EAGER)

	
	Integer agreeVatCommission;
	/**
	 */

	@Column(name = "amount", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal amount;
	/**
	 */

	@Column(name = "area", length = 300)
	@Basic(fetch = FetchType.EAGER)

	
	String area;
	/**
	 */

	@Column(name = "area_Permit_No", length = 50)
	@Basic(fetch = FetchType.EAGER)

	
	String areaPermitNo;
	/**
	 */

	@Column(name = "area_Unit", length = 100)
	@Basic(fetch = FetchType.EAGER)

	
	String areaUnit;
	/**
	 */

	@Column(name = "asking_Price", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal askingPrice;
	/**
	 */

	@Column(name = "auction_Status")
	@Basic(fetch = FetchType.EAGER)

	
	String auctionStatus;
	/**
	 */

	@Column(name = "balance_Amount", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal balanceAmount;
	/**
	 */

	@Column(name = "balcony", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String balcony;
	/**
	 */

	@Column(name = "bank", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String bank;
	/**
	 */

	@Column(name = "bank_atm_Facility", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String bankAtmFacility;
	/**
	 */

	@Column(name = "bank_Other")
	@Basic(fetch = FetchType.EAGER)

	
	String bankOther;
	/**
	 */

	@Column(name = "basement_Parking", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String basementParking;
	/**
	 */

	@Column(name = "basketball_Court", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String basketballCourt;
	/**
	 */

	@Column(name = "bbq_Area", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String bbqArea;
	/**
	 */

	@Column(name = "beach_Access", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String beachAccess;
	/**
	 */

	@Column(name = "beaches", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String beaches;
	/**
	 */

	@Column(name = "broadband_Ready", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String broadbandReady;
	/**
	 */

	@Column(name = "brokerage_Assign_To")
	@Basic(fetch = FetchType.EAGER)

	
	String brokerageAssignTo;
	/**
	 */

	@Column(name = "brokerage_Report_Copy")
	@Basic(fetch = FetchType.EAGER)

	
	String brokerageReportCopy;
	/**
	 */

	@Column(name = "built_In_Wardrobes", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String builtInWardrobes;
	/**
	 */

	@Column(name = "buliding_Name")
	@Basic(fetch = FetchType.EAGER)

	
	String bulidingName;
	/**
	 */

	@Column(name = "buliding_Number")
	@Basic(fetch = FetchType.EAGER)

	
	String bulidingNumber;
	/**
	 */

	@Column(name = "bus_Services", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String busServices;
	/**
	 */

	@Column(name = "business_Center", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String businessCenter;
	/**
	 */

	@Column(name = "car_Parks")
	@Basic(fetch = FetchType.EAGER)

	
	Integer carParks;
	/**
	 */

	@Column(name = "carpets", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String carpets;
	/**
	 */

	@Column(name = "central_Air_Conditioning", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String centralAirConditioning;
	/**
	 */

	@Column(name = "central_Heating", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String centralHeating;
	/**
	 */

	@Column(name = "childrens_Nursery", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String childrensNursery;
	/**
	 */

	@Column(name = "childrens_Play_Area", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String childrensPlayArea;
	/**
	 */

	@Column(name = "clubhouse", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String clubhouse;
	/**
	 */

	@Column(name = "communal_Gardens", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String communalGardens;
	/**
	 */

	@Column(name = "community_No", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String communityNo;
	/**
	 */

	@Column(name = "community_View", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String communityView;
	/**
	 */

	@Column(name = "concierge_Service", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String conciergeService;
	/**
	 */

	@Column(name = "covered_Parking", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String coveredParking;
	/**
	 */

	@Column(name = "cycling_Tracks", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String cyclingTracks;
	/**
	 */
	
	@Column(name = "Date")
	@Basic(fetch = FetchType.EAGER)

	
	Calendar date;
	/**
	 */
	
	@Column(name = "date_Received")
	@Basic(fetch = FetchType.EAGER)

	
	Calendar dateReceived;
	/**
	 */

	@Column(name = "driver_Room", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String driverRoom;
	/**
	 */

	@Column(name = "fitness_Center", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String fitnessCenter;
	/**
	 */

	@Column(name = "floor_No")
	@Basic(fetch = FetchType.EAGER)

	
	Integer floorNo;
	/**
	 */

	@Column(name = "floor_Plan_Upload")
	@Basic(fetch = FetchType.EAGER)

	
	String floorPlanUpload;
	/**
	 */

	@Column(name = "fully_Fitted_Kitchen", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String fullyFittedKitchen;
	/**
	 */

	@Column(name = "fully_Furnished", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String fullyFurnished;
	/**
	 */

	@Column(name = "gazebo_And_Outdoor_Entertaining_Area", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String gazeboAndOutdoorEntertainingArea;
	/**
	 */

	@Column(name = "golf_Club_And_Clubhouse", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String golfClubAndClubhouse;
	/**
	 */

	@Column(name = "gross_Area")
	@Basic(fetch = FetchType.EAGER)

	
	String grossArea;
	/**
	 */

	@Column(name = "gymnasium", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String gymnasium;
	/**
	 */

	@Column(name = "Hours24_Maintenance", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String hours24Maintenance;
	/**
	 */

	@Column(name = "intercom", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String intercom;
	/**
	 */

	@Column(name = "is_Acknowledgement_Call", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String isAcknowledgementCall;
	/**
	 */

	@Column(name = "is_Brokerage_Completed")
	@Basic(fetch = FetchType.EAGER)

	
	String isBrokerageCompleted;
	/**
	 */

	@Column(name = "is_Brokerage_Hod_Approved")
	@Basic(fetch = FetchType.EAGER)

	
	String isBrokerageHodApproved;
	/**
	 */

	@Column(name = "is_Brokerage_Report_Uploaded")
	@Basic(fetch = FetchType.EAGER)

	
	String isBrokerageReportUploaded;
	/**
	 */

	@Column(name = "is_Md_Approved")
	@Basic(fetch = FetchType.EAGER)

	
	Integer isMdApproved;
	/**
	 */

	@Column(name = "is_Mortgage")
	@Basic(fetch = FetchType.EAGER)

	
	Integer isMortgage;
	/**
	 */

	@Column(name = "is_Personal_Details_Verified", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String isPersonalDetailsVerified;
	/**
	 */

	@Column(name = "is_POA_Details_Verified", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String isPoaDetailsVerified;
	/**
	 */

	@Column(name = "is_Property_Details_Verified", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String isPropertyDetailsVerified;
	/**
	 */

	@Column(name = "is_Property_Financial_Details_Verified", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String isPropertyFinancialDetailsVerified;
	/**
	 */

	@Column(name = "is_Property_Rental_Details_Verified", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String isPropertyRentalDetailsVerified;
	/**
	 */

	@Column(name = "is_Published")
	@Basic(fetch = FetchType.EAGER)

	
	Integer isPublished;
	/**
	 */

	@Column(name = "is_Rented", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String isRented;
	/**
	 */

	@Column(name = "is_Third_Party_Payment", length = 10)
	@Basic(fetch = FetchType.EAGER)

	
	String isThirdPartyPayment;
	/**
	 */

	@Column(name = "is_Third_Party_Valuation_Completed")
	@Basic(fetch = FetchType.EAGER)

	
	String isThirdPartyValuationCompleted;
	/**
	 */

	@Column(name = "is_Vacant", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String isVacant;
	/**
	 */

	@Column(name = "is_Valuation_Completed")
	@Basic(fetch = FetchType.EAGER)

	
	String isValuationCompleted;
	/**
	 */

	@Column(name = "is_Valuation_Hod_Approved")
	@Basic(fetch = FetchType.EAGER)

	
	String isValuationHodApproved;
	/**
	 */

	@Column(name = "is_Valuation_Report_Uploaded")
	@Basic(fetch = FetchType.EAGER)

	
	String isValuationReportUploaded;
	/**
	 */

	@Column(name = "is_Verification_Hod_Approved")
	@Basic(fetch = FetchType.EAGER)

	
	String isVerificationHodApproved;
	/**
	 */

	@Column(name = "is_Watched_List")
	@Basic(fetch = FetchType.EAGER)

	
	String isWatchedList;
	/**
	 */

	@Column(name = "jacuzzi", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String jacuzzi;
	/**
	 */

	@Column(name = "kitchen_White_Goods", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String kitchenWhiteGoods;
	/**
	 */

	@Column(name = "kitchens")
	@Basic(fetch = FetchType.EAGER)

	
	Integer kitchens;
	/**
	 */

	@Column(name = "landscaped_Garden", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String landscapedGarden;
	/**
	 */
	
	@Column(name = "last_Action")
	@Basic(fetch = FetchType.EAGER)

	
	Calendar lastAction;
	/**
	 */

	@Column(name = "last_Action_Performed", length = 100)
	@Basic(fetch = FetchType.EAGER)

	
	String lastActionPerformed;
	/**
	 */

	@Column(name = "laundry_Service", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String laundryService;
	/**
	 */

	@Column(name = "laundry_WashingRoom", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String laundryWashingRoom;
	/**
	 */

	@Column(name = "laundry_washing_Room", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String laundryWashingRoom_1;
	/**
	 */
	
	@Column(name = "lease_Expiry_Date")
	@Basic(fetch = FetchType.EAGER)

	
	Calendar leaseExpiryDate;
	/**
	 */
	
	@Column(name = "lease_Start_Date")
	@Basic(fetch = FetchType.EAGER)

	
	Calendar leaseStartDate;
	/**
	 */

	@Column(name = "listed_Price", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal listedPrice;
	/**
	 */

	@Column(name = "location")
	@Basic(fetch = FetchType.EAGER)

	
	String location;
	/**
	 */

	@Column(name = "maid_Room", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String maidRoom;
	/**
	 */

	@Column(name = "map_Location")
	@Basic(fetch = FetchType.EAGER)

	
	String mapLocation;
	/**
	 */

	@Column(name = "marble_Floors", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String marbleFloors;
	/**
	 */

	@Column(name = "marina_Berth", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String marinaBerth;
	/**
	 */

	@Column(name = "medical_Centers", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String medicalCenters;
	/**
	 */

	@Column(name = "metro_Station", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String metroStation;
	/**
	 */

	@Column(name = "metros", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String metros;
	/**
	 */

	@Column(name = "morgage_Amount", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal morgageAmount;
	/**
	 */

	@Column(name = "morgage_Noc", length = 500)
	@Basic(fetch = FetchType.EAGER)

	
	String morgageNoc;
	/**
	 */

	@Column(name = "morgage_Reg_No", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String morgageRegNo;
	/**
	 */

	@Column(name = "morgage_Status", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String morgageStatus;
	/**
	 */

	@Column(name = "mortage_Bank", length = 45)
	@Basic(fetch = FetchType.EAGER)

	
	String mortageBank;
	/**
	 */

	@Column(name = "mortgage_Value", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal mortgageValue;
	/**
	 */

	@Column(name = "mortgage_Year")
	@Basic(fetch = FetchType.EAGER)

	
	Integer mortgageYear;
	/**
	 */

	@Column(name = "mosque", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String mosque;
	/**
	 */

	@Column(name = "mosques_In_Neighbourhood", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String mosquesInNeighbourhood;
	/**
	 */

	@Column(name = "net_Area")
	@Basic(fetch = FetchType.EAGER)

	
	String netArea;
	/**
	 */

	@Column(name = "no_Of_Baths")
	@Basic(fetch = FetchType.EAGER)

	
	Integer noOfBaths;
	/**
	 */

	@Column(name = "no_Of_Bedrooms")
	@Basic(fetch = FetchType.EAGER)

	
	Integer noOfBedrooms;
	/**
	 */

	@Column(name = "no_Of_Floors")
	@Basic(fetch = FetchType.EAGER)

	
	Integer noOfFloors;
	/**
	 */

	@Column(name = "no_Shops")
	@Basic(fetch = FetchType.EAGER)

	
	Integer noShops;
	/**
	 */

	@Column(name = "no_Units")
	@Basic(fetch = FetchType.EAGER)

	
	Integer noUnits;
	/**
	 */

	@Column(name = "on_High_Floor", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String onHighFloor;
	/**
	 */

	@Column(name = "on_Low_Floor", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String onLowFloor;
	/**
	 */

	@Column(name = "on_Mid_Floor", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String onMidFloor;
	/**
	 */

	@Column(name = "original_Price", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal originalPrice;
	/**
	 */

	@Column(name = "owner_Association_No")
	@Basic(fetch = FetchType.EAGER)

	
	String ownerAssociationNo;
	/**
	 */

	@Column(name = "paid_Amount", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal paidAmount;
	/**
	 */

	@Column(name = "park", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String park;
	/**
	 */

	@Column(name = "part_Furnished", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String partFurnished;
	/**
	 */

	@Column(name = "payment_Schedule", length = 50)
	@Basic(fetch = FetchType.EAGER)

	
	String paymentSchedule;
	/**
	 */

	@Column(name = "payment_Structure", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String paymentStructure;
	/**
	 */

	@Column(name = "pets_Allowed", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String petsAllowed;
	/**
	 */

	@Column(name = "plot_No")
	@Basic(fetch = FetchType.EAGER)

	
	String plotNo;
	/**
	 */

	@Column(name = "polo_Club_And_Clubhouse", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String poloClubAndClubhouse;
	/**
	 */

	@Column(name = "pre_Closure_Charges", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal preClosureCharges;
	/**
	 */

	@Column(name = "present_Use", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String presentUse;
	/**
	 */

	@Column(name = "price")
	@Basic(fetch = FetchType.EAGER)

	
	String price;
	/**
	 */

	@Column(name = "price_Per_Sqft", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal pricePerSqft;
	/**
	 */

	@Column(name = "private_Garage", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String privateGarage;
	/**
	 */

	@Column(name = "private_Garden", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String privateGarden;
	/**
	 */

	@Column(name = "private_Swimming_Pool", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String privateSwimmingPool;
	/**
	 */

	@Column(name = "project_Name")
	@Basic(fetch = FetchType.EAGER)

	
	String projectName;
	/**
	 */

	@Column(name = "property_Age", length = 50)
	@Basic(fetch = FetchType.EAGER)

	
	String propertyAge;
	/**
	 */

	@Column(name = "property_Description", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)
	

	
	String propertyDescription;
	/**
	 */

	@Column(name = "property_No", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String propertyNo;
	/**
	 */

	@Column(name = "property_Reference_No", length = 500)
	@Basic(fetch = FetchType.EAGER)

	
	String propertyReferenceNo;
	/**
	 */

	@Column(name = "property_Status", length = 250)
	@Basic(fetch = FetchType.EAGER)

	
	String propertyStatus;
	/**
	 */

	@Column(name = "property_Status_Other")
	@Basic(fetch = FetchType.EAGER)

	
	String propertyStatusOther;
	/**
	 */

	@Column(name = "property_Title", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)
	

	
	String propertyTitle;
	/**
	 */

	@Column(name = "property_Type", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String propertyType;
	/**
	 */

	@Column(name = "public_Park", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String publicPark;
	/**
	 */

	@Column(name = "public_Parking", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String publicParking;
	/**
	 */

	@Column(name = "public_Transport", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String publicTransport;
	/**
	 */

	@Column(name = "recreational_Facilities", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String recreationalFacilities;
	/**
	 */

	@Column(name = "rental_Annual_Rent", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal rentalAnnualRent;
	/**
	 */

	@Column(name = "rental_Ejari_No")
	@Basic(fetch = FetchType.EAGER)

	
	Integer rentalEjariNo;
	/**
	 */
	
	@Column(name = "rental_Expiry_Date")
	@Basic(fetch = FetchType.EAGER)

	
	Calendar rentalExpiryDate;
	/**
	 */

	@Column(name = "rental_Payment_Checks")
	@Basic(fetch = FetchType.EAGER)

	
	Integer rentalPaymentChecks;
	/**
	 */

	@Column(name = "restaurants", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String restaurants;
	/**
	 */

	@Column(name = "satellite_Cable_TV", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String satelliteCableTv;
	/**
	 */

	@Column(name = "sauna", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String sauna;
	/**
	 */

	@Column(name = "scanned_Title_Deed", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)
	

	
	String scannedTitleDeed;
	/**
	 */

	@Column(name = "school")
	@Basic(fetch = FetchType.EAGER)

	
	String school;
	/**
	 */

	@Column(name = "schools_In_Neighbourhood", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String schoolsInNeighbourhood;
	/**
	 */

	@Column(name = "seller_User_Name", length = 200)
	@Basic(fetch = FetchType.EAGER)

	
	String sellerUserName;
	/**
	 */

	@Column(name = "service_Charge", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal serviceCharge;
	/**
	 */

	@Column(name = "shared_Swimming_Pool", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String sharedSwimmingPool;
	/**
	 */

	@Column(name = "shopping_Mall")
	@Basic(fetch = FetchType.EAGER)

	
	String shoppingMall;
	/**
	 */

	@Column(name = "shopping_Malls", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String shoppingMalls;
	/**
	 */

	@Column(name = "shops")
	@Basic(fetch = FetchType.EAGER)

	
	String shops;
	/**
	 */

	@Column(name = "size_Per_Sqft", precision = 12)
	@Basic(fetch = FetchType.EAGER)

	
	BigDecimal sizePerSqft;
	/**
	 */

	@Column(name = "solid_Wood_Floors", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String solidWoodFloors;
	/**
	 */

	@Column(name = "sports_Academies", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String sportsAcademies;
	/**
	 */

	@Column(name = "squash_Courts")
	@Basic(fetch = FetchType.EAGER)

	
	String squashCourts;
	/**
	 */

	@Column(name = "status", length = 200)
	@Basic(fetch = FetchType.EAGER)

	
	String status;
	/**
	 */

	@Column(name = "steam_Room", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String steamRoom;
	/**
	 */

	@Column(name = "storage_Room", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String storageRoom;
	/**
	 */

	@Column(name = "study", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String study;
	/**
	 */

	@Column(name = "supermarkets", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String supermarkets;
	/**
	 */

	@Column(name = "tenancy_Contract_Upload", length = 500)
	@Basic(fetch = FetchType.EAGER)

	
	String tenancyContractUpload;
	/**
	 */

	@Column(name = "tenant_Name")
	@Basic(fetch = FetchType.EAGER)

	
	String tenantName;
	/**
	 */

	@Column(name = "tennis_Courts")
	@Basic(fetch = FetchType.EAGER)

	
	String tennisCourts;
	/**
	 */

	@Column(name = "third_Party_Verification", length = 10)
	@Basic(fetch = FetchType.EAGER)

	
	String thirdPartyVerification;
	/**
	 */

	@Column(name = "title_Deed_No")
	@Basic(fetch = FetchType.EAGER)

	
	String titleDeedNo;
	/**
	 */

	@Column(name = "type_Area")
	@Basic(fetch = FetchType.EAGER)

	
	String typeArea;
	/**
	 */

	@Column(name = "type_Property_Other")
	@Basic(fetch = FetchType.EAGER)

	
	String typePropertyOther;
	/**
	 */

	@Column(name = "upgraded_Interior", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String upgradedInterior;
	/**
	 */

	@Column(name = "valet_Service")
	@Basic(fetch = FetchType.EAGER)

	
	String valetService;
	/**
	 */

	@Column(name = "valuation_Assign_To")
	@Basic(fetch = FetchType.EAGER)

	
	String valuationAssignTo;
	/**
	 */

	@Column(name = "valuation_Hod_Approved")
	@Basic(fetch = FetchType.EAGER)

	
	Integer valuationHodApproved;
	/**
	 */

	@Column(name = "valuation_Report_Copy")
	@Basic(fetch = FetchType.EAGER)

	
	String valuationReportCopy;
	/**
	 */

	@Column(name = "valuation_Report_Document", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String valuationReportDocument;
	/**
	 */

	@Column(name = "verification_Hod_Approved", length = 10)
	@Basic(fetch = FetchType.EAGER)

	
	String verificationHodApproved;
	/**
	 */

	@Column(name = "view_Of_Gardens", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String viewOfGardens;
	/**
	 */

	@Column(name = "view_Of_Golfcourse", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String viewOfGolfcourse;
	/**
	 */

	@Column(name = "view_Of_Parkland", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String viewOfParkland;
	/**
	 */

	@Column(name = "view_Of_Sea_Water", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String viewOfSeaWater;
	/**
	 */

	@Column(name = "walking_Trails", length = 25)
	@Basic(fetch = FetchType.EAGER)

	
	String walkingTrails;
	/**
	 */

	@Column(name = "developer_Name", length = 405)
	@Basic(fetch = FetchType.EAGER)

	
	String developerName;
	/**
	 */

	@Column(name = "third_Party_Report_Copy", length = 200)
	@Basic(fetch = FetchType.EAGER)

	
	String thirdPartyReportCopy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "REVISION_ID", referencedColumnName = "id", nullable = false, insertable = false, updatable = false) })
	@JsonBackReference
	MyRevision myrevision;

	/**
	 */
	@Column(name = "created_At")
	@Basic(fetch = FetchType.EAGER)
	Date createdAt;
	
	@Column(name = "updated_At")
	@Basic(fetch = FetchType.EAGER)
	Date updatedAt;
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	/**
	 */
	public Integer getPropertyId() {
		return this.propertyId;
	}

	/**
	 */
	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	/**
	 */
	public Integer getRevisionId() {
		return this.revisionId;
	}

	/**
	 */
	public void setRevisionType(Boolean revisionType) {
		this.revisionType = revisionType;
	}

	/**
	 */
	public Boolean getRevisionType() {
		return this.revisionType;
	}

	/**
	 */
	public void setActionPerformedBy(String actionPerformedBy) {
		this.actionPerformedBy = actionPerformedBy;
	}

	/**
	 */
	public String getActionPerformedBy() {
		return this.actionPerformedBy;
	}

	/**
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 */
	public void setAgreeVatCommission(Integer agreeVatCommission) {
		this.agreeVatCommission = agreeVatCommission;
	}

	/**
	 */
	public Integer getAgreeVatCommission() {
		return this.agreeVatCommission;
	}

	/**
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 */
	public BigDecimal getAmount() {
		return this.amount;
	}

	/**
	 */
	public void setArea(String area) {
		this.area = area;
	}

	/**
	 */
	public String getArea() {
		return this.area;
	}

	/**
	 */
	public void setAreaPermitNo(String areaPermitNo) {
		this.areaPermitNo = areaPermitNo;
	}

	/**
	 */
	public String getAreaPermitNo() {
		return this.areaPermitNo;
	}

	/**
	 */
	public void setAreaUnit(String areaUnit) {
		this.areaUnit = areaUnit;
	}

	/**
	 */
	public String getAreaUnit() {
		return this.areaUnit;
	}

	/**
	 */
	public void setAskingPrice(BigDecimal askingPrice) {
		this.askingPrice = askingPrice;
	}

	/**
	 */
	public BigDecimal getAskingPrice() {
		return this.askingPrice;
	}

	/**
	 */
	public void setAuctionStatus(String auctionStatus) {
		this.auctionStatus = auctionStatus;
	}

	/**
	 */
	public String getAuctionStatus() {
		return this.auctionStatus;
	}

	/**
	 */
	public void setBalanceAmount(BigDecimal balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	/**
	 */
	public BigDecimal getBalanceAmount() {
		return this.balanceAmount;
	}

	/**
	 */
	public void setBalcony(String balcony) {
		this.balcony = balcony;
	}

	/**
	 */
	public String getBalcony() {
		return this.balcony;
	}

	/**
	 */
	public void setBank(String bank) {
		this.bank = bank;
	}

	/**
	 */
	public String getBank() {
		return this.bank;
	}

	/**
	 */
	public void setBankAtmFacility(String bankAtmFacility) {
		this.bankAtmFacility = bankAtmFacility;
	}

	/**
	 */
	public String getBankAtmFacility() {
		return this.bankAtmFacility;
	}

	/**
	 */
	public void setBankOther(String bankOther) {
		this.bankOther = bankOther;
	}

	/**
	 */
	public String getBankOther() {
		return this.bankOther;
	}

	/**
	 */
	public void setBasementParking(String basementParking) {
		this.basementParking = basementParking;
	}

	/**
	 */
	public String getBasementParking() {
		return this.basementParking;
	}

	/**
	 */
	public void setBasketballCourt(String basketballCourt) {
		this.basketballCourt = basketballCourt;
	}

	/**
	 */
	public String getBasketballCourt() {
		return this.basketballCourt;
	}

	/**
	 */
	public void setBbqArea(String bbqArea) {
		this.bbqArea = bbqArea;
	}

	/**
	 */
	public String getBbqArea() {
		return this.bbqArea;
	}

	/**
	 */
	public void setBeachAccess(String beachAccess) {
		this.beachAccess = beachAccess;
	}

	/**
	 */
	public String getBeachAccess() {
		return this.beachAccess;
	}

	/**
	 */
	public void setBeaches(String beaches) {
		this.beaches = beaches;
	}

	/**
	 */
	public String getBeaches() {
		return this.beaches;
	}

	/**
	 */
	public void setBroadbandReady(String broadbandReady) {
		this.broadbandReady = broadbandReady;
	}

	/**
	 */
	public String getBroadbandReady() {
		return this.broadbandReady;
	}

	/**
	 */
	public void setBrokerageAssignTo(String brokerageAssignTo) {
		this.brokerageAssignTo = brokerageAssignTo;
	}

	/**
	 */
	public String getBrokerageAssignTo() {
		return this.brokerageAssignTo;
	}

	/**
	 */
	public void setBrokerageReportCopy(String brokerageReportCopy) {
		this.brokerageReportCopy = brokerageReportCopy;
	}

	/**
	 */
	public String getBrokerageReportCopy() {
		return this.brokerageReportCopy;
	}

	/**
	 */
	public void setBuiltInWardrobes(String builtInWardrobes) {
		this.builtInWardrobes = builtInWardrobes;
	}

	/**
	 */
	public String getBuiltInWardrobes() {
		return this.builtInWardrobes;
	}

	/**
	 */
	public void setBulidingName(String bulidingName) {
		this.bulidingName = bulidingName;
	}

	/**
	 */
	public String getBulidingName() {
		return this.bulidingName;
	}

	/**
	 */
	public void setBulidingNumber(String bulidingNumber) {
		this.bulidingNumber = bulidingNumber;
	}

	/**
	 */
	public String getBulidingNumber() {
		return this.bulidingNumber;
	}

	/**
	 */
	public void setBusServices(String busServices) {
		this.busServices = busServices;
	}

	/**
	 */
	public String getBusServices() {
		return this.busServices;
	}

	/**
	 */
	public void setBusinessCenter(String businessCenter) {
		this.businessCenter = businessCenter;
	}

	/**
	 */
	public String getBusinessCenter() {
		return this.businessCenter;
	}

	/**
	 */
	public void setCarParks(Integer carParks) {
		this.carParks = carParks;
	}

	/**
	 */
	public Integer getCarParks() {
		return this.carParks;
	}

	/**
	 */
	public void setCarpets(String carpets) {
		this.carpets = carpets;
	}

	/**
	 */
	public String getCarpets() {
		return this.carpets;
	}

	/**
	 */
	public void setCentralAirConditioning(String centralAirConditioning) {
		this.centralAirConditioning = centralAirConditioning;
	}

	/**
	 */
	public String getCentralAirConditioning() {
		return this.centralAirConditioning;
	}

	/**
	 */
	public void setCentralHeating(String centralHeating) {
		this.centralHeating = centralHeating;
	}

	/**
	 */
	public String getCentralHeating() {
		return this.centralHeating;
	}

	/**
	 */
	public void setChildrensNursery(String childrensNursery) {
		this.childrensNursery = childrensNursery;
	}

	/**
	 */
	public String getChildrensNursery() {
		return this.childrensNursery;
	}

	/**
	 */
	public void setChildrensPlayArea(String childrensPlayArea) {
		this.childrensPlayArea = childrensPlayArea;
	}

	/**
	 */
	public String getChildrensPlayArea() {
		return this.childrensPlayArea;
	}

	/**
	 */
	public void setClubhouse(String clubhouse) {
		this.clubhouse = clubhouse;
	}

	/**
	 */
	public String getClubhouse() {
		return this.clubhouse;
	}

	/**
	 */
	public void setCommunalGardens(String communalGardens) {
		this.communalGardens = communalGardens;
	}

	/**
	 */
	public String getCommunalGardens() {
		return this.communalGardens;
	}

	/**
	 */
	public void setCommunityNo(String communityNo) {
		this.communityNo = communityNo;
	}

	/**
	 */
	public String getCommunityNo() {
		return this.communityNo;
	}

	/**
	 */
	public void setCommunityView(String communityView) {
		this.communityView = communityView;
	}

	/**
	 */
	public String getCommunityView() {
		return this.communityView;
	}

	/**
	 */
	public void setConciergeService(String conciergeService) {
		this.conciergeService = conciergeService;
	}

	/**
	 */
	public String getConciergeService() {
		return this.conciergeService;
	}

	/**
	 */
	public void setCoveredParking(String coveredParking) {
		this.coveredParking = coveredParking;
	}

	/**
	 */
	public String getCoveredParking() {
		return this.coveredParking;
	}

	/**
	 */
	public void setCyclingTracks(String cyclingTracks) {
		this.cyclingTracks = cyclingTracks;
	}

	/**
	 */
	public String getCyclingTracks() {
		return this.cyclingTracks;
	}

	/**
	 */
	public void setDate(Calendar date) {
		this.date = date;
	}

	/**
	 */
	public Calendar getDate() {
		return this.date;
	}

	/**
	 */
	public void setDateReceived(Calendar dateReceived) {
		this.dateReceived = dateReceived;
	}

	/**
	 */
	public Calendar getDateReceived() {
		return this.dateReceived;
	}

	/**
	 */
	public void setDriverRoom(String driverRoom) {
		this.driverRoom = driverRoom;
	}

	/**
	 */
	public String getDriverRoom() {
		return this.driverRoom;
	}

	/**
	 */
	public void setFitnessCenter(String fitnessCenter) {
		this.fitnessCenter = fitnessCenter;
	}

	/**
	 */
	public String getFitnessCenter() {
		return this.fitnessCenter;
	}

	/**
	 */
	public void setFloorNo(Integer floorNo) {
		this.floorNo = floorNo;
	}

	/**
	 */
	public Integer getFloorNo() {
		return this.floorNo;
	}

	/**
	 */
	public void setFloorPlanUpload(String floorPlanUpload) {
		this.floorPlanUpload = floorPlanUpload;
	}

	/**
	 */
	public String getFloorPlanUpload() {
		return this.floorPlanUpload;
	}

	/**
	 */
	public void setFullyFittedKitchen(String fullyFittedKitchen) {
		this.fullyFittedKitchen = fullyFittedKitchen;
	}

	/**
	 */
	public String getFullyFittedKitchen() {
		return this.fullyFittedKitchen;
	}

	/**
	 */
	public void setFullyFurnished(String fullyFurnished) {
		this.fullyFurnished = fullyFurnished;
	}

	/**
	 */
	public String getFullyFurnished() {
		return this.fullyFurnished;
	}

	/**
	 */
	public void setGazeboAndOutdoorEntertainingArea(String gazeboAndOutdoorEntertainingArea) {
		this.gazeboAndOutdoorEntertainingArea = gazeboAndOutdoorEntertainingArea;
	}

	/**
	 */
	public String getGazeboAndOutdoorEntertainingArea() {
		return this.gazeboAndOutdoorEntertainingArea;
	}

	/**
	 */
	public void setGolfClubAndClubhouse(String golfClubAndClubhouse) {
		this.golfClubAndClubhouse = golfClubAndClubhouse;
	}

	/**
	 */
	public String getGolfClubAndClubhouse() {
		return this.golfClubAndClubhouse;
	}

	/**
	 */
	public void setGrossArea(String grossArea) {
		this.grossArea = grossArea;
	}

	/**
	 */
	public String getGrossArea() {
		return this.grossArea;
	}

	/**
	 */
	public void setGymnasium(String gymnasium) {
		this.gymnasium = gymnasium;
	}

	/**
	 */
	public String getGymnasium() {
		return this.gymnasium;
	}

	/**
	 */
	public void setHours24Maintenance(String hours24Maintenance) {
		this.hours24Maintenance = hours24Maintenance;
	}

	/**
	 */
	public String getHours24Maintenance() {
		return this.hours24Maintenance;
	}

	/**
	 */
	public void setIntercom(String intercom) {
		this.intercom = intercom;
	}

	/**
	 */
	public String getIntercom() {
		return this.intercom;
	}

	/**
	 */
	public void setIsAcknowledgementCall(String isAcknowledgementCall) {
		this.isAcknowledgementCall = isAcknowledgementCall;
	}

	/**
	 */
	public String getIsAcknowledgementCall() {
		return this.isAcknowledgementCall;
	}

	/**
	 */
	public void setIsBrokerageCompleted(String isBrokerageCompleted) {
		this.isBrokerageCompleted = isBrokerageCompleted;
	}

	/**
	 */
	public String getIsBrokerageCompleted() {
		return this.isBrokerageCompleted;
	}

	/**
	 */
	public void setIsBrokerageHodApproved(String isBrokerageHodApproved) {
		this.isBrokerageHodApproved = isBrokerageHodApproved;
	}

	/**
	 */
	public String getIsBrokerageHodApproved() {
		return this.isBrokerageHodApproved;
	}

	/**
	 */
	public void setIsBrokerageReportUploaded(String isBrokerageReportUploaded) {
		this.isBrokerageReportUploaded = isBrokerageReportUploaded;
	}

	/**
	 */
	public String getIsBrokerageReportUploaded() {
		return this.isBrokerageReportUploaded;
	}

	/**
	 */
	public void setIsMdApproved(Integer isMdApproved) {
		this.isMdApproved = isMdApproved;
	}

	/**
	 */
	public Integer getIsMdApproved() {
		return this.isMdApproved;
	}

	/**
	 */
	public void setIsMortgage(Integer isMortgage) {
		this.isMortgage = isMortgage;
	}

	/**
	 */
	public Integer getIsMortgage() {
		return this.isMortgage;
	}

	/**
	 */
	public void setIsPersonalDetailsVerified(String isPersonalDetailsVerified) {
		this.isPersonalDetailsVerified = isPersonalDetailsVerified;
	}

	/**
	 */
	public String getIsPersonalDetailsVerified() {
		return this.isPersonalDetailsVerified;
	}

	/**
	 */
	public void setIsPoaDetailsVerified(String isPoaDetailsVerified) {
		this.isPoaDetailsVerified = isPoaDetailsVerified;
	}

	/**
	 */
	public String getIsPoaDetailsVerified() {
		return this.isPoaDetailsVerified;
	}

	/**
	 */
	public void setIsPropertyDetailsVerified(String isPropertyDetailsVerified) {
		this.isPropertyDetailsVerified = isPropertyDetailsVerified;
	}

	/**
	 */
	public String getIsPropertyDetailsVerified() {
		return this.isPropertyDetailsVerified;
	}

	/**
	 */
	public void setIsPropertyFinancialDetailsVerified(String isPropertyFinancialDetailsVerified) {
		this.isPropertyFinancialDetailsVerified = isPropertyFinancialDetailsVerified;
	}

	/**
	 */
	public String getIsPropertyFinancialDetailsVerified() {
		return this.isPropertyFinancialDetailsVerified;
	}

	/**
	 */
	public void setIsPropertyRentalDetailsVerified(String isPropertyRentalDetailsVerified) {
		this.isPropertyRentalDetailsVerified = isPropertyRentalDetailsVerified;
	}

	/**
	 */
	public String getIsPropertyRentalDetailsVerified() {
		return this.isPropertyRentalDetailsVerified;
	}

	/**
	 */
	public void setIsPublished(Integer isPublished) {
		this.isPublished = isPublished;
	}

	/**
	 */
	public Integer getIsPublished() {
		return this.isPublished;
	}

	/**
	 */
	public void setIsRented(String isRented) {
		this.isRented = isRented;
	}

	/**
	 */
	public String getIsRented() {
		return this.isRented;
	}

	/**
	 */
	public void setIsThirdPartyPayment(String isThirdPartyPayment) {
		this.isThirdPartyPayment = isThirdPartyPayment;
	}

	/**
	 */
	public String getIsThirdPartyPayment() {
		return this.isThirdPartyPayment;
	}

	/**
	 */
	public void setIsThirdPartyValuationCompleted(String isThirdPartyValuationCompleted) {
		this.isThirdPartyValuationCompleted = isThirdPartyValuationCompleted;
	}

	/**
	 */
	public String getIsThirdPartyValuationCompleted() {
		return this.isThirdPartyValuationCompleted;
	}

	/**
	 */
	public void setIsVacant(String isVacant) {
		this.isVacant = isVacant;
	}

	/**
	 */
	public String getIsVacant() {
		return this.isVacant;
	}

	/**
	 */
	public void setIsValuationCompleted(String isValuationCompleted) {
		this.isValuationCompleted = isValuationCompleted;
	}

	/**
	 */
	public String getIsValuationCompleted() {
		return this.isValuationCompleted;
	}

	/**
	 */
	public void setIsValuationHodApproved(String isValuationHodApproved) {
		this.isValuationHodApproved = isValuationHodApproved;
	}

	/**
	 */
	public String getIsValuationHodApproved() {
		return this.isValuationHodApproved;
	}

	/**
	 */
	public void setIsValuationReportUploaded(String isValuationReportUploaded) {
		this.isValuationReportUploaded = isValuationReportUploaded;
	}

	/**
	 */
	public String getIsValuationReportUploaded() {
		return this.isValuationReportUploaded;
	}

	/**
	 */
	public void setIsVerificationHodApproved(String isVerificationHodApproved) {
		this.isVerificationHodApproved = isVerificationHodApproved;
	}

	/**
	 */
	public String getIsVerificationHodApproved() {
		return this.isVerificationHodApproved;
	}

	/**
	 */
	public void setIsWatchedList(String isWatchedList) {
		this.isWatchedList = isWatchedList;
	}

	/**
	 */
	public String getIsWatchedList() {
		return this.isWatchedList;
	}

	/**
	 */
	public void setJacuzzi(String jacuzzi) {
		this.jacuzzi = jacuzzi;
	}

	/**
	 */
	public String getJacuzzi() {
		return this.jacuzzi;
	}

	/**
	 */
	public void setKitchenWhiteGoods(String kitchenWhiteGoods) {
		this.kitchenWhiteGoods = kitchenWhiteGoods;
	}

	/**
	 */
	public String getKitchenWhiteGoods() {
		return this.kitchenWhiteGoods;
	}

	/**
	 */
	public void setKitchens(Integer kitchens) {
		this.kitchens = kitchens;
	}

	/**
	 */
	public Integer getKitchens() {
		return this.kitchens;
	}

	/**
	 */
	public void setLandscapedGarden(String landscapedGarden) {
		this.landscapedGarden = landscapedGarden;
	}

	/**
	 */
	public String getLandscapedGarden() {
		return this.landscapedGarden;
	}

	/**
	 */
	public void setLastAction(Calendar lastAction) {
		this.lastAction = lastAction;
	}

	/**
	 */
	public Calendar getLastAction() {
		return this.lastAction;
	}

	/**
	 */
	public void setLastActionPerformed(String lastActionPerformed) {
		this.lastActionPerformed = lastActionPerformed;
	}

	/**
	 */
	public String getLastActionPerformed() {
		return this.lastActionPerformed;
	}

	/**
	 */
	public void setLaundryService(String laundryService) {
		this.laundryService = laundryService;
	}

	/**
	 */
	public String getLaundryService() {
		return this.laundryService;
	}

	/**
	 */
	public void setLaundryWashingRoom(String laundryWashingRoom) {
		this.laundryWashingRoom = laundryWashingRoom;
	}

	/**
	 */
	public String getLaundryWashingRoom() {
		return this.laundryWashingRoom;
	}

	/**
	 */
	public void setLaundryWashingRoom_1(String laundryWashingRoom_1) {
		this.laundryWashingRoom_1 = laundryWashingRoom_1;
	}

	/**
	 */
	public String getLaundryWashingRoom_1() {
		return this.laundryWashingRoom_1;
	}

	/**
	 */
	public void setLeaseExpiryDate(Calendar leaseExpiryDate) {
		this.leaseExpiryDate = leaseExpiryDate;
	}

	/**
	 */
	public Calendar getLeaseExpiryDate() {
		return this.leaseExpiryDate;
	}

	/**
	 */
	public void setLeaseStartDate(Calendar leaseStartDate) {
		this.leaseStartDate = leaseStartDate;
	}

	/**
	 */
	public Calendar getLeaseStartDate() {
		return this.leaseStartDate;
	}

	/**
	 */
	public void setListedPrice(BigDecimal listedPrice) {
		this.listedPrice = listedPrice;
	}

	/**
	 */
	public BigDecimal getListedPrice() {
		return this.listedPrice;
	}

	/**
	 */
	public void setLocation(String location) {
		this.location = location;
	}

	/**
	 */
	public String getLocation() {
		return this.location;
	}

	/**
	 */
	public void setMaidRoom(String maidRoom) {
		this.maidRoom = maidRoom;
	}

	/**
	 */
	public String getMaidRoom() {
		return this.maidRoom;
	}

	/**
	 */
	public void setMapLocation(String mapLocation) {
		this.mapLocation = mapLocation;
	}

	/**
	 */
	public String getMapLocation() {
		return this.mapLocation;
	}

	/**
	 */
	public void setMarbleFloors(String marbleFloors) {
		this.marbleFloors = marbleFloors;
	}

	/**
	 */
	public String getMarbleFloors() {
		return this.marbleFloors;
	}

	/**
	 */
	public void setMarinaBerth(String marinaBerth) {
		this.marinaBerth = marinaBerth;
	}

	/**
	 */
	public String getMarinaBerth() {
		return this.marinaBerth;
	}

	/**
	 */
	public void setMedicalCenters(String medicalCenters) {
		this.medicalCenters = medicalCenters;
	}

	/**
	 */
	public String getMedicalCenters() {
		return this.medicalCenters;
	}

	/**
	 */
	public void setMetroStation(String metroStation) {
		this.metroStation = metroStation;
	}

	/**
	 */
	public String getMetroStation() {
		return this.metroStation;
	}

	/**
	 */
	public void setMetros(String metros) {
		this.metros = metros;
	}

	/**
	 */
	public String getMetros() {
		return this.metros;
	}

	/**
	 */
	public void setMorgageAmount(BigDecimal morgageAmount) {
		this.morgageAmount = morgageAmount;
	}

	/**
	 */
	public BigDecimal getMorgageAmount() {
		return this.morgageAmount;
	}

	/**
	 */
	public void setMorgageNoc(String morgageNoc) {
		this.morgageNoc = morgageNoc;
	}

	/**
	 */
	public String getMorgageNoc() {
		return this.morgageNoc;
	}

	/**
	 */
	public void setMorgageRegNo(String morgageRegNo) {
		this.morgageRegNo = morgageRegNo;
	}

	/**
	 */
	public String getMorgageRegNo() {
		return this.morgageRegNo;
	}

	/**
	 */
	public void setMorgageStatus(String morgageStatus) {
		this.morgageStatus = morgageStatus;
	}

	/**
	 */
	public String getMorgageStatus() {
		return this.morgageStatus;
	}

	/**
	 */
	public void setMortageBank(String mortageBank) {
		this.mortageBank = mortageBank;
	}

	/**
	 */
	public String getMortageBank() {
		return this.mortageBank;
	}

	/**
	 */
	public void setMortgageValue(BigDecimal mortgageValue) {
		this.mortgageValue = mortgageValue;
	}

	/**
	 */
	public BigDecimal getMortgageValue() {
		return this.mortgageValue;
	}

	/**
	 */
	public void setMortgageYear(Integer mortgageYear) {
		this.mortgageYear = mortgageYear;
	}

	/**
	 */
	public Integer getMortgageYear() {
		return this.mortgageYear;
	}

	/**
	 */
	public void setMosque(String mosque) {
		this.mosque = mosque;
	}

	/**
	 */
	public String getMosque() {
		return this.mosque;
	}

	/**
	 */
	public void setMosquesInNeighbourhood(String mosquesInNeighbourhood) {
		this.mosquesInNeighbourhood = mosquesInNeighbourhood;
	}

	/**
	 */
	public String getMosquesInNeighbourhood() {
		return this.mosquesInNeighbourhood;
	}

	/**
	 */
	public void setNetArea(String netArea) {
		this.netArea = netArea;
	}

	/**
	 */
	public String getNetArea() {
		return this.netArea;
	}

	/**
	 */
	public void setNoOfBaths(Integer noOfBaths) {
		this.noOfBaths = noOfBaths;
	}

	/**
	 */
	public Integer getNoOfBaths() {
		return this.noOfBaths;
	}

	/**
	 */
	public void setNoOfBedrooms(Integer noOfBedrooms) {
		this.noOfBedrooms = noOfBedrooms;
	}

	/**
	 */
	public Integer getNoOfBedrooms() {
		return this.noOfBedrooms;
	}

	/**
	 */
	public void setNoOfFloors(Integer noOfFloors) {
		this.noOfFloors = noOfFloors;
	}

	/**
	 */
	public Integer getNoOfFloors() {
		return this.noOfFloors;
	}

	/**
	 */
	public void setNoShops(Integer noShops) {
		this.noShops = noShops;
	}

	/**
	 */
	public Integer getNoShops() {
		return this.noShops;
	}

	/**
	 */
	public void setNoUnits(Integer noUnits) {
		this.noUnits = noUnits;
	}

	/**
	 */
	public Integer getNoUnits() {
		return this.noUnits;
	}

	/**
	 */
	public void setOnHighFloor(String onHighFloor) {
		this.onHighFloor = onHighFloor;
	}

	/**
	 */
	public String getOnHighFloor() {
		return this.onHighFloor;
	}

	/**
	 */
	public void setOnLowFloor(String onLowFloor) {
		this.onLowFloor = onLowFloor;
	}

	/**
	 */
	public String getOnLowFloor() {
		return this.onLowFloor;
	}

	/**
	 */
	public void setOnMidFloor(String onMidFloor) {
		this.onMidFloor = onMidFloor;
	}

	/**
	 */
	public String getOnMidFloor() {
		return this.onMidFloor;
	}

	/**
	 */
	public void setOriginalPrice(BigDecimal originalPrice) {
		this.originalPrice = originalPrice;
	}

	/**
	 */
	public BigDecimal getOriginalPrice() {
		return this.originalPrice;
	}

	/**
	 */
	public void setOwnerAssociationNo(String ownerAssociationNo) {
		this.ownerAssociationNo = ownerAssociationNo;
	}

	/**
	 */
	public String getOwnerAssociationNo() {
		return this.ownerAssociationNo;
	}

	/**
	 */
	public void setPaidAmount(BigDecimal paidAmount) {
		this.paidAmount = paidAmount;
	}

	/**
	 */
	public BigDecimal getPaidAmount() {
		return this.paidAmount;
	}

	/**
	 */
	public void setPark(String park) {
		this.park = park;
	}

	/**
	 */
	public String getPark() {
		return this.park;
	}

	/**
	 */
	public void setPartFurnished(String partFurnished) {
		this.partFurnished = partFurnished;
	}

	/**
	 */
	public String getPartFurnished() {
		return this.partFurnished;
	}

	/**
	 */
	public void setPaymentSchedule(String paymentSchedule) {
		this.paymentSchedule = paymentSchedule;
	}

	/**
	 */
	public String getPaymentSchedule() {
		return this.paymentSchedule;
	}

	/**
	 */
	public void setPaymentStructure(String paymentStructure) {
		this.paymentStructure = paymentStructure;
	}

	/**
	 */
	public String getPaymentStructure() {
		return this.paymentStructure;
	}

	/**
	 */
	public void setPetsAllowed(String petsAllowed) {
		this.petsAllowed = petsAllowed;
	}

	/**
	 */
	public String getPetsAllowed() {
		return this.petsAllowed;
	}

	/**
	 */
	public void setPlotNo(String plotNo) {
		this.plotNo = plotNo;
	}

	/**
	 */
	public String getPlotNo() {
		return this.plotNo;
	}

	/**
	 */
	public void setPoloClubAndClubhouse(String poloClubAndClubhouse) {
		this.poloClubAndClubhouse = poloClubAndClubhouse;
	}

	/**
	 */
	public String getPoloClubAndClubhouse() {
		return this.poloClubAndClubhouse;
	}

	/**
	 */
	public void setPreClosureCharges(BigDecimal preClosureCharges) {
		this.preClosureCharges = preClosureCharges;
	}

	/**
	 */
	public BigDecimal getPreClosureCharges() {
		return this.preClosureCharges;
	}

	/**
	 */
	public void setPresentUse(String presentUse) {
		this.presentUse = presentUse;
	}

	/**
	 */
	public String getPresentUse() {
		return this.presentUse;
	}

	/**
	 */
	public void setPrice(String price) {
		this.price = price;
	}

	/**
	 */
	public String getPrice() {
		return this.price;
	}

	/**
	 */
	public void setPricePerSqft(BigDecimal pricePerSqft) {
		this.pricePerSqft = pricePerSqft;
	}

	/**
	 */
	public BigDecimal getPricePerSqft() {
		return this.pricePerSqft;
	}

	/**
	 */
	public void setPrivateGarage(String privateGarage) {
		this.privateGarage = privateGarage;
	}

	/**
	 */
	public String getPrivateGarage() {
		return this.privateGarage;
	}

	/**
	 */
	public void setPrivateGarden(String privateGarden) {
		this.privateGarden = privateGarden;
	}

	/**
	 */
	public String getPrivateGarden() {
		return this.privateGarden;
	}

	/**
	 */
	public void setPrivateSwimmingPool(String privateSwimmingPool) {
		this.privateSwimmingPool = privateSwimmingPool;
	}

	/**
	 */
	public String getPrivateSwimmingPool() {
		return this.privateSwimmingPool;
	}

	/**
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	/**
	 */
	public String getProjectName() {
		return this.projectName;
	}

	/**
	 */
	public void setPropertyAge(String propertyAge) {
		this.propertyAge = propertyAge;
	}

	/**
	 */
	public String getPropertyAge() {
		return this.propertyAge;
	}

	/**
	 */
	public void setPropertyDescription(String propertyDescription) {
		this.propertyDescription = propertyDescription;
	}

	/**
	 */
	public String getPropertyDescription() {
		return this.propertyDescription;
	}

	/**
	 */
	public void setPropertyNo(String propertyNo) {
		this.propertyNo = propertyNo;
	}

	/**
	 */
	public String getPropertyNo() {
		return this.propertyNo;
	}

	/**
	 */
	public void setPropertyReferenceNo(String propertyReferenceNo) {
		this.propertyReferenceNo = propertyReferenceNo;
	}

	/**
	 */
	public String getPropertyReferenceNo() {
		return this.propertyReferenceNo;
	}

	/**
	 */
	public void setPropertyStatus(String propertyStatus) {
		this.propertyStatus = propertyStatus;
	}

	/**
	 */
	public String getPropertyStatus() {
		return this.propertyStatus;
	}

	/**
	 */
	public void setPropertyStatusOther(String propertyStatusOther) {
		this.propertyStatusOther = propertyStatusOther;
	}

	/**
	 */
	public String getPropertyStatusOther() {
		return this.propertyStatusOther;
	}

	/**
	 */
	public void setPropertyTitle(String propertyTitle) {
		this.propertyTitle = propertyTitle;
	}

	/**
	 */
	public String getPropertyTitle() {
		return this.propertyTitle;
	}

	/**
	 */
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}

	/**
	 */
	public String getPropertyType() {
		return this.propertyType;
	}

	/**
	 */
	public void setPublicPark(String publicPark) {
		this.publicPark = publicPark;
	}

	/**
	 */
	public String getPublicPark() {
		return this.publicPark;
	}

	/**
	 */
	public void setPublicParking(String publicParking) {
		this.publicParking = publicParking;
	}

	/**
	 */
	public String getPublicParking() {
		return this.publicParking;
	}

	/**
	 */
	public void setPublicTransport(String publicTransport) {
		this.publicTransport = publicTransport;
	}

	/**
	 */
	public String getPublicTransport() {
		return this.publicTransport;
	}

	/**
	 */
	public void setRecreationalFacilities(String recreationalFacilities) {
		this.recreationalFacilities = recreationalFacilities;
	}

	/**
	 */
	public String getRecreationalFacilities() {
		return this.recreationalFacilities;
	}

	/**
	 */
	public void setRentalAnnualRent(BigDecimal rentalAnnualRent) {
		this.rentalAnnualRent = rentalAnnualRent;
	}

	/**
	 */
	public BigDecimal getRentalAnnualRent() {
		return this.rentalAnnualRent;
	}

	/**
	 */
	public void setRentalEjariNo(Integer rentalEjariNo) {
		this.rentalEjariNo = rentalEjariNo;
	}

	/**
	 */
	public Integer getRentalEjariNo() {
		return this.rentalEjariNo;
	}

	/**
	 */
	public void setRentalExpiryDate(Calendar rentalExpiryDate) {
		this.rentalExpiryDate = rentalExpiryDate;
	}

	/**
	 */
	public Calendar getRentalExpiryDate() {
		return this.rentalExpiryDate;
	}

	/**
	 */
	public void setRentalPaymentChecks(Integer rentalPaymentChecks) {
		this.rentalPaymentChecks = rentalPaymentChecks;
	}

	/**
	 */
	public Integer getRentalPaymentChecks() {
		return this.rentalPaymentChecks;
	}

	/**
	 */
	public void setRestaurants(String restaurants) {
		this.restaurants = restaurants;
	}

	/**
	 */
	public String getRestaurants() {
		return this.restaurants;
	}

	/**
	 */
	public void setSatelliteCableTv(String satelliteCableTv) {
		this.satelliteCableTv = satelliteCableTv;
	}

	/**
	 */
	public String getSatelliteCableTv() {
		return this.satelliteCableTv;
	}

	/**
	 */
	public void setSauna(String sauna) {
		this.sauna = sauna;
	}

	/**
	 */
	public String getSauna() {
		return this.sauna;
	}

	/**
	 */
	public void setScannedTitleDeed(String scannedTitleDeed) {
		this.scannedTitleDeed = scannedTitleDeed;
	}

	/**
	 */
	public String getScannedTitleDeed() {
		return this.scannedTitleDeed;
	}

	/**
	 */
	public void setSchool(String school) {
		this.school = school;
	}

	/**
	 */
	public String getSchool() {
		return this.school;
	}

	/**
	 */
	public void setSchoolsInNeighbourhood(String schoolsInNeighbourhood) {
		this.schoolsInNeighbourhood = schoolsInNeighbourhood;
	}

	/**
	 */
	public String getSchoolsInNeighbourhood() {
		return this.schoolsInNeighbourhood;
	}

	/**
	 */
	public void setSellerUserName(String sellerUserName) {
		this.sellerUserName = sellerUserName;
	}

	/**
	 */
	public String getSellerUserName() {
		return this.sellerUserName;
	}

	/**
	 */
	public void setServiceCharge(BigDecimal serviceCharge) {
		this.serviceCharge = serviceCharge;
	}

	/**
	 */
	public BigDecimal getServiceCharge() {
		return this.serviceCharge;
	}

	/**
	 */
	public void setSharedSwimmingPool(String sharedSwimmingPool) {
		this.sharedSwimmingPool = sharedSwimmingPool;
	}

	/**
	 */
	public String getSharedSwimmingPool() {
		return this.sharedSwimmingPool;
	}

	/**
	 */
	public void setShoppingMall(String shoppingMall) {
		this.shoppingMall = shoppingMall;
	}

	/**
	 */
	public String getShoppingMall() {
		return this.shoppingMall;
	}

	/**
	 */
	public void setShoppingMalls(String shoppingMalls) {
		this.shoppingMalls = shoppingMalls;
	}

	/**
	 */
	public String getShoppingMalls() {
		return this.shoppingMalls;
	}

	/**
	 */
	public void setShops(String shops) {
		this.shops = shops;
	}

	/**
	 */
	public String getShops() {
		return this.shops;
	}

	/**
	 */
	public void setSizePerSqft(BigDecimal sizePerSqft) {
		this.sizePerSqft = sizePerSqft;
	}

	/**
	 */
	public BigDecimal getSizePerSqft() {
		return this.sizePerSqft;
	}

	/**
	 */
	public void setSolidWoodFloors(String solidWoodFloors) {
		this.solidWoodFloors = solidWoodFloors;
	}

	/**
	 */
	public String getSolidWoodFloors() {
		return this.solidWoodFloors;
	}

	/**
	 */
	public void setSportsAcademies(String sportsAcademies) {
		this.sportsAcademies = sportsAcademies;
	}

	/**
	 */
	public String getSportsAcademies() {
		return this.sportsAcademies;
	}

	/**
	 */
	public void setSquashCourts(String squashCourts) {
		this.squashCourts = squashCourts;
	}

	/**
	 */
	public String getSquashCourts() {
		return this.squashCourts;
	}

	/**
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 */
	public String getStatus() {
		return this.status;
	}

	/**
	 */
	public void setSteamRoom(String steamRoom) {
		this.steamRoom = steamRoom;
	}

	/**
	 */
	public String getSteamRoom() {
		return this.steamRoom;
	}

	/**
	 */
	public void setStorageRoom(String storageRoom) {
		this.storageRoom = storageRoom;
	}

	/**
	 */
	public String getStorageRoom() {
		return this.storageRoom;
	}

	/**
	 */
	public void setStudy(String study) {
		this.study = study;
	}

	/**
	 */
	public String getStudy() {
		return this.study;
	}

	/**
	 */
	public void setSupermarkets(String supermarkets) {
		this.supermarkets = supermarkets;
	}

	/**
	 */
	public String getSupermarkets() {
		return this.supermarkets;
	}

	/**
	 */
	public void setTenancyContractUpload(String tenancyContractUpload) {
		this.tenancyContractUpload = tenancyContractUpload;
	}

	/**
	 */
	public String getTenancyContractUpload() {
		return this.tenancyContractUpload;
	}

	/**
	 */
	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}

	/**
	 */
	public String getTenantName() {
		return this.tenantName;
	}

	/**
	 */
	public void setTennisCourts(String tennisCourts) {
		this.tennisCourts = tennisCourts;
	}

	/**
	 */
	public String getTennisCourts() {
		return this.tennisCourts;
	}

	/**
	 */
	public void setThirdPartyVerification(String thirdPartyVerification) {
		this.thirdPartyVerification = thirdPartyVerification;
	}

	/**
	 */
	public String getThirdPartyVerification() {
		return this.thirdPartyVerification;
	}

	/**
	 */
	public void setTitleDeedNo(String titleDeedNo) {
		this.titleDeedNo = titleDeedNo;
	}

	/**
	 */
	public String getTitleDeedNo() {
		return this.titleDeedNo;
	}

	/**
	 */
	public void setTypeArea(String typeArea) {
		this.typeArea = typeArea;
	}

	/**
	 */
	public String getTypeArea() {
		return this.typeArea;
	}

	/**
	 */
	public void setTypePropertyOther(String typePropertyOther) {
		this.typePropertyOther = typePropertyOther;
	}

	/**
	 */
	public String getTypePropertyOther() {
		return this.typePropertyOther;
	}

	/**
	 */
	public void setUpgradedInterior(String upgradedInterior) {
		this.upgradedInterior = upgradedInterior;
	}

	/**
	 */
	public String getUpgradedInterior() {
		return this.upgradedInterior;
	}

	/**
	 */
	public void setValetService(String valetService) {
		this.valetService = valetService;
	}

	/**
	 */
	public String getValetService() {
		return this.valetService;
	}

	/**
	 */
	public void setValuationAssignTo(String valuationAssignTo) {
		this.valuationAssignTo = valuationAssignTo;
	}

	/**
	 */
	public String getValuationAssignTo() {
		return this.valuationAssignTo;
	}

	/**
	 */
	public void setValuationHodApproved(Integer valuationHodApproved) {
		this.valuationHodApproved = valuationHodApproved;
	}

	/**
	 */
	public Integer getValuationHodApproved() {
		return this.valuationHodApproved;
	}

	/**
	 */
	public void setValuationReportCopy(String valuationReportCopy) {
		this.valuationReportCopy = valuationReportCopy;
	}

	/**
	 */
	public String getValuationReportCopy() {
		return this.valuationReportCopy;
	}

	/**
	 */
	public void setValuationReportDocument(String valuationReportDocument) {
		this.valuationReportDocument = valuationReportDocument;
	}

	/**
	 */
	public String getValuationReportDocument() {
		return this.valuationReportDocument;
	}

	/**
	 */
	public void setVerificationHodApproved(String verificationHodApproved) {
		this.verificationHodApproved = verificationHodApproved;
	}

	/**
	 */
	public String getVerificationHodApproved() {
		return this.verificationHodApproved;
	}

	/**
	 */
	public void setViewOfGardens(String viewOfGardens) {
		this.viewOfGardens = viewOfGardens;
	}

	/**
	 */
	public String getViewOfGardens() {
		return this.viewOfGardens;
	}

	/**
	 */
	public void setViewOfGolfcourse(String viewOfGolfcourse) {
		this.viewOfGolfcourse = viewOfGolfcourse;
	}

	/**
	 */
	public String getViewOfGolfcourse() {
		return this.viewOfGolfcourse;
	}

	/**
	 */
	public void setViewOfParkland(String viewOfParkland) {
		this.viewOfParkland = viewOfParkland;
	}

	/**
	 */
	public String getViewOfParkland() {
		return this.viewOfParkland;
	}

	/**
	 */
	public void setViewOfSeaWater(String viewOfSeaWater) {
		this.viewOfSeaWater = viewOfSeaWater;
	}

	/**
	 */
	public String getViewOfSeaWater() {
		return this.viewOfSeaWater;
	}

	/**
	 */
	public void setWalkingTrails(String walkingTrails) {
		this.walkingTrails = walkingTrails;
	}

	/**
	 */
	public String getWalkingTrails() {
		return this.walkingTrails;
	}

	/**
	 */
	public void setDeveloperName(String developerName) {
		this.developerName = developerName;
	}

	/**
	 */
	public String getDeveloperName() {
		return this.developerName;
	}

	/**
	 */
	public void setThirdPartyReportCopy(String thirdPartyReportCopy) {
		this.thirdPartyReportCopy = thirdPartyReportCopy;
	}

	/**
	 */
	public String getThirdPartyReportCopy() {
		return this.thirdPartyReportCopy;
	}

	/**
	 */
	

	/**
	 */
	public ChiraghpropertyAud() {
	}

	public MyRevision getMyrevision() {
		return myrevision;
	}

	public void setMyrevision(MyRevision myrevision) {
		this.myrevision = myrevision;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	
}
