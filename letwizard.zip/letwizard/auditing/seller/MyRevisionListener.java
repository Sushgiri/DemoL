package com.bestercapitalmedia.letwizard.auditing.seller;

import org.hibernate.envers.RevisionListener;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.ibm.icu.util.Calendar;

public class MyRevisionListener implements RevisionListener {

	@Override
	public void newRevision(Object revisionEntity) {
		MyRevision rev = (MyRevision) revisionEntity;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String name = "";
		if (auth == null){
		name = "System";
		} else {
			name = auth.getName();
		}
		System.out.println("UserName using authentication " + name);
		rev.setUserName(name);
		rev.setDateTime(Calendar.getInstance().getTime());
	}

}
