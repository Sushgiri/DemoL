
package com.bestercapitalmedia.letwizard.auditing.seller;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

/**
 */
@IdClass(com.bestercapitalmedia.letwizard.auditing.seller.PropertysellerdetailsAudPK.class)
@Entity
@Table(name = "propertysellerdetails_aud")
public class PropertysellerdetailsAud implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "property_Seller_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id

	Integer sellerId;
	/**
	 */

	@Column(name = "REVISION_ID", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id

	Integer revisionId;
	/**
	 */

	@Column(name = "REVISION_TYPE")
	@Basic(fetch = FetchType.EAGER)


	Boolean revisionType;
	/**
	 */

	@Column(name = "address", length = 225)
	@Basic(fetch = FetchType.EAGER)


	String address;
	/**
	 */

	@Column(name = "email", length = 50)
	@Basic(fetch = FetchType.EAGER)


	String email;
	/**
	 */

	@Column(name = "email_Verification_Code", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String emailVerificationCode;
	/**
	 */

	@Column(name = "fax")
	@Basic(fetch = FetchType.EAGER)


	String fax;
	/**
	 */

	@Column(name = "first_Name", length = 225)
	@Basic(fetch = FetchType.EAGER)


	String firstName;
	/**
	 */

	@Column(name = "id_Card_Expiration", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String idCardExpiration;
	/**
	 */

	@Column(name = "id_Card_No", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String idCardNo;
	/**
	 */

	@Column(name = "is_Personal_Details_Verified")
	@Basic(fetch = FetchType.EAGER)


	String isPersonalDetailsVerified;
	/**
	 */

	@Column(name = "is_Poa_Accepted")
	@Basic(fetch = FetchType.EAGER)


	String isPoaAccepted;
	/**
	 */

	@Column(name = "last_Name", length = 225)
	@Basic(fetch = FetchType.EAGER)


	String lastName;
	/**
	 */

	@Column(name = "middle_Name", length = 225)
	@Basic(fetch = FetchType.EAGER)


	String middleName;
	/**
	 */

	@Column(name = "mobile", length = 225)
	@Basic(fetch = FetchType.EAGER)


	String mobile;
	/**
	 */

	@Column(name = "nationality", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String nationality;
	/**
	 */

	@Column(name = "owner_Type", length = 10)
	@Basic(fetch = FetchType.EAGER)


	String ownerType;
	/**
	 */

	@Column(name = "passport_Copy_Upload", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)



	String passportCopyUpload;
	/**
	 */

	@Column(name = "passport_Expiry_Date", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String passportExpiryDate;
	/**
	 */

	@Column(name = "passport_Id_Document_Upload")
	@Basic(fetch = FetchType.EAGER)


	Integer passportIdDocumentUpload;
	/**
	 */

	@Column(name = "passport_No", length = 225)
	@Basic(fetch = FetchType.EAGER)


	String passportNo;
	/**
	 */

	@Column(name = "poa_Agreement_Expiry", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String poaAgreementExpiry;
	/**
	 */

	@Column(name = "poa_Number")
	@Basic(fetch = FetchType.EAGER)


	String poaNumber;
	/**
	 */

	@Column(name = "poa_Property_Authority", length = 10)
	@Basic(fetch = FetchType.EAGER)


	String poaPropertyAuthority;
	/**
	 */

	@Column(name = "pobox", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String pobox;
	/**
	 */

	@Column(name = "property_Document1_upload", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String propertyDocument1Upload;
	/**
	 */

	@Column(name = "property_Document2_Upload", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String propertyDocument2Upload;
	/**
	 */

	@Column(name = "property_Document3_Upload", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String propertyDocument3Upload;
	/**
	 */

	@Column(name = "property_Document4_upload", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String propertyDocument4Upload;
	/**
	 */

	@Column(name = "scanned_Id_Copy", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)



	String scannedIdCopy;
	/**
	 */

	@Column(name = "scanned_Notorized_Copy", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)



	String scannedNotorizedCopy;
	/**
	 */

	@Column(name = "seller_Profilepic", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String sellerProfilepic;
	/**
	 */

	@Column(name = "specific_Property", length = 25)
	@Basic(fetch = FetchType.EAGER)


	String specificProperty;
	/**
	 */

	@Column(name = "telephone", length = 225)
	@Basic(fetch = FetchType.EAGER)


	String telephone;
	/**
	 */

	@Column(name = "title_Deed_Upload", columnDefinition = "LONGTEXT")
	@Basic(fetch = FetchType.EAGER)



	String titleDeedUpload;


	@Column(name = "property_Id")
	@Basic(fetch = FetchType.EAGER)


	Integer propertyId;


	@Column(name = "country_id")
	@Basic(fetch = FetchType.EAGER)


	Integer countryid;


	@Column(name = "city_id")
	@Basic(fetch = FetchType.EAGER)


	Integer cityid;

	@Column(name = "nationality_Other", length = 100)
	@Basic(fetch = FetchType.EAGER)


	String nationalityOther;

	@Column(name = "poa_Status", length = 45)
	@Basic(fetch = FetchType.EAGER)


	String poaStatus;

	@Column(name = "no_poa_expiry")
	boolean noPoaExpiry;


	@Column(name="other_document")
	@Basic(fetch = FetchType.EAGER)
	String otherDocument;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({
			@JoinColumn(name = "REVISION_ID", referencedColumnName = "id", nullable = false, insertable = false, updatable = false) })
	@JsonBackReference
	MyRevision myrevision;

	@Column(name="category_other")
	@Basic(fetch = FetchType.EAGER)
	String categoryOther;

	@Column(name="license_other")
	@Basic(fetch = FetchType.EAGER)
	String licenseOther;

	@Column(name = "vehicle_registration")
	@Basic(fetch = FetchType.EAGER)
	String vehicleRegistration;

	/**
	 */
	public void setRevisionId(Integer revisionId) {
		this.revisionId = revisionId;
	}

	/**
	 */
	public Integer getRevisionId() {
		return this.revisionId;
	}

	/**
	 */
	public void setRevisionType(Boolean revisionType) {
		this.revisionType = revisionType;
	}

	/**
	 */
	public Boolean getRevisionType() {
		return this.revisionType;
	}

	/**
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 */
	public String getAddress() {
		return this.address;
	}

	/**
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 */
	public String getEmail() {
		return this.email;
	}

	/**
	 */
	public void setEmailVerificationCode(String emailVerificationCode) {
		this.emailVerificationCode = emailVerificationCode;
	}

	/**
	 */
	public String getEmailVerificationCode() {
		return this.emailVerificationCode;
	}

	/**
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 */
	public String getFax() {
		return this.fax;
	}

	/**
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 */
	public void setIdCardExpiration(String idCardExpiration) {
		this.idCardExpiration = idCardExpiration;
	}

	/**
	 */
	public String getIdCardExpiration() {
		return this.idCardExpiration;
	}

	/**
	 */
	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}

	/**
	 */
	public String getIdCardNo() {
		return this.idCardNo;
	}

	/**
	 */
	public void setIsPersonalDetailsVerified(String isPersonalDetailsVerified) {
		this.isPersonalDetailsVerified = isPersonalDetailsVerified;
	}

	/**
	 */
	public String getIsPersonalDetailsVerified() {
		return this.isPersonalDetailsVerified;
	}

	/**
	 */
	public void setIsPoaAccepted(String isPoaAccepted) {
		this.isPoaAccepted = isPoaAccepted;
	}

	/**
	 */
	public String getIsPoaAccepted() {
		return this.isPoaAccepted;
	}

	/**
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 */
	public String getMiddleName() {
		return this.middleName;
	}

	/**
	 */
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	/**
	 */
	public String getMobile() {
		return this.mobile;
	}

	/**
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	/**
	 */
	public String getNationality() {
		return this.nationality;
	}

	/**
	 */
	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	/**
	 */
	public String getOwnerType() {
		return this.ownerType;
	}

	/**
	 */
	public void setPassportCopyUpload(String passportCopyUpload) {
		this.passportCopyUpload = passportCopyUpload;
	}

	/**
	 */
	public String getPassportCopyUpload() {
		return this.passportCopyUpload;
	}

	/**
	 */
	public void setPassportExpiryDate(String passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	/**
	 */
	public String getPassportExpiryDate() {
		return this.passportExpiryDate;
	}

	/**
	 */
	public void setPassportIdDocumentUpload(Integer passportIdDocumentUpload) {
		this.passportIdDocumentUpload = passportIdDocumentUpload;
	}

	/**
	 */
	public Integer getPassportIdDocumentUpload() {
		return this.passportIdDocumentUpload;
	}

	/**
	 */
	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	/**
	 */
	public String getPassportNo() {
		return this.passportNo;
	}

	/**
	 */
	public void setPoaAgreementExpiry(String poaAgreementExpiry) {
		this.poaAgreementExpiry = poaAgreementExpiry;
	}

	/**
	 */
	public String getPoaAgreementExpiry() {
		return this.poaAgreementExpiry;
	}

	/**
	 */
	public void setPoaNumber(String poaNumber) {
		this.poaNumber = poaNumber;
	}

	/**
	 */
	public String getPoaNumber() {
		return this.poaNumber;
	}

	/**
	 */
	public void setPoaPropertyAuthority(String poaPropertyAuthority) {
		this.poaPropertyAuthority = poaPropertyAuthority;
	}

	/**
	 */
	public String getPoaPropertyAuthority() {
		return this.poaPropertyAuthority;
	}

	/**
	 */
	public void setPobox(String pobox) {
		this.pobox = pobox;
	}

	/**
	 */
	public String getPobox() {
		return this.pobox;
	}

	/**
	 */
	public void setPropertyDocument1Upload(String propertyDocument1Upload) {
		this.propertyDocument1Upload = propertyDocument1Upload;
	}

	/**
	 */
	public String getPropertyDocument1Upload() {
		return this.propertyDocument1Upload;
	}

	/**
	 */
	public void setPropertyDocument2Upload(String propertyDocument2Upload) {
		this.propertyDocument2Upload = propertyDocument2Upload;
	}

	/**
	 */
	public String getPropertyDocument2Upload() {
		return this.propertyDocument2Upload;
	}

	/**
	 */
	public void setPropertyDocument3Upload(String propertyDocument3Upload) {
		this.propertyDocument3Upload = propertyDocument3Upload;
	}

	/**
	 */
	public String getPropertyDocument3Upload() {
		return this.propertyDocument3Upload;
	}

	/**
	 */
	public void setPropertyDocument4Upload(String propertyDocument4Upload) {
		this.propertyDocument4Upload = propertyDocument4Upload;
	}

	/**
	 */
	public String getPropertyDocument4Upload() {
		return this.propertyDocument4Upload;
	}

	/**
	 */
	public void setScannedIdCopy(String scannedIdCopy) {
		this.scannedIdCopy = scannedIdCopy;
	}

	/**
	 */
	public String getScannedIdCopy() {
		return this.scannedIdCopy;
	}

	/**
	 */
	public void setScannedNotorizedCopy(String scannedNotorizedCopy) {
		this.scannedNotorizedCopy = scannedNotorizedCopy;
	}

	/**
	 */
	public String getScannedNotorizedCopy() {
		return this.scannedNotorizedCopy;
	}

	/**
	 */
	public void setSellerProfilepic(String sellerProfilepic) {
		this.sellerProfilepic = sellerProfilepic;
	}

	/**
	 */
	public String getSellerProfilepic() {
		return this.sellerProfilepic;
	}

	/**
	 */
	public void setSpecificProperty(String specificProperty) {
		this.specificProperty = specificProperty;
	}

	/**
	 */
	public String getSpecificProperty() {
		return this.specificProperty;
	}

	/**
	 */
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	/**
	 */
	public String getTelephone() {
		return this.telephone;
	}

	/**
	 */
	public void setTitleDeedUpload(String titleDeedUpload) {
		this.titleDeedUpload = titleDeedUpload;
	}

	/**
	 */
	public String getTitleDeedUpload() {
		return this.titleDeedUpload;
	}

	/**
	 */
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	/**
	 */
	public Integer getPropertyId() {
		return this.propertyId;
	}



	/**
	 */
	public PropertysellerdetailsAud() {
	}



	public Integer getSellerId() {
		return sellerId;
	}

	public void setSellerId(Integer sellerId) {
		this.sellerId = sellerId;
	}

	public MyRevision getMyrevision() {
		return myrevision;
	}

	public void setMyrevision(MyRevision myrevision) {
		this.myrevision = myrevision;
	}

	public String getNationalityOther() {
		return nationalityOther;
	}

	public void setNationalityOther(String nationalityOther) {
		this.nationalityOther = nationalityOther;
	}

	public String getPoaStatus() {
		return poaStatus;
	}

	public void setPoaStatus(String poaStatus) {
		this.poaStatus = poaStatus;
	}

	public Integer getCountryid() {
		return countryid;
	}

	public void setCountryid(Integer countryid) {
		this.countryid = countryid;
	}

	public Integer getCityid() {
		return cityid;
	}

	public void setCityid(Integer cityid) {
		this.cityid = cityid;
	}

	public String getOtherDocument() {
		return otherDocument;
	}

	public void setOtherDocument(String otherDocument) {
		this.otherDocument = otherDocument;
	}

	public boolean getNoPoaExpiry() {
		return noPoaExpiry;
	}

	public void setNoPoaExpiry(boolean noPoaExpiry) {
		this.noPoaExpiry = noPoaExpiry;
	}

	public String getCategoryOther() {
		return categoryOther;
	}

	public void setCategoryOther(String categoryOther) {
		this.categoryOther = categoryOther;
	}

	public String getLicenseOther() {
		return licenseOther;
	}

	public void setLicenseOther(String licenseOther) {
		this.licenseOther = licenseOther;
	}

	public String getVehicleRegistration() {
		return vehicleRegistration;
	}

	public void setVehicleRegistration(String vehicleRegistration) {
		this.vehicleRegistration = vehicleRegistration;
	}
}

