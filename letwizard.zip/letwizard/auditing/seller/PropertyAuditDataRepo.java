package com.bestercapitalmedia.letwizard.auditing.seller;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface PropertyAuditDataRepo  extends CrudRepository<ChiraghpropertyAud, Integer>{

	@Query(value = "select * from chiraghproperty_aud where property_Id=?1 ", nativeQuery = true)
	public List<ChiraghpropertyAud> getAuditDataByPropertyId(int sellerId);
}
