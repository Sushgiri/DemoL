package com.bestercapitalmedia.letwizard.auditing.seller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuditService {

	@Autowired
	private  PropertyAuditDataRepo propertyAuditDataRepo;
	
	@Autowired
	private  sellerAuditDataRepo sellerAuditDataRepo;
	
	
	public void clearAuditData() {
//		propertyAuditDataRepo.deleteAll();
//		sellerAuditDataRepo.deleteAll();
	}
}
