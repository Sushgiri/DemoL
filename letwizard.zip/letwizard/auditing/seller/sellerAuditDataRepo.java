package com.bestercapitalmedia.letwizard.auditing.seller;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.seller.details.Propertysellerdetails;

public interface sellerAuditDataRepo  extends CrudRepository<PropertysellerdetailsAud, Integer>{

	@Query(value = "select * from propertySellerDetails_aud where property_Seller_Id=?1 ", nativeQuery = true)
	public List<PropertysellerdetailsAud> getAuditDataBySellerId(int sellerId);

}
