package com.bestercapitalmedia.letwizard.aedodreporting;

import javax.servlet.http.HttpServletRequest;

import org.javers.common.collections.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.balanceexports.UserBalancesControllerTest;
import com.bestercapitalmedia.letwizard.balanceexports.UserServiceBalance;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;

@CrossOrigin
@RestController
public class ODReportControllerTest {

	private static final Logger log = LoggerFactory.getLogger(ODReportControllerTest.class);

	@Autowired
	private ODReportService aedodService;

	@Autowired
	private ChiragUtill chiraghUtill;

	@Autowired
	private ResponseUtill responseUtill;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getAEDODBalancesTest", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity GetUserBalancesTest(HttpServletRequest httpServletRequest) {

		try {
			aedodService.allODBalances();
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, "User Balances Exported", null);
		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
}
