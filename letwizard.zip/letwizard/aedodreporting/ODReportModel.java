package com.bestercapitalmedia.letwizard.aedodreporting;

import java.math.BigDecimal;
import java.sql.Date;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ODReportModel {
	
	private String Chiragh_Id;
	private String Customer_Name;
	private String Currency;
	private BigDecimal OD_Available_Amt;
	private BigDecimal OD_Current_Bal;
	private BigDecimal OD_Approved_Amt;
	private BigDecimal Auction_Deposit;
	private BigDecimal OD_Utilized_Amt;
	private BigDecimal OD_Pending_Transactions;
	private BigDecimal Requested_Amount;
	private String Cheque_Number;
	private BigDecimal Cheque_Amount;
	private String Cheque_Bank;
	private Date Created_Date;
	private Date Approved_Final_Date;
	private String OD_ID;
	
}
