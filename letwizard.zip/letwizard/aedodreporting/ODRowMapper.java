package com.bestercapitalmedia.letwizard.aedodreporting;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ODRowMapper implements RowMapper<ODReportModel> {

	@Override
	public ODReportModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		ODReportModel aedodReportBalance = new ODReportModel();
		aedodReportBalance.setAuction_Deposit(rs.getBigDecimal("auction_deposit"));
		aedodReportBalance.setChiragh_Id(rs.getString("chiragh_id"));
		aedodReportBalance.setCurrency(rs.getString("currency"));
		aedodReportBalance.setCustomer_Name(rs.getString("customer_name"));
		aedodReportBalance.setOD_Approved_Amt(rs.getBigDecimal("od_approved_amt"));
		aedodReportBalance.setOD_Available_Amt(rs.getBigDecimal("od_available_amt"));
		aedodReportBalance.setOD_Current_Bal(rs.getBigDecimal("od_current_balance"));
		aedodReportBalance.setOD_Pending_Transactions(rs.getBigDecimal("od_pending_transactions"));
		aedodReportBalance.setOD_Utilized_Amt(rs.getBigDecimal("od_utilized_amt"));
		aedodReportBalance.setApproved_Final_Date(rs.getDate("approved_final_date"));
		aedodReportBalance.setCheque_Amount(rs.getBigDecimal("cheque_amount"));
		aedodReportBalance.setCheque_Bank(rs.getString("cheque_bank"));
		aedodReportBalance.setCheque_Number(rs.getString("cheque_number"));
		aedodReportBalance.setCreated_Date(rs.getDate("created_date"));
		aedodReportBalance.setOD_ID(rs.getString("od_id"));
		aedodReportBalance.setRequested_Amount(rs.getBigDecimal("requested_amount"));

		return aedodReportBalance;

	}
}
