package com.bestercapitalmedia.letwizard.aedodreporting;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;



public class WriteODReportToCSV {
	
	static final Logger logger = LoggerFactory.getLogger(WriteODReportToCSV.class);

	static void writeCSVFile(String csvFileName, List<ODReportModel> listOfUserAedod) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = {

					"OD_ID", "Created_Date", "Approved_Final_Date", "Cheque_Number", "Cheque_Amount","Requested_Amount", "Cheque_Bank",
					"Chiragh_Id", "Customer_Name", "Currency", "OD_Available_Amt", "OD_Current_Bal", "OD_Approved_Amt",
					"Auction_Deposit", "OD_Utilized_Amt", "OD_Pending_Transactions" };
			beanWriter.writeHeader(header);

			for (ODReportModel aBook : listOfUserAedod) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}


}
