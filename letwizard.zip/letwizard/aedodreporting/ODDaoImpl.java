package com.bestercapitalmedia.letwizard.aedodreporting;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bestercapitalmedia.letwizard.balanceexports.UserBalanceModel;
import com.bestercapitalmedia.letwizard.balanceexports.UserDao;
import com.bestercapitalmedia.letwizard.balanceexports.UserRowMapper;

@Repository
public class ODDaoImpl implements ODDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<ODReportModel> listOfAedodBalances() {
		return jdbcTemplate.query(ODDao.AEDOD_BALANCES, new ODRowMapper());
		
		
		 
		
	}

}
