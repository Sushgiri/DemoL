package com.bestercapitalmedia.letwizard.aedodreporting;

import java.io.File;
import java.util.List;

import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.model.enums.AesKeyStrength;
import net.lingala.zip4j.model.enums.EncryptionMethod;

public class ODReportZipFile {
	
	public static void compressWithPassword(File file, String password) throws ZipException {

		String destPath = "AEDODReport" + ".zip";

		// Setting parameters
		ZipParameters zipParameters = new ZipParameters();
		zipParameters.setEncryptFiles(true);
		zipParameters.setEncryptionMethod(EncryptionMethod.AES);
		zipParameters.setAesKeyStrength(AesKeyStrength.KEY_STRENGTH_256);

		ZipFile zipFile = new ZipFile(destPath, password.toCharArray());
		zipFile.addFile(file, zipParameters);
		
	}


}
