package com.bestercapitalmedia.letwizard.inbox;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;




public interface ThreadsRepository  extends JpaRepository<Threads, Integer>  {

//	@Query(value = "select * from threads where property_id=?1  ", nativeQuery = true)
//	public Leads findByThreadId(int propertyId);
	
	@Query(value = "select * from threads where user_id=?1 AND is_draft is NOT NULL AND is_draft = 0 AND is_deleted is NOT NULL AND is_deleted = 0 order by created_at desc",
			countQuery ="select count(*) from threads where user_id=?1 AND is_draft is NOT NULL AND is_draft = 0 AND is_deleted is NOT NULL AND is_deleted = 0 order by created_at desc"
			, nativeQuery = true)
	public Page<Threads> findSentItems(int userId,Pageable pageable);
	
	
	@Query(value = "select * from threads where user_id=?1 AND is_draft is NOT NULL AND is_draft = 1 AND is_deleted is NOT NULL AND is_deleted = 0 order by created_at desc", 
			countQuery ="select count(*) from threads where user_id=?1 AND is_draft is NOT NULL AND is_draft = 1 AND is_deleted is NOT NULL AND is_deleted = 0 order by created_at desc",
			nativeQuery = true)
	public Page<Threads> findDraftItems(int userId, Pageable pageable);
	
	@Query(value = "select * from threads where is_draft is NOT NULL AND is_draft = 0 AND  id in (SELECT thread_id from participants where user_id = ?1 AND is_deleted is NOT NULL AND is_deleted = 0) order by created_at desc",
			countQuery ="select count(*) from threads where is_draft is NOT NULL AND is_draft = 0 AND id in (SELECT thread_id from participants where user_id = ?1 AND is_deleted is NOT NULL AND is_deleted = 0) order by created_at desc"
			,nativeQuery = true)
	public Page<Threads> findInboxItems(int userId,Pageable pageable);
	
	@Query(value = "select * from threads where id =?1", nativeQuery = true)
	public Threads findThreadByID(int threadId);
	
	@Query(value = "SELECT * FROM ((select * from threads where user_id= ?1 AND is_deleted is NOT NULL AND is_deleted = 1)"
			+ "union all "
			+ "(select * from threads where id in (SELECT thread_id from participants where user_id = ?1 AND is_deleted is NOT NULL AND is_deleted = 1)) ) AS data_table ORDER BY data_table.created_at desc",
			countQuery =  "SELECT count(*) FROM ((select * from threads where user_id= ?1 AND is_deleted is NOT NULL AND is_deleted = 1)"
					+ "union all "
					+ "(select * from threads where id in (SELECT thread_id from participants where user_id = ?1 AND is_deleted is NOT NULL AND is_deleted = 1)) ) AS data_table ORDER BY data_table.created_at desc"
			,nativeQuery = true)
	public Page<Threads> findDeletedItems(int userId,Pageable pageable);
	//countQuery ="select count(*) from threads where user_id=?1 AND is_deleted is NOT NULL AND is_deleted = 1 order by created_at desc"
	//,
	@Transactional
	@Modifying
	@Query(value = "UPDATE threads SET is_deleted = ?1 where thread_id in ?2", nativeQuery = true)
	public Integer markDeleted(boolean isDeleted, List<Integer> threads);
	
	
	

	
	
}
