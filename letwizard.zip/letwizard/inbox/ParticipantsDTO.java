package com.bestercapitalmedia.letwizard.inbox;

import java.util.Date;

import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;


public class ParticipantsDTO {

	private Integer id;
	private ChiraghUserDTO chiraghuser;;
//	private Threads thread;
	private Date seenAt;
	private int departmentId;
	private Boolean isImportant;
	private Boolean isDeleted;
	private Date createdAt;
	private Date updatedAt;
	public ParticipantsDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public ChiraghUserDTO getChiraghuser() {
		return chiraghuser;
	}
	public void setChiraghuser(ChiraghUserDTO chiraghuser) {
		this.chiraghuser = chiraghuser;
	}
//	public Threads getThread() {
//		return thread;
//	}
//	public void setThread(Threads thread) {
//		this.thread = thread;
//	}
	public Date getSeenAt() {
		return seenAt;
	}
	public void setSeenAt(Date seenAt) {
		this.seenAt = seenAt;
	}
	public int getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	public Boolean getIsImportant() {
		return isImportant;
	}
	public void setIsImportant(Boolean isImportant) {
		this.isImportant = isImportant;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	
}
