package com.bestercapitalmedia.letwizard.inbox;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/threads")
public class ThreadsController {

	@Autowired ThreadsService threadsService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/thread", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createThread(@RequestBody ThreadRequestDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.createThread(request);
	}
	@RequestMapping(value = "/thread", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity updateThread(@RequestBody ThreadRequestDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.updateThread(request);
	}
	@RequestMapping(value = "/sentitems", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getSentItems(@PageableDefault(value=Integer.MAX_VALUE, page=0) Pageable pageable,HttpServletRequest httpServletRequest) {
		return threadsService.getSentItems(pageable.getPageNumber(),pageable.getPageSize());
	}
	@RequestMapping(value = "/drafts", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getDraft(@PageableDefault(value=Integer.MAX_VALUE, page=0) Pageable pageable,HttpServletRequest httpServletRequest) {
		return threadsService.getDrafts(pageable.getPageNumber(),pageable.getPageSize());
	}
	
	@RequestMapping(value = "/inbox", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity inbox(@PageableDefault(value=Integer.MAX_VALUE, page=0) Pageable pageable,HttpServletRequest httpServletRequest) {
		return threadsService.getInbox(pageable.getPageNumber(),pageable.getPageSize());
	}
	@RequestMapping(value = "/trash", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getTrashedItems(@PageableDefault(value=Integer.MAX_VALUE, page=0) Pageable pageable,HttpServletRequest httpServletRequest) {
		return threadsService.getTrashedItems(pageable.getPageNumber(),pageable.getPageSize());
	}
	@RequestMapping(value = "/{threadId}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getThreadDetail(@PathVariable(value= "threadId") int threadId,HttpServletRequest httpServletRequest) {
		return threadsService.getThreadDetails(threadId);
	}
	@RequestMapping(value = "/important", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity markImportant(@RequestBody ThreadListDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.importantThread(request, true);
	}
	@RequestMapping(value = "/unimportant", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity markUnimportant(@RequestBody ThreadListDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.importantThread(request, false);
	}
	@RequestMapping(value = "/inbox/delete", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity updateThreadDelete(@RequestBody ThreadListDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.inboxDeleteThread(request);
	}
	@RequestMapping(value = "/outbox/delete", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity updateThreadDeleteOutbox(@RequestBody ThreadListDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.outboxDeleteThread(request);
	}
	@RequestMapping(value = "/delete/attachment/{attachmentId}", method = RequestMethod.DELETE)
	public @ResponseBody ResponseEntity deleteAttachment(@PathVariable(value= "attachmentId") int attachmentId, HttpServletRequest httpServletRequest) {
		return threadsService.deleteAttachment(attachmentId);
	}
	@RequestMapping(value = "/reply", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity replyThread(@RequestBody ThreadRequestDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.createThread(request);
	}
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/forward", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity forwardThread(@RequestBody ThreadRequestDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.createThread(request);
	}
	@RequestMapping(value = "/read", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity markAsRead(@RequestBody ThreadListDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.markAsRead(request);
	}
	@RequestMapping(value = "/unread", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity markAsUnRead(@RequestBody ThreadListDTO request, HttpServletRequest httpServletRequest) {
		return threadsService.markAsUnRead(request);
	}

}
