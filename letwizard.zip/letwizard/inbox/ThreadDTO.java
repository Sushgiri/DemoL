package com.bestercapitalmedia.letwizard.inbox;

import java.util.Date;

import com.bestercapitalmedia.letwizard.user.Chiraghuser;

public class ThreadDTO {

	private Integer id;
	private String subject;
	private Integer departmentId;
	private Boolean isDeleted;
	private Boolean isImportant;
	private Boolean isDraft;
	private Date createdAt;
	private Date updatedAt;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public Boolean getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Boolean getIsImportant() {
		return isImportant;
	}
	public void setIsImportant(Boolean isImportant) {
		this.isImportant = isImportant;
	}
	public Boolean getIsDraft() {
		return isDraft;
	}
	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public ThreadDTO() {
		super();
	}
	
	
	
}
