package com.bestercapitalmedia.letwizard.inbox;

import java.util.List;

import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;


public class ThreadDetailDTO extends ThreadDTO{
	
	private ChiraghUserDTO chiraghuser;
	private List<ParticipantsDTO> participants;
	private List<AttachmentDTO> attachments;
	private MessageDTO messages;
	public ThreadDetailDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ChiraghUserDTO getChiraghuser() {
		return chiraghuser;
	}
	public void setChiraghuser(ChiraghUserDTO chiraghuser) {
		this.chiraghuser = chiraghuser;
	}

	
	public List<ParticipantsDTO> getParticipants() {
		return participants;
	}
	public void setParticipants(List<ParticipantsDTO> participants) {
		this.participants = participants;
	}

	public List<AttachmentDTO> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<AttachmentDTO> attachments) {
		this.attachments = attachments;
	}

	public MessageDTO getMessages() {
		return messages;
	}

	public void setMessages(MessageDTO messages) {
		this.messages = messages;
	}

	
	
	

}
