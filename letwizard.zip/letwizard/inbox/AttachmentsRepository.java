package com.bestercapitalmedia.letwizard.inbox;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface AttachmentsRepository extends CrudRepository<Attachments, Integer> {

	@Query(value = "select * from attachments where thread_id =?", nativeQuery = true)
	public List<Attachments> findAttachmentsByThreadID(int threadId);

	@Query(value = "select * from attachments where id =?", nativeQuery = true)
	public Attachments findAttachment(int attachmentId);
}
