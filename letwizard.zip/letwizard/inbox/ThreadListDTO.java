package com.bestercapitalmedia.letwizard.inbox;

import java.util.List;

public class ThreadListDTO {

	private List<Integer> threadIds;

	public List<Integer> getThreadIds() {
		return threadIds;
	}

	public void setThreadIds(List<Integer> threadIds) {
		this.threadIds = threadIds;
	}

	public ThreadListDTO() {
		super();
	}
	
	
}
