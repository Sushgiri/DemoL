package com.bestercapitalmedia.letwizard.inbox;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface MessagesRepository extends CrudRepository <Messages, Integer>{

	@Query(value = "select * from messages where thread_id =?", nativeQuery = true)
	public Messages findMessagesByThreadID(int threadId);
}
