package com.bestercapitalmedia.letwizard.inbox;

import java.util.List;

public class ThreadRequestDTO {

	private Integer threadId;
	private String subject;
	private Integer departmentId;
	private Boolean isDraft;
	private List<Integer> participants;
	private String body;
	private List<AttachmentDTO> attachments;
	
	
	public ThreadRequestDTO() {
		super();
	}

	
	public Integer getThreadId() {
		return threadId;
	}


	public void setThreadId(Integer threadId) {
		this.threadId = threadId;
	}


	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Boolean getIsDraft() {
		return isDraft;
	}

	public void setIsDraft(Boolean isDraft) {
		this.isDraft = isDraft;
	}

	public List<Integer> getParticipants() {
		return participants;
	}
	public void setParticipants(List<Integer> participants) {
		this.participants = participants;
	}


	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public List<AttachmentDTO> getAttachments() {
		return attachments;
	}
	public void setAttachments(List<AttachmentDTO> attachments) {
		this.attachments = attachments;
	}

	
		
	
	
	
}
