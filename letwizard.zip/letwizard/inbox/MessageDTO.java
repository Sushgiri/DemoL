package com.bestercapitalmedia.letwizard.inbox;

import java.util.Date;

public class MessageDTO {

	private String body;
	private Date createdAt;
	private Date updatedAt;
	public MessageDTO() {
		super();
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	

	
}
