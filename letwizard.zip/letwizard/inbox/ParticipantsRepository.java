package com.bestercapitalmedia.letwizard.inbox;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface ParticipantsRepository extends JpaRepository<Participants, Integer> {

	@Query(value = "select * from participants where thread_id =?", nativeQuery = true)
	public List<Participants> findParticipantsByThreadID(int threadId);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE participants SET is_deleted = ?1 where thread_id in ?2 and user_id = ?3", nativeQuery = true)
	public Integer markDelete(boolean isDelete, List<Integer> threadId, int userId);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE participants SET is_important = ?3 where user_id =?1 and thread_id in ?2", nativeQuery = true)
	public Integer markAsImportant(int userId, List<Integer> threads, boolean isImportant);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE participants SET seen_at =?1 where user_id =?2 and thread_id in ?3", nativeQuery = true)
	public Integer markAsRead(Date seenAt, int userId, List<Integer> threads);
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE participants SET seen_at = null where user_id =?1 and thread_id in ?2", nativeQuery = true)
	public Integer markAsUnRead( int userId, List<Integer> threads);
}
