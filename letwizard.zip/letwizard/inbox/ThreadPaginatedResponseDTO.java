package com.bestercapitalmedia.letwizard.inbox;

import java.util.List;



public class ThreadPaginatedResponseDTO {

	
	int totalPages;
	int pageNumber;
	int numberOfElements;
	long totalRecords;
	
	
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getNumberOfElements() {
		return numberOfElements;
	}
	public void setNumberOfElements(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}
	public long getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}
	public ThreadPaginatedResponseDTO() {
		super();
		
	}

}
