package com.bestercapitalmedia.letwizard.inbox;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.transaction.Transactional;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.PaginatedResponseDTO;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.LetwizardPropertyService;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.StringValidationUtils;

@Service
public class ThreadsService {

	private static final Logger logger = LoggerFactory.getLogger(LetwizardPropertyService.class);
	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ThreadsRepository threadRepository;

	@Autowired
	private MessagesRepository messagesRepository;

	@Autowired
	private AttachmentsRepository attachmentsRepository;

	@Autowired
	private ParticipantsRepository participantsRepository;

	@Transactional
	public ResponseEntity createBotThread(ThreadRequestDTO request) {
		try {
			// We expect this method to be called after auth etc. So we dont need aditional auth checks
//			String userName = chiragUtill.getUserNameFromAuthentication();
//			logger.info(userName, "user name {}");
//			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
//			//			System.out.println(user.getDepartements().getDepartementsId());
//			if (chiraghuser == null) {
//				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
//						null);
//			}
//			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");

			Chiraghuser chiraghBot = userRepository.findByUserName("bot");
			if (chiraghBot == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			request.setDepartmentId(chiraghBot.getDepartements().getDepartementsId()); // Saving Bot's Department ID and not taking its value from Request
			Threads newThread = new Threads();
			newThread.setCreatedAt(new Date());
			newThread.setUpdatedAt(new Date());
			newThread.setIsDeleted(false);
			newThread.setIsImportant(false);
			newThread.setChiraghuser(chiraghBot);
			newThread.setIsDraft(request.getIsDraft());
			newThread.setDepartmentId(request.getDepartmentId()); 
			newThread.setSubject(request.getSubject());
			Threads savedThread = threadRepository.save(newThread);
			if (savedThread == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
				addBody(request, savedThread, chiraghBot);
				addAttachments(request, savedThread, chiraghBot);
				addParticipants(request, savedThread);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			}
			// }

		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}
	
	@Transactional
	public ResponseEntity createThread(ThreadRequestDTO request) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");

			Threads newThread = new Threads();
			newThread.setCreatedAt(new Date());
			newThread.setUpdatedAt(new Date());
			newThread.setIsDeleted(false);
			newThread.setIsImportant(false);
			newThread.setChiraghuser(chiraghuser);
			newThread.setIsDraft(request.getIsDraft());
			newThread.setDepartmentId(request.getDepartmentId());
			newThread.setSubject(request.getSubject());
			Threads savedThread = threadRepository.save(newThread);
			if (savedThread == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
				addBody(request, savedThread, chiraghuser);
				addAttachments(request, savedThread, chiraghuser);
				addParticipants(request, savedThread);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			}
			// }

		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	@Transactional
	public ResponseEntity updateThread(ThreadRequestDTO request) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");

			Threads thread = threadRepository.findThreadByID(request.getThreadId());
			if (thread == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			thread.setChiraghuser(chiraghuser);
			thread.setIsDraft(request.getIsDraft());
			thread.setDepartmentId(request.getDepartmentId());
			thread.setSubject(request.getSubject());
			Threads savedThread = threadRepository.save(thread);
			if (savedThread == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
				addBody(request, savedThread, chiraghuser);
				updateAttachments(request, savedThread, chiraghuser);
				updateParticipants(request, savedThread);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			}
			// }

		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public void addBody(ThreadRequestDTO request, Threads thread, Chiraghuser user) {
		Messages oldMessage = messagesRepository.findMessagesByThreadID(thread.getId());
		if (oldMessage != null) {
			messagesRepository.delete(oldMessage);
		}
		if (!StringValidationUtils.isEmptyObject(request.getBody())) {
			Messages message = new Messages(thread, user, request.getBody(), request.getDepartmentId());
			messagesRepository.save(message);
		}
	}

	public void addAttachments(ThreadRequestDTO request, Threads thread, Chiraghuser user) {
		if (request.getAttachments() != null) {
			List<Attachments> newAttachments = new ArrayList<Attachments>();
			for (AttachmentDTO attachment : request.getAttachments()) {
				Attachments newAttachment = new Attachments(thread, user, attachment.getUrl(),
						attachment.getAttachmentType());
				newAttachments.add(newAttachment);
			}
			if (newAttachments != null) {
				attachmentsRepository.saveAll(newAttachments);
			}
		}
	}
	
	

	public void addParticipants(ThreadRequestDTO request, Threads thread) {

		if ((request.getParticipants() != null) && (request.getParticipants().size() > 0)) {
			List<Participants> newParticipants = new ArrayList<Participants>();
			List<Chiraghuser> chiraghusers = userRepository.findUsersById(request.getParticipants());
			for (Chiraghuser user : chiraghusers) {
				Participants participant = new Participants(thread, user, request.getDepartmentId());
				newParticipants.add(participant);

			}
			if (newParticipants != null) {
				participantsRepository.saveAll(newParticipants);
			}
		}

	}
	
	public void updateAttachments(ThreadRequestDTO request, Threads thread, Chiraghuser user) {
		
		List<Attachments> newAttachments = new ArrayList<Attachments>();
		if (request.getAttachments() != null && request.getAttachments().size() > 0) {
			List<Chiraghuser> chiraghusers = userRepository.findUsersById(request.getParticipants());
				for (AttachmentDTO attachment : request.getAttachments()) {
					Attachments newAttachment = new Attachments(thread, user, attachment.getUrl(),
					attachment.getAttachmentType());
					newAttachments.add(newAttachment);
			}
		}
		List<Attachments> oldAttachments = attachmentsRepository.findAttachmentsByThreadID(thread.getId());
		if ((newAttachments.size() == 0) && (oldAttachments != null)) {
			attachmentsRepository.deleteAll(oldAttachments);
		} else if ((newAttachments.size() > 0) && (oldAttachments == null)) {
			attachmentsRepository.saveAll(newAttachments);
		} else if ((newAttachments.size() > 0) && (oldAttachments != null)) {

			int i = oldAttachments.size() - 1;
			while (i >= 0) {
				Attachments attachment = oldAttachments.get(i);

				int index = findIndexOfAttachment(newAttachments,attachment);
						
				if (index > -1) {
					newAttachments.remove(index);
					oldAttachments.remove(i);
				} else {
					oldAttachments.remove(i);
					attachmentsRepository.delete(attachment);
				}
				i--;
			}
			if (newAttachments.size() > 0) {
				attachmentsRepository.saveAll(newAttachments);

			}

			i--;
		}
		if (newAttachments.size() > 0) {
			attachmentsRepository.saveAll(newAttachments);
		}
				

	}

	public void updateParticipants(ThreadRequestDTO request, Threads thread) {

		List<Participants> newParticipants = new ArrayList<Participants>();
		if (request.getParticipants() != null && request.getParticipants().size() > 0) {
			List<Chiraghuser> chiraghusers = userRepository.findUsersById(request.getParticipants());
			for (Chiraghuser user : chiraghusers) {
				Participants participant = new Participants(thread, user, request.getDepartmentId());
				newParticipants.add(participant);

			}
		}
		List<Participants> oldParticipants = participantsRepository.findParticipantsByThreadID(thread.getId());

		if ((newParticipants.size() == 0) && (oldParticipants != null)) {
			participantsRepository.deleteAll(oldParticipants);
		} else if ((newParticipants.size() > 0) && (oldParticipants == null)) {
			participantsRepository.saveAll(newParticipants);
		} else if ((newParticipants.size() > 0) && (oldParticipants != null)) {

			int i = oldParticipants.size() - 1;
			while (i >= 0) {
				Participants participant = oldParticipants.get(i);

				int index = findIndex(newParticipants, participant);
				if (index > -1) {
					newParticipants.remove(index);
					oldParticipants.remove(i);
				} else {
					oldParticipants.remove(i);
					participantsRepository.delete(participant);
				}
				i--;
			}
			if (newParticipants.size() > 0) {
				participantsRepository.saveAll(newParticipants);

			}

			i--;
		}
		if (newParticipants.size() > 0) {
			participantsRepository.saveAll(newParticipants);
		}

	}

	public int findIndex(List<Participants> participants, Participants participant) {
		int index = -1;
		for (int i = 0; i < participants.size(); i++) {
			Participants oldParticipant = participants.get(i);
			if (oldParticipant.getChiraghuser().getUserId() == participant.getChiraghuser().getUserId()) {
				index = i;
				break;
			}

		}

		return index;
	}

	public int findIndexOfAttachment(List<Attachments> attachments, Attachments attachment) {
		int index = -1;
		for (int i = 0; i < attachments.size(); i++) {
			Attachments oldAttachment = attachments.get(i);
			if (oldAttachment.getUrl() == attachment.getUrl()){
				index = i;
				break;
			}
			

		}

		return index;
	}
	public ResponseEntity getSentItems(int pageNumber, int pageSize) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			PageRequest pageRequest = PageRequest.of(pageNumber, pageSize);
			List<Threads> threads = new ArrayList<Threads>();
			Page<Threads> paginatedData = threadRepository.findSentItems(chiraghuser.getUserId(), pageRequest);

			threads = paginatedData.getContent();
			if (threads.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<ThreadDetailDTO> listOfSentItems = ObjectMapperUtils.mapAll(threads, ThreadDetailDTO.class);
			PaginatedResponseDTO paginatedResponse = new PaginatedResponseDTO(paginatedData, listOfSentItems);
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(paginatedResponse).collect(Collectors.toList()));

		}

		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}
	
	public ResponseEntity getTrashedItems(int pageNumber, int pageSize) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			PageRequest pageRequest = PageRequest.of(pageNumber, pageSize);
			List<Threads> threads = new ArrayList<Threads>();
			Page<Threads> paginatedData = threadRepository.findDeletedItems(chiraghuser.getUserId(), pageRequest);

			threads = paginatedData.getContent();
			if (threads.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<ThreadDetailDTO> listOfSentItems = ObjectMapperUtils.mapAll(threads, ThreadDetailDTO.class);
			PaginatedResponseDTO paginatedResponse = new PaginatedResponseDTO(paginatedData, listOfSentItems);
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(paginatedResponse).collect(Collectors.toList()));

		}

		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity getDrafts(int pageNumber, int pageSize) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			PageRequest pageRequest = PageRequest.of(pageNumber, pageSize);
			List<Threads> threads = new ArrayList<Threads>();
			Page<Threads> paginatedData = threadRepository.findDraftItems(chiraghuser.getUserId(), pageRequest);
			threads = paginatedData.getContent();
			if (threads.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<ThreadDetailDTO> listOfDrafts = ObjectMapperUtils.mapAll(threads, ThreadDetailDTO.class);

			PaginatedResponseDTO paginatedResponse = new PaginatedResponseDTO(paginatedData, listOfDrafts);
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(paginatedResponse).collect(Collectors.toList()));

		}

		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity getInbox(int pageNumber, int pageSize) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			List<Threads> threads = new ArrayList<Threads>();
			Page<Threads> paginatedData = threadRepository.findInboxItems(chiraghuser.getUserId(),
					PageRequest.of(pageNumber, pageSize));

			threads = paginatedData.getContent();
			threads = this.returnOnlyUserAsParticipant(threads, chiraghuser);
			if (threads.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<ThreadDetailDTO> listOfInboxItems = ObjectMapperUtils.mapAll(threads, ThreadDetailDTO.class);
			PaginatedResponseDTO paginatedResponse = new PaginatedResponseDTO(paginatedData, listOfInboxItems);
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(paginatedResponse).collect(Collectors.toList()));

		}

		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}
	
	List<Threads> returnOnlyUserAsParticipant(List<Threads> inboxItems, Chiraghuser user){
		List<Threads> filteredInboxItems = new ArrayList<Threads>();
		for (Threads inboxItem : inboxItems) {
			inboxItem.setParticipants(filteredUsers(inboxItem,user));
			filteredInboxItems.add(inboxItem);
		}
		return filteredInboxItems;
		
	}
	List<Participants> filteredUsers(Threads inboxItem,Chiraghuser user) {
		List<Participants> participants = new ArrayList<Participants>();
		for (Participants participant : inboxItem.getParticipants()) {
			if (participant.getChiraghuser().getUserId() == user.getUserId()) {
				participants.add(participant);
				break;
			}
		}
		return participants;
	}

	public ResponseEntity getThreadDetails(int threadId) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			Threads threads = threadRepository.findThreadByID(threadId);
			if (threads == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			ThreadDetailDTO threadDetailsDTO = mapper.map(threads, ThreadDetailDTO.class);
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(threadDetailsDTO).collect(Collectors.toList()));

		}

		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity importantThread(ThreadListDTO threads, boolean isImportant) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");

			int updateResult = participantsRepository.markAsImportant(chiraghuser.getUserId(), threads.getThreadIds(),
					isImportant);

			if (updateResult < 1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
//				ParticipantsDTO participantsDTO = ObjectMapperUtils.map(participants, ParticipantsDTO.class);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity inboxDeleteThread(ThreadListDTO threads) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");

			Integer integer = participantsRepository.markDelete(true, threads.getThreadIds(), chiraghuser.getUserId());

			if (integer < 1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
//				ParticipantsDTO participantsDTO = ObjectMapperUtils.map(participants, ParticipantsDTO.class);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity outboxDeleteThread(ThreadListDTO threads) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			Integer integer = threadRepository.markDeleted(true, threads.getThreadIds());
			if (integer < 1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
//				ParticipantsDTO participantsDTO = ObjectMapperUtils.map(participants, ParticipantsDTO.class);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);
			}
		}

		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity deleteAttachment(int attachmentId) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			Attachments attachments = attachmentsRepository.findAttachment(attachmentId);
			if (attachments == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				attachmentsRepository.deleteById(attachments.getId());
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);
			}

		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}
	
	public ResponseEntity markAsRead(ThreadListDTO threadIds) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			Integer updateResult = participantsRepository.markAsRead(new Date(),chiraghuser.getUserId(),  threadIds.getThreadIds());
			if (updateResult < 1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);
			}

		}
		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}
	
	public ResponseEntity markAsUnRead(ThreadListDTO threadIds) {
		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			Integer updateResult = participantsRepository.markAsUnRead(chiraghuser.getUserId(),  threadIds.getThreadIds());
			if (updateResult < 1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);
			}

		}
		catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

}
