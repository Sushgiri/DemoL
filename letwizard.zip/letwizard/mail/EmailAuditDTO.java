package com.bestercapitalmedia.letwizard.mail;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EmailAuditDTO {

	private String device;
	private String location;
	private String ipAddress;
	private String time;

}
