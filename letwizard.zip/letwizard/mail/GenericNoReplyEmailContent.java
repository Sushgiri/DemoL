package com.bestercapitalmedia.letwizard.mail;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@Service
public class GenericNoReplyEmailContent extends EmailContent {

	@Autowired
	public Configuration config;

	private String fileName;
	private String to;
	private String subject;
	private String userName;
	private String title;
	private String body;
	private String propertyId;
	private String propertyTitle;
	private EmailDepositRefundDTO depositRefundBody;
	private EmailDTO emailBody;
	private String url;
	private String clientServiceEmail;
	private String amount;
	private String appUrl;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}

	public String getPropertyTitle() {
		return propertyTitle;
	}

	public void setPropertyTitle(String propertyTitle) {
		this.propertyTitle = propertyTitle;
	}

	public EmailDepositRefundDTO getDepositRefundBody() {
		return depositRefundBody;
	}

	public void setDepositRefundBody(EmailDepositRefundDTO depositRefundBody) {
		this.depositRefundBody = depositRefundBody;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getClientServiceEmail() {
		return clientServiceEmail;
	}

	public void setClientServiceEmail(String clientServiceEmail) {
		this.clientServiceEmail = clientServiceEmail;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getAppUrl() {
		return appUrl;
	}

	public void setAppUrl(String appUrl) {
		this.appUrl = appUrl;
	}

	public EmailDTO getEmailBody() {
		return emailBody;
	}

	public void setEmailBody(EmailDTO emailBody) {
		this.emailBody = emailBody;
	}

	public GenericNoReplyEmailContent() {
		super();

	}

	public GenericNoReplyEmailContent(String fileName, String to, String subject, String userName, String title,
			String body, String propertyId, String propertyTitle, EmailDepositRefundDTO depositRefundBody, String url,
			String otp, String clientServiceEmail, String amount, String appUrl, EmailDTO emailBody) {
		super();

		this.fileName = fileName;
		this.to = to;
		this.subject = subject;
		this.userName = userName;
		this.title = title;
		this.body = body;
		this.propertyId = propertyId;
		this.propertyTitle = propertyTitle;
		this.depositRefundBody = depositRefundBody;
		this.url = url;
		this.clientServiceEmail = clientServiceEmail;
		this.amount = amount;
		this.appUrl = appUrl;
		this.emailBody = emailBody;

	}

	@Override
	public Message getMessage(Session session, String from) throws MessagingException, TemplateNotFoundException,
			MalformedTemplateNameException, ParseException, IOException, TemplateException {
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from, "letWizard"));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(getTo()));
		message.setSubject(getSubject());
		message.setContent(getHTMLString(), "text/html");
		return message;
	}

	public String getHTMLString() throws TemplateNotFoundException, MalformedTemplateNameException, ParseException,
			IOException, TemplateException {

		Map<String, Object> model = new HashMap<>();
		model.put("subject", getSubject());
		model.put("userName", getUserName());
		model.put("title", getTitle());
		model.put("body", getBody());
		model.put("propertyId", getPropertyId());
		model.put("propertyTitle", getPropertyTitle());
		model.put("depositRefundBody", getDepositRefundBody());
		model.put("url", getUrl());
		model.put("clientServiceEmail", getClientServiceEmail());
		model.put("amount", getAmount());
		model.put("appUrl", getAppUrl());
		model.put("emailBody", getEmailBody());

		String html = "";
		Template t;

		t = config.getTemplate(getFileName());
		html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);

		// config.getTemplate("email-template.ftl");
		// System.out.println(html);
		return html;
	}

}
