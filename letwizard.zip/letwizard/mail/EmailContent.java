package com.bestercapitalmedia.letwizard.mail;
import javax.mail.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

import java.io.IOException;

import javax.mail.Message;
import javax.mail.MessagingException;

@Service
public abstract class EmailContent {

	
	
	public EmailContent() {
		super();
	}
	public abstract Message getMessage(Session session, String from) throws MessagingException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException;
	
}
