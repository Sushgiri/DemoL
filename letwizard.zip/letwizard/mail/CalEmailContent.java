package com.bestercapitalmedia.letwizard.mail;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.UUID;

import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.joda.time.DateTime;
import org.springframework.stereotype.Service;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

import org.apache.commons.lang3.StringUtils;

@Service
public class CalEmailContent extends EmailContent {

	private List<String> to;
	private String from;
	private String invitationTitle;
	private String subject;
	private String body;
	private Date invitationDate;
	private String location;
	

	public List<String> getTo() {
		return to;
	}

	public void setTo(List<String> to) {
		this.to = to;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	
	public String getInvitationTitle() {
		return invitationTitle;
	}

	public void setInvitationTitle(String invitationTitle) {
		this.invitationTitle = invitationTitle;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
	
	
	public Date getInvitationDate() {
		return invitationDate;
	}

	public void setInvitationDate(Date invitationDate) {
		this.invitationDate = invitationDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public CalEmailContent() {
		super();
	}

	@Override
	public Message getMessage(Session session, String from) throws MessagingException, IOException{

		
		MimeMessage message = new MimeMessage(session);
        message.addHeaderLine("method=REQUEST");
        message.addHeaderLine("charset=UTF-8");
        message.addHeaderLine("component=VEVENT");

        message.setFrom(new InternetAddress(getFrom(),"letWizard"));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(StringUtils.join(getTo(), ',')));
        message.setSubject(getSubject());

        StringBuffer sb = new StringBuffer();

//        StringBuffer buffer = sb.append("BEGIN:VCALENDAR\n" + 
//        		"VERSION:2.0\n" + 
//        		"CALSCALE:GREGORIAN\n" + 
//        		"BEGIN:VEVENT\n" + 
//        		"METHOD:REQUEST\n" +
//        		getAttendies() +
////        		ATTENDEE;CN=Muhammad Nayab Butt;CUTYPE=INDIVIDUAL;EMAIL=nayab.bester@gmai
//        		"SUMMARY:" + getSubject() + " \n" + 
//        		"DTSTART;TZID=Asia/Dubai:"+ getICSDate(getInvitationDate()) +" \n" + 
//        		/*"DTEND;TZID=Asia/Dubai:20190802T110400\n" + */
//        		"LOCATION:"+ getLocation() +" \n" + 
//        		"DESCRIPTION:" + getBody() + " \n" + 
//        		"STATUS:CONFIRMED\n" + 
//        		"SEQUENCE:3\n" + 
//        		"BEGIN:VALARM\n" + 
//        		"TRIGGER:-PT10M\n" + 
//        		"DESCRIPTION:" + getBody() + " \n" + 
//        		"ACTION:DISPLAY\n" + 
//        		"END:VALARM\n" + 
//        		"END:VEVENT\n" +  
//        		"END:VCALENDAR");
        
        StringBuffer buffer = sb.append("BEGIN:VCALENDAR\n" + 
        		"PRODID:-//Google Inc//Google Calendar 70.9054//EN\n" + 
        		"VERSION:2.0\n" + 
        		"CALSCALE:GREGORIAN\n" + 
        		"BEGIN:VEVENT\n" + 
        		getICSDate(getInvitationDate()) +
   
        		getOrganizer() + 
        		getUniqueID() + 
        		getAttendies() +
        		"X-MICROSOFT-CDO-OWNERAPPTID:23634232\n" + 
        		"DESCRIPTION:" + getBody() + "\n" + 
        		"LOCATION:"+ getLocation() +" \n" + 
        		"SEQUENCE:0\n" + 
        		"STATUS:CONFIRMED\n" + 
        		"SUMMARY:" + getInvitationTitle() + " \n" + 
        		"TRANSP:OPAQUE\n" + 
        		"END:VEVENT\n" + 
        		"END:VCALENDAR\n" );

        // Create the message part
        BodyPart messageBodyPart = new MimeBodyPart();

        // Fill the message
        messageBodyPart.setHeader("Content-Class", "urn:content-  classes:calendarmessage");
        messageBodyPart.setHeader("Content-ID", "calendar_message");
        messageBodyPart.setDataHandler(new DataHandler(
                new ByteArrayDataSource(buffer.toString(), "text/calendar")));// very important

        // Create a Multipart
        Multipart multipart = new MimeMultipart();

        // Add part one
        multipart.addBodyPart(messageBodyPart);

        // Put parts in message
        message.setContent(multipart);
		return message;
	}
	public String getOrganizer() {
		String organizer = "ORGANIZER;CN=" + from  + ":mailto:" + from + "\n";
		return organizer;

	}
	public String getUniqueID() {
		return "UID:" + UUID.randomUUID().toString().toUpperCase() + "\n";
		
	}
	public String getAttendies() {
		String attendies = new String();
		for (String receiver : getTo()) {
			//attendies = attendies +	"ATTENDEE;CN=" + receiver +";CUTYPE=INDIVIDUAL;EMAIL="+receiver + ":mailto:" + receiver + "\n";
			attendies = attendies +	"ATTENDEE;CUTYPE=INDIVIDUAL;CN=" + receiver +";X-NUM-GUESTS=0" +  ":mailto:" + receiver + "\n";
		} 
		return attendies;
	}

	
	public String getICSDate(Date date) {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss");  
        String strDate = "DTSTART:" + dateFormat.format(date)+ "Z"  + "\n";  
        return  strDate; 
	}
}

