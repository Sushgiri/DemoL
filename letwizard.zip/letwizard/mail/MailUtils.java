package com.bestercapitalmedia.letwizard.mail;

public class MailUtils {
	
	public class MailSubject{
		public static final String SMS_OTP = "Sms Otp";
		public static final String EMAIL_OTP = "Email Otp";
		
	}

}
