package com.bestercapitalmedia.letwizard.mail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.inbox.ThreadRequestDTO;
import com.bestercapitalmedia.letwizard.inbox.ThreadsService;
import com.bestercapitalmedia.letwizard.systemevents.MailManagerEvent;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.lowagie.text.DocumentException;

import freemarker.core.ParseException;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@Service
public class MailManager implements ApplicationEventPublisherAware {

	private static final Logger logger = LoggerFactory.getLogger(MailManager.class);

	@Autowired
	UserRepository userRepository;

	@Autowired
	private ThreadsService threadsService;

	@Autowired
	private HTMLEmailContent htmlEmailContent;

	@Autowired
	private HTMLGenericEmailContent htmlGenericEmailContent;

	@Autowired
	private HTMLSupportEmailContent htmlSupportEmailContent;

	@Autowired
	private TextEmailContent textlEmailContent;
	@Autowired
	private MailService mailService;

	@Autowired
	private CalEmailContent calEmailContent;

	@Autowired
	private TextEmailContent textEmailContent;
	@Autowired
	private Environment environment;

	@Autowired
	private GenericSupportEmailContent genericSupportEmailContent;

	@Autowired
	private GenericNoReplyEmailContent genericNoReplyEmailContent;

	@Autowired
	private ApplicationEventPublisher publisher;

	public void sendInvitation(List<String> to, String from, String subject, String invitationTitle, String description,
			String location, Date meetingTime, Boolean async) {
		try {
			calEmailContent.setTo(to);
			calEmailContent.setFrom(from);
			calEmailContent.setSubject(subject);
			calEmailContent.setInvitationTitle(invitationTitle);
			calEmailContent.setLocation(location);
			calEmailContent.setBody(description);
			calEmailContent.setInvitationDate(meetingTime);

			logger.info("Sending Email -> invitation email from {}, to {}, with subject {}", from, to, subject);
			publisher.publishEvent(new MailManagerEvent(this, null, calEmailContent, null, async, "invitation"));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Async
	public void sendSystemMailToUser(String subject, String body, Chiraghuser user)
			throws DocumentException, IOException, TemplateException {
		ThreadRequestDTO request = new ThreadRequestDTO();
		request.setBody(body);
		request.setSubject(subject);
		request.setIsDraft(false);
		List<Integer> participants = new ArrayList<>();
		participants.add(user.getUserId());
		request.setParticipants(participants);
		threadsService.createBotThread(request);
	}

	@Async
	public void sendSystemMailToUser(String subject, String body, String email)
			throws DocumentException, IOException, TemplateException {
		ThreadRequestDTO request = new ThreadRequestDTO();
		request.setBody(body);
		request.setSubject(subject);
		request.setIsDraft(false);
		List<Integer> participants = new ArrayList<>();
		participants.add(userRepository.findByEmail(email).getUserId());
		request.setParticipants(participants);
		threadsService.createBotThread(request);
	}

	@Async
	public void sendSystemMailToUser(String subject, String body, List<String> email)
			throws DocumentException, IOException, TemplateException {
		ThreadRequestDTO request = new ThreadRequestDTO();
		request.setBody(body);
		request.setSubject(subject);
		request.setIsDraft(false);
		List<Integer> participants = new ArrayList<>();
		for (String emailAddress : email) {
			participants.add(userRepository.findByEmail(emailAddress).getUserId());
		}
		request.setParticipants(participants);
		threadsService.createBotThread(request);
	}
	// --------------------- new Email templates implimentation
	// -----------------------

	// ............ Support Emails ....................
	/*
	 * account activation forgot password Done
	 */
	public void sendGenericSupportEmail(String to, String subject, String userName, String fileName, String url,
			String date, String clientServiceEmail) throws TemplateNotFoundException, MalformedTemplateNameException,
			ParseException, DocumentException, IOException, TemplateException {

		String appURL = environment.getProperty("APP_URL");
		appURL = appURL.replaceAll("^\"|\"$", "");

		genericSupportEmailContent.setTo(to);
		genericSupportEmailContent.setFileName(fileName);
		genericSupportEmailContent.setSubject(subject);
		genericSupportEmailContent.setUrl(url);
		genericSupportEmailContent.setUserName(userName);
		genericSupportEmailContent.setDate(date);
		genericSupportEmailContent.setAppUrl(appURL);
		genericSupportEmailContent.setClientServiceEmail(clientServiceEmail);

		try {
			logger.info("Sending Email -> support email to {}, with subject {}", to, subject);
			publisher.publishEvent(new MailManagerEvent(this, genericSupportEmailContent, null, null, null, "support"));
		} catch (Exception e) {

		}

	}
	// ............ No Reply Emails ....................

	/*
	 * transfer(within chiragh) otp transfer(outside chiragh) otp add update bank
	 * account otp property submmited success seller security deposit refund buyer
	 * security deposit refund move to unsold Alert security otp for auction
	 * specification verification otp for bid OutBid bid confirmation winning bidder
	 * highestBidder Security deposit forfeited (buyer/seller) audit user logs email
	 * done
	 */
	public void sendHTML(String to, String subject, String body, String userName, String clientServiceEmail,
			String fileName, String propertyId, String propertyTitle, String title, String url, String amount,
			EmailDepositRefundDTO emailDepositRefundBody, EmailDTO emailBody) throws TemplateNotFoundException,
			MalformedTemplateNameException, ParseException, DocumentException, IOException, TemplateException {

		String appURL = environment.getProperty("APP_URL");
		appURL = appURL.replaceAll("^\"|\"$", "");

		genericNoReplyEmailContent.setTo(to);
		genericNoReplyEmailContent.setFileName(fileName);
		genericNoReplyEmailContent.setSubject(subject);
		genericNoReplyEmailContent.setTitle(title);
		genericNoReplyEmailContent.setBody(body);
		genericNoReplyEmailContent.setUserName(userName.substring(0, 1).toUpperCase() + userName.substring(1).toLowerCase());
		genericNoReplyEmailContent.setPropertyId(propertyId);
		genericNoReplyEmailContent.setPropertyTitle(propertyTitle);
		genericNoReplyEmailContent.setDepositRefundBody(emailDepositRefundBody);
		genericNoReplyEmailContent.setUrl(url);
		genericNoReplyEmailContent.setClientServiceEmail(clientServiceEmail);
		genericNoReplyEmailContent.setAmount(amount);
		genericNoReplyEmailContent.setAppUrl(appURL);
		genericNoReplyEmailContent.setEmailBody(emailBody);

		try {
			logger.info("Sending Email -> html email to {}, with subject {}", to, subject);
			publisher.publishEvent(new MailManagerEvent(this, null, null, genericNoReplyEmailContent, null, "html"));
		} catch (Exception e) {

		}
	}

	@Async
	public String sendPlainHTMLEmailForEWallet(String to, String subject, String body, String fileName, String userName)
			throws TemplateException, IOException, DocumentException {

		String appURL = environment.getProperty("APP_URL");
		appURL = appURL.replaceAll("^\"|\"$", "");
		genericNoReplyEmailContent.setBody(body);
		genericNoReplyEmailContent.setTo(to);
		genericNoReplyEmailContent.setSubject(subject);
		genericNoReplyEmailContent.setUserName(userName);
		genericNoReplyEmailContent.setFileName(fileName);
		genericNoReplyEmailContent.setAppUrl(appURL);

		this.sendSystemMailToUser(subject, genericNoReplyEmailContent.getHTMLString(), to);
		return mailService.sendNoReplyEmail(genericNoReplyEmailContent);

	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;
	}

	@Async
	public String sendPlainHTMLEmailForRentalBidConfirmation(String to, String subject, EmailDTO body, String fileName,
			String userName) throws TemplateNotFoundException, MalformedTemplateNameException, ParseException,
			DocumentException, IOException, TemplateException {

		String appURL = environment.getProperty("APP_URL");
		appURL = appURL.replaceAll("^\"|\"$", "");
		genericNoReplyEmailContent.setEmailBody(body);
		genericNoReplyEmailContent.setTo(to);
		genericNoReplyEmailContent.setSubject(subject);
		genericNoReplyEmailContent.setUserName(userName);
		genericNoReplyEmailContent.setFileName(fileName);
		genericNoReplyEmailContent.setAppUrl(appURL);

		this.sendSystemMailToUser(subject, genericNoReplyEmailContent.getHTMLString(), to);
		return mailService.sendNoReplyEmail(genericNoReplyEmailContent);

	}

}
