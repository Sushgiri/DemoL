package com.bestercapitalmedia.letwizard.mail;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.DocumentException;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@Service
public class PDFEmailContent extends EmailContent{

	
	@Autowired
	private Configuration config;
	
	private String fileName;
	private String to;
	private String subject;
	private String body;
	
	
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	
	
	

	public PDFEmailContent() {
		super();
		
	}
	public PDFEmailContent(String fileName, String to, String subject, String body) {
		super();
		this.fileName = fileName;
		this.to = to;
		this.subject = subject;
		this.body = body;
		
	}
	@Override
	public Message getMessage(Session session, String from) throws MessagingException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException {
		try {
			createPDF(renderHTML());
		} catch (DocumentException | IOException e) {
			
			e.printStackTrace();
		}
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from,"letWizard"));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(getTo()));
		message.setSubject(getSubject());
		
		message.setContent(getPDF());
		
		return message;
	}
	
	public Multipart getPDF() throws MessagingException {
		 BodyPart messageBodyPart = new MimeBodyPart();

		 // Now set the actual message
		 messageBodyPart.setText("This is message body");

		 Multipart multipart = new MimeMultipart();

		 // Set text message part
		 multipart.addBodyPart(messageBodyPart);

		 // Part two is attachment
		 messageBodyPart = new MimeBodyPart();
		 String filename = "So4712641.pdf";
		 DataSource source = new FileDataSource(filename);
		 messageBodyPart.setDataHandler(new DataHandler(source));
		 messageBodyPart.setFileName(filename);
		 multipart.addBodyPart(messageBodyPart);
		 return multipart;

	}
	public String renderHTML() {
		Map<String, Object> model = new HashMap<>();
		model.put("subject", getSubject());
		
		model.put("body", getBody());
		model.put("buttonTitle", "NO Button Required");
		String html = "";
		Template t;
		try {
			t = config.getTemplate(getFileName());
			html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
		} catch (IOException e) {
			e.printStackTrace();
			
		} catch (TemplateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				//config.getTemplate("email-template.ftl");
        System.out.println(html);
	    return html;
	}
	
	public void createPDF(String html) throws DocumentException, IOException {
	    FileUtils.writeByteArrayToFile(new File("So4712641.pdf"), toPdf(html));
	    
	  }
	private static byte[] toPdf(String html) throws DocumentException, IOException {
	    final ITextRenderer renderer = new ITextRenderer();
	    renderer.setDocumentFromString(html);
	    renderer.layout();
	    try (ByteArrayOutputStream fos = new ByteArrayOutputStream(html.length())) {
	      renderer.createPDF(fos);
	      return fos.toByteArray();
	    }
	  }
}
