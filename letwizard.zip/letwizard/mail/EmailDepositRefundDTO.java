package com.bestercapitalmedia.letwizard.mail;

public class EmailDepositRefundDTO {

	private String propertyId;
	private String propertyTitle;
	private String currentHighestBid;
	private String currentExchangeCurrency;
	private String currentExchangeAmount;
	private String previousBid;
	private String previousBidExchangeCurrency;
	private String previousBidExchangeAmount;
	private String auctionUrl;
	private String auctionDepositAmount;
	private String auctionEndDate;
	private String amountAndCurrency;

	public EmailDepositRefundDTO() {

	}

	public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}

	public String getPropertyTitle() {
		return propertyTitle;
	}

	public void setPropertyTitle(String propertyTitle) {
		this.propertyTitle = propertyTitle;
	}

	public String getCurrentHighestBid() {
		return currentHighestBid;
	}

	public void setCurrentHighestBid(String currentHighestBid) {
		this.currentHighestBid = currentHighestBid;
	}

	public String getPreviousBid() {
		return previousBid;
	}

	public void setPreviousBid(String previousBid) {
		this.previousBid = previousBid;
	}

	public String getPreviousBidExchangeCurrency() {
		return previousBidExchangeCurrency;
	}

	public void setPreviousBidExchangeCurrency(String previousBidExchangeCurrency) {
		this.previousBidExchangeCurrency = previousBidExchangeCurrency;
	}

	public String getPreviousBidExchangeAmount() {
		return previousBidExchangeAmount;
	}

	public void setPreviousBidExchangeAmount(String previousBidExchangeAmount) {
		this.previousBidExchangeAmount = previousBidExchangeAmount;
	}

	public String getAuctionUrl() {
		return auctionUrl;
	}

	public void setAuctionUrl(String auctionUrl) {
		this.auctionUrl = auctionUrl;
	}

	public String getCurrentExchangeCurrency() {
		return currentExchangeCurrency;
	}

	public void setCurrentExchangeCurrency(String currentExchangeCurrency) {
		this.currentExchangeCurrency = currentExchangeCurrency;
	}

	public String getCurrentExchangeAmount() {
		return currentExchangeAmount;
	}

	public void setCurrentExchangeAmount(String currentExchangeAmount) {
		this.currentExchangeAmount = currentExchangeAmount;
	}

	public String getAuctionDepositAmount() {
		return auctionDepositAmount;
	}

	public void setAuctionDepositAmount(String auctionDepositAmount) {
		this.auctionDepositAmount = auctionDepositAmount;
	}

	public String getAuctionEndDate() {
		return auctionEndDate;
	}

	public void setAuctionEndDate(String auctionEndDate) {
		this.auctionEndDate = auctionEndDate;
	}

	public String getAmountAndCurrency() {
		return amountAndCurrency;
	}

	public void setAmountAndCurrency(String amountAndCurrency) {
		this.amountAndCurrency = amountAndCurrency;
	}
	

}
