package com.bestercapitalmedia.letwizard.mail;

public class EmailDTO extends EmailAuditDTO {

	private String propertyId;
	private String propertyTitle;
	private String openPrice;
	private String bidAmount;
	private String auctionEndDate;
	private String auctionUrl;
	private String exchangeAmount;
	private String exchangeCurrency;
	private String bidDepositExchangeAmount;
	private String bidDepositAmount;
	private String bidDate;
	private String footer;

	private String userName;
	private String userCode;
	private String baseCurrency;

	public String getBaseCurrency() {
		return baseCurrency;
	}

	public void setBaseCurrency(String baseCurrency) {
		this.baseCurrency = baseCurrency;
	}

	public EmailDTO() {

	}

	public String getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(String propertyId) {
		this.propertyId = propertyId;
	}

	public String getPropertyTitle() {
		return propertyTitle;
	}

	public void setPropertyTitle(String propertyTitle) {
		this.propertyTitle = propertyTitle;
	}

	public String getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(String openPrice) {
		this.openPrice = openPrice;
	}

	public String getBidAmount() {
		return bidAmount;
	}

	public void setBidAmount(String bidAmount) {
		this.bidAmount = bidAmount;
	}

	public String getExchangeAmount() {
		return exchangeAmount;
	}

	public void setExchangeAmount(String exchangeAmount) {
		this.exchangeAmount = exchangeAmount;
	}

	public String getAuctionEndDate() {
		return auctionEndDate;
	}

	public void setAuctionEndDate(String auctionEndDate) {
		this.auctionEndDate = auctionEndDate;
	}

	public String getAuctionUrl() {
		return auctionUrl;
	}

	public void setAuctionUrl(String auctionUrl) {
		this.auctionUrl = auctionUrl;
	}

	public String getExchangeCurrency() {
		return exchangeCurrency;
	}

	public void setExchangeCurrency(String exchangeCurrency) {
		this.exchangeCurrency = exchangeCurrency;
	}

	public String getBidDate() {
		return bidDate;
	}

	public void setBidDate(String bidDate) {
		this.bidDate = bidDate;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getBidDepositExchangeAmount() {
		return bidDepositExchangeAmount;
	}

	public void setBidDepositExchangeAmount(String bidDepositExchangeAmount) {
		this.bidDepositExchangeAmount = bidDepositExchangeAmount;
	}

	public String getBidDepositAmount() {
		return bidDepositAmount;
	}

	public void setBidDepositAmount(String bidDepositAmount) {
		this.bidDepositAmount = bidDepositAmount;
	}
}
