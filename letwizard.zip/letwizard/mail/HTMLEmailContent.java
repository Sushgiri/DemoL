package com.bestercapitalmedia.letwizard.mail;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@Service
public class HTMLEmailContent extends EmailContent {


	@Autowired
	public Configuration config;
	
	private String fileName;
	private String to;
	private String subject;
	private String body;
	private String url;
	private String actionButtonTitle;
	
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public String getActionButtonTitle() {
		return actionButtonTitle;
	}
	public void setActionButtonTitle(String actionButtonTitle) {
		this.actionButtonTitle = actionButtonTitle;
	}
	public HTMLEmailContent() {
		super();
		
	}
	
	
	
	public HTMLEmailContent(String fileName, String to, String subject, String body, String url,
			String actionButtonTitle) {
		super();
		
		this.fileName = fileName;
		this.to = to;
		this.subject = subject;
		this.body = body;
		this.url = url;
		this.actionButtonTitle = actionButtonTitle;
		
		
	}
	@Override
	public Message getMessage(Session session, String from) throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, MessagingException, IOException, TemplateException {
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from, "letWizard"));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(getTo()));
		message.setSubject(getSubject());
		message.setContent(getHTMLString(), "text/html");;
		return message;
	}
	public String getHTMLString() throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException  {
		
		
		Map<String, Object> model = new HashMap<>();
		model.put("subject", getSubject());
		model.put("url", getUrl());
		model.put("body", getBody());
		model.put("buttonTitle", getActionButtonTitle());
		String html = "";
		Template t;
		
		t = config.getTemplate(getFileName());
		html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
		
				//config.getTemplate("email-template.ftl");
		// System.out.println(html);
	    return html;
	}
	
	
	
}
