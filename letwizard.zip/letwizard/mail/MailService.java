package com.bestercapitalmedia.letwizard.mail;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailSender;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.constants.EmailMessages;

// TODO: Auto-generated Javadoc
/**
 * The Class MailService.
 */
@Service
public class MailService {

	
	//public static String fromEmailAddress = "noreply@letwizard.com";
	/** The from email. */
	@Value("${app.email.from}")
	private String fromEmail;

	/** The app url. */
	@Value("${app.url}")
	private String appUrl;

	/** The reset password url. */
	@Value("${resetPassword.url}")
	private String resetPasswordUrl;

	/** The support email. */
	@Value("${app.email.support}")
	private String supportEmail;

	/** The SMTP Sender Email Address. */
	@Value("${smtp.email.address}")
	private String smtpSenderEmail;

	/** The SMTP Sender Email Password. */
	@Value("${smtp.email.password}")
	private String smtpSenderPassword;
	
	/** The mail sender. */
	@Autowired
	private MailSender mailSender;

	/** The java mail sender. */
	@Autowired
	private JavaMailSender javaMailSender;
		
	/*public static String fromSupportEmailAddress = "noreply@letwizard.com";
	public static String fromSupportEmailPassword = "Noreply@2022";
	
	public static String fromInfoEmailAddress = "noreply@letwizard.com";
	public static String fromInfoEmailPassword = "Noreply@2022";
	
	public static String fromNoReplyEmailAddress = "noreply@letwizard.com";
	public static String fromNoReplyEmailPassword = "Noreply@2022";*/



	

	/**
	 * Send mail.
	 *
	 * @param to
	 *            the to
	 * @param subject
	 *            the subject
	 * @param body
	 *            the body
	 */
	public String sendMail(String to, String subject, String body) {
		/*final String username = "noreply@letwizard.com";
		final String password = "Noreply@2022";*/

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");
		//props.put("mail.mime.allowutf8", true);
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(smtpSenderEmail));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			
			message.setSubject(subject);
			message.setText(body);
			

			Transport.send(message);
			
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}

	public String sendEmail(EmailContent emailContent) {
		/*final String username = "noreply@letwizard.com";
		final String password = "Noreply@2022";*/

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.mime.allowutf8", true);
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			Transport.send(message);
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}

	
	@Async
	public String sendAsyncEmail(EmailContent emailContent) {
		/*final String username = "noreply@letwizard.com";
		final String password = "Noreply@2022";*/

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			
			Transport.send(message);
			
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}

	public String sendSupportEmail(EmailContent emailContent) {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.mime.allowutf8", true);
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			Transport.send(message);
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}
	
	public String sendInfoEmail(EmailContent emailContent) {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.mime.allowutf8", true);
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			Transport.send(message);
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}

	public String sendNoReplyEmail(EmailContent emailContent) {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.mime.allowutf8", true);
		
		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			Transport.send(message);
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}
	
	@Async
	public String sendAsyncSupportEmail(EmailContent emailContent) {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			
			Transport.send(message);
			
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}
	
	@Async
	public String sendAsyncInfoEmail(EmailContent emailContent) {

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			
			Transport.send(message);
			
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}
	
	@Async
	public String sendAsyncNoReplyEmail(EmailContent emailContent) {
		
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.office365.com");
		props.put("mail.smtp.port", "587");
		props.put("mail.mime.allowutf8", true);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(smtpSenderEmail, smtpSenderPassword);
			}
		});

		try {

			Message message = emailContent.getMessage(session, smtpSenderEmail);
			
			Transport.send(message);
			
			return EmailMessages.EMAIL_SENT_SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			return EmailMessages.EMAIL_SENT_FAILURE;
		}
	}



}
