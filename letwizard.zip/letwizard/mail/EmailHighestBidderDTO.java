package com.bestercapitalmedia.letwizard.mail;

import java.math.BigDecimal;
import java.util.Date;


public class EmailHighestBidderDTO {
	
	private String auctionId;
	private String auctionName;
	private String openPrice;
	private String highestBid;
	private String highestBidCurrency;
	private String highestBidExchangeAmount;
	
	public EmailHighestBidderDTO(){
		
	}

	public String getAuctionName() {
		return auctionName;
	}

	public void setAuctionName(String auctionName) {
		this.auctionName = auctionName;
	}

	
	public String getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(String openPrice) {
		this.openPrice = openPrice;
	}

	public String getHighestBid() {
		return highestBid;
	}

	public void setHighestBid(String highestBid) {
		this.highestBid = highestBid;
	}

	

	public String getHighestBidCurrency() {
		return highestBidCurrency;
	}

	public void setHighestBidCurrency(String highestBidCurrency) {
		this.highestBidCurrency = highestBidCurrency;
	}

	public String getHighestBidExchangeAmount() {
		return highestBidExchangeAmount;
	}

	public void setHighestBidExchangeAmount(String highestBidExchangeAmount) {
		this.highestBidExchangeAmount = highestBidExchangeAmount;
	}

	public String getAuctionId() {
		return auctionId;
	}

	public void setAuctionId(String auctionId) {
		this.auctionId = auctionId;
	}
	
	
	


}
