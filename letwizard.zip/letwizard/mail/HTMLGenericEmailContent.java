package com.bestercapitalmedia.letwizard.mail;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.core.ParseException;
import freemarker.template.Configuration;
import freemarker.template.MalformedTemplateNameException;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@Service
public class HTMLGenericEmailContent extends EmailContent {


	@Autowired
	public Configuration config;
	
	private String fileName;
	private String to;
	private String subject;
	private String url;
	private String header;
	private String title;
	private String userName;
	private EmailDTO body;
	private EmailDepositRefundDTO depositRefundBody;
	private EmailHighestBidderDTO highestBidderBody;


	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	
	public EmailDTO getBody() {
		return body;
	}
	public void setBody(EmailDTO body) {
		this.body = body;
	}
	public HTMLGenericEmailContent() {
		super();
		
	}

	public EmailDepositRefundDTO getDepositRefundBody() {
		return depositRefundBody;
	}
	public void setDepositRefundBody(EmailDepositRefundDTO depositRefundBody) {
		this.depositRefundBody = depositRefundBody;
	}
	
	public EmailHighestBidderDTO getHighestBidderBody() {
		return highestBidderBody;
	}
	public void setHighestBidderBody(EmailHighestBidderDTO highestBidderBody) {
		this.highestBidderBody = highestBidderBody;
	}
	public HTMLGenericEmailContent(String fileName, String to, String subject, String url, String header,String title, String userName, EmailDTO body) {
		super();
		
		this.fileName = fileName;
		this.to = to;
		this.subject = subject;
		this.url = url;
		this.header = header;
		this.title = title;
		this.userName = userName;
		this.body = body;
	
	}
	
	public HTMLGenericEmailContent(String fileName, String to, String subject, String url, String header,String title, String userName, EmailDepositRefundDTO depositRefundBody) {
		super();
		
		this.fileName = fileName;
		this.to = to;
		this.subject = subject;
		this.url = url;
		this.header = header;
		this.title = title;
		this.userName = userName;
		this.depositRefundBody = depositRefundBody;
	
	}
	
	public HTMLGenericEmailContent(String fileName, String to, String subject, String url, String header,String title, String userName, EmailHighestBidderDTO highestBidderBody) {
		super();
		
		this.fileName = fileName;
		this.to = to;
		this.subject = subject;
		this.url = url;
		this.header = header;
		this.title = title;
		this.userName = userName;
		this.highestBidderBody = highestBidderBody;
	
	}
	@Override
	public Message getMessage(Session session, String from) throws MessagingException, TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException {
		Message message = new MimeMessage(session);
		message.setFrom(new InternetAddress(from, "letWizard"));
		message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(getTo()));
		message.setSubject(getSubject());
		message.setContent(getHTMLString(), "text/html");
		return message;
	}
	public String getHTMLString() throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, IOException, TemplateException {
		
		
		Map<String, Object> model = new HashMap<>();
		model.put("subject", getSubject());
		model.put("url", getUrl());
		model.put("userName", getUserName());
		model.put("header", getHeader());
		model.put("title", getTitle());
		model.put("body", getBody());
		model.put("depositRefundBody", getDepositRefundBody());
		model.put("highestBidderBody", getHighestBidderBody());


		String html = "";
		Template t;
		
		t = config.getTemplate(getFileName());
		html = FreeMarkerTemplateUtils.processTemplateIntoString(t, model);
		
				//config.getTemplate("email-template.ftl");
		// System.out.println(html);
	    return html;
	}
	
}
