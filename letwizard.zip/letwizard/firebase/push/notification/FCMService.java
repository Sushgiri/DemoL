//package com.bestercapitalmedia.letwizard.firebase.push.notification;
//
//import java.util.Arrays;
//
//import javax.validation.Valid;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.bestercapitalmedia.chiragh.api.response.ResponseUtill;
//import com.bestercapitalmedia.chiragh.constants.ResponseCodes;
//import com.google.firebase.messaging.FirebaseMessaging;
//import com.google.firebase.messaging.Message;
//import com.google.firebase.messaging.Notification;
//
//@Service
//public class FCMService {
//
//	@Autowired
//	private ResponseUtill responseUtill;
//
//	public @ResponseBody ResponseEntity sendPushNotification(@Valid FirebasePushDTO firebasePushDTO) {
////		Message message = Message.builder().setToken(firebasePushDTO.getToken()).setNotification(
////				Notification.builder().setTitle(firebasePushDTO.getTitle()).setBody(firebasePushDTO.getBody()).build())
////				.build();
////		try {
////			String response = FirebaseMessaging.getInstance().send(message);
////			System.out.println("Successfully sent message: " + response);
////		} catch (Exception e) {
////			e.printStackTrace();
////		}
////		return responseUtill.getApiResponse(ResponseCodes.SUCCESS, "Push Notification Sent",
////				Arrays.asList(firebasePushDTO));
//
//		Message message = Message.builder().setToken(firebasePushDTO.getToken())
//				.putData("title", firebasePushDTO.getTitle()).putData("body", firebasePushDTO.getBody()).build();
//
//		try {
//			String response = FirebaseMessaging.getInstance().send(message);
//			System.out.println("Successfully sent message: " + response);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return responseUtill.getApiResponse(ResponseCodes.SUCCESS, "Push Notification Sent",
//				Arrays.asList(firebasePushDTO));
//	}
//}



