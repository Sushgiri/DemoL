//package com.bestercapitalmedia.letwizard.firebase.push.notification;
//
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import com.google.auth.oauth2.GoogleCredentials;
//import com.google.firebase.FirebaseApp;
//import com.google.firebase.FirebaseOptions;
//
//@Configuration
//public class FirebaseInitializer {
//
//
//
//	@Bean
//	public FirebaseApp initializeFirebase() throws IOException {
//		// FirebaseOptions options = null;
////		try {
////			FileInputStream serviceAccount = new FileInputStream(
////					new ClassPathResource("letwizard-316a6-ef8133f4e3a6.json").getFile());
//
////			FileInputStream serviceAccount = new FileInputStream(
////					"src/main/resources/letwizard-316a6-ef8133f4e3a6.json");
////
////			options = new FirebaseOptions.Builder().setCredentials(GoogleCredentials.fromStream(serviceAccount))
////					.build();
////
////			return FirebaseApp.initializeApp(options);
////		} catch (IOException | IllegalStateException e) {
////			e.printStackTrace();
////		}
////		return FirebaseApp.initializeApp(options);
//
//		if (FirebaseApp.getApps().isEmpty()) {
//			FileInputStream serviceAccount = new FileInputStream(
//					"src/main/resources/letwizard-316a6-ef8133f4e3a6.json");
//
//
//			if (serviceAccount == null) {
//				throw new IllegalStateException("Firebase service account key file not found");
//			}
//
//			FirebaseOptions options = new FirebaseOptions.Builder()
//					.setCredentials(GoogleCredentials.fromStream(serviceAccount)).build();
//
//			return FirebaseApp.initializeApp(options);
//		} else {
//			return FirebaseApp.getInstance();
//		}
//
//	}
//}



