//package com.bestercapitalmedia.letwizard.firebase.push.notification;
//
//import lombok.Data;
//
//@Data
//public class FirebasePushDTO {
//
//	private String token;
//	private String title;
//	private String body;
//}



