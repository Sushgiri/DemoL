package com.bestercapitalmedia.letwizard.balanceexports;

import java.util.List;

public interface UserDao {

	public final static String USER_BALANCES_PROC = "CALL getAllBalancesInAllCurrencies();";

	public List<UserBalanceModel> listOfBalances();

}
