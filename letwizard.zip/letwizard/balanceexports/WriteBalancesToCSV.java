package com.bestercapitalmedia.letwizard.balanceexports;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

public class WriteBalancesToCSV {
	static final Logger logger = LoggerFactory.getLogger(WriteBalancesToCSV.class);

	static void writeCSVFile(String csvFileName, List<UserBalanceModel> listOfUserBalances) {
		ICsvBeanWriter beanWriter = null;

		try {

			beanWriter = new CsvBeanWriter(new FileWriter(csvFileName), CsvPreference.STANDARD_PREFERENCE);

			String[] header = { "Chiragh_Id", "Customer_Name", "Currency", "Current_Balance", "Available_Balance",
					"Auction_Deposit", "Pending_Transactions", "Hold_Amount" };
			beanWriter.writeHeader(header);

			for (UserBalanceModel aBook : listOfUserBalances) {

				beanWriter.write(aBook, header);
			}

		} catch (IOException ex) {
			logger.info("Error writing the CSV file: " + ex);
		} finally {
			if (beanWriter != null) {
				try {
					beanWriter.close();

				} catch (IOException ex) {
					logger.error("Error closing the writer: " + ex);
				}
			}
		}
	}

}
