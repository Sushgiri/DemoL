package com.bestercapitalmedia.letwizard.balanceexports;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class UserRowMapper implements RowMapper<UserBalanceModel> {

	@Override
	public UserBalanceModel mapRow(ResultSet rs, int rowNum) throws SQLException {

		UserBalanceModel userBalanceModal = new UserBalanceModel();
		userBalanceModal.setAuction_Deposit(rs.getBigDecimal("auction_deposit"));
		userBalanceModal.setAvailable_Balance(rs.getBigDecimal("available_balance"));
		userBalanceModal.setChiragh_Id(rs.getString("chiragh_id"));
		userBalanceModal.setCurrency(rs.getString("currency"));
		userBalanceModal.setCurrent_Balance(rs.getBigDecimal("current_balance"));
		userBalanceModal.setCustomer_Name(rs.getString("customer_name"));
		userBalanceModal.setHold_Amount(rs.getBigDecimal("hold_amount"));
		userBalanceModal.setPending_Transactions(rs.getBigDecimal("pending_transactions"));

		return userBalanceModal;

	}
}
