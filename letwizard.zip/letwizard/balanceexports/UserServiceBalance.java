package com.bestercapitalmedia.letwizard.balanceexports;

import java.io.File;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.bestercapialmedia.letwizard.sns.AmazonSnsClient;
import com.bestercapitalmedia.letwizard.s3.AmazonClient;

import net.lingala.zip4j.exception.ZipException;

@Service
public class UserServiceBalance {

	@Autowired
	private UserDao userDao;

	private AmazonClient amazonClient;

	@Autowired
	public UserServiceBalance(AmazonClient amazonClient) {
		this.amazonClient = amazonClient;

	}

	private static final Logger logger = LoggerFactory.getLogger(UserServiceBalance.class);
	@Autowired
	private Environment environment;

	// @Scheduled(cron = "0 15 0 * * *")
	public void allBalances() {
		logger.info("Getting all user balances from database");
		List<UserBalanceModel> list = userDao.listOfBalances();
		UserBalanceModel userBalanceModalSalt = new UserBalanceModel();
		list.add(userBalanceModalSalt);
		List<File> filesToAdd = new ArrayList<>();
		String currency = list.get(0).getCurrency();
		List<UserBalanceModel> userCSVList = new ArrayList<>();
		for (UserBalanceModel userBalanceModal : list) {
			if (currency.equals(userBalanceModal.getCurrency())) {
				userCSVList.add(userBalanceModal);
			} else {
				logger.info("Writing data into CSV files");
				WriteBalancesToCSV.writeCSVFile("BalancesIn" + currency + ".csv", userCSVList);
				filesToAdd.add(new File("BalancesIn" + currency + ".csv"));
				userCSVList.clear();
				userCSVList.add(userBalanceModal);
				currency = userBalanceModal.getCurrency();
			}

		}
		logger.info("Generating Password for Zip File");
		String password = generateRandomPassword(14);

		try {
			logger.info("Compressing Files Into Zip and adding password to it");
			ZipPasswordUtils.compressWithPassword(filesToAdd, password);
		} catch (ZipException e) {
			e.printStackTrace();
		}
		File file = new File("DAX1135.zip");
		String fileName = getFileName(file);
		logger.info("Uploading Zip on amazon");
		String fileUrl = this.amazonClient.uploadFileToS3(fileName, file);
		logger.info("Deleting files from root folder");
		for (File files : filesToAdd) {
			files.delete();
		}
		file.delete();
		if (AmazonClient.isExported) {

			logger.info("Data upload at chiragh-data-exports is complete");
			
			if ("rentalstageInd".equals(this.environment.getProperty("spring.profiles.active"))) {
				logger.info("Sending email with download link and password");
				AmazonSnsClient.sendMessageToDAXPublishTopic(
						"Hello,\n" + "\n" + "Hoping that you are doing well, the download link for user balances for"
								+ " " + getDate() + " " + "is provided below along with the password for zip file.\n"
								+ "\n" + "Download Link: " + fileUrl+ "\n" + "Password for File: " + password + "\n"
								+ "\n" + "Best Regards,\n" + "letWizard Development Team");
				logger.info("Email Dispatched");
				AmazonClient.isExported = false;
			} 
			else if ("prod".equals(this.environment.getProperty("spring.profiles.active")) || "dr".equals(this.environment.getProperty("spring.profiles.active"))) {
				AmazonSnsClient.sendMessageToProdTopic(
						"Hello,\n" + "\n" + "Hoping that you are doing well, the download link for user balances for"
								+ " " + getDate() + " " + "is provided below along with the password for zip file.\n"
								+ "\n" + "Download Link: " + fileUrl + "\n" + "Password for File: " + password + "\n"
								+ "\n" + "Best Regards,\n" + "letWizard Development Team");
				logger.info("Email Dispatched");
				AmazonClient.isExported = false;
			}
		}

	}

	private String getDate() {
		String yesterdayDate = null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		DateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
		yesterdayDate = dateFormat.format(cal.getTime());
		return yesterdayDate;
	}

	private String getFileName(File multiPart) {

		return new Date().getTime() + "-" + multiPart.getName();

	}

	private static String generateRandomPassword(int len) {
		// ASCII range - alphanumeric (0-9, a-z, A-Z)
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

		SecureRandom random = new SecureRandom();
		StringBuilder sb = new StringBuilder();

		// each iteration of loop choose a character randomly from the given ASCII range
		// and append it to StringBuilder instance

		for (int i = 0; i < len; i++) {
			int randomIndex = random.nextInt(chars.length());
			sb.append(chars.charAt(randomIndex));
		}

		return sb.toString();
	}

}
