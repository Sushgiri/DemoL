package com.bestercapitalmedia.letwizard.balanceexports;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserBalanceModel {
	
	private BigDecimal Hold_Amount;
	private BigDecimal Pending_Transactions;
	private BigDecimal Available_Balance;
	private BigDecimal Auction_Deposit;
	private BigDecimal Current_Balance;
	private String Chiragh_Id;
	private String Customer_Name;
	private String Currency;	
}
