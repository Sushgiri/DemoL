package com.bestercapitalmedia.letwizard.balanceexports;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<UserBalanceModel> listOfBalances() {
		return jdbcTemplate.query(UserDao.USER_BALANCES_PROC, new UserRowMapper());
	}

}
