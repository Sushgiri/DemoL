package com.bestercapitalmedia.letwizard.balanceexports;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;

@RestController
@CrossOrigin
public class UserBalancesControllerTest {

	private static final Logger log = LoggerFactory.getLogger(UserBalancesControllerTest.class);

	@Autowired
	private UserServiceBalance userServiceBalance;

	@Autowired
	private ChiragUtill chiraghUtill;

	@Autowired
	private ResponseUtill responseUtill;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getUserBalancesInAllCurrenciesTest", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity GetUserBalancesTest(HttpServletRequest httpServletRequest) {

		try {
			userServiceBalance.allBalances();
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, "User Balances Exported", null);
		}

		catch (Exception e) {
			log.error(e.getMessage(), e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
}
