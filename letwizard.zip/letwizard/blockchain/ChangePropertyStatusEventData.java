package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class ChangePropertyStatusEventData {

	private String status;

}
