package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class RejectBidEventData {

	private String bid_id;
	private boolean seller_reject;

}
