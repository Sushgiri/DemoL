package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class RejectBidAttributesDTO {

	private String event_type;
	private RejectBidEventData event_data;

}
