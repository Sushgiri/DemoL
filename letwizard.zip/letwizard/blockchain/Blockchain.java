package com.bestercapitalmedia.letwizard.blockchain;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "blockchain_details")
public class Blockchain implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Column(name = "id", nullable = false)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name="property_id")
	private Integer property_id;
	
	@Column(name="bid_id")
	private Integer bid_id;
	
	@Column(name="sequence_id")
	private Integer sequence_id;
	
	@Column(name="identifier")
	private String identifier;
	
	@Column(name="token_id")
	private String token_id;
	
	@Column(name="request_payload")
	private String request_payload;
	
	@Column(name="response_payload")
	private String response_payload;
	
	@Column(name="is_exported")
	private Boolean is_exported;
	
	@Column(name="created_at")
	private Date created_at;
	
	@Column(name="updated_at")
	private Date updated_at;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProperty_id() {
		return property_id;
	}
	public void setProperty_id(Integer property_id) {
		this.property_id = property_id;
	}
	public Integer getBid_id() {
		return bid_id;
	}
	public void setBid_id(Integer bid_id) {
		this.bid_id = bid_id;
	}
	public Integer getSequence_id() {
		return sequence_id;
	}
	public void setSequence_id(Integer sequence_id) {
		this.sequence_id = sequence_id;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getToken_id() {
		return token_id;
	}
	public void setToken_id(String token_id) {
		this.token_id = token_id;
	}
	public String getRequest_payload() {
		return request_payload;
	}
	public void setRequest_payload(String request_payload) {
		this.request_payload = request_payload;
	}
	public String getResponse_payload() {
		return response_payload;
	}
	public void setResponse_payload(String response_payload) {
		this.response_payload = response_payload;
	}
	public Boolean getIs_exported() {
		return is_exported;
	}
	public void setIs_exported(Boolean is_exported) {
		this.is_exported = is_exported;
	}
	public Date getCreated_at() {
		return created_at;
	}
	public void setCreated_at(Date created_at) {
		this.created_at = created_at;
	}
	public Date getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(Date updated_at) {
		this.updated_at = updated_at;
	}

}
