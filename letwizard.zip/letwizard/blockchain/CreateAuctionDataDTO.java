package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class CreateAuctionDataDTO {
	
	private CreateAuctionAttributesDTO attributes;

}
