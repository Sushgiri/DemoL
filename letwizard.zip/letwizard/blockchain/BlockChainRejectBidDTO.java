package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class BlockChainRejectBidDTO {
	
	private RejectBidDataDTO data;
}
