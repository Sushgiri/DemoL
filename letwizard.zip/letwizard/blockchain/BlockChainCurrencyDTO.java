package com.bestercapitalmedia.letwizard.blockchain;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BlockChainCurrencyDTO {

	private String currency_id;
    private String name;
    private String code;
}
