package com.bestercapitalmedia.letwizard.blockchain;
import java.sql.Date;
import java.time.LocalDate;

import lombok.Data;

@Data
public class ClientDTO {

	private String client_id;
	private String name;
	private String url;
	private String dated;

}
