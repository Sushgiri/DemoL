package com.bestercapitalmedia.letwizard.blockchain;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.bid.BidDTO;
import com.bestercapitalmedia.letwizard.brokerage.proposal.BrokerageProposal;
import com.bestercapitalmedia.letwizard.brokerage.proposal.BrokerageProposalRepository;
import com.bestercapitalmedia.letwizard.city.City;
import com.bestercapitalmedia.letwizard.city.CityRepository;
import com.bestercapitalmedia.letwizard.constants.BasicErrorMessages;
import com.bestercapitalmedia.letwizard.constants.BlockChainConstants;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.country.Country;
import com.bestercapitalmedia.letwizard.country.CountryRepository;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.RequestChangeDto;
import com.bestercapitalmedia.letwizard.property.bidfinalize.BidFinalizedRequestDTO;
import com.bestercapitalmedia.letwizard.property.bidfinalize.Product;
import com.bestercapitalmedia.letwizard.property.bidfinalize.PropertyBidFinalizeRepository;
import com.bestercapitalmedia.letwizard.property.bidprocess.PropertybidprocessRepository;
import com.bestercapitalmedia.letwizard.systemevents.BlockChainChangePropertyStatusEvent;
import com.bestercapitalmedia.letwizard.systemevents.BlockChainFinalizeBidEvent;
import com.bestercapitalmedia.letwizard.systemevents.BlockChainRejectBidEvent;
import com.bestercapitalmedia.letwizard.systemevents.BlockChainSaveBidEvent;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrency;
import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrencyRepository;


@Service
public class BlockChainService implements ApplicationEventPublisherAware{

	private static final Logger logger = LoggerFactory.getLogger(BlockChainService.class);

	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private ApplicationEventPublisher publisher;
	
	@Autowired
	private UserRepository userRepositry;
	
	@Autowired
	private Environment environment;
	
	@Autowired
	private VoucherCurrencyRepository voucherRepositry;
	
	@Autowired
	private PropertybidprocessRepository propertyBidProcessRepositry;
	
	@Autowired
	private BrokerageProposalRepository brokerageProposalReposotry;
	
	@Autowired
	private PropertyRepository propertyRepositry;
	
	@Autowired
	private BlockchainRepository blockChainRepositry;
	
	@Autowired
	private PropertybidprocessRepository propertyBidProcess;
	
	@Autowired
	private CityRepository cityRepository;
	
	@Autowired
	private CountryRepository countryRepository;
	
	/*public ResponseEntity saveBlockchainBid(BidDTO property) {
		try {
			logger.info("In Save Bid, BlockChain Service");
			String tokenId = blockChainRepositry.getTokenIdByProductId(property.getProductId());
			VoucherCurrency voucherCurrency = voucherRepositry.getCurrencyById(property.getCurrencyId());
			Chiraghuser chiraghUser = userRepositry.findUserByEmail(property.getUserEmail());
			int sequenceId = propertyBidProcess.findTotalBidPlaced(property.getProductId());
			sequenceId = sequenceId+1;
			BlockChainChiraghUserDTO user = new BlockChainChiraghUserDTO();
			int bidId = propertyBidProcessRepositry.findBidId(property.getProductId(), property.getBidAmount(), property.getUserId());
			user.setCity(property.getCity());
			user.setCountry(property.getCountry());
			user.setUser_email(property.getUserEmail());
			user.setUser_id(property.getUserId().toString());
			user.setUser_name(property.getUserName());
			
			//clientDto code was commented before commenting this function
			ClientDTO client = new ClientDTO();
			client.setClient_id(String.valueOf(property.getClientId()));
			client.setDated(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX").format(new Date()));
			client.setName(this.environment.getProperty("spring.profiles.active"));
			client.setUrl(this.environment.getProperty("Paytab_URL")); 
			
			BlockChainCurrencyDTO currency = new BlockChainCurrencyDTO();
			currency.setCode(voucherCurrency.getCode());
			currency.setCurrency_id(voucherCurrency.getId().toString());
			currency.setName(voucherCurrency.getName());
			
			SaveBidEventData eventData = new SaveBidEventData();
			eventData.setBid_amount(property.getBidAmount().toString());
			eventData.setBid_id(String.valueOf(bidId));
	//		eventData.setClient(client);
			eventData.setDate_time(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX").format(new Date()));
			eventData.setFinalized(false);
			eventData.setOtp(property.getOtp());
			eventData.setSeller_reject(false);
			eventData.setSequence_id(sequenceId);
			eventData.setToken(chiraghUser.getToken());
			eventData.setUser(user);
			eventData.setVoucher_id(property.getVoucherId().toString());
			eventData.setCurrency(currency);
			
			SaveBidAttributesDTO attributes = new SaveBidAttributesDTO();
			attributes.setEvent_type(BlockChainConstants.TokenType.BCI_AUCTION_BID); // constant
			attributes.setEvent_data(eventData);
			
			SaveBidDataDTO data = new SaveBidDataDTO();
			data.setAttributes(attributes);
			
			BlockChainSaveBidDTO saveBidBCI = new BlockChainSaveBidDTO();
			saveBidBCI.setData(data);
            logger.info("Publishing save bid event, blockchain service");

			//publisher.publishEvent(new BlockChainSaveBidEvent(this, saveBidBCI, tokenId));
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESSFULLY , null);
			
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}*/

	   /*public ResponseEntity finalizeBlockchainBid(BidFinalizedRequestDTO property) {

		try {
			logger.info("In finalized bid, blockchain service");
			String tokenId = blockChainRepositry.getTokenIdByProductId(property.getPropertyId());
			Integer bidId = propertyBidProcessRepositry.findBidId(property.getPropertyId(), property.getBidAmount(), property.getUserId());
			FinalizeBidEventData eventData = new FinalizeBidEventData();
			eventData.setBid_id(bidId.toString());
			eventData.setFinalized(true);
			
			FinalizeBidAttributesDTO attributes = new FinalizeBidAttributesDTO();
			attributes.setEvent_type(BlockChainConstants.TokenType.FINALIZE_BID); // constant
			attributes.setEvent_data(eventData);
			
			FinalizeBidDataDTO data = new FinalizeBidDataDTO();
			data.setAttributes(attributes);
			
			BlockChainFinalizeBidDTO finalizeBidBCI = new BlockChainFinalizeBidDTO();
			finalizeBidBCI.setData(data);
			
			logger.info("Publishing finalized bid event, blockchain service");

			//publisher.publishEvent(new BlockChainFinalizeBidEvent(this, finalizeBidBCI, tokenId));
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESSFULLY , null);
			
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}*/
	/*public ResponseEntity rejectBlockchainBid(BidFinalizedRequestDTO property) {

		try {
			logger.info("Reject bid, blockchain service");
			String tokenId = blockChainRepositry.getTokenIdByProductId(property.getPropertyId());
			Integer bidId = propertyBidProcessRepositry.findBidId(property.getPropertyId(), property.getBidAmount(), property.getUserId());
			
			RejectBidEventData eventData = new RejectBidEventData();
			eventData.setBid_id(bidId.toString());
			eventData.setSeller_reject(true);		
		
			RejectBidAttributesDTO attributes = new RejectBidAttributesDTO();
			attributes.setEvent_type(BlockChainConstants.TokenType.REJECT_BID); // constant
			attributes.setEvent_data(eventData);
			
			RejectBidDataDTO data = new RejectBidDataDTO();
			data.setAttributes(attributes);
			
			BlockChainRejectBidDTO rejectBidBCI = new BlockChainRejectBidDTO();
			rejectBidBCI.setData(data);
			
			logger.info("Publishing reject bid event, blockchain service");
			//publisher.publishEvent(new BlockChainRejectBidEvent(this, rejectBidBCI, tokenId));
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESSFULLY , null);
			
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}*/
	
	/*public ResponseEntity archiveProperty(com.bestercapitalmedia.chiragh.property.bidfinalize.Product property) {
		try {
			logger.info("Archive Property, blockchain service");
			String tokenId = blockChainRepositry.getTokenIdByProductId(property.getProductId());
			ChangePropertyStatusEventData eventData = new ChangePropertyStatusEventData();
			
			eventData.setStatus("archived");		
		
			ChangePropertyStatusAttributesDTO attributes = new ChangePropertyStatusAttributesDTO();
			attributes.setEvent_type(BlockChainConstants.TokenType.ARCHIVE_PROPERTY); // constant
			attributes.setEvent_data(eventData);
			
			ChangePropertyStatusDataDTO data = new ChangePropertyStatusDataDTO();
			data.setAttributes(attributes);
			
			BlockChainChangePropertyStatusDTO archivePropertyBCI = new BlockChainChangePropertyStatusDTO();
			archivePropertyBCI.setData(data);
			
			logger.info("Publishing archive property event, blockchain service");
			//publisher.publishEvent(new BlockChainChangePropertyStatusEvent(this, archivePropertyBCI, tokenId));
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESSFULLY , null);
			
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}*/
	
	/*public ResponseEntity closeProperty(Product property) {
		try {
			logger.info("In closeProperty, blockchain service");
			String tokenId = blockChainRepositry.getTokenIdByProductId(property.getProductId()); 
			ChangePropertyStatusEventData eventData = new ChangePropertyStatusEventData();
			
			eventData.setStatus("completed");		
		
			ChangePropertyStatusAttributesDTO attributes = new ChangePropertyStatusAttributesDTO();
			attributes.setEvent_type(BlockChainConstants.TokenType.ARCHIVE_PROPERTY); // constant
			attributes.setEvent_data(eventData);
			
			ChangePropertyStatusDataDTO data = new ChangePropertyStatusDataDTO();
			data.setAttributes(attributes);
			
			BlockChainChangePropertyStatusDTO archivePropertyBCI = new BlockChainChangePropertyStatusDTO();
			archivePropertyBCI.setData(data);
			
			//String tokenId = "";
			logger.info("Publishing close property event, blockchain service");
			//publisher.publishEvent(new BlockChainChangePropertyStatusEvent(this, archivePropertyBCI, property.getProductId().toString()));
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESSFULLY , null);
			
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}*/
	
	/*public ResponseEntity liveProperty(RequestChangeDto property) {
		try {
			logger.info("In live property, blockchain service");
			String tokenId = blockChainRepositry.getTokenIdByProductId(property.getPropertyId());
			ChangePropertyStatusEventData eventData = new ChangePropertyStatusEventData();
			
			eventData.setStatus("live");		
		
			ChangePropertyStatusAttributesDTO attributes = new ChangePropertyStatusAttributesDTO();
			attributes.setEvent_type(BlockChainConstants.TokenType.ARCHIVE_PROPERTY); // constant
			attributes.setEvent_data(eventData);
			
			ChangePropertyStatusDataDTO data = new ChangePropertyStatusDataDTO();
			data.setAttributes(attributes);
			
			BlockChainChangePropertyStatusDTO archivePropertyBCI = new BlockChainChangePropertyStatusDTO();
			archivePropertyBCI.setData(data);
			
			logger.info("Publishing live property event, blockchain service");
			//publisher.publishEvent(new BlockChainChangePropertyStatusEvent(this, archivePropertyBCI, tokenId));
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESSFULLY , null);
			
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}*/
	
	/*public ResponseEntity createBlockChainAuction(com.bestercapitalmedia.chiragh.property.Product property) {
		try {
			logger.info("Create Auction, blockchain service");
		     Chiraghuser chiraghUser = userRepositry.findUserByEmail(property.getSellerEmail());
		     Chiraghproperty chiraghProperty = propertyRepositry.findByPropertyId(property.getProductId());
		     float bidRange = brokerageProposalReposotry.getBidRangeByPropertyId(property.getProductId());
		     BrokerageProposal brokerageProposal = brokerageProposalReposotry.findProposalByPropertyId(property.getProductId());
             Country sellerCountry = countryRepository.getByCountryId(chiraghUser.getCountryId());
		     City sellerCity = cityRepository.getByCityId(chiraghUser.getCityId());
		     
			CreateAuctionSellerUserDTO seller_user = new CreateAuctionSellerUserDTO();
			seller_user.setCity(sellerCity.getName());
			seller_user.setCountry(sellerCountry.getName());
			seller_user.setUser_email(property.getSellerEmail());
			seller_user.setUser_id(chiraghUser.getUserId().toString());
			seller_user.setUser_name(chiraghUser.getUserName());

			CreateAuctionProductDTO product = new CreateAuctionProductDTO();
			product.setCity(chiraghProperty.getCity());
			product.setCountry(chiraghProperty.getCountry());
			product.setProduct_id(property.getProductId().toString());
			product.setProduct_title(chiraghProperty.getPropertyTitle());
			product.setProduct_type(chiraghProperty.getPropertyType());

			CreateAuctionTokenDataDTO token_data = new CreateAuctionTokenDataDTO();
			token_data.setAuction_end_date(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX").format(property.getAuctionEndDate()));
			token_data.setAuction_start_date(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX").format(property.getAuctionStartDate()));
			token_data.setBid_range(String.valueOf(bidRange));
			token_data.setDated(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX").format(property.getDate()));
			token_data.setProduct(product);
			token_data.setSeller_user(seller_user);
			token_data.setStatus(property.getStatus());
			if ("dev".equalsIgnoreCase(this.environment.getProperty("spring.profiles.active"))) {
				token_data.setClient_id("1");
			} else if ("test".equalsIgnoreCase(this.environment.getProperty("spring.profiles.active"))) {
				token_data.setClient_id("5");
			} else if ("stage".equalsIgnoreCase(this.environment.getProperty("spring.profiles.active"))) {
				token_data.setClient_id("3");
			} else if ("pre".equalsIgnoreCase(this.environment.getProperty("spring.profiles.active"))) {
				token_data.setClient_id("7");
			} else if ("prod".equalsIgnoreCase(this.environment.getProperty("spring.profiles.active"))) {
				token_data.setClient_id("6");
			} else {
				token_data.setClient_id(this.environment.getProperty("spring.profiles.active"));
			}
			
			token_data.setOpen_price(brokerageProposal.getOpenPrice().toString());
			token_data.setReserve_price(brokerageProposal.getReservePrice().toString());
			token_data.setDuration(brokerageProposal.getAuctionDuration().toString());

			CreateAuctionAttributesDTO attributes = new CreateAuctionAttributesDTO();
			attributes.setToken_data(token_data);
			attributes.setToken_object_id(property.getProductId().toString());
			attributes.setToken_type(BlockChainConstants.TokenType.BCI_AUCTION);

			CreateAuctionDataDTO data = new CreateAuctionDataDTO();
			data.setAttributes(attributes);

			BlockChainCreateAuctionDTO createAuction = new BlockChainCreateAuctionDTO();
			createAuction.setData(data);
			String tokenId = "";
			logger.info("Publishing create auction event, blockchain service");
			//publisher.publishEvent(new com.bestercapitalmedia.chiragh.systemevents.BlockChainCreateAuctionEvent(this, createAuction, tokenId));
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESS, null);

		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}*/

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;
		
	}

}
