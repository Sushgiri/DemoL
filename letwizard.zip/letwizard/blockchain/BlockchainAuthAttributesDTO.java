package com.bestercapitalmedia.letwizard.blockchain;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BlockchainAuthAttributesDTO {

	private String token;

}
