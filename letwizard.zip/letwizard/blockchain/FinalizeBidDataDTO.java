package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class FinalizeBidDataDTO {

	private FinalizeBidAttributesDTO attributes;

}
