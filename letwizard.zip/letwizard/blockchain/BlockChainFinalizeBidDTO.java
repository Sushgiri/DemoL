package com.bestercapitalmedia.letwizard.blockchain;

import lombok.Data;

@Data
public class BlockChainFinalizeBidDTO {
	
	private FinalizeBidDataDTO data;
}
