package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class ChangePropertyStatusAttributesDTO {
	
	private String event_type;
	private ChangePropertyStatusEventData event_data;

}
