package com.bestercapitalmedia.letwizard.blockchain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.systemevents.SystemEventListener;

@RestController
@CrossOrigin
public class BlockchainTestController {

	@Autowired
	SystemEventListener systemEventListener;
	
	/*
	@CrossOrigin("*")
	@GetMapping("/getToken")
	public String getJWTtoken() {
		
		return systemEventListener.getJWTTokenForBlockchain();
		
	}
	
	@CrossOrigin("*")
	@GetMapping("/createAuction")
	public String createAuction() {
		
		return systemEventListener.getJWTTokenForBlockchain();
		
	}
	
	@CrossOrigin("*")
	@GetMapping("/saveBid")
	public String saveBid() {
		
		return systemEventListener.getJWTTokenForBlockchain();
		
	}
	
	@CrossOrigin("*")
	@GetMapping("/finalizeBid")
	public String finalizeBid() {
		
		return systemEventListener.getJWTTokenForBlockchain();
		
	}*/

}
