package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class RejectBidDataDTO {

	private RejectBidAttributesDTO attributes;

}
