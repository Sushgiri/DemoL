package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class CreateAuctionTokenDataDTO {
	
	private String auction_start_date;
	private String auction_end_date;
	private String bid_range;
	private String dated;
	private String status;
	private String client_id;
	private String open_price;
    private String reserve_price;
    private String duration;
	private CreateAuctionProductDTO product;
	private CreateAuctionSellerUserDTO seller_user;
	

}
