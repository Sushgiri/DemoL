package com.bestercapitalmedia.letwizard.blockchain;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BlockchainAuthDataDTO {

	private BlockchainAuthAttributesDTO attributes;

}
