package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class CreateAuctionAttributesDTO {
	
	private String token_type;
	private String token_object_id;
	private CreateAuctionTokenDataDTO token_data;
	

}
