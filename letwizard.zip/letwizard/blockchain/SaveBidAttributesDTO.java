package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class SaveBidAttributesDTO {

	private String event_type;
	private SaveBidEventData event_data;

}
