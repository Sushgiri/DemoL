package com.bestercapitalmedia.letwizard.blockchain;

import lombok.Data;

@Data
public class BlockChainChiraghUserDTO {

	private String user_id;
    private String user_email;
    private String user_name;
    private String city;
    private String country;
}
