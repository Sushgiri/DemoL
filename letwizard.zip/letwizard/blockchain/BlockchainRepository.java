package com.bestercapitalmedia.letwizard.blockchain;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface BlockchainRepository extends CrudRepository<Blockchain, Integer> {
	
	@Query(value = "SELECT token_id FROM blockchain_details WHERE property_id=?1", nativeQuery = true)
	public String getTokenIdByProductId(Integer propertyId);
	

}
