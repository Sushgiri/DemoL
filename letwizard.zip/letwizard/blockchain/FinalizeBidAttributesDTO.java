package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class FinalizeBidAttributesDTO {

	private String event_type;
	private FinalizeBidEventData event_data;

}
