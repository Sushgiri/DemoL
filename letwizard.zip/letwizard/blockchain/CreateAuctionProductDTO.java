package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class CreateAuctionProductDTO {
	
	private String product_id;
	private String product_title;
	private String product_type;
	private String city;
	private String country;

}
