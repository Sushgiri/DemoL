package com.bestercapitalmedia.letwizard.blockchain;
import lombok.Data;

@Data
public class FinalizeBidEventData {

	private String bid_id;
	private boolean finalized;

}
