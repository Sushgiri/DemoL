package com.bestercapitalmedia.letwizard.blockchain;
import java.sql.Date;

import lombok.Data;

@Data
public class SaveBidEventData {

	private String bid_id;
	private boolean finalized;
	private Integer sequence_id;
	private String voucher_id;
	private String otp;
	private String bid_amount;
	private String date_time;
	private String token;
	private boolean seller_reject;
	private BlockChainChiraghUserDTO user;
//	private ClientDTO client;
	private BlockChainCurrencyDTO currency;

}
