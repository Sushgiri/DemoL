package com.bestercapitalmedia.letwizard.blockchain;

import lombok.Data;

@Data
public class BlockChainCreateAuctionDTO {
	
	private CreateAuctionDataDTO data;

}
