package com.bestercapitalmedia.letwizard.faqs;

import org.springframework.http.ResponseEntity;

public interface FrequentlyAskQuestionService {

	public ResponseEntity getAllFAQs();

}
