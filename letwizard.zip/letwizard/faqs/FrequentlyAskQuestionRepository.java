package com.bestercapitalmedia.letwizard.faqs;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface FrequentlyAskQuestionRepository extends JpaRepository<FrequentlyAskQuestion, Integer> {

	@Query(value = "Select * from frequently_ask_question", nativeQuery = true)
	public List<FrequentlyAskQuestion> getAllFAQs();

}
