package com.bestercapitalmedia.letwizard.faqs;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/api/faq")
public class FrequentlyAskQuestionController {

	private static final Logger log = LoggerFactory.getLogger(FrequentlyAskQuestionController.class);

	@Autowired
	private FrequentlyAskQuestionService faqService;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity GetBank(HttpServletRequest httpServletRequest) {

		return faqService.getAllFAQs();
	}
}
