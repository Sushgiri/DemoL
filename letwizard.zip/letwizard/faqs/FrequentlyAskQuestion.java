package com.bestercapitalmedia.letwizard.faqs;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "frequently_ask_question")
public class FrequentlyAskQuestion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer id;

	@Column(name = "category", length = 255)
	@Basic(fetch = FetchType.EAGER)
	String category;
	@Column(name = "title")
	@Basic(fetch = FetchType.EAGER)
	String title;

	@Column(name = "description")
	@Basic(fetch = FetchType.EAGER)
	String description;

	public FrequentlyAskQuestion() {

	}

}
