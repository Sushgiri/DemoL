package com.bestercapitalmedia.letwizard.faqs;

import lombok.Data;

@Data
public class FrequentlyAskQuestionDTO {

	private Integer id;
	private String category;
	private String title;
	private String description;

	public FrequentlyAskQuestionDTO() {

	}

}
