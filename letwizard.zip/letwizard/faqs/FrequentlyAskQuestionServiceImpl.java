package com.bestercapitalmedia.letwizard.faqs;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;

@Service
public class FrequentlyAskQuestionServiceImpl implements FrequentlyAskQuestionService {

	private static final Logger logger = LoggerFactory.getLogger(FrequentlyAskQuestionServiceImpl.class);

	@Autowired
	private FrequentlyAskQuestionRepository faqRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Override
	public ResponseEntity getAllFAQs() {
		try {

			List<FrequentlyAskQuestion> allFAQs = faqRepository.getAllFAQs();

			if (allFAQs == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						allFAQs);
			}

		} catch (Exception e) {
			logger.error("Error Occures while Retriving FAQs " + e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

}
