package com.bestercapitalmedia.letwizard.contactus;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.thymeleaf.util.StringUtils;

import com.bestercapitalmedia.letwizard.admin.notifications.NotificationConstants;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationsService;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.BasicErrorMessages;
import com.bestercapitalmedia.letwizard.constants.EmailTemplatesConstants;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.mail.MailManager;
import com.bestercapitalmedia.letwizard.systemevents.ContactUsLeadEvent;
import com.bestercapitalmedia.letwizard.systemevents.PropertyEstimationLeadEvent;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;

@Service
public class ContactUsServiceImpl implements ContactUsService, ApplicationEventPublisherAware {

	@Autowired
	private ContactUsRepository contactUsRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private NotificationsService notificationService;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ChiragUtill chiragUtill;
	
	@Autowired 
	private MailManager mailManager;
	
	@Autowired
	private ApplicationEventPublisher publisher;

	@Override
	public ResponseEntity save(ContactUs contactUs) {

		try {
			ModelMapper mapper = new ModelMapper();
			String userName = chiragUtill.getUserNameFromAuthentication();

			contactUs.date = DateUtils.getDefault().getNowCalender();
			ContactUs contactUs2 = contactUsRepository.save(contactUs);

			Chiraghuser mdUser = userRepository.getMD();
			
			if(userName.equalsIgnoreCase("chiragh-client")) {

			notificationService.createNotificationForSystem(NotificationConstants.Description.contact_us,
					NotificationConstants.Subject.contact_us, contactUs2.getContactUsId(), mdUser.getUserId(), null);
			} else {
				notificationService.createNotification(NotificationConstants.Description.contact_us,
						NotificationConstants.Subject.contact_us, contactUs2.getContactUsId(), mdUser.getUserId(), null);
			}
			
			if (contactUs2 != null) {
				if (!StringUtils.isEmpty(contactUs2.getEmail())) {
					// send email
					mailManager.sendGenericSupportEmail(contactUs2.getEmail(),
							"Contact Us", contactUs2.getFirstName() , 
							EmailTemplatesConstants.CONTACT_US_TEMP, "", "", "");
				}
			}

			else {
				return responseUtill.getApiResponse(ResponseCodes.FUNCTIONAL_FAILURE, BasicErrorMessages.DATA_NOT_SAVED, null);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		// event listener to call "create lead 3rd party API"
		publisher.publishEvent(new ContactUsLeadEvent(this, contactUs));
		return responseUtill.getApiResponse(ResponseCodes.SUCCESS, BasicErrorMessages.DATA_SAVED_SUCCESSFULLY , null);
	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;

	}
}
