package com.bestercapitalmedia.letwizard.contactus;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface ContactUsService {

	public ResponseEntity save(ContactUs contactUs);
}
