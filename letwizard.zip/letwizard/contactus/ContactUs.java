package com.bestercapitalmedia.letwizard.contactus;

import java.io.Serializable;
import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="contactus")
public class ContactUs implements Serializable  {

	@Id
	@Column(name="contact_Us_Id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int contactUsId;
	
	@Column(name="first_Name")
	String firstName;
	
	@Column(name="middle_Name")
	String middleName;
	
	@Column(name="last_Name")
	String lastName;
	
	@Column(name="email")
	String email;
	
	@Column(name="message")
	String message;
	
	@Column(name="date")
	Calendar date;

	public int getContactUsId() {
		return contactUsId;
	}

	public void setContactUsId(int contactUsId) {
		this.contactUsId = contactUsId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Calendar getDate() {
		return date;
	}

	public void setDate(Calendar date) {
		this.date = date;
	}

	public ContactUs() {
	}
	
	
	
}
