package com.bestercapitalmedia.letwizard.api.response;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

@Component
public class ResponseUtill<T> {
	@Autowired
	LetwizardResponse<T> engineResponse;
	@Autowired
	LetwizardResponseHeader responseHeader;
	@Autowired
	LetwizardResponseBody<T> responseBody;

	public LetwizardResponse<T> apiResponse(int code, String msg, List<T> data) {
		responseHeader.setCode(code);
		responseHeader.setMsg(msg);
		responseBody.setData(data);
		engineResponse.setResponseHeader(responseHeader);
		engineResponse.setResponseBody(responseBody);
		return engineResponse;
	}// end of engine Response

	public LetwizardResponse<T> apiFileResponse(int code, String msg, String data) {
		responseHeader.setCode(code);
		responseHeader.setMsg(msg);
		engineResponse.setResponseHeader(responseHeader);
		engineResponse.setResponseBody(responseBody);
		return engineResponse;
	}// end of engine Response

	public ResponseEntity getApiResponse(int code, String msg, List data) {
		if (code == 1)
			return new ResponseEntity(apiResponse(code, msg, data), HttpStatus.OK);
		else if(code==0)
			return new ResponseEntity(apiResponse(code, msg, data), HttpStatus.OK);
		else if(code==2 || code==3)
			return new ResponseEntity(apiResponse(code, msg, data), HttpStatus.OK);
		else if(code == 403)
			return new ResponseEntity(apiResponse(code, msg, data), HttpStatus.FORBIDDEN);
		else
			return new ResponseEntity(apiResponse(code, msg, data), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public ResponseEntity getApiFileResponse(int code, String msg, String  data) {
		if (code == 1)
			return new ResponseEntity(apiFileResponse(code, msg, data), HttpStatus.OK);
		else if(code==0)
			return new ResponseEntity(apiFileResponse(code, msg, data), HttpStatus.OK);
		else
			return new ResponseEntity(apiFileResponse(code, msg, data), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
