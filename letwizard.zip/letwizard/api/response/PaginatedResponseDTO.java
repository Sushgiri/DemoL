package com.bestercapitalmedia.letwizard.api.response;

import java.util.List;

import org.springframework.data.domain.Page;



public class PaginatedResponseDTO<T> {

	int totalPages;
	int pageNumber;
	int numberOfElements;
	long totalRecords;
	List<T> data;
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getNumberOfElements() {
		return numberOfElements;
	}
	public void setNumberOfElements(int numberOfElements) {
		this.numberOfElements = numberOfElements;
	}
	public long getTotalRecords() {
		return totalRecords;
	}
	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}
	
	public List<T> getData() {
		return data;
	}
	public void setData(List<T> data) {
		this.data = data;
	}
	public PaginatedResponseDTO() {

	}
	public PaginatedResponseDTO(Page<T> paginatedData, List<T> data) {
		this.setNumberOfElements(paginatedData.getNumberOfElements());
		this.setTotalRecords(paginatedData.getTotalElements());
		this.setTotalPages(paginatedData.getTotalPages());
		this.setPageNumber(paginatedData.getNumber());
		this.setData(data);
	}

	
}
