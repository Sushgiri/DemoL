package com.bestercapitalmedia.letwizard.api.response;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class LetwizardResponseHeader implements Serializable {

	private int code;
	private String msg;
	
	
	
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public LetwizardResponseHeader() {
	
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	
	
}
