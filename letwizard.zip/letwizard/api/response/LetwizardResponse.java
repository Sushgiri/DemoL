package com.bestercapitalmedia.letwizard.api.response;

import java.io.Serializable;

import org.springframework.stereotype.Component;

@Component
public class LetwizardResponse<T>  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	LetwizardResponseHeader responseHeader;
	LetwizardResponseBody<T> responseBody;
	
	
	
	public LetwizardResponse() {
	}



	public LetwizardResponseHeader getResponseHeader() {
		return responseHeader;
	}



	public void setResponseHeader(LetwizardResponseHeader responseHeader) {
		this.responseHeader = responseHeader;
	}



	public LetwizardResponseBody getResponseBody() {
		return responseBody;
	}



	public void setResponseBody(LetwizardResponseBody responseBody) {
		this.responseBody = responseBody;
	}
	
	
}
