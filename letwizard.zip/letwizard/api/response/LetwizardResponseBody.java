package com.bestercapitalmedia.letwizard.api.response;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

@Component
public class LetwizardResponseBody<T> implements Serializable {

	private List<T> data;

	

	public LetwizardResponseBody() {
	
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}
}
