package com.bestercapitalmedia.letwizard.bidplace.consumer;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.rabbitmq.client.AMQP.Exchange;
import com.rabbitmq.client.ConnectionFactory;

@Configuration
public class BidPlaceConsumerConfiguration {

//	@Bean
//	  public TopicExchange eventExchange() {
//	    return new TopicExchange("event-exchange");
//	  }
//
//	  @Bean
//	  public Queue queue() {
//	    return new Queue("bid-queue");
//	  }
//
//	  @Bean
//	  public Binding binding(Queue queue, TopicExchange eventExchange) {
//	    return BindingBuilder
//	            .bind(queue)
//	            .to(eventExchange)
//	            .with("customer.*");
//	  }
//
//	     @Bean
//	    RabbitTemplate rabbitTemplate(org.springframework.amqp.rabbit.connection.ConnectionFactory connectionFactory){
//	        RabbitTemplate template = new RabbitTemplate();
//	        template.setConnectionFactory(connectionFactory);
//	        Jackson2JsonMessageConverter jsonConverter = new Jackson2JsonMessageConverter();
//	        template.setMessageConverter(jsonConverter);
//	        return template;
//	    }
//	     
//	     @Bean
//	     SimpleMessageListenerContainer container(org.springframework.amqp.rabbit.connection.ConnectionFactory connectionFactory, MessageListenerAdapter listenerAdapter) {
//	         SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
//	         container.setConnectionFactory(connectionFactory);
//	         container.setQueueNames("bid-queue");
//	         container.setMessageListener(listenerAdapter);
//	         return container;
//	     }
//	     
//	     @Bean
//	     MessageListenerAdapter listenerAdapter(BidPlaceConsumer receiver) {
//	         return new MessageListenerAdapter(receiver, "receiveMessage");
//	     }
}
