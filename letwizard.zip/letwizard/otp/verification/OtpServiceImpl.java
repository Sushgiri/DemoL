package com.bestercapitalmedia.letwizard.otp.verification;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapialmedia.letwizard.sns.AmazonSnsClient;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.*;
import com.bestercapitalmedia.letwizard.mail.MailManager;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;

@Service
public class OtpServiceImpl implements OtpService {

	private static final Logger logger = LoggerFactory.getLogger(OtpServiceImpl.class);

	@Autowired
	private OtpVerificationRepository otpRepo;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private PropertyRepository propertyRepo;

	@Autowired
	private MailManager mailManager;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private Environment environment;

	@Override
	public boolean save(BidOTPDTO bidOTPDTO) {
		try {
			System.out.println("PropertyId" + bidOTPDTO.getPropertyId());
			System.out.println("userId" + bidOTPDTO.getUserId());
			Integer integer = otpRepo.invalidateOTP(bidOTPDTO.getPropertyId(), bidOTPDTO.getUserId());

			OtpVerification entity = new OtpVerification();
			Chiraghuser chiraghuser = userRepo.findByUserId(bidOTPDTO.getUserId());
			Chiraghproperty chiraghproperty = propertyRepo.findByPropertyId(bidOTPDTO.getPropertyId());
			entity.setChiraghproperty(chiraghproperty);
			entity.setChiraghuser(chiraghuser);
			entity.setOtp(RandomStringUtils.randomNumeric(4));
			otpRepo.save(entity);
			String mobileNumber = "+" + chiraghuser.getMobileCode() + chiraghuser.getMobileNo();
			logger.info("Sending SMS -> to phoneNumber: {} with userId: {}", mobileNumber, chiraghuser.getUserId());

			
				if (chiraghproperty.getRentalProperty()==null && (bidOTPDTO.getBidType() != null && bidOTPDTO.getBidType().equalsIgnoreCase("bid_now"))) {
					AmazonSnsClient.sendSMSMessage("Hello " + chiraghuser.getFirstName() + ",\n"
							+ "PLEASE do not share your OTP code with anyone to ensure your account safety." + "\n"
							+ "Your OTP for biding a property on letWizard.com is " + entity.getOtp() + "." + "\n"
							+ "Property ID: " + entity.getChiraghproperty().getPropertyId() + "\n"
							+ "If you have not requested this, please ignore this message.", mobileNumber);
				} else if (chiraghproperty.getRentalProperty() !=null && (bidOTPDTO.getBidType() != null && bidOTPDTO.getBidType().equalsIgnoreCase("Reservation_CheckedIn"))) {
				AmazonSnsClient.sendSMSMessage("Hello " + chiraghuser.getFirstName() + ",\n"
						+ "PLEASE do not share your OTP code with anyone to ensure your account safety." + "\n"
						+ "Your OTP for Check-In a property at letWizard.com is " + entity.getOtp() + "." + "\n"
						+ "Property ID: " + entity.getChiraghproperty().getPropertyId() + "\n"
						+ "If you have not requested this, please ignore this message.", mobileNumber);
			}
				else {
					AmazonSnsClient.sendSMSMessage("Hello " + chiraghuser.getFirstName() + ",\n"
							+ "PLEASE do not share your OTP code with anyone to ensure your account safety." + "\n"
							+ "Your OTP for buying a property on letWizard.com is " + entity.getOtp() + "." + "\n"
							+ "Property ID: " + entity.getChiraghproperty().getPropertyId() + "\n"
							+ "If you have not requested this, please ignore this message.", mobileNumber);
				
					}
			if (chiraghproperty.getRentalProperty()!=null ) {
				if (bidOTPDTO.getBidType() != null && bidOTPDTO.getBidType().equalsIgnoreCase("Reservation_CheckedIn")) {
					mailManager.sendPlainHTMLEmailForEWallet(chiraghuser.getUserEmail(),
							EmailTemplatesConstants.Subjects.RESERVATION_CHECKEDIN_SUBJECT,
							EmailTemplatesConstants.EmailBody.reservationcheckedInOTP(chiraghproperty, entity.getOtp()),
							EmailTemplatesConstants.BID_PLACED_TEMP, chiraghuser.getFirstName());
				}else{
					mailManager.sendPlainHTMLEmailForEWallet(chiraghuser.getUserEmail(),
							EmailTemplatesConstants.Subjects.BIDDING_OTP,
							EmailTemplatesConstants.EmailBody.bidOtpRental(chiraghproperty, entity.getOtp()),
							EmailTemplatesConstants.BID_PLACED_TEMP, chiraghuser.getFirstName());
				}
			} 
			if (chiraghproperty.getRentalProperty()==null ) {
	
				if (bidOTPDTO.getBidType() != null && bidOTPDTO.getBidType().equalsIgnoreCase("bid_now")) {
					mailManager.sendPlainHTMLEmailForEWallet(chiraghuser.getUserEmail(),
							EmailTemplatesConstants.Subjects.BIDDING_OTP1,
							EmailTemplatesConstants.EmailBody.bidOtpSeller(chiraghproperty, entity.getOtp()),
							EmailTemplatesConstants.BID_PLACED_TEMP, chiraghuser.getFirstName());
				}else {
					mailManager.sendPlainHTMLEmailForEWallet(chiraghuser.getUserEmail(),
							EmailTemplatesConstants.Subjects.BUYING_OTP1,
							EmailTemplatesConstants.EmailBody.buyOtpSeller(chiraghproperty, entity.getOtp()),
							EmailTemplatesConstants.BID_PLACED_TEMP, chiraghuser.getFirstName());
				}
				
			} 
			

			/*
			 * if (bidOTPDTO.getBidType() != null &&
			 * !bidOTPDTO.getBidType().equalsIgnoreCase("bid_now")) {
			 * AmazonSnsClient.sendSMSMessage("Hello " + chiraghuser.getFirstName() + ",\n"
			 * +
			 * "PLEASE do not share your OTP code with anyone to ensure your account safety."
			 * + "\n" + "Your OTP for buying a property on letwizard.com is " +
			 * entity.getOtp() +"."+ "\n" + "Property ID: " +
			 * entity.getChiraghproperty().getPropertyId() + "\n" +
			 * "If you have not requested this, please ignore this message.", mobileNumber);
			 * } else { if (chiraghproperty.getRentalProperty() != null) { if
			 * (bidOTPDTO.getBidType() != null &&
			 * bidOTPDTO.getBidType().equalsIgnoreCase("bid_now")) {
			 * mailManager.sendPlainHTMLEmailForEWallet(chiraghuser.getUserEmail() ,
			 * EmailTemplatesConstants.Subjects.BIDDING_OTP
			 * ,EmailTemplatesConstants.EmailBody.bidOtp(chiraghproperty,entity.getOtp())
			 * ,EmailTemplatesConstants.BID_PLACED_TEMP ,chiraghuser.getFirstName()); } }
			 * AmazonSnsClient.sendSMSMessage("Hello " + chiraghuser.getFirstName() + ",\n"
			 * +
			 * "PLEASE do not share your OTP code with anyone to ensure your account safety."
			 * + "\n" + "Your OTP for making an offer on a property on letWizard.com is " +
			 * entity.getOtp() +"."+ "\n" + "Property ID: " +
			 * entity.getChiraghproperty().getPropertyId() + "\n" +
			 * "If you have not requested this, please ignore this message.", mobileNumber);
			 * }
			 */

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public String bidVerification(BidVerificationDTO bidVerificationDTO) {
		try {
			OtpVerification otpVerification = otpRepo.verifyBid(bidVerificationDTO.getPropertyId(),
					userRepo.findByUserName(bidVerificationDTO.getUserName()).getUserId(), bidVerificationDTO.getOtp());
			if (otpVerification == null)
				return BidMessages.BID_VERIFICATION_FALIURE;
			else if (otpVerification.getOtp().equalsIgnoreCase(bidVerificationDTO.getOtp())) {
				return BidMessages.BID_VERIFICATION_SUCCESS;
			} else {
				return BidMessages.BID_VERIFICATION_FALIURE;
			}
		} catch (Exception e) {
			return "Error/n" + e.getMessage();
		}
	}

	@Override
	public ResponseEntity verifyOTO(int propertyId, int userId) {
		try {
			OtpVerification otpVerification = otpRepo.verifyOTP(propertyId, userId);
			if (otpVerification == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(otpVerification).collect(Collectors.toList()));
			}
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
		}
	}

	@Override
	public ResponseEntity verifyOTP(BidOTPDTO bidOtpDto) {
		try {
			ChiragUtill chiraghUtil = new ChiragUtill();
			OtpVerification otpVerification = otpRepo.validateOTP(bidOtpDto.getPropertyId(), bidOtpDto.getUserId(),
					bidOtpDto.getOtp());
			if (otpVerification == null) {

				if ("1122".equals(bidOtpDto.getOtp())
						&& ("test".equals(this.environment.getProperty("spring.profiles.active"))
								|| "rental".equals(this.environment.getProperty("spring.profiles.active")))) {
					return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
							null);
				}

				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else if (otpVerification != null || ("1122".equals(bidOtpDto.getOtp())
					&& "test".equals(this.environment.getProperty("spring.profiles.active")))) {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
		}
	}

	//////////////////////////////////////////////////////

	@Override
	public boolean OdCancelOtp(CancelOdOTPDTO cancelOdOTPDTO) {
		try {

			System.out.println("Lead Id" + cancelOdOTPDTO.getOverDraftId());
			System.out.println("userId" + cancelOdOTPDTO.getUserId());
			Integer integer = otpRepo.invalidateCancelOdOTP(cancelOdOTPDTO.getUserId());

			OtpVerification entity = new OtpVerification();
			Chiraghuser chiraghuser = userRepo.findByUserId(cancelOdOTPDTO.getUserId());
			entity.setChiraghuser(chiraghuser);
			entity.setOtp(RandomStringUtils.randomNumeric(4));
			otpRepo.save(entity);
			String mobileNumber = "+" + chiraghuser.getMobileCode() + chiraghuser.getMobileNo();
			logger.info("Sending SMS -> to phoneNumber: {} with userId: {}", mobileNumber, chiraghuser.getUserId());

			AmazonSnsClient.sendSMSMessage("Hello " + chiraghuser.getFirstName() + ",\n"
					+ "PLEASE do not share your OTP code with anyone to ensure your account safety." + "\n"
					+ "Your OTP for submitting the OD Cancellation Request on letWizard.com is " + entity.getOtp() + "."
					+ "\n" + "OD ID: " + cancelOdOTPDTO.getOverDraftId() + "\n"
					+ "If you have not requested this, please ignore this message.", mobileNumber);

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean verifyCancelOdOTP(CancelOdOTPDTO cancelOdOTPDTO) {
		try {
			ChiragUtill chiraghUtil = new ChiragUtill();
			OtpVerification otpVerification = otpRepo.validateCancelOdOTP(cancelOdOTPDTO.getUserId(),
					cancelOdOTPDTO.getOtp());
			if (otpVerification == null) {

				if ("1122".equals(cancelOdOTPDTO.getOtp())
						&& "test".equals(this.environment.getProperty("spring.profiles.active"))) {
					// return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
					// PropertyMessages.DATA_RETRIVED_SUCCESS,null);
					return true;
				}

//				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,null);
				return false;
			} else if (otpVerification != null || ("1122".equals(cancelOdOTPDTO.getOtp())
					&& "test".equals(this.environment.getProperty("spring.profiles.active")))) {
//				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,null);
				return true;
			} else {
//				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,null);
				return false;
			}
		} catch (Exception e) {
//			return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE, null);
			return false;
		}
	}

	//////////////////////////////////////////////////////

}
