package com.bestercapitalmedia.letwizard.otp.verification;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.BidMessages;
import com.bestercapitalmedia.letwizard.constants.EmailMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.TransactionMessages;
import com.bestercapitalmedia.letwizard.constants.UserMessages;
import com.bestercapitalmedia.otp.transactions.LetwizardTransactionService;
import com.bestercapitalmedia.otp.transactions.SaveTransactionDto;

@RestController
@CrossOrigin
@RequestMapping("/api/otpVerification")
public class OtpVerificationController {

	@Autowired
	private OtpService otpService;

	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private LetwizardTransactionService chiraghTransactionService;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/post", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity save(@RequestBody BidOTPDTO bidOTPDTO, HttpServletRequest httpServletRequest) {
		if (otpService.save(bidOTPDTO)) {
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, UserMessages.SMS_SENT_SUCCESS, null);
		} else {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, UserMessages.SMS_SENT_SUCCESS, null);
		}
	}


	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/checkUserAuthenticationForBidding", method = RequestMethod.POST)
	public @ResponseBody String save(@RequestBody BidVerificationDTO bidVerificationDTO, HttpServletRequest httpServletRequest) {
		String response = otpService.bidVerification(bidVerificationDTO);
		if (response.equals(BidMessages.BID_VERIFICATION_SUCCESS)) {
			return response;
		} else {
			return BidMessages.BID_VERIFICATION_FALIURE;
		}
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getSecurityOtp/{userId}/{propertyId}", method = RequestMethod.GET)
	public ResponseEntity getSecurityOtp(@PathVariable(value = "userId") int userId, @PathVariable(value = "propertyId") int propertyId,
			HttpServletRequest httpServletRequest) {

		String otp = chiraghTransactionService.generateTransactionOtp(userId, propertyId);
		if (otp.equals("") || otp.equals(UserMessages.User_FOUND))
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, TransactionMessages.OTP_GENERATION_FAILURE,
					Stream.of(otp).collect(Collectors.toList()));
		else
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, TransactionMessages.OTP_GENERATION_SUCCESS,
					null);

	}// end of getOwners

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/saveTransaction", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity saveTransaction(@RequestBody SaveTransactionDto saveTransactionDto,
			HttpServletRequest httpServletRequest) {

		String response = chiraghTransactionService.saveTransaction(saveTransactionDto);
		if (response.equals("") || response.equals(TransactionMessages.TRANSACTION_SAVED_FAILURE))
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, TransactionMessages.TRANSACTION_SAVED_FAILURE,
					null);
		else
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, TransactionMessages.TRANSACTION_SAVED_SUCCESS,
					null);
	}// end of getOwners

	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{propertyId}/{userId}", method = RequestMethod.GET)
	public ResponseEntity verifySecurityOtp(@PathVariable(value = "propertyId") int propertyId, @PathVariable(value = "userId") int userId,
			HttpServletRequest httpServletRequest) {

		return otpService.verifyOTO(propertyId, userId);

	}// end of getOwners
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/v2/validateotp", method = RequestMethod.POST)
	public ResponseEntity verifySecurityOtpV2(@RequestBody BidOTPDTO bidOtpDto, HttpServletRequest httpServletRequest) {
		return otpService.verifyOTP(bidOtpDto);
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/saveCancelOdOtp", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity save(@RequestBody CancelOdOTPDTO cancelOdOTPDTO, HttpServletRequest httpServletRequest) {
		if (otpService.OdCancelOtp(cancelOdOTPDTO)) {
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, UserMessages.SMS_SENT_SUCCESS, null);
		} else {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, UserMessages.SMS_SENT_SUCCESS, null);
		}
	}

//	@CrossOrigin(origins = "*")
//	@RequestMapping(value = "/validateCancelOdotp", method = RequestMethod.POST)
//	public ResponseEntity verifySecurityOtpV2(@RequestBody CancelOdOTPDTO cancelOdOTPDTO, HttpServletRequest httpServletRequest) {
//		return otpService.verifyCancelOdOTP(cancelOdOTPDTO);
//	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/CheckedInOtp/Post", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity ReservationCheckedIn(@RequestBody BidOTPDTO bidOTPDTO, HttpServletRequest httpServletRequest) {
		if (otpService.save(bidOTPDTO)) {
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, UserMessages.SMS_SENT_SUCCESS, null);
		} else {
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, UserMessages.SMS_SENT_SUCCESS, null);
		}
	}
	
}
