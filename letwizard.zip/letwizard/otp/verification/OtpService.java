package com.bestercapitalmedia.letwizard.otp.verification;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface OtpService {

	public boolean save(BidOTPDTO bidOTPDTO);
	public String bidVerification(BidVerificationDTO bidVerificationDTO);
	public ResponseEntity verifyOTO(int propertyId, int userId);
	public ResponseEntity verifyOTP(BidOTPDTO bidOtpDto);
	public boolean OdCancelOtp(CancelOdOTPDTO cancelOdOTPDTO);
	public boolean verifyCancelOdOTP(CancelOdOTPDTO cancelOdOTPDTO);
	
}
