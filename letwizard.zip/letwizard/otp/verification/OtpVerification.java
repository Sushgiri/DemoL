package com.bestercapitalmedia.letwizard.otp.verification;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "otpverification")
public class OtpVerification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	int id;

//	@Column(name = "property_Id", insertable = false, updatable = false)
//	int propertyId;

	@Column(name = "otp")
	String otp;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "property_Id", referencedColumnName = "property_Id") })
	@JsonBackReference(value = "otpverification")
	Chiraghproperty chiraghproperty;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "user_Id", referencedColumnName = "user_id") })
	@JsonBackReference
	Chiraghuser chiraghuser;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

//	public int getPropertyId() {
//		return propertyId;
//	}
//
//	public void setPropertyId(int propertyId) {
//		this.propertyId = propertyId;
//	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Chiraghproperty getChiraghproperty() {
		return chiraghproperty;
	}

	public void setChiraghproperty(Chiraghproperty chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}

	public OtpVerification() {

	}

	public Chiraghuser getChiraghuser() {
		return chiraghuser;
	}

	public void setChiraghuser(Chiraghuser chiraghuser) {
		this.chiraghuser = chiraghuser;
	}

}
