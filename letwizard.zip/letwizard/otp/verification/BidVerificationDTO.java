package com.bestercapitalmedia.letwizard.otp.verification;

public class BidVerificationDTO {

	int propertyId;
	String userName;
	String otp;
	public int getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(int propertyId) {
		this.propertyId = propertyId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public BidVerificationDTO() {
	
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
}
