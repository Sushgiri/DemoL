package com.bestercapitalmedia.letwizard.otp.verification;

public class CancelOdOTPDTO {

	int overDraftId;
	int userId;
	String otp;

	public CancelOdOTPDTO() {
	
	}

	public int getOverDraftId() {
		return overDraftId;
	}

	public void setOverDraftId(int overDraftId) {
		this.overDraftId = overDraftId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}
}
