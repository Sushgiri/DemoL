package com.bestercapitalmedia.letwizard.instering.record.in.db;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class HibaTest {


    @SerializedName("selection1")
    public List<Selection1> selection1;
    

    public List<Selection1> getSelection1() {
		return selection1;
	}


	public void setSelection1(List<Selection1> selection1) {
		this.selection1 = selection1;
	}


	public static class Selection1 {


        @SerializedName("ProjectName")
        public String ProjectName;
        @SerializedName("Address")
        public String Address;
        @SerializedName("PropertyPrice")
        public String PropertyPrice;
        @SerializedName("BedRoom")
        public String BedRoom;
        @SerializedName("BathRoom")
        public String BathRoom;
        @SerializedName("PropertyArea")
        public String PropertyArea;
        @SerializedName("PropertyType")
        public String PropertyType;
        @SerializedName("Description")
        public String Description;
        @SerializedName("PropertyBannerImage")
        public String PropertyBannerImage;
        @SerializedName("PropertImage")
        public String PropertImage;
        @SerializedName("PropertImage_url")
        public String PropertImageUrl;
        @SerializedName("PropertyAllImages")
        public List<PropertyAllImages> PropertyAllImages;

        public class PropertyAllImages {
            /**
             * image : https://www.propertyfinder.ae/property/1535974188/95/95/MODE/86d97a/6374979-ec7eeo.jpg
             */

            @SerializedName("image")
            public String image;
        }

		public String getProjectName() {
			return ProjectName;
		}

		public void setProjectName(String projectName) {
			ProjectName = projectName;
		}

		public String getAddress() {
			return Address;
		}

		public void setAddress(String address) {
			Address = address;
		}

		public String getPropertyPrice() {
			return PropertyPrice;
		}

		public void setPropertyPrice(String propertyPrice) {
			PropertyPrice = propertyPrice;
		}

		public String getBedRoom() {
			return BedRoom;
		}

		public void setBedRoom(String bedRoom) {
			BedRoom = bedRoom;
		}

		public String getBathRoom() {
			return BathRoom;
		}

		public void setBathRoom(String bathRoom) {
			BathRoom = bathRoom;
		}

		public String getPropertyArea() {
			return PropertyArea;
		}

		public void setPropertyArea(String propertyArea) {
			PropertyArea = propertyArea;
		}

		public String getPropertyType() {
			return PropertyType;
		}

		public void setPropertyType(String propertyType) {
			PropertyType = propertyType;
		}

		public String getDescription() {
			return Description;
		}

		public void setDescription(String description) {
			Description = description;
		}

		public String getPropertyBannerImage() {
			return PropertyBannerImage;
		}

		public void setPropertyBannerImage(String propertyBannerImage) {
			PropertyBannerImage = propertyBannerImage;
		}

		public String getPropertImage() {
			return PropertImage;
		}

		public void setPropertImage(String propertImage) {
			PropertImage = propertImage;
		}

		public String getPropertImageUrl() {
			return PropertImageUrl;
		}

		public void setPropertImageUrl(String propertImageUrl) {
			PropertImageUrl = propertImageUrl;
		}

		public List<PropertyAllImages> getPropertyAllImages() {
			return PropertyAllImages;
		}

		public void setPropertyAllImages(List<PropertyAllImages> propertyAllImages) {
			PropertyAllImages = propertyAllImages;
		}
        
        
    }
    


}