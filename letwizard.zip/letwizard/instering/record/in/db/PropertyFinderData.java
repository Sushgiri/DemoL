package com.bestercapitalmedia.letwizard.instering.record.in.db;

public class PropertyFinderData {
	
	String ProjectName[]= {"Park View | Large 2 BR | F Type | Shoreline",
			"Two Bedroom | Duplex Villa | Two Parking",
			"Move in now! Semi corner Single Row Villa",
			"Exclusive Fully Furnished 2 BR w/Balcony",
			"Atrium Entry |Atlantis View |High Number",
			"High flr. 1BR w/ Good View + Rental back",
			"PRICE REDUCED | Bldg 06 | Sea View | Type B",
			"3BR | Ready to Occupy | Landscaped Garden",
			"Brand New Affordable 2 Bedroom Apartrment",
			"Renovated | Furnished | Ready to Move in",
			"Ideal Layout 3 BR with Landscaped Garden",
			"Bespoke Brand new Mansion| 16,700 sq.ft.",
			"Vacant | High Floor | Largest 1 Bedroom",
			"3M | Close To Pool And Park | Vacant",
			"Independent 4BR Villa|Nakheel Villas|JVC",
			"Street view 3BR apt with Huge Rental Back",
			"Best Layout| 3 BR + Study Room| Belgravia",
			"Comfortable 2BR Apartment On High Floor!",
			"Hot Price! 2BR apt with Huge Rent refund",
			"Multiple 2 BR Different Views Keys Ready",
			"Exclusive Fully Furnished 2 BR w/Balcony",
			"Move in now! Semi corner Single Row Villa",
			"Very Good Price 3 BR with 2 Balconies !!",
			"Two Bedroom | Duplex Villa | Two Parking",
			"Urban Charm 3 BR Apt w/ Maid and Balcony",};
	
	String MapLocation[]= {"Hayat Townhouses 1, Hayat Townhouses, Town Square, Dubai",
			"Zahra Apartments 1A, Zahra Apartments, Town Square, Dubai",
			"Marina Residences 6, Marina Residences, Palm Jumeirah, Dubai",
			"Oceana Atlantic, Oceana, Palm Jumeirah, Dubai",
			"Hayat Townhouses 1, Hayat Townhouses, Town Square, Dubai",
			"Signature Villas Frond H, Signature Villas, Palm Jumeirah, Dubai",
			"Shemara Tower, Marina Promenade, Dubai Marina, Dubai",
			"Mira 4, Mira, Reem, Dubai",
			"Jumeirah Village Circle 4, Mira, Reem, Dubai",
			"Al Reem Island, Town Square, Reem, Dubai",
			"Nakheel Villas, Jumeirah Village Circle, Dubai",
			"Tower 1, Al Reef Downtown, Al Reef, Abu Dhabi",
			"Belgravia 1, Belgravia, Jumeirah Village Circle, Dubai",
			"MAG 5, Marina Square, Al Reem Island, Abu Dhabi",
			"Marina Bay by DAMAC, Najmat Abu Dhabi, Al Reem Island, Abu Dhabi",
			"Zahra Apartments 1A, Zahra Apartments, Town Square, Dubai",
			"The Torch, Dubai Marina, Dubai","Zone 7, Hydra Village, Abu Dhabi",
			"Amaya Towers, Shams Abu Dhabi, Al Reem Island, Abu Dhabi",
			"The Residences 9, The Residences, Downtown Dubai, Dubai",
			"Sun Tower, Shams Abu Dhabi, Al Reem Island, Abu Dhabi",
			"Garden Homes Frond B, Garden Homes, Palm Jumeirah, Dubai",
			"Oceanscape, Shams Abu Dhabi, Al Reem Island, Abu Dhabi",
			"Beach Towers, Shams Abu Dhabi, Al Reem Island, Abu Dhabi",
			"Palmera 2, Palmera, Arabian Ranches, Dubai",
			"Index Tower, DIFC, Dubai","The Wave, Najmat Abu Dhabi, Al Reem Island, Abu"};
	
	String PropertyPrice[]= {"1,450,000 AED",
			"850,000 AED",
			"3,075,000 AED",
			"1,450,000 AED",
			"36,000,000 AED",
			"1,650,000 AED",
			"3,200,000 AED",
			"1,200,000 AED",
			"2,170,000 AED",
			"2,000,000 AED",
			"1,070,000 AED",
			"800,000 AED",
			"1,050,000 AED",
			"1,200,000 AED",
			"2,150,000 AED",
			"2,250,000 AED",
			"880,000 AED",
			"10,950,000 AED",
			"900,000 AED",
			"2,000,000 AED",
			"2,200,000 AED",
			"5,750,000 AED",
			"2,700,000 AED",
			"996,000 AED",
			"500,800 AED"};
	
	String BedRoom[]= {"3",
			"2",
			"3",
			"2",
			"3",
			"6",
			"1",
			"3",
			"4",
			"3",
			"3",
			"2",
			"2",
			"2",
			"2",
			"3",
			"3",
			"2",
			"1",
			"5",
			"1",
			"2",
			"3",
			"3",
			"3"};
	
	String BathRoom[]= {"4",
			"2",
			"3",
			"3",
			"4",
			"7",
			"2",
			"2",
			"5",
			"3",
			"4",
			"3",
			"3",
			"2",
			"2",
			"3",
			"4",
			"3",
			"1",
			"5",
			"2",
			"2",
			"3",
			"4",
			"3"};
	
	String PropertyArea[]= {"2,226",
			"938",
			"2,438",
			"2,229",
			"12,000",
			"1,073",
			"1,560",
			"1,960",
			"1,722",
			"1,273",
			"907",
			"1,258",
			"1,848",
			"2,190",
			"2,480",
			"5,342",
			"1,342",
			"4,342",
			"5,342",
			"995",
			"996",
			"1,729",
			"2,219",
			"3,128",
			"1,929",};
	
    //String unit[]= {"sqft",};
    String Description[]= {"Hayat Townhouses Brand New Townhouse 3 Bedroom Plus Maid's 3.5 Baths Ready to move in Peaceful community Call Paresh Display phone number or visit www.homes4life.ae for further details On completion, this community will be a full-fledged township with Commercial (shops and offices), Residential and Community places (Parks, cafes, restaurants, hospitals, schools, etc) making it a lifestyle destination for the occupants Hayat townhouses provide the perfect combination of contemporary living with comfort and luxury with superior amenities to create a residential convenience. Each home has been practically designed and carefully considered to accomplish a cutting edge way of life within a beautifully landscaped suburban neighborhood surrounded by 350 shops, restaurants, cafes, a shaded public plaza and recreation facilities for both children and adults. All rooms are enormous with big windows ensuring plenty of natural light. The living/dining room leads with the view of the playground outside",
    		"Brand New Community Modern-Styled Zahra Apartments 2 Bedrooms nReady to move in BUA 938 sqft Call Paresh Display phone number | visit www.homes4life.ae for further details Nshama offers trendy, dynamic and sustainable communities with a range of modern amenities and the best in facilities management and lifestyle features. Zahra Apartments encapsulate contemporary living as its best. As part of the Zahra Community, these contemporary homes combine light and airy living spaces with quality finishes for the very best in contemporary living.A development of superb apartments in a superb location with convenient transportation links, providing an environment perfect for you. Enjoy a wealth of leisure and retail activities all within walking distance including parks, shops, restaurants and cafes. Further, it is located near the entrance of the project, located near Al Barsha, in easy proximity to popular malls as well as the Al Maktoum International Airport, which is less than 20 minutes away",
    		"Bldg 06 | Sea and Atlantis View | Type B Type: Three Bedroom Apartment plus Maids room – Type B Building: 06 BUA: 2438 sq ft Selling Price: AED 3,075,000/- Net to Owner plus commission and transfer Note: Full Sea and Atlantis View Vacant Now In Immaculate condition always been Owner Occupied never been Rented Also Available Following Units: Bldg 04 Atlantis View at AED 2,750,000/- Vacant Now\\nBldg 04 Sea View at AED 3,200,000/- Vacant Now Bldg 05 Sea and Atlantis View at AED 3,200,000/- Vacant Now For further information please contact our Palm Specialist Darshan Jagwani directly on Display phone number Trakheesi Permit # 19205 Tel: Display phone number Fax: Display phone number Mob: Display phone number About Marina Residences Marina Residence offers a selection of two and three bedroom apartments with spectacular View that are available in a choice of styles. All rooms are demonstrate exceptional attention to detail, from balconies of the from balconies living room overloooking the",
    		"Presenting this stunning & large 2 bedroom C type apartment in the prestigious Oceana Development for sale\\nFreshly renovated by one of the UAE interior designers, the apartment was done with every attention to detail for a family with a child, furnished with a fully equipped kitchen, and ready to move in. This property also includes a study which was converted to a guest bedroom with extra closet space. Large balcony with panoramic views over the Marina with luxury boats, palm fronds & the Landmark-Atlantis Hotel.This beachfront resort community is centrally located on The Palm's Trunk and offers a private beach access, together with swimming pool, lazy river, & state of the art gym. Amenities also include poolside bar, restaurant, etc.\\nPalm Jumeirah is the world's largest man-made island and is comprised of a 2-km long trunk, a crown made up of 17 fronds, surrounding crescent, and built in the shape of a palm tree.For viewing appointment, kindly call Anna Kirichenko: Display phone number",
    		"3 Bedroom plus Maid's Townhouse 3.5 Baths Near pool and park Ready to move in Peaceful community With storage and laundry room Call Paresh on Display phone number On completion this community will be a full fledged township with Commercial (shops and offices), Residential (townhouses and apartments) and Community places (Parks, cafes, restaurants, hospitals, schools, etc) making it a lifestyle destination for the occupants. Hayat townhouses provide the perfect combination of contemporary living with comfort and convenience. Each home has been practically designed and carefully considered to achieve a modern lifestyle within beautifully landscaped suburban neighborhood. NSHAMA Town Square a mega development which will eventually have 3,000 townhouses and 18,000 apartments. The development will be anchored by a central square the size of 16 football fields which will be surrounded by 350 shops, restaurants, cafes, a shaded public plaza and recreation facilities for both children and adults."
    		,"Luxury Mansion is delighted to present to you this fully furnished Luxury 6 bedrooms Mansion with unique architectural design, high ceiling foyer and wide windows that provides abundant light. Ultra-chic brand new mansion in the Palm surrounded by the sea.From the massive floor to ceiling all glass wall escalating over 3 floors giving you a panoramic view of the Arabian Sea and Marina Skyline, to the state of the art smart home technology, you will see why this is considered the best of the best on the Palm. The upper floor is an entertaining area, half indoor/half outdoor offering breathtaking sea views.The Architects are considered the best in Dubai, and have a special touch on all their work, using only the best materials like all European fittings on this villa.BUA: 12,000 sq.ft.Infinity swimming poolOpen-plan living and dining areas have beautiful views of the seaAn air-conditioned garage with parking for multiple cars with a private rampContemporary outlookElevator",
    		"Largest 1 Bed in Marina Promenade | Vacant | High Floor | Sea and Marina Views- 1 Bedroom Apartment- Vacant- Sea and Marina Views- Largest Layout- Balcony- 2 Bathrooms- 1 Parking Space- Vacant- Reference No. PJM181466- Agent: Alec Smith on Display phone number, RERA BRN No. 38513- RERA PERMIT No. 25010Allsopp & Allsopp Real Estate brings to the market a well presented large 1-bedroom apartment in Marina Promenade.Consisting of open plan living kitchen area with appliances, double bedroom with en suite bathrooms, separate guest bathroom & balcony space.This corner plot unit is one of the largest 1 bedroom in the development.1 parking space & high quality facilities including Squash courts, Badminton Courts, Swimming Pools and Gyms.Located close to JBR Beach, Tram, Maria Mall and Marina Walk.Property Reference: PJM181466 Finance is available on this property through Allsopp & Allsopp Mortgage Services.Please call Alec Smith on Display phone numberfor more information or to arrange a viewing.",
    		"Brand New, Close to Pool and Park- Type 3M- Close to pool and park- Middle Unit- Dark wood finish- Brand New- Bua: 2,170 Sq. Ft.- Plot: 2,180 Sq. Ft.- 3 Bedroom Plus Maid’s Room- Agent: Rachel Stephens on Display phone number RERA BRN No: 36745- RERA PERMIT No. 25010 Allsopp and Allsopp are delighted to bring this type 3M to the market for sale. The villa comprises of a lounge/dining with kitchen, guest powder room and maids to the ground floor. The first floor then has three bedrooms. The master has its own en-suite with the other two sharing. Externally and to the front of the villa is a garage with the rear coming as a blank canvass for any prospective buyer.Property Reference: PJM180683 Finance is available on this property through Allsopp & Allsopp partnership with In-House Mortgage Services.For further details or to arrange a viewing appointment please contact our Head Office on +9714294444.Please call Rachel Stephens on Display phone numberfor more information or to arrange a viewing.",
    		"Marketing Permit No. 0850876257 For Est is proud to offer this Villa in Nakheel Villas, Jumeirah Village Circle for Sale* AED 3,200,000* 4 Bedrooms (Maids + Majelis)* 5 Bathrooms* BUA: 3,800 sq. ft.* Plot size: 6,900 sq. ft.* Upgraded* Possible sale with or without furniture* Covered 2 parking spaces* Close kitchen with appliances* Balconies* Private swimming pool * Parkland view* BBQ area* Biggest plot size* ACTUAL PHOTOS For more info please contact 800 FOR EST Tel : Display phone number Fax : Display phone number Suite # 2106, Marina Plaza, Dubai Marina, DUBAI UAE Jumeirah Village Circle is a master development of Nakheel where plots were sold to individual developers for construction of townhouse, apartment & commercial projects. These are the same property types which Nakheel built in Jumeirah Village Triangle but at a lesser number. There are a total of 303 villas and 317 townhouses built by Arabtec. The Arabtec construction is renowned for being one of the best in Dubai, and therefore, this is an added value to this community.",
    		"About Property:A fabulous living experience within the huge 3 bedroom apartment for sale in the Al Reef Tower - Al Reef Downtown, Abu Dhabi, UAE.Property Features:Large Windows Full Facilities Spacious rooms About Community:Covering 130,000 square meters of lovely landscaped area. A beautiful picture of tree-lined boulevards connecting lush public parks, tranquil swimming pools along with delicious restaurants and cafes.Community Amenities and Surroundings:24/7 Maintenance Children Playgrounds Landscaped Gardens Nearby 5 Minutes from Airport 30 Minutes from Abu Dhabi Island Contact us on:United Gulf Properties is one of the leading real estate broker in the United Arab Emirates. For various properties offers and hottest deals/ properties, please call:For Rent: Display phone number General Inquiries:Toll fee: 800-UGPAE (84723) Phone: Display phone number You can also visit our website at www.ugp.ae| Facebook https://www.facebook.com/ugpae/ | on instagram: @ugpae | Google+ | Twitter | Youtube",
    		"Marketing Permit No. 1977238763\nFor Est is proud to offer this Beautiful apartment in Belgravia 1, JVC Available for Sale.\n* AED 2,170,000\n* 3 Bedrooms + Study room\n* 4 Bathrooms\n* BUA: 1,960 sq. ft.\n* Community View\n* Vacant\n* 2 parking spaces\n* 2 balconies\n* Low Floor\nFor more info please contact 800 FOR EST\nTel : Display phone number\nFax : Display phone number\nSuite # 2106, Marina Plaza, Dubai Marina, DUBAI\nJumeirah Village Circle (JVC)\nThe trend for community living is on the rise as more and more people are opting to live in self-sustained communities, where everything they need is well within reach. Jumeirah Village adds a cosmopolitan and kindred hue to the spirit of village living.\nJumeirah Village offers two international schools nearby, town and country clubs, community centre, jogging and cycling trails, community sports and leisure amenities (football and cricket pitch, tennis courts, croquet lawn and swimming pools), medical facilities, veterinary clinics with 24security Jumeirah Village is demarcated into three sectors that are located on the Emirates road, near the Jumeirah islands in Dubai.",
    		"Mesmerizing Apartments with Refreshing Views in this 2 BR Apartment with Sea and City Views in MAG 5 Marina Square. MAG 5 Residences (B2 Tower) is perfectly positioned for a premium lifestyle in this central location right at Marina Square. This 42-story tower offers a range of very spacious apartments surrounded by the spectacular views of the Arabian Gulf and the Abu Dhabi skyline and it boasts of its high-end facilities and amenities giving a vibrant island living.Apartment Features:Bright Open Plan Living/Dining Room Modern Kitchen with Elegant Cabinet Maid's Room Guest Room Built-in Wardrobes Secured Car Parking Panoramic Views High-Class Facilities High-Speed Elevator Double Glazed Window Health Care and Recreation Facilities Shared Equipped Gymnasium Shared Pool Basement Parking 24 Hour Security and Maintenance\nVarious options in multiple projects for Rent and Sale.Toll Free: Display phone number For Rent & Sale: Display phone number List your property with us: info@nwmea.com| www.nwmea.com",
    		"About Property:Grab the hottest deal for a 2 bedroom apartment in the serenity of Al Reem Island, Abu Dhabi, UAE.Additional Features:Fully prepared kitchen Bathrooms Spacious rooms About Community:Al Reem Island is a residential, commercial and business project in Al Reem Isle, a natural island of 600 m off-coast from Abu Dhabi Island.This ‘mega development’ transforms the island into a ‘city within a city’.Some of the facilities that are on the island includes seven schools, golf courses, shopping malls, art galleries and four hospitals.Community Amenities and Surroundings:24/7 MaintenanceSchools and Colleges Gyms and Recreational Areas20 Minutes from Airport.10 Minutes from Abu Dhabi Island.5 Minutes from the Reem Mall.Contact us on:For various properties offers, please call:For Rent: Display phone number Toll fee: 800-UGPAE (84723)Phone: Display phone number visit our website at www.ugp.ae| Facebook https://www.facebook.com/ugpae/|on instagram: @ugpae |Google+ |Twitter |Youtube",
    		"Treo Homes are the leading agency in NSHAMA and have a team of agents dedicated to leasing and sales across the Townsquare sub-commnuites. We can assist with all your leasing and buying requirements.We are proud to present this brand new 2 Bedroom apartment in Zahra, Townsquare. These apartments have been finished to a high quality, with modern sleek finishes. As you enter there is a living and dining area adjacent to the kitchen and a master bedroom with large terrace area. The apartment benefits from all the close by amenities including a swimming pool and gymnasium.The building is equipped with multiple floors of parking, a Spinney's supermarket and a number of smaller shops including a Starbucks.The buildings are situated at the entrance to Townsquare, they benefit from the direct access to Umm Sequim Road providing direct access to all main highways.Largest 2 Bedroom 971 SQ-FT.Balcony Pool and Gym access Spinney's supermarket Handed overMultiple options Parking available",
    		"OBG proudly offers this vacant 2 bedroom apartment in The Torch Tower. It has semi closed kitchen layout in mid-floor with Community and Golf club views. There is a balcony with access from the living room, separate laundry and storage rooms. Master bedroom comes with attached bathroom and second separate bathroom in the hall. Apartment comes with one parking on the podium level. Facilities on 5th floor and it comes with swimming pool and huge mixed use gym.It is great investment for investor as I can easily rent out this apartment for AED 100,000 which means you will get 10% ROI as well for end user.The Torch is a development of the Select Group, well known developer in UAE with their latest projects Marina Gate Complex, Studio One and Number 9 in Dubai Marina. Tower managed by Kingfiled and they have very helpful staff.My name is Farid and I specialize in Dubai Marina mainly on the towers of Select Group. I know in and out everything about projects of Select Group and I have all available apartments for sale as well for rent.",
    		"About Property:Own a Spacious and well maintained 3 bedroom Villa within the access to modern facilities in Hydra Village. This unit consists of 1,849 sq.ft. and has two modern and wide bedrooms along with bathrooms and parking space. Hydra Village is one of the finest communities of Abu Dhabi.Additional Features:Spacious rooms Luxurious layout Huge kitchen Huge windows Panoramic view Community Amenities and Surroundings:Nearby:Schools and Colleges 24/7 Hospitals Gyms and Recreational Areas 30 Minutes from Abu Dhabi Airport 45 Minutes from Abu Dhabi Island 15 Minutes from Dubai Contact us on:United Gulf Properties is one of the leading real estate broker in the United Arab Emirates. For various properties offers and hottest deals/ properties, please call:\nFor Rent: Display phone number General Inquiries:Toll fee: 800-UGPAE (84723)Phone: Display phone number You can also visit our website at www.ugp.ae| Facebook https://www.facebook.com/ugpae/ | on instagram: @ugpae |Google+ |Twitter |Youtube",
    		"Lowest price in the market, Negotiable, Unit is on Mid floor Amaya Towers consists of two 25-level residential buildings resting on a common 5-level parking and retail podium in one of the most exclusive spots of Shams Abu Dhabi. Amaya Towers offers a lifestyle rich in choices and varieties.Features:Outstanding Finishes Bright Open Plan Living/Dining Area Modern Kitchen ScenicTerrace Shared Pool Shared Gym Built-in Wardrobe Maid's Room Car ParkAmaya Towers Amenities:Top Quality Finishes Outdoor Swimming Pool Visitors Car Park 4 high-speed elevator High-speed internet Fitness & Leisure center Open-air space for functions 24 Hours security & CCTV system Visitors registration lobby Location:Shams Abu Dhabi, Al Reem Island\n10 minutes to Abu Dhabi Downtown 20 minutes to Abu Dhabi International Airport Various options in multiple projects for Rent and Sale.For Sale: Display phone number I Toll Free: Display phone number For Rent: Display phone number List your property with us: info@nwmea.com | www.nwmea.com",
    		"Two Bedroom | Duplex Villa | Vacant | The Residences- Duplex Villa- Two Bedrooms- 2.5 Bathrooms- Vacant- 2,480 sq. ft- Balcony- Terrace- Two Car Parking- Gym/Pool- Property Sales Reference: PJM180994- Agent: Stephen Catharell on Display phone number, RERA BRN No. 32359 A two-Bedroom Duplex Villa, with a total area of 2,480 sq. ft located at The Residences. Consists of a large living/dining area, two Bedrooms with ensuite bathrooms, guest bathroom, kitchen with built-in appliances and a large terrace. Views overlooking the Boulevard towards Old Town and Vida Hotel.Property Sales Reference: PJM180994 Finance is available on this property through Allsopp & Allsopp Mortgage Services.For further details or to arrange a viewing appointment please contact our Head Office on +9714294444, alternatively visit our website www.allsoppandallsopp.com where you will find an extensive selection of properties available both for sale and for rent.Please call Stephen Catharell on Display phone numberfor more information or to arrange a viewing.",
    		"About Property:Grab the hottest deal for a 1 bedroom apartment in the serenity of Al Reem Island, Abu Dhabi, UAE.Additional Features:Fully prepared kitchen Bathrooms pacious rooms About Community:Al Reem Island is a residential, commercial and business project in Al Reem Isle, a natural island of 600 m off-coast from Abu Dhabi Island.This ‘mega development’ transforms the island into a ‘city within a city’.Some of the facilities that are on the island includes seven schools, golf courses, shopping malls, art galleries and four hospitals.Community Amenities and Surroundings:24/7 MaintenanceSchools and CollegesGyms and Recreational Areas 20 Minutes from Airport.10 Minutes from Abu Dhabi Island.5 Minutes from the Reem Mall.For various properties offers, please call:For Rent: Display phone number Toll fee: 800-UGPAE (84723)Phone: Display phone number You can also visit our website at www.ugp.ae| Facebook https://www.facebook.com/ugpae/ | on instagram: @ugpae | Google+ | Twitter | Youtube",
    		"DON'T MISS THIS OPPORTUNITY!Appello Real Estate is pleased to offer this immaculate five bedroom villa located in highly sought after Palm Jumeirah - which described as a wonder of the modern world and world's desirable residential area. This villa offers all the comforts and pleasures of luxury living.Property Features:* 5 Bedrooms* Atrium Entry Villa* Breathtaking View* Private Beach Access* Mediterranean Type 2* Plot size: 6498 sq.ft* 24 hour security* Private Pool\n* Landscaped arden Palm Jumeirah is the world’s largest man-made island. Its luxury villas and apartments have spectacular views of the sea and the surrounding architecture. All its features, starting with the exquisite and unique architecture, with its exclusive venues, resorts and landmark hotels, have created a spectacular, world-renowned residential and tourism destination.To arrange a viewing please contact, on Display phone number.If your call is not answered, please drop us a SMS or email..",
    		"About Community:Al Reem Island is a residential, commercial project in Al Reem Isle, a natural island of 600m off-coast from Abu Dhabi Island.The Gate District on Reem Island has quickly become one of Abu Dhabi’s foremost residential districts offering a perfect lifestyle destination. It is braced by a world class community with leisure facilities along with high-end retail offerings.Community Amenities and Surroundings:24/7 Maintenance Tennis and squash courts Recreation lodgings Saunas and Jacuzzis Playgrounds Nearby Areas:20 Minutes from Airport 5 Minutes from Abu DhabiContact us on:United Gulf Properties is one of the leading real estate broker in the United Arab Emirates. For various properties offers and hottest deals/ properties, please call:For Rent: Display phone number General Inquiries:Toll fee: 800-UGPAE (84723) Phone: Display phone number You can also visit our website at www.ugp.ae| Facebook https://www.facebook.com/ugpae/ | on instagram: @ugpae | Google+ | Twitter | Youtube |",
    		"About Property:Grab the hottest deal for a 2 bedroom apartment in the serenity of Al Reem Island, Abu Dhabi, UAE.Additional Features:Fully prepared kitchen Bathrooms Spacious rooms About Community:Al Reem Island is a residential, commercial and business project in Al Reem Isle, a natural island of 600 m off-coast from Abu Dhabi Island.This ‘mega development’ transforms the island into a ‘city within a city’.Some of the facilities that are on the island includes seven schools, golf courses, shopping malls, art galleries and four hospitals.Community Amenities and Surroundings:24/7 Maintenance Schools and CollegesGyms and Recreational Areas 20 Minutes from Airport 10 Minutes from Abu Dhabi Island.5 Minutes from the Reem Mall Contact us on:For various properties offers, please call:For Rent: Display phone number Toll fee: 800-UGPAE (84723) Phone: Display phone number visit our website at www.ugp.ae| Facebook https://www.facebook.com/ugpae/ | on instagram: @ugpae | Google+ | Twitter | Youtube",
    		"- Palmera 2- Type B- 2 Bedrooms plus study area\n- Bua: 2,219 Sq. Ft.- Plot: 2,765 Sq. Ft.- Well Located\n- Backing Pool and Park- Vacant on Transfer- Please call Agent: Danny Langston on Display phone number- RERA Permit No: 0392055262A must-see villa located in the popular community of Palmera in Arabian Ranches.On the first floor there is a large master bedroom with walk in wardrobe and en-suite.On the other end of the corridor there is a large second bedroom, study/third bedroom and a family bathroom.The entrance hallway, living room and dining area all have the flooring throughout to the ground floor. The kitchen is immaculate as though never used.Externally there is parking for two cars to the front, a terrace off the master bedroom, and a landscaped garden with a patio space. Viewings are highly recommended to appreciate.To discuss this property or to arrange a viewing please call Danny Langston on Display phone number Property Reference No.: DUB181779",
    		"Large Three Bedroom | DIFC Views | Vacant-Suite Area | 2,997 sq.ft.-Balcony Area | 130 sq.ft.-Total Area | 3,128 sq.ft.-Maids Room-Study-Balcony-Closed Kitchen-DIFC Views-3 Beds all with Ensuite-Powder room-Separate living and dining-Vacant-Reference No.: DUB181063-Agent: Charlie King Display phone number, RERA BRN No. 28081 New to market is this stunning three bedroom apartment in Index Tower with DIFC Views. Fully equipped kitchen, dining room, Large living room with balcony, three bedrooms with ensuite, powder room, store room and maids room.Property Reference: DUB181063 Finance is available on this property through Allsopp & Allsopp Mortgage Services.For further details or to arrange a viewing appointment please contact our Head Office on +9714294444, alternatively visit our website www.allsoppandallsopp.com where you will find an extensive selection of properties available both for sale and for rent.Agent: Charlie King Display phone number, RERA BRN No. 28081",
    		"The Wave Tower is a dazzling tower on Al Reem Island.The Wave Tower is a brand new high-rise building on Al Reem Island adding to Abu Dhabi Skyrise. This contemporary tower offers modern and excellent residences, offices and retail spaces. Built on a waterfront district on the island, the tower presents great panoramic views of the Marina and the spectacular Arabian Gulf.This Elegant Apartment Features:High-Quality Finishes Floor to Ceiling Window Modern Kitchen with Cabinet Balcony Elegant Bedroom Built-in Wardrobe Maid's Room ample Car Parking Apartment Facilities and Amenities:24 Hours Security and Maintenance Top Quality Finishes Fitness Center Landscaped and Roof Gardens Elegant Leisure Facilities Swimming Pool Children's Play Area Entry Lobbies Multipurpose Hall Basement Parking Various options in multiple projects for Rent and Sale.For Sale: Display phone number I Toll-Free: Display phone number For Rent: Display phone number List your property with us: info@nwmea.com | www.nwmea.com",};
    
    String PropertyType[]= {"Townhouse",
    		"Apartment",
    		"Apartment",
    		"Apartment",
    		"Townhouse",
    		"Villa",
    		"Apartment",
    		"Villa",
    		"Villa",
    		"Apartment",
    		"Apartment",
    		"Apartment",
    		"Apartment",
    		"Apartment",
    		"Villa",
    		"Apartment",
    		"Apartment",
    		"Apartment",
    		"Villa",
    		"Apartment",
    		"Apartment",
    		"Apartment",
    		"Villa",
    		"Apartment",
    		"Apartment",};
    
	
    
	public String[] getProjectName() {
		return ProjectName;
	}



	public void setProjectName(String[] projectName) {
		ProjectName = projectName;
	}



	public String[] getMapLocation() {
		return MapLocation;
	}



	public void setMapLocation(String[] mapLocation) {
		MapLocation = mapLocation;
	}



	public String[] getPropertyPrice() {
		return PropertyPrice;
	}



	public void setPropertyPrice(String[] propertyPrice) {
		PropertyPrice = propertyPrice;
	}



	public String[] getBedRoom() {
		return BedRoom;
	}



	public void setBedRoom(String[] bedRoom) {
		BedRoom = bedRoom;
	}



	public String[] getBathRoom() {
		return BathRoom;
	}



	public void setBathRoom(String[] bathRoom) {
		BathRoom = bathRoom;
	}



	public String[] getPropertyArea() {
		return PropertyArea;
	}



	public void setPropertyArea(String[] propertyArea) {
		PropertyArea = propertyArea;
	}



//	public String[] getUnit() {
//		return unit;
//	}
//
//
//
//	public void setUnit(String[] unit) {
//		this.unit = unit;
//	}



	public String[] getDescription() {
		return Description;
	}



	public void setDescription(String[] description) {
		Description = description;
	}



	public String[] getPropertyType() {
		return PropertyType;
	}



	public void setPropertyType(String[] propertyType) {
		PropertyType = propertyType;
	}



	public PropertyFinderData() {
		
	}
    
}
