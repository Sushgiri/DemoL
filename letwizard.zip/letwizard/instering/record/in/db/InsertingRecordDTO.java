package com.bestercapitalmedia.letwizard.instering.record.in.db;

public class InsertingRecordDTO {
	
	String userName;
	
	Integer totalRecordsToEnter;

	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public InsertingRecordDTO() {


		
	}
//	public int getTotalRecordsToEnter() {
//		return totalRecordsToEnter;
//	}
//	public void setTotalRecordsToEnter(int totalRecordsToEnter) {
//		this.totalRecordsToEnter = totalRecordsToEnter;
//	}
	public Integer getTotalRecordsToEnter() {
		return totalRecordsToEnter;
	}
	public void setTotalRecordsToEnter(Integer totalRecordsToEnter) {
		this.totalRecordsToEnter = totalRecordsToEnter;
	}
	

}