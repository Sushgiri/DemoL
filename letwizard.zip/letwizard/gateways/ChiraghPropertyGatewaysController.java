package com.bestercapitalmedia.letwizard.gateways;

/**
 * The Class ChiraghPropertyGatewaysController.
 */
public class ChiraghPropertyGatewaysController {

	
	
	
	
	
	
	
}
