package com.bestercapitalmedia.letwizard.appointments;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface AppointmentsRepository extends CrudRepository<Appointments, Integer> {

	@Query(value = "select * from appointments where department_id =?1 And property_id =?2 order by created_at desc", nativeQuery = true)
	public List<Appointments> findAppointmentsByDeptnProperty(int departmentId, int propertyId);
	
	@Query(value = "select * from appointments where property_id =?1 and department_id=?2 order by created_at desc limit 1", nativeQuery = true)
	public Appointments findLatestAppointment(Integer propertyId, int departmentId);
	
	@Query(value = "select count(*) from appointments where property_id =?1", nativeQuery = true)
	public Integer countAppointment(Integer propertyId);

	@Query(value = "select * from appointments where property_id =?1", nativeQuery = true)
	public List<Appointments> getAppointmentsByProperty(Integer propertyId);

	@Query(value = "SELECT * FROM appointments WHERE buyer_process_id IN (SELECT buyer_Process_Id FROM buyerprocess WHERE property_id = ?1 ) ORDER BY created_at DESC ", nativeQuery = true)
	public List<Appointments> getAppointmentsByBuyerProcess(Integer propertyId);
	
	@Query(value = "select * from appointments where id =?1", nativeQuery = true)
	public Appointments getAppointmentById(Integer appointmentId);
	
	@Query(value = "select * from appointments where buyer_process_id =?1 and department_id=?2 and is_buyer = 1 order by created_at desc limit 1", nativeQuery = true)
	public Appointments findLatestAppointmentForBuyer(Integer buyerProcessId, int departmentId);
	
	@Query(value = "select * from appointments where buyer_process_id =?1 and is_buyer = 1 and department_id = 3 and brokerage_confirm = 1 order by created_at desc limit 1", nativeQuery = true)
	public Appointments getOpenHouseAppointment(Integer buyerProcess);

	@Query(value = "SELECT * FROM appointments WHERE property_id = ?1 AND department_id = 3 AND (is_buyer IS NULL OR is_buyer = 0)", nativeQuery = true)
	public Appointments getBrokerageAppointment(Integer propertyId);
	
	@Query(value = "SELECT * FROM appointments WHERE property_id = ?1 AND department_id=3 AND brokerage_confirm = 1 AND buyer_process_id IS NULL", nativeQuery = true)
	public List<Appointments> brokerageAppointmentForPropertyDetails(Integer propertyId);
	
	
}
