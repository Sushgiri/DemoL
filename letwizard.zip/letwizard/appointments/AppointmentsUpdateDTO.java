package com.bestercapitalmedia.letwizard.appointments;

public class AppointmentsUpdateDTO {
	private Integer brokerageConfirm;
	private Integer thirdpartyConfirm;
	public AppointmentsUpdateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getBrokerageConfirm() {
		return brokerageConfirm;
	}
	public void setBrokerageConfirm(Integer brokerageConfirm) {
		this.brokerageConfirm = brokerageConfirm;
	}
	public Integer getThirdpartyConfirm() {
		return thirdpartyConfirm;
	}
	public void setThirdpartyConfirm(Integer thirdpartyConfirm) {
		this.thirdpartyConfirm = thirdpartyConfirm;
	}
	
	
}
