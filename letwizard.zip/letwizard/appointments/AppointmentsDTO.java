package com.bestercapitalmedia.letwizard.appointments;

import java.util.Date;

import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcessDTO;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcessDTO2;
import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;

public class AppointmentsDTO {
	private int id;
	private String title;
	private String description;
	private Date dated;
	private Integer valuationConfirm;
	private Integer brokerageConfirm;
	private Integer thirdpartyConfirm;
	private Integer propertyId;
	private Integer departmentId;
	private Date createdAt;
	private Date updatedAt;
	private Boolean buyerConfirm;
	private BuyerProcessDTO buyerProcess;
	private Integer leadId;
	private ChiraghUserDTO createdBy;
	public AppointmentsDTO() {
//		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getDated() {
		return dated;
	}
	public void setDated(Date dated) {
		this.dated = dated;
	}
	public Integer getValuationConfirm() {
		return valuationConfirm;
	}
	public void setValuationConfirm(Integer valuationConfirm) {
		this.valuationConfirm = valuationConfirm;
	}
	public Integer getBrokerageConfirm() {
		return brokerageConfirm;
	}
	public void setBrokerageConfirm(Integer brokerageConfirm) {
		this.brokerageConfirm = brokerageConfirm;
	}
	public Integer getThirdpartyConfirm() {
		return thirdpartyConfirm;
	}
	public void setThirdpartyConfirm(Integer thirdpartyConfirm) {
		this.thirdpartyConfirm = thirdpartyConfirm;
	}
	public Integer getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public Integer getLeadId() {
		return leadId;
	}
	public void setLeadId(Integer leadId) {
		this.leadId = leadId;
	}
	public Boolean getBuyerConfirm() {
		return buyerConfirm;
	}
	public void setBuyerConfirm(Boolean buyerConfirm) {
		this.buyerConfirm = buyerConfirm;
	}
	public BuyerProcessDTO getBuyerProcess() {
		return buyerProcess;
	}
	public void setBuyerProcess(BuyerProcessDTO buyerProcess) {
		this.buyerProcess = buyerProcess;
	}
	public ChiraghUserDTO getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(ChiraghUserDTO createdBy) {
		this.createdBy = createdBy;
	}
	
}
