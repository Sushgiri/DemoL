package com.bestercapitalmedia.letwizard.appointments;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcess;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "appointments")
public class Appointments implements java.io.Serializable {

	private int id;
	private String title;
	private String description;
	private Date dated;
	private Integer valuationConfirm;
	private Integer brokerageConfirm;
	private Integer thirdpartyConfirm;
//	private Integer propertyId;
	private Integer departmentId;
	private Date createdAt;
	private Date updatedAt;
	private Boolean isBuyer;
//	private Integer buyerProcessId;
	private Boolean buyerConfirm;
	private Chiraghproperty chiraghproperty;
	private BuyerProcess buyerProcess;
	private Chiraghuser createdBy;
	public Appointments() {
	}

//	public Appointments(int id, Date createdAt, Date updatedAt) {
//		this.id = id;
//		this.createdAt = createdAt;
//		this.updatedAt = updatedAt;
//	}
//
//	public Appointments(int id, String title, String description, Date dated, Byte valuationConfirm,
//			Byte brokerageConfirm, Byte thirdpartyConfirm, Integer propertyId, Integer departmentId, Date createdAt,
//			Date updatedAt) {
//		this.id = id;
//		this.title = title;
//		this.description = description;
//		this.dated = dated;
//		this.valuationConfirm = valuationConfirm;
//		this.brokerageConfirm = brokerageConfirm;
//		this.thirdpartyConfirm = thirdpartyConfirm;
//		this.propertyId = propertyId;
//		this.departmentId = departmentId;
//		this.createdAt = createdAt;
//		this.updatedAt = updatedAt;
//	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "id", unique = true, nullable = false)
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "title")
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "description")
	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dated", length = 26)
	public Date getDated() {
		return this.dated;
	}

	public void setDated(Date dated) {
		this.dated = dated;
	}

	@Column(name = "valuation_confirm")
	public Integer getValuationConfirm() {
		return this.valuationConfirm;
	}

	public void setValuationConfirm(Integer valuationConfirm) {
		this.valuationConfirm = valuationConfirm;
	}

	@Column(name = "brokerage_confirm")
	public Integer getBrokerageConfirm() {
		return this.brokerageConfirm;
	}

	public void setBrokerageConfirm(Integer brokerageConfirm) {
		this.brokerageConfirm = brokerageConfirm;
	}

	@Column(name = "thirdparty_confirm")
	public Integer getThirdpartyConfirm() {
		return this.thirdpartyConfirm;
	}

	public void setThirdpartyConfirm(Integer thirdpartyConfirm) {
		this.thirdpartyConfirm = thirdpartyConfirm;
	}

//	public Integer getPropertyId() {
//		return this.propertyId;
//	}
//
//	public void setPropertyId(Integer propertyId) {
//		this.propertyId = propertyId;
//	}

	@Column(name = "department_id")
	public Integer getDepartmentId() {
		return this.departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", length = 26)
	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", length = 26)
	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "property_Id")
	@JsonBackReference(value = "appointments")
	public Chiraghproperty getChiraghproperty() {
		return chiraghproperty;
	}

	public void setChiraghproperty(Chiraghproperty chiraghproperty) {
		this.chiraghproperty = chiraghproperty;
	}

	@Column(name = "is_buyer")
	public Boolean getIsBuyer() {
		return isBuyer;
	}

	public void setIsBuyer(Boolean isBuyer) {
		this.isBuyer = isBuyer;
	}

//	@Column(name = "buyer_process_id")
//	public Integer getBuyerProcessId() {
//		return buyerProcessId;
//	}
//
//	public void setBuyerProcessId(Integer buyerProcessId) {
//		this.buyerProcessId = buyerProcessId;
//	}

	@Column(name = "buyer_confirm")
	public Boolean getBuyerConfirm() {
		return buyerConfirm;
	}

	public void setBuyerConfirm(Boolean buyerConfirm) {
		this.buyerConfirm = buyerConfirm;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "buyer_process_id")
	public BuyerProcess getBuyerProcess() {
		return buyerProcess;
	}

	public void setBuyerProcess(BuyerProcess buyerProcess) {
		this.buyerProcess = buyerProcess;
	}

	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "created_by")
	public Chiraghuser getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Chiraghuser createdBy) {
		this.createdBy = createdBy;
	}
	
}
