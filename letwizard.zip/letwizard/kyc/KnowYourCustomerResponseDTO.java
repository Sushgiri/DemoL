package com.bestercapitalmedia.letwizard.kyc;

import java.math.BigDecimal;
import java.util.Date;

public class KnowYourCustomerResponseDTO {

	private String id;
	private String companyName;
	private String tradeLicenseNumber;
	private String dateOfIncorporation;
	private String placeOfIncorporation;
	private String companyAddressLane1;
	private String companyAddressLane2;
	private String beneficiaryOwner;
	private String nationality;
	private String scannedPassportCopy;
	private String scannedCopy;
	private String scannedAddressProofCopy;
	private String companyTradeLicenseCopy;
	private String otherDoc;
	private String netWorthCurrency;
	private BigDecimal annualIncomes;
	private BigDecimal valuationOfPatrimony;
	private BigDecimal evaluationOfIncomes;
	private Boolean isCitizen;
	private String fatcaForm;
	private String w8benForm;
	private Boolean isSanctionedCountry;
	private Boolean subsidiaryOffice;
	private Boolean isServiceProvider;
	private String customerComplianceForm;
	private String kycStatus;
	private Date createdAt;
	private String trnNumber;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getTradeLicenseNumber() {
		return tradeLicenseNumber;
	}

	public void setTradeLicenseNumber(String tradeLicenseNumber) {
		this.tradeLicenseNumber = tradeLicenseNumber;
	}

	public String getDateOfIncorporation() {
		return dateOfIncorporation;
	}

	public void setDateOfIncorporation(String dateOfIncorporation) {
		this.dateOfIncorporation = dateOfIncorporation;
	}

	public String getPlaceOfIncorporation() {
		return placeOfIncorporation;
	}

	public void setPlaceOfIncorporation(String placeOfIncorporation) {
		this.placeOfIncorporation = placeOfIncorporation;
	}

	public String getCompanyAddressLane1() {
		return companyAddressLane1;
	}

	public void setCompanyAddressLane1(String companyAddressLane1) {
		this.companyAddressLane1 = companyAddressLane1;
	}

	public String getCompanyAddressLane2() {
		return companyAddressLane2;
	}

	public void setCompanyAddressLane2(String companyAddressLane2) {
		this.companyAddressLane2 = companyAddressLane2;
	}

	public String getBeneficiaryOwner() {
		return beneficiaryOwner;
	}

	public void setBeneficiaryOwner(String beneficiaryOwner) {
		this.beneficiaryOwner = beneficiaryOwner;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getScannedPassportCopy() {
		return scannedPassportCopy;
	}

	public void setScannedPassportCopy(String scannedPassportCopy) {
		this.scannedPassportCopy = scannedPassportCopy;
	}

	public String getScannedCopy() {
		return scannedCopy;
	}

	public void setScannedCopy(String scannedCopy) {
		this.scannedCopy = scannedCopy;
	}

	public String getScannedAddressProofCopy() {
		return scannedAddressProofCopy;
	}

	public void setScannedAddressProofCopy(String scannedAddressProofCopy) {
		this.scannedAddressProofCopy = scannedAddressProofCopy;
	}

	public String getCompanyTradeLicenseCopy() {
		return companyTradeLicenseCopy;
	}

	public void setCompanyTradeLicenseCopy(String companyTradeLicenseCopy) {
		this.companyTradeLicenseCopy = companyTradeLicenseCopy;
	}

	public String getOtherDoc() {
		return otherDoc;
	}

	public void setOtherDoc(String otherDoc) {
		this.otherDoc = otherDoc;
	}

	public String getNetWorthCurrency() {
		return netWorthCurrency;
	}

	public void setNetWorthCurrency(String netWorthCurrency) {
		this.netWorthCurrency = netWorthCurrency;
	}

	public BigDecimal getAnnualIncomes() {
		return annualIncomes;
	}

	public void setAnnualIncomes(BigDecimal annualIncomes) {
		this.annualIncomes = annualIncomes;
	}

	public BigDecimal getValuationOfPatrimony() {
		return valuationOfPatrimony;
	}

	public void setValuationOfPatrimony(BigDecimal valuationOfPatrimony) {
		this.valuationOfPatrimony = valuationOfPatrimony;
	}

	public BigDecimal getEvaluationOfIncomes() {
		return evaluationOfIncomes;
	}

	public void setEvaluationOfIncomes(BigDecimal evaluationOfIncomes) {
		this.evaluationOfIncomes = evaluationOfIncomes;
	}

	public Boolean getIsCitizen() {
		return isCitizen;
	}

	public void setIsCitizen(Boolean isCitizen) {
		this.isCitizen = isCitizen;
	}

	public String getFatcaForm() {
		return fatcaForm;
	}

	public void setFatcaForm(String fatcaForm) {
		this.fatcaForm = fatcaForm;
	}

	public String getW8benForm() {
		return w8benForm;
	}

	public void setW8benForm(String w8benForm) {
		this.w8benForm = w8benForm;
	}

	public Boolean getIsSanctionedCountry() {
		return isSanctionedCountry;
	}

	public void setIsSanctionedCountry(Boolean isSanctionedCountry) {
		this.isSanctionedCountry = isSanctionedCountry;
	}

	public Boolean getSubsidiaryOffice() {
		return subsidiaryOffice;
	}

	public void setSubsidiaryOffice(Boolean subsidiaryOffice) {
		this.subsidiaryOffice = subsidiaryOffice;
	}

	public Boolean getIsServiceProvider() {
		return isServiceProvider;
	}

	public void setIsServiceProvider(Boolean isServiceProvider) {
		this.isServiceProvider = isServiceProvider;
	}

	public String getCustomerComplianceForm() {
		return customerComplianceForm;
	}

	public void setCustomerComplianceForm(String customerComplianceForm) {
		this.customerComplianceForm = customerComplianceForm;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKycStatus() {
		return kycStatus;
	}

	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getTrnNumber() {
		return trnNumber;
	}

	public void setTrnNumber(String trnNumber) {
		this.trnNumber = trnNumber;
	}
}
