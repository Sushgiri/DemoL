package com.bestercapitalmedia.letwizard.kyc;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.javers.common.collections.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.BuyerMessages;
import com.bestercapitalmedia.letwizard.constants.KysMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.mail.MailService;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;

@RestController
@CrossOrigin
@RequestMapping("/api/kyc")
public class KnowYourCustomerController {

	private static final Logger logger = LoggerFactory.getLogger(KnowYourCustomerController.class);
	@Autowired
	private ChiragUtill chiraghUtill;
	@Autowired
	private MailService mailService;
	@Autowired
	private PropertyRepository propertyRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private KnowYourCustomerService knowYourCustomerService;
	@Autowired
	private ResponseUtill responseUtill;

	/**
	 * 
	 * To save user KYC Form details and generate leads for admin finance department
	 * 
	 * @param knowYourCustomerRequest
	 * @param authentication
	 * @param httpServletRequest
	 * @return
	 */
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/post", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createKyc(@Valid @RequestBody KnowYourCustomerDTO knowYourCustomerRequest,
			Authentication authentication, HttpServletRequest httpServletRequest) {
		try {
			KnowYourCustomerDTO knowYourCustomerResponse = knowYourCustomerService.createKyc(knowYourCustomerRequest,
					authentication);

			if (knowYourCustomerResponse == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, KysMessages.KYC_SAVED_FAILURE,
						Stream.of(knowYourCustomerResponse).collect(Collectors.toList()));
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, KysMessages.KYC_SAVED_SUCCESS,
						Stream.of(knowYourCustomerResponse).collect(Collectors.toList()));

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getall", method = RequestMethod.GET)
	public ResponseEntity getAllKycForm(Authentication authentication, HttpServletRequest httpServletRequest) {
		try {
			List<KnowYourCustomerResponseDTO> knowYourCustomerResponse = knowYourCustomerService
					.getAllKycForms(authentication);

			if (knowYourCustomerResponse.isEmpty())
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, KysMessages.DATA_RETRIVED_FAILURE, null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, KysMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(knowYourCustomerResponse).collect(Collectors.toList()));

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/kyc/approval/status", method = RequestMethod.GET)
	public ResponseEntity getKycStatus(Authentication authentication, HttpServletRequest httpServletRequest) {
		try {
			KycStatusResponseDTO kycStatus = new KycStatusResponseDTO();
			Boolean isApprovalPending = knowYourCustomerService.getKycStatus(authentication);

			if (isApprovalPending) { // kyc already submitted and its approval is pending

				kycStatus.setIsKycApprovalPending("true");
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, KysMessages.KYC_APPROVAL_PENDING,
						Stream.of(kycStatus).collect(Collectors.toList()));

			} else if (!isApprovalPending) { // kyc not submitted

				kycStatus.setIsKycApprovalPending("false");

				Boolean isKycRejected = knowYourCustomerService.getKycRejected(authentication);
				if (isKycRejected) { // user kyc rejected
					kycStatus.setIsKycRejected("true");
					return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
							KysMessages.SUBMIT_YOUR_KYC_AFTER_REJECTION,
							Stream.of(kycStatus).collect(Collectors.toList()));
				} else if (!isKycRejected) { // no kyc rejected
					kycStatus.setIsKycRejected("false");

				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, KysMessages.SUBMIT_YOUR_KYC,
						Stream.of(kycStatus).collect(Collectors.toList()));

			} else {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, KysMessages.DATA_RETRIVED_FAILURE, null);

			}

		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					BuyerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

}
