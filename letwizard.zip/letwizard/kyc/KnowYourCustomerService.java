package com.bestercapitalmedia.letwizard.kyc;

import java.util.List;

import org.springframework.security.core.Authentication;

public interface KnowYourCustomerService {
	
	KnowYourCustomerDTO createKyc(KnowYourCustomerDTO knowYourCustomerRequest, Authentication authentication);
	List<KnowYourCustomerResponseDTO> getAllKycForms(Authentication authentication);
	Boolean getKycStatus(Authentication authentication);
	Boolean getKycRejected(Authentication authentication);

}
