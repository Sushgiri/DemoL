package com.bestercapitalmedia.letwizard.kyc;

import lombok.Data;

@Data
public class KycStatusResponseDTO {

	private String isKycApprovalPending;
	private String isKycRejected;


}
