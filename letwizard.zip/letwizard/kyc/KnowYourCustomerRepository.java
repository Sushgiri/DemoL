package com.bestercapitalmedia.letwizard.kyc;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface KnowYourCustomerRepository extends JpaRepository<KnowYourCustomer, Integer> {

	@Query(value = "Select * from know_your_customer WHERE user_id= ?1", nativeQuery = true)
	public List<KnowYourCustomer> getByKycUserId(int userId);

	@Query(value = "SELECT * FROM know_your_customer WHERE (kyc_status = 'in process' OR kyc_status = 'pending') AND user_id=?1", nativeQuery = true)
	public KnowYourCustomer findKycLeadByUserId(int userId);

	@Query(value = "SELECT * FROM know_your_customer WHERE user_id=?1 ORDER BY updated_at DESC", nativeQuery = true)
	public List<KnowYourCustomer> findAllKycLeadsByUserId(int userId);

	@Query(value = "SELECT * FROM know_your_customer WHERE user_id=?1 AND  (kyc_status = 'in process' OR kyc_status = 'pending') ", nativeQuery = true)
	public KnowYourCustomer findPendingApprovalKyc(int userId);

	@Query(value = "SELECT * FROM know_your_customer WHERE user_id = ?1 AND kyc_status = 'reject' LIMIT 1 ", nativeQuery = true)
	public KnowYourCustomer findRejectedKyc(int userId);

	@Query(value = "SELECT * FROM know_your_customer WHERE user_id = ?1 AND kyc_status = 'approve' LIMIT 1 ", nativeQuery = true)
	public KnowYourCustomer findApprovedKycByUserId(int userId);

	@Query(value = "Select * from know_your_customer WHERE user_id= ?1 AND owner_type ='company' order by created_at desc LIMIT 1", nativeQuery = true)
	public KnowYourCustomer getByKycUserIdForCompany(int userId);

	@Query(value = "Select * from know_your_customer WHERE user_id= ?1 AND owner_type ='owner' order by created_at desc LIMIT 1", nativeQuery = true)
	public KnowYourCustomer getByKycUserIdForOwner(int userId);
}
