package com.bestercapitalmedia.letwizard.kyc.leads;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface KycLeadsRepository extends JpaRepository<KycLeads, Integer> {

	@Query(value = "SELECT * FROM kyc_leads kyc_l JOIN know_your_customer kyc ON kyc.id = kyc_l.kyc_id WHERE (kyc_l.status = 'not started' OR kyc_l.status = 'in process') AND kyc.user_id=?1", nativeQuery = true)
	public KycLeads findKycLeadByUserId(int userId);
	
	@Query(value = "SELECT * FROM kyc_leads kyc_l JOIN know_your_customer kyc ON kyc.id = kyc_l.kyc_id WHERE kyc.user_id=?1", nativeQuery = true)
	public List<KycLeads> findAllKycLeadsByUserId(int userId);

}
