package com.bestercapitalmedia.letwizard.kyc;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bestercapitalmedia.fcmpushnotifications.firebase.FCMService;
import com.bestercapitalmedia.fcmpushnotifications.model.PushNotificationRequest;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationConstants;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationsService;
import com.bestercapitalmedia.letwizard.constants.EmailTemplatesConstants;
import com.bestercapitalmedia.letwizard.constants.TransactionConstants;
import com.bestercapitalmedia.letwizard.constants.WalletConstants;
import com.bestercapitalmedia.letwizard.kyc.leads.KycLeads;
import com.bestercapitalmedia.letwizard.kyc.leads.KycLeadsRepository;
import com.bestercapitalmedia.letwizard.leads.LeadUtils;
import com.bestercapitalmedia.letwizard.mail.EmailDTO;
import com.bestercapitalmedia.letwizard.mail.MailManager;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.bidprocess.Propertybidprocess;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.PusherUtil;
import com.bestercapitalmedia.letwizard.utill.StringUtils;
import com.bestercapitalmedia.letwizard.vouchers.CreateVoucherDTO;
import com.bestercapitalmedia.letwizard.vouchers.Voucher;
import com.bestercapitalmedia.letwizard.vouchers.VoucherDTO;
import com.bestercapitalmedia.letwizard.vouchers.VoucherRepository;
import com.bestercapitalmedia.letwizard.vouchers.VoucherService;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.lowagie.text.DocumentException;

import freemarker.template.MalformedTemplateNameException;
import freemarker.template.TemplateException;
import freemarker.template.TemplateNotFoundException;

@Service
public class KnowYourCustomerServiceImpl implements KnowYourCustomerService {

	private static final Logger logger = LoggerFactory.getLogger(KnowYourCustomerServiceImpl.class);
	@Autowired
	private KnowYourCustomerRepository knowYourCustomerRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private KycLeadsRepository kycLeadsRepository;

	@Autowired
	private VoucherRepository voucherRepository;

	@Autowired
	private VoucherService voucherService;

	@Autowired
	private NotificationsService notificationService;

	@Autowired
	private MailManager mailManager;

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private FCMService fcmService;
	
	@Override
	public KnowYourCustomerDTO createKyc(KnowYourCustomerDTO knowYourCustomerRequest, Authentication authentication) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");

			Chiraghuser letWizardUser = userRepository.findByUserNameAndRole(userName);
			ModelMapper modelmapper = new ModelMapper();

			String username = authentication.getName();
			Chiraghuser kycUser = userRepository.findByUserNameAndRole(username);
			if (kycUser == null) {
				return null;
			}
			Date date = new Date();
			if (knowYourCustomerRequest.getDob() != null) {

				try {
					SimpleDateFormat dateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
					Date passportExpiryDate = new Date();
					Calendar calendar = Calendar.getInstance();
					date = dateFormat1
							.parse(knowYourCustomerRequest.getDob() != null ? knowYourCustomerRequest.getDob() : null);
					passportExpiryDate = dateFormat.parse(knowYourCustomerRequest.getPassportExpiry() != null
							? knowYourCustomerRequest.getPassportExpiry()
							: null);
					if (passportExpiryDate != null) {
						calendar.setTime(passportExpiryDate);
						kycUser.setPassportExpiryDate(calendar);
					} else {
						calendar.setTime(null);
					}
					if (date != null) {
						kycUser.setDob(date);
					} else {
						kycUser.setDob(null);
					}

				} catch (ParseException | NullPointerException e) {
					System.out.println("Error occurred while parsing date: " + e.getMessage());
				}

			}

			Chiraghuser letwizardUser = null;

			if (knowYourCustomerRequest.getOwnerType().equalsIgnoreCase("owner") && kycUser != null) {

				kycUser.setBuildingAddress(knowYourCustomerRequest.getBuildingAddress());
				kycUser.setPoBox(knowYourCustomerRequest.getPoBox());
				kycUser.setCountryId(knowYourCustomerRequest.getCountryId());
				kycUser.setCityId(knowYourCustomerRequest.getCityId());
				kycUser.setPassportNumber(knowYourCustomerRequest.getPassportNumber());
				kycUser.setNationality(knowYourCustomerRequest.getNationality());
				kycUser.setMobileCode(knowYourCustomerRequest.getMobileCode());
				kycUser.setMobileNo(knowYourCustomerRequest.getMobileNumber());
				kycUser.setUserEmail(knowYourCustomerRequest.getUserEmail());
				letwizardUser = userRepository.save(kycUser);

			}

//					.findKycLeadByUserId(letwizardUser.getUserId())).isPresent());
			Optional<KnowYourCustomer> kycOwnerPresentCheck = Optional
					.ofNullable(knowYourCustomerRepository.getByKycUserIdForOwner(kycUser.getUserId()));
			if (true) {
				KnowYourCustomer knowYourCustomer = null;
				KnowYourCustomer kycOwnerNew = knowYourCustomerRepository.getByKycUserIdForOwner(kycUser.getUserId());
				if (kycOwnerNew !=null
						&& knowYourCustomerRequest.getOwnerType().equalsIgnoreCase("owner")) {
					KnowYourCustomer kycOwner = knowYourCustomerRepository.getByKycUserIdForOwner(kycUser.getUserId());
					kycOwner.setChiraghuser(kycUser);
					kycOwner.setCompanyName(null);
					kycOwner.setTradeLicenseNumber(null);
					kycOwner.setCompanyTradeLicenseCopy(null);
					kycOwner.setDateOfIncorporation(null);
					kycOwner.setPlaceOfIncorporation(null);
					kycOwner.setCompanyAddressLane1(null);
					kycOwner.setCompanyAddressLane2(null);
					kycOwner.setBeneficiaryOwner(null);
					kycOwner.setNationality(knowYourCustomerRequest.getNationality());
					kycOwner.setTrnTemp(null);
					kycOwner.setOwnerType("owner");
					if (!knowYourCustomerRequest.getIsCitizen()) {
						kycOwner.setKycStatus(LeadUtils.KycStatus.APPROVE); // if isCitizen is false auto approve
						kycOwner.setCreatedAt(new Date());
						kycOwner.setUpdatedAt(new Date());
						kycOwner.getChiraghuser().setIsKycApprove(true);

						knowYourCustomer = knowYourCustomerRepository.save(kycOwner);
						if (knowYourCustomer != null) {
							// create lead
							createKycLeadAutoApprove(kycUser, knowYourCustomer,
									WalletConstants.Currency.DEFAULT_CURRENCY_ID);
						}
					} else {
						if (null == kycUser.getIsKycApprove()) {
							kycOwner.getChiraghuser().setIsKycApprove(false);
						}
						kycOwner.setKycStatus(LeadUtils.KycStatus.PENDING);
						kycOwner.setCreatedAt(new Date());
						kycOwner.setUpdatedAt(new Date());

						knowYourCustomer = knowYourCustomerRepository.save(kycOwner);
						if (knowYourCustomer != null) {
							// create lead
							createKycLead(kycUser, knowYourCustomer, WalletConstants.Currency.DEFAULT_CURRENCY_ID);
						}
					}
					
				}
				if (!kycOwnerPresentCheck.isPresent()
						&& knowYourCustomerRequest.getOwnerType().equalsIgnoreCase("owner")) {
					KnowYourCustomer kycDetails = new KnowYourCustomer();
					kycDetails = modelmapper.map(knowYourCustomerRequest, KnowYourCustomer.class);
					kycDetails.setChiraghuser(kycUser);
					kycDetails.setCompanyName(null);
					kycDetails.setTradeLicenseNumber(null);
					kycDetails.setCompanyTradeLicenseCopy(null);
					kycDetails.setDateOfIncorporation(null);
					kycDetails.setPlaceOfIncorporation(null);
					kycDetails.setCompanyAddressLane1(null);
					kycDetails.setCompanyAddressLane2(null);
					kycDetails.setBeneficiaryOwner(null);
					kycDetails.setNationality(knowYourCustomerRequest.getNationality());
					kycDetails.setTrnTemp(null);
					kycDetails.setOwnerType("owner");
					
					if (!knowYourCustomerRequest.getIsCitizen()) {
						kycDetails.setKycStatus(LeadUtils.KycStatus.APPROVE); // if isCitizen is false auto approve
						kycDetails.setCreatedAt(new Date());
						kycDetails.setUpdatedAt(new Date());
						kycDetails.getChiraghuser().setIsKycApprove(true);

						knowYourCustomer = knowYourCustomerRepository.save(kycDetails);
						if (knowYourCustomer != null) {
							// create lead
							createKycLeadAutoApprove(kycUser, knowYourCustomer,
									WalletConstants.Currency.DEFAULT_CURRENCY_ID);
						}
					} else {
						if (null == kycUser.getIsKycApprove()) {
							kycDetails.getChiraghuser().setIsKycApprove(false);
						}
						kycDetails.setKycStatus(LeadUtils.KycStatus.PENDING);
						kycDetails.setCreatedAt(new Date());
						kycDetails.setUpdatedAt(new Date());

						knowYourCustomer = knowYourCustomerRepository.save(kycDetails);
						if (knowYourCustomer != null) {
							// create lead
							createKycLead(kycUser, knowYourCustomer, WalletConstants.Currency.DEFAULT_CURRENCY_ID);
						}
					}
					return knowYourCustomerRequest;
				}
				if (knowYourCustomerRequest.getOwnerType().equalsIgnoreCase("company")) {
					Optional<KnowYourCustomer> kycCompanyCheck = Optional
							.ofNullable(knowYourCustomerRepository.getByKycUserIdForCompany(kycUser.getUserId()));

					if (kycCompanyCheck.isPresent()) {
						KnowYourCustomer kyc = knowYourCustomerRepository.getByKycUserIdForCompany(kycUser.getUserId());
						kyc.setChiraghuser(kycUser);
						kyc.setCompanyName(knowYourCustomerRequest.getCompanyName());
						kyc.setTradeLicenseNumber(knowYourCustomerRequest.getTradeLicenseNumber());
						kyc.setCompanyTradeLicenseCopy(knowYourCustomerRequest.getCompanyTradeLicenseCopy());
						kyc.setDateOfIncorporation(knowYourCustomerRequest.getDateOfIncorporation());
						kyc.setPlaceOfIncorporation(knowYourCustomerRequest.getPlaceOfIncorporation());
						kyc.setCompanyAddressLane1(knowYourCustomerRequest.getCompanyAddressLane1());
						kyc.setCompanyAddressLane2(knowYourCustomerRequest.getCompanyAddressLane2());
						kyc.setBeneficiaryOwner(knowYourCustomerRequest.getBeneficiaryOwner());
						kyc.setNationality(knowYourCustomerRequest.getNationality());
						kyc.setOwnerType("company");
						if (knowYourCustomerRequest.getTrnNumber() != null) {
							if (!knowYourCustomerRequest.getTrnNumber().isEmpty()
									|| knowYourCustomerRequest.getTrnNumber() != "") {
								kyc.setTrnTemp(knowYourCustomerRequest.getTrnNumber());
							}
						}

						if (!knowYourCustomerRequest.getIsCitizen()) {
							kyc.setKycStatus(LeadUtils.KycStatus.APPROVE); // if isCitizen is false auto approve
							kyc.setCreatedAt(new Date());
							kyc.setUpdatedAt(new Date());
							kyc.getChiraghuser().setIsKycApprove(true);

							knowYourCustomer = knowYourCustomerRepository.save(kyc);
							if (knowYourCustomer != null) {
								// create lead
								createKycLeadAutoApprove(kycUser, knowYourCustomer,
										WalletConstants.Currency.DEFAULT_CURRENCY_ID);
							}
						} else {
							if (null == kycUser.getIsKycApprove()) {
								kyc.getChiraghuser().setIsKycApprove(false);
							}
							kyc.setKycStatus(LeadUtils.KycStatus.PENDING);
							kyc.setCreatedAt(new Date());
							kyc.setUpdatedAt(new Date());

							knowYourCustomer = knowYourCustomerRepository.save(kyc);
							if (knowYourCustomer != null) {
								// create lead
								createKycLead(kycUser, knowYourCustomer, WalletConstants.Currency.DEFAULT_CURRENCY_ID);
							}
						}
					}

					if (!kycCompanyCheck.isPresent()) {
						KnowYourCustomer kycNew = new KnowYourCustomer();
						kycNew = modelmapper.map(knowYourCustomerRequest, KnowYourCustomer.class);
						kycNew.setChiraghuser(kycUser);
						kycNew.setCompanyName(knowYourCustomerRequest.getCompanyName());
						kycNew.setTradeLicenseNumber(knowYourCustomerRequest.getTradeLicenseNumber());
						kycNew.setCompanyTradeLicenseCopy(knowYourCustomerRequest.getCompanyTradeLicenseCopy());
						kycNew.setDateOfIncorporation(knowYourCustomerRequest.getDateOfIncorporation());
						kycNew.setPlaceOfIncorporation(knowYourCustomerRequest.getPlaceOfIncorporation());
						kycNew.setCompanyAddressLane1(knowYourCustomerRequest.getCompanyAddressLane1());
						kycNew.setCompanyAddressLane2(knowYourCustomerRequest.getCompanyAddressLane2());
						kycNew.setBeneficiaryOwner(knowYourCustomerRequest.getBeneficiaryOwner());
						kycNew.setNationality(knowYourCustomerRequest.getNationality());
						kycNew.setOwnerType("company");
						if (knowYourCustomerRequest.getTrnNumber() != null) {
							if (!knowYourCustomerRequest.getTrnNumber().isEmpty()
									|| knowYourCustomerRequest.getTrnNumber() != "") {
								kycNew.setTrnTemp(knowYourCustomerRequest.getTrnNumber());
							}
						}

						if (!knowYourCustomerRequest.getIsCitizen()) {
							kycNew.setKycStatus(LeadUtils.KycStatus.APPROVE); // if isCitizen is false auto approve
							kycNew.setCreatedAt(new Date());
							kycNew.setUpdatedAt(new Date());
							kycNew.getChiraghuser().setIsKycApprove(true);

							knowYourCustomer = knowYourCustomerRepository.save(kycNew);
							if (knowYourCustomer != null) {
								// create lead
								createKycLeadAutoApprove(kycUser, knowYourCustomer,
										WalletConstants.Currency.DEFAULT_CURRENCY_ID);
							}
						} else {
							if (null == kycUser.getIsKycApprove()) {
								kycNew.getChiraghuser().setIsKycApprove(false);
							}
							kycNew.setKycStatus(LeadUtils.KycStatus.PENDING);
							kycNew.setCreatedAt(new Date());
							kycNew.setUpdatedAt(new Date());

							knowYourCustomer = knowYourCustomerRepository.save(kycNew);
							if (knowYourCustomer != null) {
								// create lead
								createKycLead(kycUser, knowYourCustomer, WalletConstants.Currency.DEFAULT_CURRENCY_ID);
							}
						}
					}
					return knowYourCustomerRequest;
				}
//				List<KnowYourCustomer> kyc1 = knowYourCustomerRepository.findAllKycLeadsByUserId(letwizardUser.getUserId());
//				System.out.println("kyc list "+kyc1);
//				if (kyc1 != null) {
//					return knowYourCustomerRequest;
//				}
				return knowYourCustomerRequest = null;
			}

		} catch (Exception e) {
			logger.error("exception while submiting kyc form ", e);

		}
		return null;
	}

	private void triggerKycSubmitEmail(Chiraghuser kycUser, KnowYourCustomer knowYourCustomer) {
		try {
			// notification
			notificationService.createKycNotification(kycUser, NotificationConstants.Description.kycSubmit,
					NotificationConstants.Subject.kycSubmite, knowYourCustomer.getId(),
					knowYourCustomer.getChiraghuser().getUserId());
			
			kycCreatePushNotification(knowYourCustomer, NotificationConstants.NotificationId.kycSubmit, 
					NotificationConstants.Title.yourKYCApplicationSubmittedSuccessfully, NotificationConstants.Topic.kycSubmit, 
					NotificationConstants.PNDescription.yourKYCApplicationSubmittedSuccessfully, 
					NotificationConstants.Type.yourKYCApplicationSubmittedSuccessfully);
			// email
			mailManager.sendHTML(knowYourCustomer.getChiraghuser().getUserEmail(),
					EmailTemplatesConstants.Subjects.KYC_SUBMITED, EmailTemplatesConstants.Body.KYC_SUBMITTED,
					knowYourCustomer.getChiraghuser().getFirstName(), EmailTemplatesConstants.CLIENT_SERVICE_EMAIL,
					EmailTemplatesConstants.FileNames.KYC_SUBMIT_TEMP, "", "", "", "", "", null, null);

		} catch (Exception e) {
			logger.error(
					"exception occures while sending email/notification for KYC(know your customer) Submittion Request ",
					e);
		}
	}

	private void triggerKycApproveEmail(Chiraghuser kycUser, KnowYourCustomer knowYourCustomer) {
		try {
			// notification
			notificationService.createKycNotification(kycUser, NotificationConstants.Description.kycApprove,
					NotificationConstants.Subject.kycApprove, knowYourCustomer.getId(),
					knowYourCustomer.getChiraghuser().getUserId());

			kycCreatePushNotification(knowYourCustomer, NotificationConstants.NotificationId.kycSubmit, 
					NotificationConstants.Title.yourKYCApplicationApprovedSuccessfully, NotificationConstants.Topic.kycSubmit, 
					NotificationConstants.PNDescription.yourKYCApplicationApprovedSuccessfully, 
					NotificationConstants.Type.yourKYCApplicationApprovedSuccessfully);
			
			// email
			mailManager.sendHTML(knowYourCustomer.getChiraghuser().getUserEmail(),
					EmailTemplatesConstants.Subjects.KYC_APPROVED, EmailTemplatesConstants.Body.KYC_APPROVED,
					knowYourCustomer.getChiraghuser().getFirstName(), EmailTemplatesConstants.CLIENT_SERVICE_EMAIL,
					EmailTemplatesConstants.FileNames.KYC_APPROVE_TEMP, "", "", "", "", "", null, null);

		} catch (Exception e) {
			logger.error("exception occures while sending email/notification for KYC(Know your customer) Approved ", e);
		}
	}

	public void createKycLead(Chiraghuser kycUser, KnowYourCustomer knowYourCustomer, int currencyId) {
		try {

			KycLeads kycLeads = new KycLeads();
			kycLeads.setKnowYourCustomer(knowYourCustomer);
			kycLeads.setDepartementId(TransactionConstants.Department.FINANCE);
			kycLeads.setCreatedAt(new Date());
			kycLeads.setUpdatedAt(new Date());
			kycLeads.setStatus(TransactionConstants.LeadStatus.NOT_STARTED);
			kycLeads.setCurrencyId(currencyId);
			KycLeads savedLead = kycLeadsRepository.save(kycLeads);

			// Implement pusher
			Map<String, String> map = new HashMap<>();
			map.put("leadId", savedLead.getId().toString());
			map.put("kycId", kycUser.getUserId().toString());
			PusherUtil.getDefault().push("new-kyc-leads", "created", map);
			// kyc submit email
			triggerKycSubmitEmail(kycUser, knowYourCustomer);

		} catch (Exception e) {
			logger.error("exception while creating kyc lead ", e);
		}
	}

	public void createKycLeadAutoApprove(Chiraghuser kycUser, KnowYourCustomer knowYourCustomer, int currencyId) {
		try {

			Chiraghuser superAdmin = userRepository.getSingleMD();

			KycLeads kycLeads = new KycLeads();
			kycLeads.setKnowYourCustomer(knowYourCustomer);
			kycLeads.setAssignedBy(superAdmin);
			kycLeads.setAssignedAt(new Date());
			kycLeads.setDepartementId(TransactionConstants.Department.FINANCE);
			kycLeads.setCreatedAt(new Date());
			kycLeads.setUpdatedAt(new Date());
			kycLeads.setProcess(TransactionConstants.LeadProcess.APPROVAL);
			kycLeads.setKycData(TransactionConstants.KycData.AUTO_APPROVED);

			kycLeads.setStatus(TransactionConstants.LeadStatus.DONE);
			kycLeads.setCurrencyId(currencyId);
			KycLeads savedLead = kycLeadsRepository.save(kycLeads);

			if (kycLeads != null) {
				List<Voucher> isVoucherExist = voucherRepository
						.getVouchersByUserId(kycLeads.getKnowYourCustomer().getChiraghuser().getUserId());
				logger.info("checking if currency account exists after kyc approval");
				if (isVoucherExist.isEmpty() || null == isVoucherExist) {
					// create user wallet if not exist
					logger.info("adding default currency account after kyc approval");
					// LW-107
					// createUserCurrencyAccounts(kycLeads.getKnowYourCustomer().getChiraghuser());
					logger.info("added default currency account after kyc approval");
				}

			}
			// Implement pusher
			Map<String, String> map = new HashMap<>();
			map.put("leadId", savedLead.getId().toString());
			map.put("kycId", kycUser.getUserId().toString());
			PusherUtil.getDefault().push("kyc-leads", "auto-approved", map);

			// kyc submit email
			triggerKycSubmitEmail(kycUser, knowYourCustomer);
			Thread.sleep(3000);
			// kyc approove email
			triggerKycApproveEmail(kycUser, knowYourCustomer);

		} catch (Exception e) {
			logger.error("exception while creating kyc Auto approved lead ", e);
		}
	}

	@Override
	public List<KnowYourCustomerResponseDTO> getAllKycForms(Authentication authentication) {
		try {

			String username = authentication.getName();
			Chiraghuser kycUser = userRepository.findByUserNameAndRole(username);
			if (kycUser == null) {
				return null;
			}
			List<KnowYourCustomer> knowYourCustomerList = knowYourCustomerRepository
					.findAllKycLeadsByUserId(kycUser.getUserId());
			if (knowYourCustomerList == null) {
				return null;
			}
			List<KnowYourCustomerResponseDTO> knowYourCustomerResposeList = ObjectMapperUtils
					.mapAll(knowYourCustomerList, KnowYourCustomerResponseDTO.class);
			// response
			return knowYourCustomerResposeList;
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Boolean getKycStatus(Authentication authentication) {
		try {

			String username = authentication.getName();
			Chiraghuser chiraghuser = userRepository.findByUserNameAndRole(username);
			if (chiraghuser == null) {
				return null;
			}
			KnowYourCustomer userPendingApprovalKyc = knowYourCustomerRepository
					.findPendingApprovalKyc(chiraghuser.getUserId());
			if (userPendingApprovalKyc == null) {
				return false; // no approval pending
			} else {
				triggerEmailForFinanceDepartment(chiraghuser);
				return true; // kyc approval pending
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Async
	public void triggerEmailForFinanceDepartment(Chiraghuser chiraghuser)
			throws TemplateNotFoundException, MalformedTemplateNameException, ParseException, DocumentException,
			IOException, TemplateException, InterruptedException {

		EmailDTO emailBody = new EmailDTO();
		emailBody.setUserName(StringUtils.capitalizer(chiraghuser.getFirstName() + " " + chiraghuser.getLastName()));
		emailBody.setUserCode(chiraghuser.getUserCode());

		List<Chiraghuser> financeUsers = userRepository.findUsersByDepartment(TransactionConstants.Department.FINANCE);
		for (Chiraghuser user : financeUsers) {
			mailManager.sendHTML(user.getUserEmail(), EmailTemplatesConstants.Subjects.KYC_APPROVAL_PENDING,
					EmailTemplatesConstants.Body.KYC_APPROVAL_PENDING,
					StringUtils.capitalizer(user.getDepartements().getName()),
					EmailTemplatesConstants.CLIENT_SERVICE_EMAIL, EmailTemplatesConstants.KYC_APPROVAL_PENDING_TEMP, "",
					"", "", "", "", null, emailBody);
			Thread.sleep(3000);
		}
	}

	@Transactional
	private void createUserCurrencyAccounts(Chiraghuser chiraghuser) {
		try {
			CreateVoucherDTO auctionFeeVoucher = new CreateVoucherDTO();
			auctionFeeVoucher.setIsCredit(true);
			auctionFeeVoucher.setAmount(new BigDecimal("0"));
			auctionFeeVoucher.setDescription("Account opening");
			auctionFeeVoucher.setTransactionStatus(2);
			auctionFeeVoucher.setExchangeCurrencyId(1); // WRONG WORKING
			auctionFeeVoucher.setPaymentMode("cash");
			auctionFeeVoucher.setRevenueStreamId(TransactionConstants.RevenueStream.topUp);
			VoucherDTO auctionFeeVoucherDTO = voucherService.createGenericVoucher(auctionFeeVoucher, chiraghuser);
		} catch (Exception e) {
			logger.error("exception occures while creating wallet after KYC approval", e);

		}
	}

	@Override
	public Boolean getKycRejected(Authentication authentication) {
		try {

			String username = authentication.getName();
			Chiraghuser chiraghuser = userRepository.findByUserNameAndRole(username);
			if (chiraghuser == null) {
				return null;
			}
			KnowYourCustomer userRejectedKyc = knowYourCustomerRepository.findRejectedKyc(chiraghuser.getUserId());
			if (userRejectedKyc == null) {
				return false; // no kyc rejected
			} else {
				return true; // kyc rejected
			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private void kycCreatePushNotification(KnowYourCustomer knowYourCustomer, String messageId,
			String messageTitle, String messageTopic, String messageDescription, String type) {

		logger.info("KnowYourCustomerServiceImpl : kycCreatePushNotification");

		if (knowYourCustomer != null) {
			if (knowYourCustomer.getChiraghuser() != null) {
				Chiraghuser user = knowYourCustomer.getChiraghuser();
				if (user.getFirebaseToken() != null && !user.getFirebaseToken().isEmpty()) {

					try {
						// Build notification payload
						Notification notification = new Notification(messageTitle, messageDescription);
						
						// Build data payload
						Map<String, String> data = new HashMap<>();
						data.put("message_id", messageId);
						data.put("title", messageTitle);
						data.put("message", messageDescription);
						data.put("notification_type", type);
						
						data.put("kyc_id", knowYourCustomer.getId()+"");
						data.put("status", knowYourCustomer.getKycStatus());
						
						// Build the message
						Message message = Message.builder().setToken(user.getFirebaseToken()) // FCM Token
								.setNotification(notification) // Notification object for foreground/background
								.putAllData(data) // Data payload for additional info
								.build();
						
						logger.info("Data in message to be sent : " + data);

						// Send the message using FirebaseMessaging
						String response = FirebaseMessaging.getInstance().send(message);
						
						logger.info("Successfully sent message : " + response);
						
					} catch (Exception e) {
						logger.error("Exception in KnowYourCustomerServiceImpl : kycCreatePushNotification : " + e.getMessage(), e);
					}
				}
			}
		}
	}
}