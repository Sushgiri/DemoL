
package com.bestercapitalmedia.letwizard.kyc;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonBackReference;

import com.bestercapitalmedia.letwizard.user.Chiraghuser;

@Entity
@Table(name = "know_your_customer")
public class KnowYourCustomer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumns({ @JoinColumn(name = "user_Id", referencedColumnName = "user_id") })
	@JsonBackReference
	Chiraghuser chiraghuser;

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "trade_license_number")
	private String tradeLicenseNumber;

	@Column(name = "date_of_incorporation")
	@Basic(fetch = FetchType.EAGER)
	private String dateOfIncorporation;

	@Column(name = "place_of_incorporation")
	@Basic(fetch = FetchType.EAGER)
	private String placeOfIncorporation;

	@Column(name = "company_address_lane1")
	@Basic(fetch = FetchType.EAGER)
	private String companyAddressLane1;

	@Column(name = "company_address_lane2")
	@Basic(fetch = FetchType.EAGER)
	private String companyAddressLane2;

	@Column(name = "beneficiary_owner")
	@Basic(fetch = FetchType.EAGER)
	private String beneficiaryOwner;

	@Column(name = "nationality")
	@Basic(fetch = FetchType.EAGER)
	private String nationality;

	@Column(name = "scanned_passport_copy")
	@Basic(fetch = FetchType.EAGER)
	private String scannedPassportCopy;

	@Column(name = "scanned_copy")
	@Basic(fetch = FetchType.EAGER)
	private String scannedCopy;

	@Column(name = "scanned_address_proof_copy")
	@Basic(fetch = FetchType.EAGER)
	private String scannedAddressProofCopy;

	@Column(name = "company_trade_license_copy")
	@Basic(fetch = FetchType.EAGER)
	private String companyTradeLicenseCopy;

	@Column(name = "other_doc")
	@Basic(fetch = FetchType.EAGER)
	private String otherDoc;

	@Column(name = "net_worth_currency")
	@Basic(fetch = FetchType.EAGER)
	private String netWorthCurrency;

	@Column(name = "annual_incomes")
	@Basic(fetch = FetchType.EAGER)
	private BigDecimal annualIncomes;

	@Column(name = "valuation_of_patrimony")
	@Basic(fetch = FetchType.EAGER)
	private BigDecimal valuationOfPatrimony;

	@Column(name = "evaluation_of_incomes")
	@Basic(fetch = FetchType.EAGER)
	private BigDecimal evaluationOfIncomes;

	@Column(name = "is_citizen")
	@Basic(fetch = FetchType.EAGER)
	private Boolean isCitizen;

	@Column(name = "fatca_form")
	@Basic(fetch = FetchType.EAGER)
	private String fatcaForm;

	@Column(name = "w8ben_form")
	@Basic(fetch = FetchType.EAGER)
	private String w8benForm;

	@Column(name = "is_sanctioned_country")
	@Basic(fetch = FetchType.EAGER)
	private Boolean isSanctionedCountry;

	@Column(name = "subsidiary_office")
	@Basic(fetch = FetchType.EAGER)
	Boolean subsidiaryOffice;

	@Column(name = "is_service_provider")
	@Basic(fetch = FetchType.EAGER)
	private Boolean isServiceProvider;

	@Column(name = "customer_compliance_form")
	@Basic(fetch = FetchType.EAGER)
	private String customerComplianceForm;

	@Column(name = "kyc_status")
	@Basic(fetch = FetchType.EAGER)
	private String kycStatus;

	@Column(name = "created_at")
	@Basic(fetch = FetchType.EAGER)
	private Date createdAt;

	@Column(name = "updated_at")
	@Basic(fetch = FetchType.EAGER)
	private Date updatedAt;

	@Column(name = "trn_number")
	private String trnNumber;

	@Column(name = "trn_temp")
	private String trnTemp;
	
	@Column(name = "owner_type")
	private String ownerType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOwnerType() {
		return ownerType;
	}

	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	public Chiraghuser getChiraghuser() {
		return chiraghuser;
	}

	public void setChiraghuser(Chiraghuser chiraghuser) {
		this.chiraghuser = chiraghuser;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getTradeLicenseNumber() {
		return tradeLicenseNumber;
	}

	public void setTradeLicenseNumber(String tradeLicenseNumber) {
		this.tradeLicenseNumber = tradeLicenseNumber;
	}

	public String getDateOfIncorporation() {
		return dateOfIncorporation;
	}

	public void setDateOfIncorporation(String dateOfIncorporation) {
		this.dateOfIncorporation = dateOfIncorporation;
	}

	public String getPlaceOfIncorporation() {
		return placeOfIncorporation;
	}

	public void setPlaceOfIncorporation(String placeOfIncorporation) {
		this.placeOfIncorporation = placeOfIncorporation;
	}

	public String getCompanyAddressLane1() {
		return companyAddressLane1;
	}

	public void setCompanyAddressLane1(String companyAddressLane1) {
		this.companyAddressLane1 = companyAddressLane1;
	}

	public String getCompanyAddressLane2() {
		return companyAddressLane2;
	}

	public void setCompanyAddressLane2(String companyAddressLane2) {
		this.companyAddressLane2 = companyAddressLane2;
	}

	public String getBeneficiaryOwner() {
		return beneficiaryOwner;
	}

	public void setBeneficiaryOwner(String beneficiaryOwner) {
		this.beneficiaryOwner = beneficiaryOwner;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getScannedPassportCopy() {
		return scannedPassportCopy;
	}

	public void setScannedPassportCopy(String scannedPassportCopy) {
		this.scannedPassportCopy = scannedPassportCopy;
	}

	public String getScannedCopy() {
		return scannedCopy;
	}

	public void setScannedCopy(String scannedCopy) {
		this.scannedCopy = scannedCopy;
	}

	public String getScannedAddressProofCopy() {
		return scannedAddressProofCopy;
	}

	public void setScannedAddressProofCopy(String scannedAddressProofCopy) {
		this.scannedAddressProofCopy = scannedAddressProofCopy;
	}

	public String getCompanyTradeLicenseCopy() {
		return companyTradeLicenseCopy;
	}

	public void setCompanyTradeLicenseCopy(String companyTradeLicenseCopy) {
		this.companyTradeLicenseCopy = companyTradeLicenseCopy;
	}

	public String getOtherDoc() {
		return otherDoc;
	}

	public void setOtherDoc(String otherDoc) {
		this.otherDoc = otherDoc;
	}

	public String getNetWorthCurrency() {
		return netWorthCurrency;
	}

	public void setNetWorthCurrency(String netWorthCurrency) {
		this.netWorthCurrency = netWorthCurrency;
	}

	public BigDecimal getAnnualIncomes() {
		return annualIncomes;
	}

	public void setAnnualIncomes(BigDecimal annualIncomes) {
		this.annualIncomes = annualIncomes;
	}

	public BigDecimal getValuationOfPatrimony() {
		return valuationOfPatrimony;
	}

	public void setValuationOfPatrimony(BigDecimal valuationOfPatrimony) {
		this.valuationOfPatrimony = valuationOfPatrimony;
	}

	public BigDecimal getEvaluationOfIncomes() {
		return evaluationOfIncomes;
	}

	public void setEvaluationOfIncomes(BigDecimal evaluationOfIncomes) {
		this.evaluationOfIncomes = evaluationOfIncomes;
	}

	public Boolean getIsCitizen() {
		return isCitizen;
	}

	public void setIsCitizen(Boolean isCitizen) {
		this.isCitizen = isCitizen;
	}

	public String getFatcaForm() {
		return fatcaForm;
	}

	public void setFatcaForm(String fatcaForm) {
		this.fatcaForm = fatcaForm;
	}

	public String getW8benForm() {
		return w8benForm;
	}

	public void setW8benForm(String w8benForm) {
		this.w8benForm = w8benForm;
	}

	public Boolean getIsSanctionedCountry() {
		return isSanctionedCountry;
	}

	public void setIsSanctionedCountry(Boolean isSanctionedCountry) {
		this.isSanctionedCountry = isSanctionedCountry;
	}

	public Boolean getSubsidiaryOffice() {
		return subsidiaryOffice;
	}

	public void setSubsidiaryOffice(Boolean subsidiaryOffice) {
		this.subsidiaryOffice = subsidiaryOffice;
	}

	public Boolean getIsServiceProvider() {
		return isServiceProvider;
	}

	public void setIsServiceProvider(Boolean isServiceProvider) {
		this.isServiceProvider = isServiceProvider;
	}

	public String getCustomerComplianceForm() {
		return customerComplianceForm;
	}

	public void setCustomerComplianceForm(String customerComplianceForm) {
		this.customerComplianceForm = customerComplianceForm;
	}

	public String getKycStatus() {
		return kycStatus;
	}

	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getTrnNumber() {
		return trnNumber;
	}

	public void setTrnNumber(String trnNumber) {
		this.trnNumber = trnNumber;
	}

	public String getTrnTemp() {
		return trnTemp;
	}

	public void setTrnTemp(String trnTemp) {
		this.trnTemp = trnTemp;
	}
}