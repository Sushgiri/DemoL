package com.bestercapitalmedia.letwizard.constants;

public class EvaluationConstants {
		
	public static final String USER_NAME = "dev@letwizard.com";
	public static final String PASSWORD = "Dev@123@@";
	public static final String GRANT_TYPE = "password";
	public static final String CLIENT_ID = "15";
	public static final String CLIENT_SECRET = "ozJ6xhRLcdHasXCGoGi1tWZ7KM9XdnhUdAhVPEDU";

}
