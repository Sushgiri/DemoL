package com.bestercapitalmedia.letwizard.constants;

public class LetwizardConstants {

//	String url = "http://stage-chiragh.surge.sh/registrationSuccess/" + token;
//	String url = "http://localhost:4200/registrationSuccess/" + token;
//	String url = "http://demo.chiragh.com/registrationSuccess/" + token;
//	public static final  String APP_URL="http://localhost:4200";

	public static final String APP_URL = "http://dev.chiragh.com";
//	public static final String APP_URL="http://demo.chiragh.com";
//	public static final String APP_URL="http://18.219.50.120";
	public static final int CLIENT_ID = 5;
	public static final int EXTEND_CLOSURE_TIME_BY_MINUTES = 3;
	
	public static final String LAST_MINUTE_BID = "LastMinuteBid";

	public static String BASE_URL_LEAD_HUB = "https://leadnest.ai";
	public static String OAUTH_TOKEN = "/oauth/token";
	public static String API_END_POINT = "/api/";
	
	public static final String IMAGE_PATH = "/home/ubuntu/apache-tomcat-stage/webapps/ChiraghDocuments/";
//	public static final  String IMAGE_PATH="https://s3.us-east-2.amazonaws.com/chiragh-asset/images/";

//	18.221.100.88:8085
//	public static final  String BIDDING_ENGINE_SERVER_PATH="http://localhost:8085";	
//	public static final  String BIDDING_ENGINE_SERVER_PATH="http://18.188.51.240:8080/BiddingEngine/";	
	public static final String BIDDING_ENGINE_SERVER_PATH = "https://bidding.letwizard.com/BiddingEngine";
//	public static final String BIDDING_ENGINE_SERVER_PATH = "http://127.0.0.1:8085";
//	public static final  String BIDDING_ENGINE_SERVER_PATH="http://18.188.51.240:8080/BiddingEngine";
//	public static final  String EVENTS_SERVER_REQUEST_PATH = "http://ec2-18-222-176-142.us-east-2.compute.amazonaws.com/queries.json";
//	public static final  String EVENTS_SERVER_PATH = "http://ec2-18-222-176-142.us-east-2.compute.amazonaws.com:/events.json?accessKey=dWWhfUYbp0v1qVHoV1KqHoatEIAEKvz8DeJWTVnW5zdpqbDYJHCTwdzbRO3UTTzj";

	public static final String EVENTS_SERVER_REQUEST_PATH = "http://13.59.166.45:8000/queries.json";
	public static final String EVENTS_SERVER_PATH = "http://13.59.166.45:7070/events.json?accessKey=_OWu3VkUjwe3o4aen-fT1BkBFqunm0gTSYLKQYqx7Jpx_o3rwhMIjOW-IgvyliAr";

	// ===== Shill bidding Constant =====
	public static final String SHILL_BIDDING_BASE_URL = "http://ec2-18-222-176-142.us-east-2.compute.amazonaws.com:8443";
	public static final String SHILL_BIDDING_START_URL = "/api/biddingactivityapicallrecords/biddingstartend";
	public static final String REAL_TIME_BIDDING_COMMON_REQUEST_URL = "/api/biddingactivityapicallrecords/postdata";
	public static final String SHILL_BIDDING_END_URL = "/api/biddingactivityapicallrecords/biddingstartend";

	public static final String SHILL_BIDDING_API_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiI1ZTA1MGViNTFiZTUwYzY1NzRmMTMwNzQiLCJleHAiOjEwMjE3Mzg5NzQ5NjM0fQ.nHLepUbDwVfDf97NRNGfxEI-dGabU9CSlwc0z6u5oU8";
	public static final String SHILL_BIDDING_APP_SECRET_KEY = "chiragh_bidding";
	public static final String SHILL_BIDDING_APP_ID = "5e050eb51be50c6574f13074";

	// ===== Property Evaluation Gadget =====
	// host for local testing 3.12.2.18
	public static final String ES_HOST = "3.12.2.18";
	public static final Integer ES_PORT = 9251;
	public static final String EVALUATION_GADGET_SERVER_PATH = "http://3.12.2.18:9251/evaluation_gadget/_search?pretty";
	public static final String EVALUATION_SUGGESTION_SERVER_PATH = "http://3.12.2.18:9251/area_suggestion/_doc/_search?pretty";

	// ===== Property Evaluation Leads API =====

	public static final String PROPERTY_EVALUATION_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String PROPERTY_EVALUATION_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-estimatelead");

	// ===== Property mortgage Eligibility Leads API =====

	public static final String PROPERTY_MORTGAGE_ELIGIBILITY_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String PROPERTY_MORTGAGE_ELIGIBILITY_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-lead");

	// ===== contact us  Leads API========

	public static final String CONTACT_US_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String CONTACT_US_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-contactuslead");

	// ======= request call back Leads API====

	public static final String REQUEST_CALL_BACK_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String REQUEST_CALL_BACK_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-requestcallback");

	// ======== genie search Leads API=======

	public static final String GENIE_SEARCH_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String GENIE_SEARCH_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-geniesearchlead");

	// =====Agent partner ship Leads API=========

	public static final String AGENT_PARTNERSHIP_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String AGENT_PARTNERSHIP_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-agentpartnershiplead");

	// ====== book a video call  Leads API ======

	public static final String BOOK_VIDEO_CALL_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String BOOK_VIDEO_CALL_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-videocalllead");
	
	// ====== Rent Now Pay Later (RNPL) Leads API ======

	public static final String RNPL_LEAD_AUTH = BASE_URL_LEAD_HUB.concat(OAUTH_TOKEN);
	public static final String RNPL_LEAD_URL = BASE_URL_LEAD_HUB.concat(API_END_POINT).concat("new-rnpl-lead");
	
	public static final String universalOtp = "1122222";
}