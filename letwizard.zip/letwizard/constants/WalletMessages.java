package com.bestercapitalmedia.letwizard.constants;

public class WalletMessages extends BasicErrorMessages {
	public static final String TOP_UP_SUCCESS = "Top-up request submitted successfuly.";
	public static final String WITHDRAW_REQUEST_SUCCESS = "Transfer (Outside letWizard) Request Generated Successfully";
}
