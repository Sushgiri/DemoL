package com.bestercapitalmedia.letwizard.constants;

public class ResponseCodes {

	public static final int SUCCESS=1;
	public static final int INTERNAL_SERVER_ERROR=500;
	public static final int FAILURE=0;
	public static final int FUNCTIONAL_FAILURE=2;
	public static final int NOT_FOUND=3;
	public static final int FORBIDDEN=403;
	
	
}
