package com.bestercapitalmedia.letwizard.constants;

public class BookVideoCallConstants {
	
	public class CallType{
		public static final int REQUEST_CALL_BACK  = 1;
		public static final int BOOK_VIDEO_CALL  = 2;

	}
		

}
