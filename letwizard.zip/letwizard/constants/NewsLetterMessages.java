package com.bestercapitalmedia.letwizard.constants;

public class NewsLetterMessages {
	
	public static final String NEWS_LETTER_SAVED_SUCCESS="You are now subscribed to our Newsletter emails";
	public static final String SUBSCRIPTION_FAILURE="You are already subscribed to our Newsletter emails.";
	public static final String INVALID_EMAIL="Entered email is InValid";


}
