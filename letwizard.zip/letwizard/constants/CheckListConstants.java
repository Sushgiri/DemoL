package com.bestercapitalmedia.letwizard.constants;

public class CheckListConstants {
	

	public class CheckListIds{
		public static final int BROKERAGE_AGENCY_TAGGED = 76;	

	}

}

