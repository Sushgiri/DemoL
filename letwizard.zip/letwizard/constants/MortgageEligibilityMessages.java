package com.bestercapitalmedia.letwizard.constants;

public class MortgageEligibilityMessages {
	
	public static final String SAVED_SUCCESS="Data Saved Successfully!";
	public static final String INVALID_EMAIL="Entered email is InValid";


}
