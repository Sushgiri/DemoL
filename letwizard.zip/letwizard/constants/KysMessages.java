package com.bestercapitalmedia.letwizard.constants;

public class KysMessages extends BasicErrorMessages{
	
	public static final String KYC_SAVED_FAILURE="Your KYC Form Not Saved!";
	public static final String KYC_SAVED_SUCCESS="Your KYC Form Saved Sucessfully!";
	
	public static final String KYC_APPROVAL_PENDING="Your KYC is currently under review. You will be able to proceed with the listing terms only after receiving an approval on your KYC. Thank you for your patience.";

	public static final String SUBMIT_YOUR_KYC="Kindly Complete Your KYC to proceed with the listing terms.";
	
	public static final String SUBMIT_YOUR_KYC_AFTER_REJECTION="Your KYC Application was rejected. Kindly Complete Your KYC and submit for approval to proceed with the listing terms.";


}
