package com.bestercapitalmedia.letwizard.constants;

public class BasicErrorMessages {
	public static final String FAILURE_MSG="Something went Wrong! ";
	public static final String INTERNAL_SERVER_ERROR_MSG="Something went Wrong! Resource not found";
	public static final String DATA_RETRIVED_SUCCESS="Data Retrived Successfully ";
	public static final String DATA_RETRIVED_FAILURE="Data Not Retrived!";
	public static final String AMOUNT_INSUFFICIENT="You don't have enough amount to submit this transaction!";
	public static final String INACTIVE_VALUATIONCOMPANY="The valuation company you're trying to select is no longer available";
	public static final String INVALID_OTP="Your OTP is invalid or already expired.";
	
	public static final String DATA_NOT_FOUND="Data not found!!";
	public static final String RESOURCE_DELETED_SUCESSFULLY="Resource Deleted Successfully";
	public static final String DATA_SAVED_FAILURE="Data Not Saved!";
	public static final String DATA_SAVED_SUCCESS="Data  Saved Successfully";
	public static final String TOUR_SAVED_SUCCESS="Property Tour Saved Successfully";
	public static final String CONTRACT_SAVED_SUCCESS="Contract Price Saved Successfully";
	public static final String PRICE_SAVED_SUCCESS="Price And Availability Saved Successfully";
	public static final String IMAGE_SAVED_FAILURE="IMAGE Not Saved!";
	public static final String IMAGE_SAVED_SUCCESS="IMAGE  Saved Successfully";
	public static final String User_NOT_FOUND="Invalid Session!";
	public static final String User_FOUND="User Found Successfully";
	public static final String USER_NOT_FOUND_AGAINST_USER_NAME="User Not Found against UserName";
	
	public static final String DATA_UPDATE_SUCCESS="Data UPDATE Successfully ";
	public static final String DATA_UPDATE_FAILURE="Data UPDATE Failure ";
    public static final String FILE_UPLOAD_SUCESSFULLY="File Upload Successfully";
    public static final String FILE_UPLOAD_FAILURE="Error In File Uploading";
	public static final String BUYER_WATCH_LIST="No Watch List Existed Against User";
	
	public static final String RECORD_INSERT_FAILURE="No User Exist";
	public static final String RECORD_INSERT_SUCCESS="Congratzzzz......!! Record have been Instered in d.b";
	public static final String DEPOSIT_REFUND_EMAIL_FAILURE="Deposit refund email not working";
	public static final String HIGHEST_BIDDER_EMAIL_FAILURE="Highest bidder email not working";

	public static final String ISSUE_WITH_CURRENCY_CONVERTER_API = "Exchange rate not available currently, try again later";
	
	public static final String TECHNICAL_ISSUE = "Sorry! We are experiencing technical difficulties at this time and we are working hard to try and resolve this issue as soon as possible. Thank you for your understanding.";
	public static final String DATA_NOT_SAVED = "Data Not Saved!!";
	
	public static final String DATA_SAVED_SUCCESSFULLY="Data Saved Successfully";
	
	public static final String CHANGE_REQUEST_NOT_ALLOWED="Change request can no longer be submitted as lead has already moved for HOD approval";



}

