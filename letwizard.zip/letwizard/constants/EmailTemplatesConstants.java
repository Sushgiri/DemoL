package com.bestercapitalmedia.letwizard.constants;

import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.bidprocess.Propertybidprocess;
import com.bestercapitalmedia.letwizard.property.rental.PropertyPriceAvailability;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.utill.DateUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EmailTemplatesConstants {

	@Autowired
	public static Environment environment;

	public static final String CLIENT_SERVICE_EMAIL = "support@letwizard.com";
	// ------------------------- New Email Template constants
	// ----------------------------
	public static final String SMS_LOGIN_2FACTOR = "sms-login-otp-2factor.ftl";
	public static final String FORGOT_PASSWORD_TEMP = "forgot-password-temp-n2.ftl";
	public static final String WALLET_OTP_GENERIC_EMAIL = "wallet-otp-generic-email-n2.ftl";
	public static final String ACTIVATE_ACCOUNT_TEMP = "activate-account-temp-n2.ftl";
	public static final String OUTBID_TEMP = "outbid-temp-n2.ftl";
	public static final String OUTBID_TEMP_RENTAL = "outbid-temp-n2-rental.ftl";
	public static final String GENERIC_EMAIL_TEMP = "generic-temp-n2.ftl";
	public static final String SECURITY_AND_VERIFICATION_OTP_TEMP = "security-verification-temp-n2.ftl";
	public static final String PROPERTY_LIVE_TEMP = "live-property-email-temp-n2.ftl";
	public static final String BID_PLACED_TEMP = "bid-placed-email-temp-n2.ftl";
	public static final String BID_CONFIRMATON_TEMP = "bid-confirmation-temp-n2.ftl";
	public static final String WINNING_BIDDER_TEMP = "winning-bidder-temp-n2.ftl";
	public static final String WINNING_BIDDER_TEMP_RENTAL = "winning-bidder-temp-n2-rental.ftl";
	public static final String OFFER_ACCEPTED_TEMP = "offer-accepted-temp.ftl";
	public static final String OFFER_ACCEPTED_RENTAL_TEMP = "offer-accepted-rental-temp.ftl";
	public static final String PROPERTY_SUBMITTED_TEMP = "property-submit-n2.ftl";
	public static final String WELCOME_EMAIL_TEMP = "welcome-email-temp.ftl";
	public static final String EMAIL_NOTIFICATION_WHEN_KYC_NOT_DONE = "email-notification-kyc-not-done.ftl";
	public static final String BID_CONFIRMATON_RENTAL = "rental-bid-confirmation-temp-n2.ftl";
	public static final String RENTAL_CHECKOUT_REVIEW = "rental-checkedout-review.ftl";
	public static final String RENTAL_RENT_NOW_PENDING = "rental-rent-now-pending.ftl";
	public static final String CONTACT_US_TEMP = "contact-us-temp-n2.ftl";
	public static final String RENT_NOW_BID_CONFIRMATION_TEMP = "rent-now-bid-confirmation.ftl";
	public static final String PAYTABS_TMEP = "paytab-temp.ftl";
	public static final String LISTING_TERMS_SELLERS = "seller-listing-terms.ftl";
	public static final String LISTING_TERMS_RENTALS = "rental-listing-terms.ftl";
	public static final String LISTING_TERM_TEMP = "listing-terms-temp.ftl";
	public static final String BID_CONFIRMATION_OWNER = "bid-confirmation-to-owner.ftl";
	public static final String VERIFY_EMAIL_GMAIL_SIGNUP = "verify-email-gmail-signup.ftl";
	public static final String RESET_YOUR_PASSWORD = "reset-password-temp.ftl";
	public static final String Auto_Reject_PG_Amount = "rental-auto-reject-pg-amount.ftl";
	public static final String Owner_Received_Bidder_Auto_Rejection = "owner-receive-bidder-autoreject-pg-amount-confirm.ftl";
	// test email
	public static final String TEST_TEMP = "test-temp.ftl";

	public static final String AUDIT_USER_LOGS_TEMP = "audit-user-logs-temp.ftl";

	public static final String KYC_APPROVAL_PENDING_TEMP = "kyc-approval-pending-temp-n2.ftl";

	public class Subjects {

		// no reply email
		public static final String PLACING_BID_OTP = "Here's Your OTP for Placing Your Bid on letWizard";
		public static final String PROPERTY_SUBMITTED = "Your Property Has Been Submitted Successfully!";
		public static final String PROPERTY_SUBMITTED_RENTAL = "Your Rental Property Has Been Submitted Successfully!";
		public static final String SECURITY_OTP = "Here’s Your OTP for Approving Listing Specifications";
		public static final String OUT_BID = "Someone Has Outbid You on letWizard!";
		public static final String PROPERTY_UN_SOLD_TAB = "Your Property Has Been Moved To The Unsold Tab";
		public static final String PROPERTY_UN_SOLD_TAB_RENTAL = "Your Property Has Been Moved To The Vacant Tab";
		public static final String PROPERTY_LIVE = "Your Property Is Live on letWizard for Bidding!";
		public static final String PROPERTY_LIVE_RENTAL = "Your Rental Property Is Live on letWizard for Bidding!";
		public static final String BID_PLACED_RENTAL = "Bid Confirmation";
		public static final String BID_ACCEPTED_RENTAL_MONTHLY = "Congratulations! You’ve Won The Bid!";
		public static final String RENT_NOW = "Congratulations! Your property is now on rent officially.";
		public static final String SECURITY_DEPOSIT_REFUNDED = "Your Security Deposit Has Been Refunded";
		public static final String AUCTION_DEPOSIT_REFUNDED = "Your Participation Guarantee Has Been Refunded";
		public static final String BID_CONFIRMATION = "Bid Confirmation";
		public static final String PROPERTY_RE_AUCTION = "Re-listing of Property";
		public static final String PROPERTY_RE_AUCTION_RENTAL = "Re-listing of Rental Property";
		public static final String WINNING_BIDDER = "Congratulations! You’ve won the bid!";
		public static final String OFFER_ACCEPTED = "Congratulations! Your offer has been accepted.";
		public static final String AUCTION_DEPOSIT_FORFEITED = "Your Participation Guarantee Has Been Forfeited!";
		public static final String SECURITY_DEPOSIT_FORFEITED = "Your Security Deposit Has Been Forfeited!";
		public static final String WELCOME_EMAIL_START = "Welcome ";
		public static final String WELCOME_EMAIL_END = "! We’re glad to have you onboard";
		public static final String EMAIL_NOTIFICATION_WHEN_KYC_NOT_DONE = "Your Property Has Been Saved!";
		public static final String BIDDING_OTP = "Here’s Your OTP for placing your Bid on letWizard rental";
		public static final String BIDDING_OTP1 = "Here’s Your OTP for Biding on letWizard Seller";
		public static final String BUYING_OTP1 = "Here’s Your OTP for Buying on letWizard Seller";
		public static final String SELLER_REJECT = "Seller has rejected your's bidding.";
		public static final String OWNER_BID_SUBJECT = "Your property's new bid confirmation";
		public static final String RESERVATION_CHECKEDIN_SUBJECT = "Here’s Your OTP for Check-In at letWizard rental";
		// support email
		public static final String ACCOUNT_ACTIVATION = "Activate Your letWizard Account";
		public static final String FORGOT_PASSWORD = "Forgot Your letWizard Password?";
		public static final String RESET_PASSWORD = "Set Your Password for Direct Access";
		public static final String VERIFY_EMAIL = "Verify your's email address with OTP shown in the mail";
		// wallet

		public static final String MY_ACCOUNTS = "Here's Your OTP to Add or Update Your Bank Account Information";
		public static final String INTERNAL_TRANSFER = "letWizard eWallet: Here's Your OTP for Transfer (Within letWizard)"; // TRANSFER
		public static final String OUTSIDE_TRANSFER = "letWizard eWallet: Here’s Your OTP for Transfer (Outside letWizard)"; // WITHDRAW

		// kyc approve

		public static final String KYC_APPROVED = "Your KYC Application Has Been Approved";
		public static final String KYC_SUBMITED = "Your KYC Application Has Been Submitted";

		public static final String KYC_APPROVAL_PENDING = "User KYC is pending approval from letWizard";

	}

	public class Body {
		public static final String PROPERTY_SUBMITTED = "Congratulations! You have successfully submitted your property to be listed on letWizard. A representative from our team will be contacting you soon to confirm your details and guide you through the next steps of the process. <br>"
				+ "We wish you all the best and hope your property is sold soon. ";
		public static final String PROPERTY_SUBMITTED_RENTAL = "Congratulations! You have successfully submitted your rental property to be listed on letWizard. A representative from our team will be contacting you soon to confirm your details and guide you through the next steps of the process. <br>"
				+ "We wish you all the best and hope your property is rented soon. ";
		public static final String PROPERTY_UN_SOLD_TAB = "This is to inform you that your property has been marked as unsold and moved to the unsold tab on your letWizard dashboard. We hope you'll be back soon to set an listing again.";
		public static final String PROPERTY_UN_SOLD_TAB_RENTAL = "This is to inform you that your property has been marked as vacant and moved to the vacant tab on your letWizard dashboard. We hope you'll be back soon to set an listing again.";

		public static final String PROPERTY_LIVE = "Congratulations!<br>"
				+ "You have successfully set an listing for your property on letWizard. Buyers from all around the world will be placing their bid on your property throughout the duration of your bidding. <br>"
				+ "Here's wishing you good luck!";

		public static final String PROPERTY_LIVE_RENTAL = "Congratulations!<br>"
				+ "You have successfully set an listing for your rental property on letWizard. Tenants from all around the world will be placing their bids on your property throughout the duration of your bidding. <br>"
				+ "Here's wishing you good luck!";

		public static final String PROPERTY_RE_AUCTION = "Your request for re-listing your property has been successfully submitted to letWizard. A representative from our team will be contacting you soon to guide you through the process of re-listing.";
		public static final String PROPERTY_RE_AUCTION_RENTAL = "Your request for re-listing your rental property has been successfully submitted to letWizard. A representative from our team will be contacting you soon to guide you through the process of re-listing.";
		public static final String KYC_APPROVAL_PENDING = "This is to inform that the following letWizard user's KYC Application is still under review and pending approval. The user is currently unable to complete the listing terms and proceed with the listing of the property on letWizard.com. Kindly review the KYC Application and complete the due process to allow the user to continue listing the property.";
		public static final String KYC_APPROVED = "It gives us great pleasure to inform that your KYC Application has been approved by the team at letWizard. You can now proceed to use your eWallet on letWizard.com for making transactions and bid on the property of your choice. <br><br> Once again, we thank you for your patience while we reviewed your application and completed the due verification process. <br><br>";
		public static final String KYC_SUBMITTED = "We would like thank you for taking the time to submit your KYC Application on letWizard.com.<br><br>The team at letWizard will now carefully review your application and verify the documents you have provided. Once your KYC Application is approved, you will be able to avail all the services on letWizard.com, including making transactions through the eWallet and bidding on properties of your choice.<br><br>To see the status of your application, please log in to letWizard.com, visit the Profile tab under your dashboard and click on KYC Application.<br><br>";
		public static final String SELLER_REJECTED = "Unfortunately , seller has rejeceted your bid, please try next time.";
	}

	public class Footers {

		public static final String AUCTION_SPECS_OTP = "For more information regarding your listing specifications, please contact our support team at ";
		public static final String PLACING_BID_OTP = "For more information regarding your bid, please contact our support team at ";
		public static final String PROPERTY_UN_SOLD = "For more information regarding your unsold property, please contact our client support at ";
		public static final String PROPERTY_UN_SOLD_RENTAL = "For more information regarding your rental property, please contact our client support at ";
		// wallet
		public static final String MY_ACCOUNTS = "For more information regarding your letWizard account, please contact our client support at ";
		public static final String INTERNAL_TRANSFER = "For more information regarding your fund transfer, please contact our client support at ";
		public static final String OUTSIDE_TRANSFER = "For more information regarding your fund transfer, please contact our client support at ";

		public static final String AUCTION_DEPOSIT_REFUNDED = "For more information regarding your listing deposit, please contact our support team at ";
		public static final String SECURITY_DEPOSIT_REFUNDED = "For more information regarding your security deposit, please contact our support team at ";

		public static final String AUCTION_DEPOSIT_FORFEITED = "For more information regarding your listing deposit, please contact our support team at ";
		public static final String SECURITY_DEPOSIT_FORFEITED = "For more information regarding your security deposit, please contact our support team at ";

		public static final String PROPERTY_RE_AUCTION = "For more information on your re-listing request, please contact our client support at ";
		public static final String PROPERTY_SUBMITTED = "For more information regarding your listing, please contact our support team at ";
	}

	public static class EmailBody {

		// Overdraft
		public static String OverdraftSubmitted(String currencyCode, String odId) {
			return "This is to inform that your request for activating the "
					+ "credit facility on your letWizard eWallet has been submitted successfully. Your unique ID for the requested credit facility is "
					+ currencyCode + " " + odId
					+ "<br> <br> Our Operations Team will be carefully assessing your request and you will be notified once it has been approved.<br> <br> For  more  information  or  further  assistance,  please  get  in  touch  with  our  support  team  at "
					+ CLIENT_SERVICE_EMAIL;
		}

		public static String CancelOverdraftSubmitted(String currencyCode, String odId, String pdfUrl) {
			return "You have successfully submitted your OD Cancellation Request with the unique ID no: OD "
					+ currencyCode + odId + " on letWizard."
					+ "<br> <br> Please find attached to this email a copy of the OD Cancellation Request Form.<br> <br>  <a href='"
					+ pdfUrl + "' >" + pdfUrl
					+ "</a> .<br> <br>For more information regarding your OD Cancellation Request, please contact our support team at  <a href='"
					+ CLIENT_SERVICE_EMAIL + "' >" + CLIENT_SERVICE_EMAIL + "</a>";
		}

		public static String EWalletTransactionEmailBody(String fromAccount, String toAccount, BigDecimal amount) {
			return "Your request for a Transfer Within letWizard from your " + fromAccount + " account to your "
					+ toAccount + " account for the amount of " + fromAccount + " " + amount
					+ " has been approved. You may now proceed to use your eWallet for transactions on letWizard.com.<br><br>"
					+ "If you have not submitted this request, kindly get in touch with our team for assistance.<br><br>For more information regarding your transfer, please contact our team at support@letwizard.com";
		}

		public static String topUpAprovel(String fromAccount, BigDecimal amount) {
			return "Your request for Top-Up on your letWizard eWallet for the amount of " + fromAccount + " " + amount
					+ " has been approved. You may now proceed to use your eWallet for transactions on letWizard.com. <br> <br> If you have not submitted this request, kindly get in touch with our team for assistance. <br><br>  For more information regarding your top-up, please contact our team at support@letwizard.com";
		}

		public static String bidPaced(Chiraghproperty chiraghproperty, String currencyCode, BigDecimal amount,
				String appURL) {
			appURL = appURL.replaceAll("^\"|\"$", "");
			String propertyUrl = appURL + "/detail/" + chiraghproperty.getPropertyId();
			String auctionUrl = appURL + "/dashboard/landlord/" + chiraghproperty.getPropertyId() + "/sidebar/auctions";
			String auctionEndDate = DateUtils.getDefault().addDaysAndMinuts(
					chiraghproperty.getBrokerageProposal().getAuctionStartDate(),
					chiraghproperty.getBrokerageProposal().getAuctionDuration(), -1) + "Gulf Standard Time";
			String content = "It gives us great pleasure to inform that you have received a bid on your rental property.<br>";
			content += "You have <b>5 minutes</b> to either accept the bid or put the bid on hold to wait till the listing ends.<br>";
			content += "<b>What happens if you accept or put the bid on hold?</b><br>";
			content += "If you accept this bid, your prospective tenant will be notified to proceed with the booking of the property. If you put it on hold, you&apos;ll be receiving bids till the listing completes, after which letWizard will automatically pick the highest bidder as the winner. <br>";
			content += "Ready to make the decision? <a href='" + auctionUrl
					+ "'> <b> Click here </b><a/> to accept or put the bid on hold.<br><br>";
			content += "<b>Property ID:</b> " + chiraghproperty.getPropertyId() + "<br>";
			content += "<b>Current Bid:</b> " + currencyCode + " " + amount + "<br>";
			content += "<b>Listing End Date:</b> " + auctionEndDate + "<br>";
			content += "<b>Property Link:</b> " + propertyUrl + "<br><br>";
			content += "If you want further information regarding this bid, please contact our client support at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";

			return content;
		}

		public static String dateFormatConversion(Date userDate) {
			SimpleDateFormat format = new SimpleDateFormat("d");
			String date = format.format(userDate);

			if (date.endsWith("1") && !date.endsWith("11")) {
				format = new SimpleDateFormat("d'st' MMM, yyyy");
			} else if (date.endsWith("2") && !date.endsWith("12")) {
				format = new SimpleDateFormat("d'nd' MMM, yyyy");
			} else if (date.endsWith("3") && !date.endsWith("13")) {
				format = new SimpleDateFormat("d'rd' MMM, yyyy");
			} else {
				format = new SimpleDateFormat("d'th' MMM, yyyy");
			}
			String yourDate = format.format(userDate);
			return yourDate;
		}

		public static String bidWinner(Chiraghproperty chiraghproperty, String currencyCode, BigDecimal amount,
				Integer buyerProcessId, Propertybidprocess propertybidprocess, String appURL) {
			appURL = appURL.replaceAll("^\"|\"$", "");
			String propertyUrl = appURL + "/detail/" + chiraghproperty.getPropertyId();
			String bookingUrl = appURL + "/dashboard/tenant-booking-invoice/" + chiraghproperty.getPropertyId()
					+ "/sidebar/bookingInvoice/" + buyerProcessId;
			String content = "It gives us great pleasure to announce that the bid you posted for the following "+chiraghproperty.getPropertyPriceAvailability().getAvailabilityType().toLowerCase()+" rental property has been accepted by the landlord.<br><br>";
			content += "In order to proceed with booking this property, you need to complete the payment by clicking on the link provided below. <br><br>";
			content += "<b> Property ID: </b> " + chiraghproperty.getPropertyId() + "<br>";
			content += "<b>Property Title: </b> " + chiraghproperty.getPropertyTitle() + "<br>";
			content += "<b>Check-in: </b>" + dateFormatConversion(propertybidprocess.getCheckInDate()) + "<br>";
			content += "<b>Check-out: </b>" + dateFormatConversion(propertybidprocess.getCheckOutDate()) + "<br>";
			content += "<b>Booking Amount: </b>" + chiraghproperty.getBrokerageProposal().getVoucherCurrency().getCode()
					+ "  " + chiraghproperty.getBrokerageProposal().getRentNowPriceFin() + "<br>";
			content += "<b>Property Link: </b> <a href= '" + bookingUrl + "'>" + bookingUrl + "</a> <br><br>";
			content += "Once your payment is complete, you can get in touch with the landlord directly for more details on your check-in and check-out timings, as well as set a time for handover of keys. <br><br>";
			content += "<b> Landlord Name: </b>" + chiraghproperty.getChiraghuser().getFirstName() + " "
					+ chiraghproperty.getChiraghuser().getLastName() + "<br>";
			content += "<b> Contact No: </b> " + chiraghproperty.getChiraghuser().getMobileCode()
					+ chiraghproperty.getChiraghuser().getMobileNo() + "<br><br>";

			content += "Once again congratulations on winning the bid and renting your dream property. <br>";
			content += "We hope you have a great time and will be back soon to rent another property. <br>";
			content += "If you want further information, please contact our support team at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";
			return content;
		}

		public static String ownerMailAcceptedBid(Chiraghproperty chiraghproperty, String currencyCode,
				BigDecimal amount, Integer buyerProcessId, Propertybidprocess propertybidprocess, String appURL) {
			appURL = appURL.replaceAll("^\"|\"$", "");
			String propertyUrl = appURL + "/detail/" + chiraghproperty.getPropertyId();
			String bookingUrl = appURL + "/dashboard/tenant-booking-invoice/" + chiraghproperty.getPropertyId()
					+ "/sidebar/bookingInvoice/" + buyerProcessId;
			String content = "Someone bid on your property accepted by the system ,details mentioned below- .<br><br>";

			content += "<b> Property ID: </b> " + chiraghproperty.getPropertyId() + "<br>";
			content += "<b>Property Title: </b> " + chiraghproperty.getPropertyTitle() + "<br>";
			content += "<b>Check-in: </b>" + dateFormatConversion(propertybidprocess.getCheckInDate()) + "<br>";
			content += "<b>Check-out: </b>" + dateFormatConversion(propertybidprocess.getCheckOutDate()) + "<br>";
			content += "<b>Booking Amount: </b>" + chiraghproperty.getBrokerageProposal().getVoucherCurrency().getCode()
					+ "  " + chiraghproperty.getBrokerageProposal().getRentNowPriceFin() + "<br>";

			content += "<b> Tenant Name: </b>" + propertybidprocess.getChiraghuser().getFirstName() + " "
					+ propertybidprocess.getChiraghuser().getLastName() + "<br>";
			content += "<b> Contact No: </b> " + propertybidprocess.getChiraghuser().getMobileCode()
					+ propertybidprocess.getChiraghuser().getMobileNo() + "<br><br>";

			content += "Once again congratulations on successfully selling your property <br>";
			content += "We hope you have a great time and will be back soon to rent another property. <br>";
			content += "If you want further information, please contact our support team at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";
			return content;
		}

		public static String rentNow(Chiraghuser chiraghuser, PropertyPriceAvailability propertyPriceAvailability) {

			String content = "It gives us great pleasure to inform you that the tenant has processed the payment for your rental property, and your property is now officially on rent. ";
			content += "<br><br>Here are some details about your new tenant to help you proceed with the next steps.<br><br>";
			content += "<b> Tenant Name: </b>" + chiraghuser.getFirstName() + " " + chiraghuser.getLastName() + "<br>";
			content += "<b>Contact Number: </b>" + chiraghuser.getMobileCode() + chiraghuser.getMobileNo() + "<br>";
			content += "<b>Check-in: </b>" + dateFormatConversion(propertyPriceAvailability.getAvailableFromN())
					+ "<br>";
			content += "<b>Check-out: </b>" + dateFormatConversion(propertyPriceAvailability.getAvailableEndN())
					+ "<br><br>";
			content += "You can get in touch with your tenant directly to set a time for handover of keys and discuss your property rules.<br><br>";
			content += "Once again congratulations on successfully renting your property through letWizard!<br><br>";
			content += "We hope you will back again soon to list another rental property. <br> <br>";
			content += "For more information, please contact our support team at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";

			return content;

		}

		public static String bidOtpRental(Chiraghproperty chiraghproperty, String otp) {
			String content = "Your OTP for placing your bid on letWizard rental is <b>" + otp
					+ "</b>. Please make sure that you DO NOT share your OTP with anyone. We wish you good luck on your bid.<br><br>";
			content += "<b>Property ID:</b> " + chiraghproperty.getPropertyId() + "<br>";
			content += "<b>Property Title:</b> " + chiraghproperty.getPropertyTitle() + "<br><br>";
			content += "For more information regarding your bid, please contact our support team at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";
			return content;
		}

		public static String bidOtpSeller(Chiraghproperty chiraghproperty, String otp) {
			String content = "Your OTP for bid on letWizard Seller is <b>" + otp
					+ "</b>. Please make sure that you DO NOT share your OTP with anyone. We wish you good luck on your bid.<br><br>";
			content += "<b>Property ID:</b> " + chiraghproperty.getPropertyId() + "<br>";
			content += "<b>Property Title:</b> " + chiraghproperty.getPropertyTitle() + "<br><br>";
			content += "For more information regarding your bid, please contact our support team at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";
			return content;
		}

		public static String buyOtpSeller(Chiraghproperty chiraghproperty, String otp) {
			String content = "Your OTP for buying on letWizard Seller is <b>" + otp
					+ "</b>. Please make sure that you DO NOT share your OTP with anyone. We wish you good luck on your bid.<br><br>";
			content += "<b>Property ID:</b> " + chiraghproperty.getPropertyId() + "<br>";
			content += "<b>Property Title:</b> " + chiraghproperty.getPropertyTitle() + "<br><br>";
			content += "For more information regarding your Buying, please contact our support team at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";
			return content;
		}
		public static String reservationcheckedInOTP(Chiraghproperty chiraghproperty, String otp) {
			String content = "Your OTP for check-In at letWizard rental is <b>" + otp
					+ "</b>. Please make sure that you DO NOT share your OTP with anyone. We're so excited to have you here. We hope your stay is filled with relaxation and comfort.<br><br>";
			content += "<b>Property ID:</b> " + chiraghproperty.getPropertyId() + "<br>";
			content += "<b>Property Title:</b> " + chiraghproperty.getPropertyTitle() + "<br><br>";
			content += "For more information regarding your Checked In, please contact our support team at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";
			return content;
		}
	}

	public static class Subject {

		// overdraft
		public static String OverdraftSubmitted(String currencyCode) {
			return "Credit Facility Request Submitted";
			// return currencyCode + " Facility Request Submitted";
		}

		public static String OverdraftCnlSubmitted(String currencyCode) {
			// return "Your " +currencyCode + " Cancellation Request Has Been Submitted
			// Successfully!";
			return "Your Credit Facility Cancellation Request Has Been Submitted Successfully!";
		}

		public static String EWalletSubject(String subject) {
			return subject;
		}

		public static String eWaletAprovelAndTransactions(String subject) {
			return subject;
		}

	}

	public static class FileNames {
		public static final String OVERDRAFT_TEMP = "overdraft-generic-temp.ftl";
		public static final String KYC_SUBMIT_TEMP = "kyc-submit-temp-n2.ftl";
		public static final String KYC_APPROVE_TEMP = "kyc-approve-temp-n2.ftl";
		public static final String EWALLET_TRANSACTIONS = "eWallet-transactions-temp-n2.ftl";
		public static final String CANCELOVERDRAFT_TEMP = "odCancilation-Email-Template.ftl";
		public static final String OFFER_REJECTED_TEMP = "offer-rejected-rental-temp2.ftl";
		public static final String OWNER_GETTING_BID_REJECTED_MAILS = "owner-get-mail-bid-autorejected.ftl";
	}

	public static String rentalBidPaced(Chiraghproperty chiraghproperty, String currencyCode, BigDecimal amount,
			String appURL) {
		appURL = appURL.replaceAll("^\"|\"$", "");
		String propertyUrl = appURL + "/detail/" + chiraghproperty.getPropertyId();
		String auctionUrl = appURL + "/dashboard/landlord/" + chiraghproperty.getPropertyId() + "/sidebar/auctions";
		String auctionEndDate = DateUtils.getDefault().addDaysAndMinuts(
				chiraghproperty.getBrokerageProposal().getAuctionStartDate(),
				chiraghproperty.getBrokerageProposal().getAuctionDuration(), -1) + "Gulf Standard Time";
		String content = "It gives us great pleasure to inform that you have received a bid on your rental property.<br>";
		content += "<b>Property ID:</b> " + chiraghproperty.getPropertyId() + "<br>";
		content += "<b>Current Bid:</b> " + currencyCode + " " + amount + "<br>";
		content += "<b>Listing End Date:</b> " + auctionEndDate + "<br>";
		content += "<b>Property Link:</b> " + propertyUrl + "<br><br>";
		content += "If you want further information regarding this bid, please contact our client support at <a href = 'mailto://support@letwizard.com' > support@letwizard.com</a>";

		return content;
	}

}
