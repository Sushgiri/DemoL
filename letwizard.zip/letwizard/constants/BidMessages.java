package com.bestercapitalmedia.letwizard.constants;

public class BidMessages {

	
	public  static final  String BID_SAVED="Bid Saved Successfully";
	public  static final  String BID_NOTSAVED="Time is expired you cannot bid !";
	public  static final  String BIDDETAILS_GET="Bid Details Retrived Successfully";
	public  static final  String BIDDETAILS_NOTGET="Something went wrong!!Bid Details  Not Retrived";
	public  static final  String BID_VERIFICATION_SUCCESS="User authorized for bidding successfully";
	public  static final  String BID_VERIFICATION_FALIURE="The OTP you entered is either invalid or expired. Please re-enter";
	public  static final  String BID_OTP_FAILURE="Invalid Otp";
	public  static final  String BID_OTP_SUCCESS="Otp Validate Successfully";
	public  static final  String BID_AMOUNT="Bid amount should be greater than the highest bid.";
	
	public static final String UNIVERSAL_OTP="d99dbca7a8aca84bfc5d7b40f7b1e87b";
}
