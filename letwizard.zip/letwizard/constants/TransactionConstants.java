package com.bestercapitalmedia.letwizard.constants;

public class TransactionConstants {

	public class RevenueStream{
		public static final int sellerSecurity = 1;
		public static final int buyerSecurity = 2;
		public static final int sellerCommision = 3;
		public static final int buyerCommision = 4;
		public static final int thirdPartyValuation = 5;
		public static final int topUp = 6;
		public static final int withdrawal = 7;
		public static final int auctionFee = 8;
		public static final int refund = 9;
		public static final int auctionDeposit = 10;
		public static final int accountTransfer = 11;
		public static final int sellerSecurityForfeit = 12;
		public static final int auctionDepositForfeit = 13;
		public static final int auctionFeeRefund = 14;
		public static final int sellerSecurityReversed = 15;
		public static final int auctionDepositReversed = 16;
		public static final int foreignExchangeFluctuationGain = 17;
		public static final int jvCreditDebit = 18;
		public static final int jvEarMark = 19;
		public static final int jvReleaseEarMark = 20;
		public static final int odCredit = 21;
		public static final int auctionFeeCreditCard = 22;
		public static final int odSettle = 23;
		public static final int buyNowDeposit = 24;
		public static final int odCancel = 26;
		public static final int landlordSecurity = 27;
		public static final int tenantSecurity = 28;
		public static final int landlordCommission = 29;
		public static final int tenantCommission = 30;
		public static final int rentalAuctionDeposit = 31;
		public static final int landlordSecurityForfeit = 32;
		public static final int rentalAuctionDepositForfeit = 33;
		public static final int rentalAuctionFeeRefund = 34;
		public static final int landlordSecurityReversed = 35;
		public static final int rentalAuctionDepositReversed = 36;
		public static final int rentNowDeposit = 37;
		public static final int rentalAuctionFee = 38;
		public static final int rentalPaymentCreditCard = 39;
		public static final int rentalPayment = 40;
		public static final int tenantOtherDeposit = 41;
		public static final int landlordOtherDeposit = 42;
		public static final int landlordVat = 43;
		public static final int tenantVat = 44;
		public static final int landlordRent = 45;
		public static final int tenantRent = 46;
		public static final int landlordPerformanceFee = 47;
		public static final int landlordOtherFee = 48;
		public static final int landlordVatApplicableFee = 49;


	}

	public class TransactionStatus{
		public static final int pending = 1;
		public static final int approved = 2;
		public static final int inProcess = 3;
		public static final int decline = 4;
	}

	public class RevenueStreamDescription{
		public static final String sellerSecurity = "Seller Security Guarantee";
		public static final String landlordSecurity = "Landlord Security Guarantee";
		public static final String securityFromTenant = "Security Guarantee from Tenant";
		public static final String buyerSecurity = "";
		public static final String tenantSecurity = "Tenant Security Guarantee";
		public static final String sellerCommision = "";
		public static final String landlordCommision = "Landlord Commission";
		public static final String buyerCommision = "";
		public static final String tenantCommision = "Tenant Commission";
		public static final String thirdPartyValuation = "third party valuation fee";
		public static final String thirdPartyValuationRefund = "third party valuation fee reversal";
		public static final String topUp = "topup amount";
		public static final String withdrawal = "Transfer (Outside letWizard) Request";
		public static final String auctionFee = "auction fee";
		public static final String rentalAuctionFee = "Rental listing fee";
		public static final String refund = "";
		public static final String auctionDeposit = "Participation Guarantee";
		public static final String rentalAuctionDeposit = "Rental listing Guarantee";
		public static final String buyNowDeposit = "Buy Now Guarantee";
		public static final String rentNowDeposit = "Rent Now Guarantee";
		public static final String accountTransfer = "account transfer";
		public static final String sellerSecurityForfeit = "Seller Security Forfeited";
		public static final String landlordSecurityForfeit = "Seller Security Forfeited";
		public static final String auctionDepositForfeit = "Auction Guarantee Forfeited";
		public static final String rentalAuctionDepositForfeit = "Rental Participation Guarantee Forfeited";
		public static final String auctionFeeRefund = "Auction Fee Refund";
		public static final String sellerSecurityReversed = "Seller security released";
		public static final String landlordSecurityReversed = "Landlord security released";
		public static final String auctionDepositReversed = "Auction Guarantee released";
		public static final String rentalAuctionDepositReversed = "Rental Participation Guarantee released";
		public static final String accountTransferExchangeGain = "account transfer exchange gain";
		public static final String jvCredit = "Journal Voucher Credit";
		public static final String jvDebit = "Journal Voucher Debit";
		public static final String jvEarMark = "Journal Voucher Earmark";
		public static final String jvReleaseEarMark = "Journal Voucher Release Earmark";
		public static final String odCredit = "OD Credit";
		public static final String auctionFeeCreditCard = "Auction Fee Credit Card";
		public static final String rentalPaymentCreditCard = "Rental Payment Credit Card";
		public static final String odSettle = "Journal Voucher Settle OD";
		public static final String tenantRent = "Rent";
		public static final String landlordRent = "Rent";
		public static final String tenantOtherDeposit = "Other Deposit";
		public static final String landlordOtherDeposit = "Other Deposit";
		public static final String tenantVat = "VAT";
		public static final String landlordVat = "VAT";
		public static final String landlordPerformanceFee = "Performance Fee";
		public static final String landlordOtherFee = "Other Fees";
		public static final String landlordVatApplicableFee = "VAT & Applicable Fees";
	}

	public class Department{
		public static final int FINANCE = 4;

	}
	public class Role{
		public static final int USER = 2;
		public static final int HOD = 3;

	}
	public class LeadStatus{
		public static final String NOT_STARTED = "not started";
		public static final String IN_PROCESS = "in process";
		public static final String ARCHIVE = "archive";
		public static final String DONE = "done";
		public static final String REJECT = "reject";

	}
	public class LeadProcess{
		public static final String APPROVAL = "approval";
	}

	public class InvoiceType{
		public static final String TAX_INVOICE = "tax_invoice";
	}

	public class InvoiceTemplates{
		public static final String TAX_TEMPLATE = "tax-receipt.ftl";
	}

	public class NumaricConstant{
		public static final int ONE_HUNDRED_FIVE = 105; // FOR 5% VAT
		public static final int HUNDRED = 100;

	}
	public class Tax{
		public static final int VAT_PERCENTAGE = 5;

	}

	public class LocalCurrency{
		public static final int AED_LOCAL_CURRECNY_ID = 2;

	}

	public class KycData{
		public static final String AUTO_APPROVED = "auto-approved";
	}

}
