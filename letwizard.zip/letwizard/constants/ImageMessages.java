package com.bestercapitalmedia.letwizard.constants;

public class ImageMessages {

	public static final String IMAGE_TYPE_UPDATE_SUCCESS = "Image Type Updated Sucessfully";
	public static final String IMAGE_TYPE_UPDATE_FAILURE = "Image Type Not Updated!";

	public static final String IMAGE_SAVED_FAILURE = "Image Not Saved!";
	public static final String IMAGE_SAVED_SUCCESS = "Image Saved Sucessfully";
	public static final String IMAGE_UPDATE_SUCCESS = "Image Updated Sucessfully";
	public static final String IMAGE_UPDATE_FAILURE = "Image Not Found!! Invalid Url!";
	public static final String IMAGE_DELETE_SUCCESS = "Image Delete Successfully";
	public static final String IMAGE_DELETE_FAILURE = "Something went wrong! Image Not Delete !!";
	public static final String VIDEO_SAVED_SUCCESS = "Video Saved Sucessfully";
	public static final String VIDEO_UPDATE_FAILURE = "Video Not Found!! Invalid Url!";
	public static final String VIDEO_DELETE_SUCCESS = "Video Delete Successfully";
	public static final String VIDEO_DELETE_FAILURE = "Something went wrong! Video Not Delete !!";
	public static final String VIDEO_SAVED_FAILURE = "Video Not Saved!";

}
