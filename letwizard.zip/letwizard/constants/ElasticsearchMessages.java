package com.bestercapitalmedia.letwizard.constants;


public class ElasticsearchMessages {

	public static final String  DATA_NOT_FOUND = "Data Not Found!";
	public static final String  DATA_RETRIVED_SUCCESS = "Data Retrived Successfully!";
	public static final String  INTERNAL_SERVER_ERROR_MSG = "Something went Wrong! Resource not found!";
}
