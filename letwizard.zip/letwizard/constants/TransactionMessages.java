package com.bestercapitalmedia.letwizard.constants;

public class TransactionMessages {

	public  static final  String OTP_GENERATION_SUCCESS="OTP Generated Successfully";
	public  static final  String OTP_GENERATION_FAILURE="OTP Not Generated Successfully";
	public  static final  String TRANSACTION_SAVED_SUCCESS="Transaction Saved Successfully";
	public  static final  String TRANSACTION_SAVED_FAILURE="Transaction  Not Saved ";
	
	public class Accounts {
		public static final int CASH_IN_HAND = 1;
		public static final int CASH_IN_BANK = 2;
		public static final int INCOME = 3;
		public static final int USER = 4;
		public static final int PAYABLE = 5;
		public static final int RECEIVABLE = 6;
		public static final int EXCLUSIVE_RIGHTS = 7;

	}	
	
	public class Reference{
		public  static final  String USER="user";
		public  static final  String CHIRAGH="chiragh";
	}
	
}

