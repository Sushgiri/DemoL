package com.bestercapitalmedia.letwizard.constants;

public class UserMessages extends BasicErrorMessages{

	public static final String LOGIN_SUCCESS_MSG="Login Successfully";
	public static final String EMAIL_NOT_SENT="Something went Wrong! EMAIL NOT SENT";
	public static final String EMAIL_SENT="EMAIL SENT SUCCESSFULLY";
	public static final String RESET_PASSWORD_FAIL="Password Reset Fail! User Not Verified";
	public static final String RESET_PASSWORD_SUCCESS="Password Reset Successfully";
	public static final String User_VERIFIED="User Verified Successfully";
	public static final String User_NOT_VERIFIED="User Not Verified!";
	public static final String VIRIFICATION_LINK_EXPIRED="Token is expired or user already activated";
	public static final String VIRIFICATION_OTP_EXPIRED="OTP expired";
	
	public static final String PASSWORD_CHANGED_SUCCESS="Password Changed Successfully";
	public static final String PASSWORD_CHANGED_FAILURE="Something went wrong! Password Not Changed";
	public static final String USER_REGISTER_SUCCESS="User Register Successfully";
	public static final String USER_REGISTER_FAILURE="User Registeration Fail!";
	
	public static final String USER_INDEXED="All Activated Users Indexed to Recommendation Engine!";
	
	public static final String USER_SUBSCRIBE="User has been subscribed successfully";
	public static final String USER_UNSUBSCRIBE="User has been un-subscribed successfully";

	public static final String SMS_SENT_SUCCESS="SMS Sent";
	public static final String SMS_SENT_FAILURE="SMS Sending fail";

	public static final String FORGET_PASSWORD_FAIL = "You have not activated your letWizard account yet. Please check your email and click on the activation link to activate your account. If you did not receive an email check your spam.";
    
}
