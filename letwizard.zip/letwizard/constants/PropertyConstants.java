package com.bestercapitalmedia.letwizard.constants;

public class PropertyConstants {

	public static final  String UPCOMING_AUCTION_STATUS = "waiting";
	public static final  String CURRENT_AUCTION_STATUS = "live";
	public static final String ACTIVE_STATUS = "active";

}
