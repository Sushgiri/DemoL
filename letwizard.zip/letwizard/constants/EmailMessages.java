package com.bestercapitalmedia.letwizard.constants;

public class EmailMessages {

	public static final String EMAIL_SENT_SUCCESS="Email Sent";
	public static final String EMAIL_SENT_FAILURE="Email Sending fail";
	
	public class EmailSubjects{
		public static final String SECURITY_ALERT="Your letWizard account has been signed in from a new device";
	}


}
