package com.bestercapitalmedia.letwizard.constants;

public class PropertyMessages extends BasicErrorMessages {
	

	public static final String PROPERTY_STATUS_NOT_UPDATED="Property Status not updated";
	public static final String PROPERTY_STATUS_UPDATED="Property Status updated Successfully";
	
	public static final String PROPERTY_FOUND_SUCCESS="Property found Successfully";
	public static final String PROPERTY_FOUND_FAILURE="Property not found!!";
	
	public static final String PROPERTY_SAVED_SUCCESS="Property saved successfully";
	public static final String PROPERTY_SAVED_FAILURE="Property Not saved !!";

	public static final String PROPERTY_MORTGAGE_DETAIL_SAVED_SUCCESS="Property Mortgage Details Saved Successfully";
	public static final String PROPERTY_MORTGAGE_DETAIL_SAVED_FAILURE="Property Mortgage Details Not Saved!!";
	
	public static final String PROPERTY_RENTAL_DETAIL_SAVED_FAILURE="Property Rental Details Not Saved!!";
	public static final String PROPERTY_RENTAL_DETAIL_SAVED_SUCCESS="Property Rental Details Saved Successfully";
	
	public static final String PROPERTY_Attributes_SAVED_SUCCESS="Property Atributes Saved Successfully";
	public static final String PROPERTY_Attributes_SAVED_FAILURE="Property Atributes Not Saved ";
	
	public static final String PROPERTY_Attributes_LIST_GET_SUCCESS="Property Atributes List Retrived Successfully ";
	public static final String PROPERTY_Attributes_LIST_GET_FAILURE="Property Atributes List Not Retrived!! ";
	
	
	
	public static final String PROPERTY_SEND_TO_ENGINE_SUCCESS="Property is Live now.";
	public static final String PROPERTY_SEND_TO_ENGINE_FAILURE="Property Not Sent to Bidding Engine";
	public static final String PROPERTY_ASSIGN_SUCCESS="Property has been assigned to user successfully";
	public static final String PROPERTY_ASSIGN_FAILURE="Something went wrong. Please try again!";
	public static final String PROPERTY_DETAILS_SAVED_SUCCESS="Property details have been saved successfully";
	public static final String PROPERTY_DETAILS_SAVED_FAILURE="Something went wrong! Property not saved";
	public static final String PROPERTY_DETAILS_NOT_UPDATED="Your update request can no longer be completed as your property has already been moved to valuation stage.";
	public static final String PROPERTY_RENTAL_DETAILS_SAVED_SUCCESS="Rental details saved succesfully";
	public static final String PROPERTY_RENTAL_DETAILS_SAVED_FAILURE="Something went wrong! Property rental details not saved";
	public static final String PROPERTY_FINANCIAL_DETAILS_SAVED_SUCCESS="Mortgage details saved successfully";
	public static final String PROPERTY_FINANCIAL_DETAILS_SAVED_FAILURE="Something went wrong. Mortgage details not saved";
	public static final String PROPERTY_SEARCH_EMPTY=" 0 result found!";
	public static final String PROPERTY_SEARCH_NULL=" No record found!";
	public static final String WATCH_LIST_ADDED="Property added to Watch List sucessfully";
	public static final String WATCH_LIST_EXIST="Property removed From Watch List!";
	public static final String HISTORY_ADDED="Property Added to History Sucessfully";
	public static final String HISTORY_EXIT="Property already exist in your History";
	public static final String HISTORY_DELETE="Property deleted From History sucessfully!";
	public static final String WATCH_LIST_DELETE="Property deleted From Watch List Sucessfully!";
	public static final String NO_PROPERTY_EXIST="Property Not Existed!";
	public static final String VALUATION_COMPANIES_SUCCESS="List Of Companies Extracted Sucessfully!";
	public static final String VALUATION_COMPANIES_FAILURE="No Company Existed!";
	public static final String BANK_EXISTED="Bank Already Exist!";
	public static final String BANK_SUCCESS="List Of Bank Extracted Sucessfully!";
	public static final String BANK_ADDED="New Bank Added Sucessfully!";
	public static final String VALUATION_COMPANIES_PROCESS_SUCCESS="User Selected These Companies For Valuation";
	public static final String VALUATION_COMPANIES_PROCESS_FAILURE="User Selected No Company For Valuation";
	public static final String PROPERTY_FEATURES_NULL=" No record found!";
	public static final String PROPERTY_FEATURES_SUCCESS="List Of Features/Facilities/Neighbourhood Extracted Sucessfully!";
	public static final String AUCTION_FEE_DETAILS_FAILURE="Auction Details Are Not Saved ";
	public static final String AUCTION_FEE_DETAILS_SUCCESS="Auction Details Saved Successfully";
	public static final String INVALID_OTP="Your OTP is invalid or already expired.";
	public static final String INVALID_EMAIL="Entered email is InValid";
	public static final String VALUATION_COMPANY_UPDATE="Valuation company updated successfully";
	public static final String USER_ACTIVATED="User already activated";
	public static final String SHILL_BIDDING_API_ERROR="Shill Bidding API not working fine!";
	public static final String PROFILE_IMAGE_SAVED="Profile image saved successfully";
	public static final String PROFILE_IMAGE_DELETED="Profile image deleted successfully";
	public static final String BID_ERROR="Your bid cannot be placed at the moment. Please try again after sometime.";
	
	public static final String VIEWED_PROPERTY_AND_USER_INDEXED="Viewed Property and Viewed By User Indexed to Recommendation Engine!";

	public static final String WALLET_SAVE_FAILURE="Wallet Not Saved!";
	public static final String WALLET_ALREADY_EXIST="This wallet already exist";
	public static final String BROKERAGE_AGENCY_ALREADY_EXIST="The brokerage agency you are trying to add already exist.";

	public static final String ENQUIRY_FORM_EXIST="Enquiry Form Already Exist";

	public static final String AEDOD_UTILIZED="Your OD Utilized Amount is not equal to 0.0";
	
	public static final String DEVICE_TOKEN_UPDATED_SUCCESSFULLY="Firebase device token updated successfully";
}