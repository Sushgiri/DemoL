package com.bestercapitalmedia.letwizard.constants;
public class BlockChainConstants {
	
	public class TokenType {
		public static final String BCI_AUCTION = "BCIAuction";
		public static final String BCI_AUCTION_BID = "bciAuctionBid";
		public static final String FINALIZE_BID = "finalizeBid";
		public static final String REJECT_BID = "rejectBid";
		public static final String ARCHIVE_PROPERTY = "updateStatus";
		
	}
	
	public static final String BCI_AUTH_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZGVudGl0eVR5cGUiOiJ1c2VyIiwidXNlcklkIjoiVXNlcjEiLCJlbmNyeXB0ZWQiOiIiLCJleHAiOjI2MDc0MzA2NTEsImlhdCI6MTYwNzM0NDI1MSwiaXNzIjoiYXV0aG9yaXR5LXNlcnZpY2UifQ.ZmtesNHftABLQhUVNdEz2JXXsrbie4t5HsYCKMijdPQ";

	public static final String BCI_BASE_URL = "https://bci.dev.docuwalk.com";
	public static final String BCI_CREATE_AUCTION = "/token";

	public static final String BCI_AUCTION_BID_START = "/token/BCIAuction";
	public static final String BCI_AUCTION_BID_END = "/event";

	public static final String BCI_GET_AUCTION_DETAILS = "/token/BCIAuction";

	public static final String BCI_FINALIZE_BID_START = "/token/BCIAuction";
	public static final String BCI_FINALIZE_BID_END = "/event";

	public static final String BCI_REJECT_BID_START = "/token/BCIAuction";
	public static final String BCI_REJECT_BID_END = "/event";
	
	public static final String BCI_ARCHIVE_PROPERTY_START = "/token/BCIAuction";
	public static final String BCI_ARCHIVE_PROPERTY_END = "/event";
	public static final String BCI_JWT_TOKEN = "/auth";
	
	public static final String BCI_CREATE_AUCTION_IDENTIFIER = "createAuction";
	public static final String BCI_SAVE_BID_IDENTIFIER = "saveBid";
	public static final String BCI_FINALIZED_BID_IDENTIFIER = "finalizedBid";
	public static final String BCI_REJECT_BID_IDENTIFIER = "rejectBid";
	public static final String BCI_CLOSE_AUCTION_IDENTIFIER = "closeAuction";
	public static final String BCI_ARCHIVE_AUCTION_IDENTIFIER = "archiveAuction";
	public static final String BCI_LIVE_AUCTION_IDENTIFIER = "liveAuction";

}
