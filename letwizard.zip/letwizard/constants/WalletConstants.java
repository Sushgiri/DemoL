package com.bestercapitalmedia.letwizard.constants;

public class WalletConstants {
	
	public static final String WITHDRAWAL_TRANSACTION_TYPE="withdrawal";	


	public class Currency{
		public static final int DEFAULT_CURRENCY_ID=2;	

	}
	
	public class OverdraftCurrency{
		public static final int AEDOD_DEFAULT_CURRENCY_ID=21;	

	}
	
	public class OverdraftCurrencyCode{
		public static final String AEDOD_DEFAULT_CURRENCY_CODE="OD";	

	}

}

