package com.bestercapitalmedia.letwizard.constants;

public class BuyerMessages extends BasicErrorMessages{
	
	public static final String DATA_SAVED_FAILURE="Buyer Details Not Saved!";
	
	public static final String DATA_SAVED_SUCCESS="Buyer Details Saved Sucessfully!";
	
	public static final String DATA_RETRIEVED_SUCCESS="Buyer Details Retrieved Sucessfully!";
	
	public static final String DATA_RETRIEVED_FAILURE="Buyer Doesn't Exist!";
	
	public static final String BUYER_EXIST_FAILURE="Invaild!";
	
	public static final String BUYER_EXIST_SUCCESS="Buyer Details Existing!";
	public static final String BUYER_NOTEXIST_SUCCESS="Buyer Details Doesn't Exist!";
	
}
