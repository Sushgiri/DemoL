package com.bestercapitalmedia.letwizard.constants;

public class LetwizardMessages {
	//messages for checklist
	public static final String CHECKLIST_SAVED_SUCCESS="Checklist Saved Sucessfully";
	public static final String CHECKLIST_SAVED_FAILURE="Checklist  Not Saved!!";
	
	public class overdraftMessages {
		public static final String OVERDRAFT_SAVED_SUCCESS="Overdraft Saved Sucessfully";
		public static final String OVERDRAFT_SAVED_FAILURE="Overdraft  Not Saved!!";
		public static final String KYC_NOT_APPROVED="You cannot submit OD request until your KYC is approved";

		public static final String OVERDRAFT_CANNOT_SUBMIT_AGAIN="You cannot submit the same details as per your already Active OD facility";

	}
	
}
