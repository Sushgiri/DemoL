package com.bestercapitalmedia.letwizard.constants;

public class SellerMessages extends BasicErrorMessages {
	public static final String USER_REGISTER_FAILURE = "User Register Successfully";
	public static final String COMPANY_ATTRIBUTES_RETRIEVAL_FAILURE = "Data Not Retrived!";
	public static final String COMPANY_ATTRIBUTES_RETRIEVAL_SUCCESS = "Data Retrived Successfully!";
	public static final String COMPANY_LEGAL_REPRESENTATIVE_SUCCESS = "Company Representative save Successfully";
    public static final String COMPANY_LEGAL_REPRESENTATIVE_FAILURE="Company Representative not Save"; 
	public static final String PROPERTY_RESOURCE_NOT_FOUND = "Property Resource Not Found";
	public static final String COMPANY_LEGAL_RESOURCE_NOT_FOUND = "Company Legal Resource Not Found";
	public static final String COMPANY_RESOURCE_NOT_FOUND = "Company Resource Not Found";
}
