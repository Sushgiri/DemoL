package com.bestercapitalmedia.letwizard.agentpartnership;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface AgentPartnershipService {

	public ResponseEntity save(AgentPartnershipDTO agentPartnership);
}
