package com.bestercapitalmedia.letwizard.agentpartnership;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AgentPartnershipRepository extends JpaRepository<AgentPartnership, Integer> {

}
