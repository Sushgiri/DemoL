package com.bestercapitalmedia.letwizard.agentpartnership;

import lombok.Data;

@Data
public class AgentPartnershipDTO {

	private String firstName;
	private String lastName;
	private String companyName;
	private String companyAddress;
	private String businessActivity;
	private Integer cityId;
	private Integer countryId;
	private String emailAddress;
	private String mobileNo;
	private String phoneNo;

}
