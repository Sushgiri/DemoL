package com.bestercapitalmedia.letwizard.agentpartnership;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "agent_partnership")
public class AgentPartnership implements Serializable {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "first_name")
	@Basic(fetch = FetchType.EAGER)
	private String firstName;

	@Column(name = "last_name")
	@Basic(fetch = FetchType.EAGER)
	private String lastName;

	@Column(name = "company_name")
	@Basic(fetch = FetchType.EAGER)
	private String companyName;
	
	@Column(name = "company_address")
	@Basic(fetch = FetchType.EAGER)
	private String companyAddress;

	@Column(name = "business_activity")
	@Basic(fetch = FetchType.EAGER)
	private String businessActivity;
	
	@Column(name = "city_id")
	@Basic(fetch = FetchType.EAGER)
	private Integer cityId;

	@Column(name = "country_id")
	@Basic(fetch = FetchType.EAGER)
	private Integer countryId;

	@Column(name = "email_address")
	@Basic(fetch = FetchType.EAGER)
	private String emailAddress;
	
	@Column(name = "mobile_no")
	@Basic(fetch = FetchType.EAGER)
	private String mobileNo;
	
	@Column(name = "phone_no")
	@Basic(fetch = FetchType.EAGER)
	private String phoneNo;
	
	@Column(name = "created_at")
	@Basic(fetch = FetchType.EAGER)
	private Date createdAt;

	@Column(name = "updated_at")
	@Basic(fetch = FetchType.EAGER)
	private Date updatedAt;

}
