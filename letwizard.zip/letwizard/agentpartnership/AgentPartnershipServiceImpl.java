package com.bestercapitalmedia.letwizard.agentpartnership;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.systemevents.AgentPartnershipLeadEvent;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;

@Service
public class AgentPartnershipServiceImpl implements AgentPartnershipService, ApplicationEventPublisherAware {

	@Autowired
	private AgentPartnershipRepository agentPartnershipRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private ApplicationEventPublisher publisher;

	@Override
	public ResponseEntity save(AgentPartnershipDTO agentPartnership) {

		try {

			AgentPartnership agentPartner = ObjectMapperUtils.map(agentPartnership, AgentPartnership.class);
			if (agentPartner != null) {
				agentPartner.setCreatedAt(DateUtils.getDefault().getNowTime());
				agentPartner.setUpdatedAt(DateUtils.getDefault().getNowTime());
				AgentPartnership agentPartnershipSaved = agentPartnershipRepository.save(agentPartner);

				// event listener to call "create lead 3rd party API"
				publisher.publishEvent(new AgentPartnershipLeadEvent(this, agentPartnership));

				if (agentPartnershipSaved == null) {
					return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE,
							null);

				} else {
					return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS,
							null);

				}
			} else {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		publisher = applicationEventPublisher;

	}
}
