package com.bestercapitalmedia.letwizard.newsletter;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.envers.NotAudited;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/newsletter")
public class NewsletterController {

	@Autowired
	NewsletterService newsletterService;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createNewsletter(@RequestBody NewsletterDTO newsletterDTO,
			HttpServletRequest httpServletRequest) {
		return newsletterService.createNewsletter(newsletterDTO);
	}

	@NotAudited
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/update", method = RequestMethod.PATCH)
	public @ResponseBody ResponseEntity toggleNewsletter(@RequestBody NewsletterDTO newsletterDTO,
			HttpServletRequest httpServletRequest) throws Exception {
		return newsletterService.toggleNewsletter(newsletterDTO);
	}
}
