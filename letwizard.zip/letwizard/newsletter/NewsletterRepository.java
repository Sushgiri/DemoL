package com.bestercapitalmedia.letwizard.newsletter;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface NewsletterRepository extends CrudRepository<Newsletter, Integer> {

	@Query(value = "Select * FROM newsletter WHERE subscriber_Email =:subscriberEmail", nativeQuery = true)
	public Newsletter isNewsletterExist(@Param("subscriberEmail") String subscriberEmail);

	@Transactional
	@Modifying
	@Query(value = "UPDATE newsletter SET contact_number=?1,name=?2,newsletter_send_offer=?3 WHERE subscriber_Email =?4", nativeQuery = true)
	public void updateIsNewsletter(String contact_number, String name, boolean newsletter_send_offer,
			String subscriber_Email);

	@Transactional
	@Modifying
	@Query(value = "INSERT INTO newsletter (subscriber_Email,created_at,contact_number,name,newsletter_send_offer) VALUES(subscriber_Email=?1,created_at=?2,contact_number=?3,name=?4,newsletter_send_offer=?5)", nativeQuery = true)
	public void insertIntosNewsletter(String subscriber_Email, Date created_at, String contact_number, String name,
			boolean newsletter_send_offer);

	@Transactional
	@Modifying
	@Query(value = "UPDATE newsletter SET newsletter_send_offer=?1 WHERE subscriber_Email =?2", nativeQuery = true)
	public void updateIsNewsletterFromProfilePreference(boolean newsletter_send_offer, String subscriber_Email);

}
