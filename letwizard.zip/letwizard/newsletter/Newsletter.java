package com.bestercapitalmedia.letwizard.newsletter;

import java.io.Serializable;
//
//import java.lang.StringBuilder;
//import java.util.Date;
//import java.util.Set;
import java.util.Date;

//import org.hibernate.envers.Audited;

import javax.persistence.*;

import org.hibernate.envers.Audited;

@Entity
@Table(name = "newsletter")
public class Newsletter implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "news_Letter_Id", unique = true, nullable = false)
	@Basic(fetch = FetchType.EAGER)
    private Integer newsLetterId;
	
	@Column(name = "subscriber_Email")
	@Basic(fetch = FetchType.EAGER)
	private String subscriberEmail;
	
	@Column(name = "created_at")
	@Basic(fetch = FetchType.EAGER)
	private Date createdAt;
	
	@Column(name = "newsletter_send_offer")
	@Basic(fetch = FetchType.EAGER)
	private Boolean newsletter_sendOffer;
	
	public Boolean getNewsletter_sendOffer() {
		return newsletter_sendOffer;
	}


	public void setNewsletter_sendOffer(Boolean newsletter_sendOffer) {
		this.newsletter_sendOffer = newsletter_sendOffer;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}


	@Column(name = "name")
	@Basic(fetch = FetchType.EAGER)
	private String name;
	
	@Column(name = "contact_number")
	@Basic(fetch = FetchType.EAGER)
	private String contactNumber;
		
	public Newsletter() {
	}


		public Integer getNewsLetterId() {
			return newsLetterId;
		}

		public void setNewsLetterId(Integer newsLetterId) {
			this.newsLetterId = newsLetterId;
		}
	
		public String getSubscriberEmail() {
			return subscriberEmail;
		}

		public void setSubscriberEmail(String subscriberEmail) {
			this.subscriberEmail = subscriberEmail;
		}


		public Date getCreatedAt() {
			return createdAt;
		}


		public void setCreatedAt(Date createdAt) {
			this.createdAt = createdAt;
		}

		




}

