package com.bestercapitalmedia.letwizard.newsletter;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.hibernate.envers.NotAudited;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.NewsLetterMessages;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.profile.preference.ProfilePreferenceRepository;
import com.bestercapitalmedia.letwizard.profile.preference.ProfilePreferences;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;

@Service
public class NewsletterService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private NewsletterRepository newsletterRepository;

	@Autowired
	private ProfilePreferenceRepository profilePreferenceRepository;

	public @ResponseBody ResponseEntity createNewsletter(NewsletterDTO requestDTO) {
		try {

			ModelMapper mapper = new ModelMapper();
			ProfilePreferences pf = profilePreferenceRepository
					.getProfilePreferenceByEmailID(requestDTO.getSubscriberEmail());
			Newsletter newsletterExist = newsletterRepository.isNewsletterExist(requestDTO.getSubscriberEmail());
			ChiragUtill chiragUtill = new ChiragUtill();
			String emailValid = chiragUtill.validateEmailAddress(requestDTO.getSubscriberEmail());
			Chiraghuser user = userRepository.findUserByEmail(requestDTO.getSubscriberEmail());
			if (emailValid.equals("valid")) {
				if (newsletterExist == null) {

					if (user != null) {
						String result = (user.getMiddleName() != null) ? " " + user.getMiddleName() : "";
						Newsletter addNewsletter = new Newsletter();
						addNewsletter.setName(user.getFirstName() + result + " " + user.getLastName());
						addNewsletter.setContactNumber("+" + user.getMobileCode() + " " + user.getMobileNo());
						addNewsletter.setSubscriberEmail(requestDTO.getSubscriberEmail());
						addNewsletter.setCreatedAt(DateUtils.getDefault().getNowTime());
						addNewsletter.setNewsletter_sendOffer(true);
						Newsletter newNewsletter = newsletterRepository.save(addNewsletter);
						requestDTO.setNewsLetterId(newNewsletter.getNewsLetterId());
						requestDTO.setCreatedAt(newNewsletter.getCreatedAt());
						requestDTO.setName(newNewsletter.getName());
						requestDTO.setContactNumber(newNewsletter.getContactNumber());
						requestDTO.setNewsletter_sendOffer(newNewsletter.getNewsletter_sendOffer());
						if (user.getSend_offers() == false) {
							user.setSend_offers(true);
							userRepository.save(user);
						}
						if (pf == null) {
							ProfilePreferences profiles = new ProfilePreferences();
							profiles.setChiraghuser(user);
							profiles.setCreated_at(new Date());
							profiles.setUser_email_id(user.getUserEmail());
							List<String> list = Collections.singletonList("subscribe");
							profiles.setRights(list);
							profilePreferenceRepository.save(profiles);
						}
						if (pf != null) {
							pf.setChiraghuser(user);
							pf.setCreated_at(new Date());
							pf.setUser_email_id(user.getUserEmail());
							List<String> list = Collections.singletonList("subscribe");
							pf.setRights(list);
							profilePreferenceRepository.save(pf);
						}
					}
					if (user == null) {
						Newsletter addNewsletter = new Newsletter();
						addNewsletter.setName("N/A");
						addNewsletter.setContactNumber("N/A");
						addNewsletter.setSubscriberEmail(requestDTO.getSubscriberEmail());
						addNewsletter.setCreatedAt(DateUtils.getDefault().getNowTime());
						addNewsletter.setNewsletter_sendOffer(true);
						Newsletter newNewsletter = newsletterRepository.save(addNewsletter);
						requestDTO.setNewsLetterId(newNewsletter.getNewsLetterId());
						requestDTO.setCreatedAt(newNewsletter.getCreatedAt());
						requestDTO.setName(newNewsletter.getName());
						requestDTO.setContactNumber(newNewsletter.getContactNumber());
						requestDTO.setNewsletter_sendOffer(newNewsletter.getNewsletter_sendOffer());

						if (pf == null) {
							ProfilePreferences profiles = new ProfilePreferences();
							profiles.setChiraghuser(null);
							profiles.setCreated_at(new Date());
							profiles.setUser_email_id(requestDTO.getSubscriberEmail());
							List<String> list = Collections.singletonList("subscribe");
							profiles.setRights(list);
							profilePreferenceRepository.save(profiles);
						}
						if (pf != null) {
							pf.setChiraghuser(null);
							pf.setCreated_at(new Date());
							pf.setUser_email_id(requestDTO.getSubscriberEmail());
							List<String> list = Collections.singletonList("subscribe");
							pf.setRights(list);
							profilePreferenceRepository.save(pf);
						}
					}
				}
				if (newsletterExist != null) {
					Chiraghuser user1 = userRepository.findUserByEmail(newsletterExist.getSubscriberEmail());
					String middleName = (user.getMiddleName() != null) ? " " + user.getMiddleName() : "";
					String result1 = (user1 != null) ? user.getFirstName() + middleName + " " + user.getLastName()
							: "N/A";
					String result2 = (user1 != null) ? "+" + user1.getMobileCode() + " " + user1.getMobileNo() : "N/A";
					newsletterExist.setNewsletter_sendOffer(true);
					newsletterExist.setContactNumber(result2);
					newsletterExist.setName(result1);
					newsletterExist.setNewsletter_sendOffer(true);
					newsletterRepository.save(newsletterExist);
					if (user1 != null) {

						user1.setSend_offers(true);
						userRepository.save(user1);
					}
					
					
				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, NewsLetterMessages.NEWS_LETTER_SAVED_SUCCESS,
						Stream.of(requestDTO).collect(Collectors.toList()));

			}
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, NewsLetterMessages.SUBSCRIPTION_FAILURE,
					Stream.of(requestDTO).collect(Collectors.toList()));
		}

		catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}

	}

	@NotAudited
	public @ResponseBody ResponseEntity toggleNewsletter(NewsletterDTO requestDTO) throws Exception {
		Chiraghuser user = userRepository.findUserByEmail(requestDTO.getSubscriberEmail());
		Newsletter newsletterExist = newsletterRepository.isNewsletterExist(requestDTO.getSubscriberEmail());
		try {
			if (requestDTO.getNewsletter_sendOffer() == false) {
				if (newsletterExist != null && user != null) {
					newsletterExist.setNewsletter_sendOffer(false);
					newsletterRepository.save(newsletterExist);
					user.setSend_offers(false);
					userRepository.save(user);
				}
				if (newsletterExist != null && user == null) {
					newsletterExist.setNewsletter_sendOffer(false);
					newsletterRepository.save(newsletterExist);
				}
				requestDTO.setContactNumber("+" + user.getMobileCode() + " " + user.getMobileNo());
				requestDTO.setName(user.getFirstName() + " " + user.getMiddleName() + " " + user.getLastName());
				requestDTO.setCreatedAt(user.getCreatedAt());
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
						"User register with this email " + requestDTO.getSubscriberEmail() + " updated successfully",
						Stream.of(requestDTO).collect(Collectors.toList()));
			} else if (requestDTO.getNewsletter_sendOffer() == true) {
				if (newsletterExist != null && user != null) {
					newsletterExist.setNewsletter_sendOffer(true);
					newsletterRepository.save(newsletterExist);
					user.setSend_offers(true);
					userRepository.save(user);
				}
				if (newsletterExist != null && user == null) {
					newsletterExist.setNewsletter_sendOffer(true);
					newsletterRepository.save(newsletterExist);
				}
				requestDTO.setContactNumber("+" + user.getMobileCode() + " " + user.getMobileNo());
				requestDTO.setName(user.getFirstName() + " " + user.getMiddleName() + " " + user.getLastName());
				requestDTO.setCreatedAt(user.getCreatedAt());
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
						"User register with this email " + requestDTO.getSubscriberEmail() + "updated successfully",
						Stream.of(requestDTO).collect(Collectors.toList()));
			} else {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, "Newsletter subcription not found",
						Stream.of(requestDTO).collect(Collectors.toList()));
			}
		} catch (Exception e) {
			throw e;

		}
	}
}
