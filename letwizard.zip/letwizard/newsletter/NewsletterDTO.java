package com.bestercapitalmedia.letwizard.newsletter;

import java.util.Date;

public class NewsletterDTO {

	private Integer newsLetterId;
	private String subscriberEmail;
	private Date createdAt;
	private Boolean newsletter_sendOffer;
	public Boolean getNewsletter_sendOffer() {
		return newsletter_sendOffer;
	}


	public void setNewsletter_sendOffer(Boolean newsletter_sendOffer) {
		this.newsletter_sendOffer = newsletter_sendOffer;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}


	private String name;
	private String contactNumber;
	public NewsletterDTO() {
	}


	public Integer getNewsLetterId() {
		return newsLetterId;
	}


	public void setNewsLetterId(Integer newsLetterId) {
		this.newsLetterId = newsLetterId;
	}


	public String getSubscriberEmail() {
		return subscriberEmail;
	}


	public void setSubscriberEmail(String subscriberEmail) {
		this.subscriberEmail = subscriberEmail;
	}


	public Date getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	
	

	
	

}
