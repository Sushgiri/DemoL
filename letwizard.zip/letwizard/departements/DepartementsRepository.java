package com.bestercapitalmedia.letwizard.departements;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.user.Chiraghuser;



public interface DepartementsRepository extends CrudRepository<Departements, Integer> {

	@Query(value = "select * from departements where id=?1  ", nativeQuery = true)
	public Departements findByDepartementById(int departementId);
	
	@Query(value = "select * from departements where 1", nativeQuery = true)
	public List<Departements> findAllDepartments();
	
	
}
