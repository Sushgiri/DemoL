package com.bestercapitalmedia.letwizard.departements;

public class DepartmentsDTO {
	
	private Integer departementsId;
	private String name;

	public DepartmentsDTO() {
	}

//	public Integer getId() {
//		return id;
//	}
//
//	public void setId(Integer id) {
//		this.id = id;
//	}

	
	public String getName() {
		return name;
	}

	public Integer getDepartementsId() {
		return departementsId;
	}

	public void setDepartementsId(Integer departementsId) {
		this.departementsId = departementsId;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	

}
