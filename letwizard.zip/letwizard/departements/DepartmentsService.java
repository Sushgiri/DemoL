package com.bestercapitalmedia.letwizard.departements;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.PaginatedResponseDTO;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.inbox.ThreadDetailDTO;
import com.bestercapitalmedia.letwizard.inbox.Threads;
import com.bestercapitalmedia.letwizard.property.LetwizardPropertyService;
import com.bestercapitalmedia.letwizard.user.ChiraghUserDTO;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;

@Service
public class DepartmentsService {

	private static final Logger logger = LoggerFactory.getLogger(LetwizardPropertyService.class);
	
	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private DepartementsRepository departmentsRepository;
	
	
	public ResponseEntity getDepartments() {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<Departements> departments = new ArrayList<Departements>();
			departments = departmentsRepository.findAllDepartments();
			if (departments.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<DepartmentsDTO> listOfSentItems = ObjectMapperUtils.mapAll(departments, DepartmentsDTO.class);
			
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					listOfSentItems);
		}
		catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}
	
	public ResponseEntity getUsersOfDepartment(int departmentId) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<Chiraghuser> users = new ArrayList<Chiraghuser>();
			users = userRepository.findUsersByDepartment(departmentId);
			if (users.isEmpty()) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			List<ChiraghUserDTO> listOfUsers = ObjectMapperUtils.mapAll(users, ChiraghUserDTO.class);
			
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					listOfUsers);
		}
		catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}
}
