package com.bestercapitalmedia.letwizard.departements;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/departments")
public class DepartementsController {

	@Autowired DepartmentsService departmentService;
	
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getAllDepartments(HttpServletRequest httpServletRequest) {
		return departmentService.getDepartments();
	}
	
	@RequestMapping(value = "/{departmentId}/user", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getUsersOfDepartment(@PathVariable(value = "departmentId") int departmentId, HttpServletRequest httpServletRequest) {
		return departmentService.getUsersOfDepartment(departmentId);
	}
}
