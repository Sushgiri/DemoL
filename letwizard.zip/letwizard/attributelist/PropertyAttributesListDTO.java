package com.bestercapitalmedia.letwizard.attributelist;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The Class ChiraghPropertyDetailsDTO.
 */
public class PropertyAttributesListDTO {


	Integer propertyAttributesId;
	String name;	
	String type;
	String status;
	String selected;
	boolean isForEvaluation;
	Integer evaluationSeq;

	public PropertyAttributesListDTO() {

	}

	public Integer getPropertyAttributesId() {
		return propertyAttributesId;
	}

	public void setPropertyAttributesId(Integer propertyAttributesId) {
		this.propertyAttributesId = propertyAttributesId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSelected() {
		return selected;
	}

	public void setSelected(String selected) {
		this.selected = selected;
	}

	public boolean isForEvaluation() {
		return isForEvaluation;
	}

	public void setForEvaluation(boolean isForEvaluation) {
		this.isForEvaluation = isForEvaluation;
	}

	public Integer getEvaluationSeq() {
		return evaluationSeq;
	}

	public void setEvaluationSeq(Integer evaluationSeq) {
		this.evaluationSeq = evaluationSeq;
	}
	
	
}
