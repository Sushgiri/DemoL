package com.bestercapitalmedia.letwizard.attributelist;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.constants.PropertyMessages;

@Service
public class PropertyAttributesListServiceImpl implements PropertyAttributesListService {

	@Autowired
	private PropertyAttributesListRepository  propertyAttributesListRepository;
	
	@Override
	public String save(PropertyAttributesListDTO propertyDetailsDTO) {
		ModelMapper mapper=new ModelMapper();
		Propertyattributeslist obj=mapper.map(propertyDetailsDTO, Propertyattributeslist.class);
		propertyAttributesListRepository.save(obj);
		return PropertyMessages.PROPERTY_RENTAL_DETAIL_SAVED_SUCCESS;
	}

	@Override
	public List<PropertyAttributesListDTO> findAll() {
		List<PropertyAttributesListDTO> list=new ArrayList<>();
		ModelMapper mapper=new ModelMapper();
		propertyAttributesListRepository.findAllByStatus().stream().forEach(s->{
		    list.add(mapper.map(s, PropertyAttributesListDTO.class));
		});
			return list;
	}

	@Override
	public Propertyattributeslist findById(int id) {
		return propertyAttributesListRepository.findById(id);
	}

	@Override
	public List<PropertyAttributesListDTO> findforEvaluation() {
		List<PropertyAttributesListDTO> list=new ArrayList<>();
		ModelMapper mapper=new ModelMapper();
		propertyAttributesListRepository.findForEvaluation().stream().forEach(s->{
			if(s.getName().equals("Covered Parking")) {
				s.setName("Parking");
			}
			else if(s.getName().equals("Metros")) {
				s.setName("Metro");
			}
			if(s.getName().equals("Super Markets")) {
				s.setName("Supermarket");
			}
			if(s.getName().equals("Children Play Area")) {
				s.setName("Kids Play Area");
			}
		    list.add(mapper.map(s, PropertyAttributesListDTO.class));
		});
			return list;
	}

}
