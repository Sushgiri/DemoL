package com.bestercapitalmedia.letwizard.attributelist;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface PropertyAttributesListRepository  extends CrudRepository<Propertyattributeslist, Integer>{

	@Query(value = "select * from propertyattributeslist ORDER BY name ASC", nativeQuery = true)
	public List<Propertyattributeslist> findAll();
	
	@Query(value = "select * from propertyattributeslist  where status ='true' ORDER BY name ASC", nativeQuery = true)
	public List<Propertyattributeslist> findAllByStatus();

	@Query(value = "select * from propertyattributeslist where property_Attributes_Id=?1  ", nativeQuery = true)
	public Propertyattributeslist findById(int id);
	
	@Query(value = "SELECT * FROM propertyattributeslist WHERE is_for_evaluation= 1 ORDER BY evaluation_seq ASC", nativeQuery = true)
	public List<Propertyattributeslist> findForEvaluation();
	
	@Query(value = "SELECT * FROM propertyattributeslist WHERE property_Attributes_Id IN(?1)", nativeQuery = true)
	public List<Propertyattributeslist> findByAmenitiesIds(List<Integer> id);
	

}
