package com.bestercapitalmedia.letwizard.attributelist;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/properyattributeslist")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class PropertyAttributesListController {

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private PropertyAttributesListService propertyAttributesListService;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ResponseEntity save(@RequestBody PropertyAttributesListDTO propertyDetailsDTO,
			HttpServletRequest httpServletRequest) {
		try {
			String response = propertyAttributesListService.save(propertyDetailsDTO);
			if (response == null || response.isEmpty())
				return responseUtill.getApiResponse(ResponseCodes.FAILURE,
						PropertyMessages.PROPERTY_RENTAL_DETAIL_SAVED_FAILURE, null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
						PropertyMessages.PROPERTY_RENTAL_DETAIL_SAVED_SUCCESS,
						Stream.of(response).collect(Collectors.toList()));
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getAll", method = RequestMethod.GET)
	public ResponseEntity findAll(HttpServletRequest httpServletRequest) {
		try {
			List<PropertyAttributesListDTO> response = propertyAttributesListService.findAll();
			if (response == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE,
						PropertyMessages.PROPERTY_Attributes_LIST_GET_FAILURE, null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
						PropertyMessages.PROPERTY_Attributes_LIST_GET_SUCCESS, response);
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/getforevaluation", method = RequestMethod.GET)
	public ResponseEntity findforEvaluation(HttpServletRequest httpServletRequest) {
		try {
			List<PropertyAttributesListDTO> response = propertyAttributesListService.findforEvaluation();
			if (response == null)
				return responseUtill.getApiResponse(ResponseCodes.FAILURE,
						PropertyMessages.PROPERTY_Attributes_LIST_GET_FAILURE, null);
			else
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS,
						PropertyMessages.PROPERTY_Attributes_LIST_GET_SUCCESS, response);
		} catch (Exception e) {
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}


}
