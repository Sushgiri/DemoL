
package com.bestercapitalmedia.letwizard.attributelist;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.bestercapitalmedia.letwizard.propertyattributes.Propertyattributes;

/**
 */

@Entity
@Table(name = "propertyattributeslist")
public class Propertyattributeslist implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 */

	@Column(name = "property_Attributes_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer propertyAttributesId;
	/**
	 */

	@Column(name = "name", length = 200)
	@Basic(fetch = FetchType.EAGER)

	
	String name;
	/**
	 */

	@Column(name = "type", length = 200)
	@Basic(fetch = FetchType.EAGER)

	
	String type;
	/**
	 */

	@Column(name = "status", length = 200)
	@Basic(fetch = FetchType.EAGER)

	
	String status;

	/**
	 */
	/**
	 */

	@Column(name = "is_for_evaluation")
	@Basic(fetch = FetchType.EAGER)

	
	Boolean isForEvaluation;

	/**
	 */
	@OneToMany(mappedBy = "propertyattributeslist", fetch = FetchType.LAZY)
	java.util.Set<Propertyattributes> propertyattributeses;

	@Column(name = "evaluation_seq")
	@Basic(fetch = FetchType.EAGER)
	Integer evaluationSeq;
	
	public Integer getPropertyAttributesId() {
		return propertyAttributesId;
	}

	public void setPropertyAttributesId(Integer propertyAttributesId) {
		this.propertyAttributesId = propertyAttributesId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public java.util.Set<Propertyattributes> getPropertyattributeses() {
		return propertyattributeses;
	}

	public void setPropertyattributeses(java.util.Set<Propertyattributes> propertyattributeses) {
		this.propertyattributeses = propertyattributeses;
	}

	public Propertyattributeslist() {
	}

	public Boolean getIsForEvaluation() {
		return isForEvaluation;
	}

	public void setIsForEvaluation(Boolean isForEvaluation) {
		this.isForEvaluation = isForEvaluation;
	}

	public Integer getEvaluationSeq() {
		return evaluationSeq;
	}

	public void setEvaluationSeq(Integer evaluationSeq) {
		this.evaluationSeq = evaluationSeq;
	}

	
	

	
}
