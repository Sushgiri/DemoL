package com.bestercapitalmedia.letwizard.attributelist;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface PropertyAttributesListService {

	public String save(PropertyAttributesListDTO propertyDetailsDTO);
	
	public List<PropertyAttributesListDTO> findAll();
	
	public Propertyattributeslist findById(int id);
	
	public List<PropertyAttributesListDTO> findforEvaluation();

	
}
