package com.bestercapitalmedia.letwizard.country;

import java.util.List;

public interface CountriesDao {

	public static final String GET_ALL_COUNTRIES = "Select * from country where country_Id > 0 and is_active = 1 order by name";

	public List<BaseCountryDTO> getAllCountries();

	public static final String GET_ALL_NATIONALITIES = "Select * from country where country_Id > 0 and is_active = 1 order by nationality";

	public List<BaseCountryDTO> getAllNationalities();
}
