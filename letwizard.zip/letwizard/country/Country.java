
package com.bestercapitalmedia.letwizard.country;

import java.io.Serializable;

import java.lang.StringBuilder;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.persistence.Id;

import org.hibernate.annotations.Filter;
import org.hibernate.annotations.Where;
import org.hibernate.annotations.WhereJoinTable;

import com.bestercapitalmedia.letwizard.city.City;

import javax.persistence.*;

// TODO: Auto-generated Javadoc
/**
 * The Class Country.
 */

@Entity
@Table(name = "country")
public class Country implements Serializable {
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The country id. */

	@Column(name = "country_Id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer countryId;
	
	/** The name. */

	@Column(name = "name", length = 225)
	@Basic(fetch = FetchType.EAGER)

	
	String name;

	/** The name. */

	@Column(name = "is_active", length = 225)
	@Basic(fetch = FetchType.EAGER)

	
	Integer isActive;

	@Column(name = "nationality", length = 100)
	@Basic(fetch = FetchType.EAGER)

	
	String nationality;
	
	@Column(name = "iso2", length = 2)
	@Basic(fetch = FetchType.EAGER)

	
	String iso2;
	
	
	@Column(name = "iso3", length = 3)
	@Basic(fetch = FetchType.EAGER)

	
	String iso3;
	
	
	@Column(name = "code", length = 5)
	@Basic(fetch = FetchType.EAGER)

	
	Integer code;
	
	/** The cities. */
	@OneToMany(mappedBy = "country", fetch = FetchType.LAZY)
	@OrderBy("name")
	@Where(clause = "is_active = 1")
	java.util.Set<City> cities;

	/**
	 * Sets the country id.
	 *
	 * @param countryId the new country id
	 */
	public void setCountryId(Integer countryId) {
		this.countryId = countryId;
	}

	/**
	 * Gets the country id.
	 *
	 * @return the country id
	 */
	public Integer getCountryId() {
		return this.countryId;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return this.name;
	}

	
	/**
	 * Sets the cities.
	 *
	 * @param cities the new cities
	 */
	

	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}

	/**
	 * Instantiates a new country.
	 */
	public Country() {
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getIso2() {
		return iso2;
	}

	public void setIso2(String iso2) {
		this.iso2 = iso2;
	}

	public String getIso3() {
		return iso3;
	}

	public void setIso3(String iso3) {
		this.iso3 = iso3;
	}

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}


	public java.util.Set<City> getCities() {
		return cities;
	}

	public void setCities(java.util.Set<City> cities) {
		this.cities = cities;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
