package com.bestercapitalmedia.letwizard.country;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bestercapitalmedia.letwizard.city.CityDTO;

public class CountriesRowMapper implements RowMapper<BaseCountryDTO> {

	@Override
	public BaseCountryDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		BaseCountryDTO country = new BaseCountryDTO();
		country.setCode(rs.getInt("code"));
		country.setCountryId(rs.getInt("country_Id"));
		country.setIsActive(rs.getBoolean("is_active"));
		country.setIso2(rs.getString("iso2"));
		country.setIso3(rs.getString("iso3"));
		country.setName(rs.getString("name"));
		country.setNationality(rs.getString("nationality"));

		return country;
	}

}
