package com.bestercapitalmedia.letwizard.country;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.utill.CompressAnnotation.Compress;

// TODO: Auto-generated Javadoc
/**
 * The Class CountryController.
 */
@RestController
//@RequestMapping("/api/country/")
public class CountryController {

	/** The country repository. */
	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private CountryService countryService;

	/**
	 * List.
	 *
	 * @return the iterable
	 */
	@Compress
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/countries", method = RequestMethod.GET)
	public ResponseEntity getAllCountries(HttpServletRequest httpServletRequest) {

		return countryService.getAllCountries();
	}

	@Compress
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/v2/countries", method = RequestMethod.GET)
	public ResponseEntity getAllCountriesV2(HttpServletRequest httpServletRequest) {

		return countryService.getAllCountriesV2();
	}

	@Compress
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/nationalities", method = RequestMethod.GET)
	public ResponseEntity getAllNationalities(HttpServletRequest httpServletRequest) {

		return countryService.getAllNationalities();
	}

	/**
	 * Creates the.
	 *
	 * @param users the users
	 * @return the country
	 */
//	@RequestMapping(value="/post")
//	public Country create(Country users) {
//		return countryRepository.save(users);
//	}

	/**
	 * Update.
	 *
	 * @param id     the id
	 * @param entity the entity
	 * @return the country
	 */
//	@RequestMapping(value = "/put/{id}", method = RequestMethod.PUT)
//	public Country update(@PathVariable(value = "id") long id, @RequestBody Country entity) {
//		return countryRepository.save(entity);
//	}

	/**
	 * Delete.
	 *
	 * @param id the id
	 */
//	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
//	public void delete(@PathVariable(value = "id") int id) {
//		countryRepository.deleteById(id);
//	}

	/**
	 * Gets the.
	 *
	 * @param id the id
	 * @return the optional
	 */
//	@RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
//	public Optional<Country> get(@PathVariable(value = "id") int id) {
//		return countryRepository.findById(id);
//	}
}// end of class controller
