package com.bestercapitalmedia.letwizard.country;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CountriesDaoImpl implements CountriesDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<BaseCountryDTO> getAllCountries() {

		return jdbcTemplate.query(GET_ALL_COUNTRIES, new CountriesRowMapper());

	}

	@Override
	public List<BaseCountryDTO> getAllNationalities() {

		return jdbcTemplate.query(GET_ALL_NATIONALITIES, new CountriesRowMapper());

	}

}
