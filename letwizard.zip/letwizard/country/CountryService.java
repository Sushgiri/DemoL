package com.bestercapitalmedia.letwizard.country;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.city.CityDTO;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class CountryService {

	@Autowired
	private CountryRepository countryRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private CountriesDao countriesDao;

	public ResponseEntity getAllCountries() {

		try {
			ModelMapper mapper = new ModelMapper();
			List<Country> countrylist = countryRepository.getAllCountries();
			// List<CountryDTO> countrylist = countryRepository.getAllCountries().stream()
			// .map(s -> mapper.map(s,CountryDTO.class)).collect(Collectors.toList());
//			System.out.println("All cities"+countrylist);
			if (countrylist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				List<BaseCountryDTO> countrylistDTO = ObjectMapperUtils.mapAll(countrylist, BaseCountryDTO.class);

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						countrylistDTO);
			}
		} catch (Exception e) {

			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	public ResponseEntity getAllCountriesV2() {

		try {

			List<BaseCountryDTO> countrylist = countriesDao.getAllCountries();
			if (countrylist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						countrylist);
			}
		} catch (Exception e) {

			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

	public ResponseEntity getAllNationalities() {

		try {

			List<BaseCountryDTO> countrylist = countriesDao.getAllNationalities();
			if (countrylist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						countrylist);
			}
		} catch (Exception e) {

			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					SellerMessages.INTERNAL_SERVER_ERROR_MSG, null);
		}
	}

}
