package com.bestercapitalmedia.letwizard.country;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bestercapitalmedia.letwizard.city.City;


/**
 * The Interface CountryRepository.
 */
public interface CountryRepository extends CrudRepository<Country, Integer> {
	
	@Query(value = "Select * from country where country_Id > 0 and is_active = 1 order by name", nativeQuery = true)
	public List<Country> getAllCountries();

	
	@Query(value = "Select * from country where country_Id=?1", nativeQuery = true)
	public Country getByCountryId(int countryId);
	
	// For Country Search
			@Query(value = "{call getCountryById (:countryId)}", nativeQuery = true)
			public Country getCountryById(@Param("countryId") int countryId);
}
