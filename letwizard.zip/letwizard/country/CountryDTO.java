package com.bestercapitalmedia.letwizard.country;

import java.util.HashSet;
import java.util.Set;

import com.bestercapitalmedia.letwizard.city.CityDTO;



// TODO: Auto-generated Javadoc
/**
 * The Class CountryDTO.
 */
public class CountryDTO extends BaseCountryDTO {
	
	
	
	private Set<CityDTO> cities = new HashSet<CityDTO>();
	
	

	public Set<CityDTO> getCities() {
		return cities;
	}

	public void setCities(Set<CityDTO> cities) {
		this.cities = cities;
	}

	public CountryDTO() {
		super();
	
	}
	
	
	
	
	
	
}
