package com.bestercapitalmedia.letwizard.letwizardotp;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CreateOtpRequestDTO {
	
	@JsonProperty("transactionType")
	private String subject;
	private Integer currencyId;
	private Integer userId;
	private Integer otpId;
	private String otpType;
	private String otpSubject;
	private String smsOtp;
	private String emailOtp;
	private String userName;
	private String token;
	private String testOtp;
	private BigDecimal amount;
	private OtpDataDTO data;
	
	public CreateOtpRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Integer getCurrencyId() {
		return currencyId;
	}

	public void setCurrencyId(Integer currencyId) {
		this.currencyId = currencyId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getOtpType() {
		return otpType;
	}

	public void setOtpType(String otpType) {
		this.otpType = otpType;
	}

	public String getOtpSubject() {
		return otpSubject;
	}

	public void setOtpSubject(String otpSubject) {
		this.otpSubject = otpSubject;
	}

	public Integer getOtpId() {
		return otpId;
	}

	public void setOtpId(Integer otpId) {
		this.otpId = otpId;
	}

	public String getSmsOtp() {
		return smsOtp;
	}

	public void setSmsOtp(String smsOtp) {
		this.smsOtp = smsOtp;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getEmailOtp() {
		return emailOtp;
	}

	public void setEmailOtp(String emailOtp) {
		this.emailOtp = emailOtp;
	}

	public String getTestOtp() {
		return testOtp;
	}

	public void setTestOtp(String testOtp) {
		this.testOtp = testOtp;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public OtpDataDTO getData() {
		return data;
	}

	public void setData(OtpDataDTO data) {
		this.data = data;
	}
	
}
