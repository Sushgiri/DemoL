package com.bestercapitalmedia.letwizard.letwizardotp;

import java.math.BigDecimal;

public class OtpDataDTO {

	private BigDecimal askRate;
	private BigDecimal desToSrcRate;
	private BigDecimal srcToDesRate;

	public OtpDataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BigDecimal getAskRate() {
		return askRate;
	}

	public void setAskRate(BigDecimal askRate) {
		this.askRate = askRate;
	}

	public BigDecimal getDesToSrcRate() {
		return desToSrcRate;
	}

	public void setDesToSrcRate(BigDecimal desToSrcRate) {
		this.desToSrcRate = desToSrcRate;
	}

	public BigDecimal getSrcToDesRate() {
		return srcToDesRate;
	}

	public void setSrcToDesRate(BigDecimal srcToDesRate) {
		this.srcToDesRate = srcToDesRate;
	}

}
