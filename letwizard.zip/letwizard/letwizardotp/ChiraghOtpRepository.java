package com.bestercapitalmedia.letwizard.letwizardotp;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.vouchers.Voucher;

public interface ChiraghOtpRepository extends JpaRepository<ChiraghOtp, Integer> {

	@Query(value = "select * from chiragh_otp where user_id = ?1 and currency_id = ?2 and subject = ?3 and is_valid = 1", nativeQuery = true)
	public ChiraghOtp getValidOtp(int userId, int currencyId, String subject);

	@Query(value = "select * from chiragh_otp where user_id = ?1 and subject = ?2 and is_valid = 1 order by created_at desc limit 1", nativeQuery = true)
	public ChiraghOtp getValidOtpForRegistration(int userId, String subject);

	@Transactional
	@Modifying
	@Query(value = "UPDATE chiragh_otp SET is_valid = 0 where user_id = ?1 and currency_id = ?2 and subject = ?3 and is_valid = 1", nativeQuery = true)
	public Integer invalidateOtp(int userId, int currencyId, String subject);

	@Transactional
	@Modifying
	@Query(value = "UPDATE chiragh_otp SET is_valid = 0 where user_id = ?1 and subject = ?2 and is_valid = 1", nativeQuery = true)
	public Integer invalidateRegistrationOtp(int userId, String subject);

}
