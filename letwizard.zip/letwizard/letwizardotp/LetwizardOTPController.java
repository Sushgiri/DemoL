package com.bestercapitalmedia.letwizard.letwizardotp;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.vouchers.VoucherService;
import com.bestercapitalmedia.letwizard.wallet.CreateTopupDTO;

@RestController
@RequestMapping("/api/chiragh/otp/")
public class LetwizardOTPController {
	
	@Autowired
	private LetwizardOTPService chiraghOTPService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createOtp(@RequestBody CreateOtpRequestDTO createOtpRequestDTO, HttpServletRequest httpServletRequest) {

		return chiraghOTPService.createOtp(createOtpRequestDTO);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/test/create", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createTestOtp(@RequestBody CreateOtpRequestDTO createOtpRequestDTO, HttpServletRequest httpServletRequest) {

		return chiraghOTPService.createTestOtp(createOtpRequestDTO);
	}

}
