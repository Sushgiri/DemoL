package com.bestercapitalmedia.letwizard.letwizardotp;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.transaction.Transactional;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.WalletConstants;
import com.bestercapitalmedia.letwizard.otpcodes.LetwizardOtpCodeRepository;
import com.bestercapitalmedia.letwizard.otpcodes.LetwizardOtpCodeService;
import com.bestercapitalmedia.letwizard.otpcodes.ChiraghOtpCodes;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.ForgotPasswordServiceResponse;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.vouchers.VoucherRepository;

@Service
public class LetwizardOTPService {

	private static final Logger logger = LoggerFactory.getLogger(LetwizardOTPService.class);

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private ChiraghOtpRepository chiraghOtpRepository;

	@Autowired
	private LetwizardOtpCodeService chiraghOtpCodeService;

	@Autowired
	private LetwizardOtpCodeRepository chiraghOtpCodeRepository;

	@Autowired
	private Environment environment;

	@Autowired
	private VoucherRepository voucherRepository;

	@Transactional
	public ResponseEntity createOtp(CreateOtpRequestDTO createOtpRequestDTO) {

		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			// System.out.println(user.getDepartements().getDepartementsId());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			// start changes against CD-304
			if (createOtpRequestDTO.getSubject().equals("transfer")
					|| createOtpRequestDTO.getSubject().equals(WalletConstants.WITHDRAWAL_TRANSACTION_TYPE)) {
				if (createOtpRequestDTO.getAmount() == null) {
					return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
							null);
				}
				// check is it fine to send the otp based on the amount entered, get the balance
				BigDecimal availableBalance = voucherRepository.getBalanceByCurrency(chiraghuser.getUserId(), "ab",
						createOtpRequestDTO.getCurrencyId()); // available balance
				// if (availableBalance < createOtpRequestDTO.getAmount()) {
				if (availableBalance.compareTo(createOtpRequestDTO.getAmount()) == -1) {
					return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.AMOUNT_INSUFFICIENT,
							null);
				}
			}
			// end changes against CD-304

			// invalidate all other otp for same subject
			if(createOtpRequestDTO.getSubject().equals("UPIAccounts") || createOtpRequestDTO.getSubject().equals("CardAccount") ||createOtpRequestDTO.getSubject().equals("PaypalAccount")){
				chiraghOtpRepository.invalidateRegistrationOtp(chiraghuser.getUserId(),
						createOtpRequestDTO.getSubject());
			}else{
				chiraghOtpRepository.invalidateOtp(chiraghuser.getUserId(), createOtpRequestDTO.getCurrencyId(),
						createOtpRequestDTO.getSubject());
			}

			ChiraghOtp chiraghOtp = new ChiraghOtp();
			ChiraghOtpCodes chiraghOtpCodes = null;
			Boolean isOtpSent = false;
			String emailBody = "Please use this OTP For " + createOtpRequestDTO.getSubject() + " OTP: ";
			chiraghOtp = ObjectMapperUtils.map(createOtpRequestDTO, ChiraghOtp.class);
			chiraghOtp.setUserId(chiraghuser.getUserId());
			chiraghOtp.setCreatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp.setUpdatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp = chiraghOtpRepository.save(chiraghOtp);

			if (chiraghOtp != null) {
				createOtpRequestDTO.setOtpId(chiraghOtp.getId());
				isOtpSent = chiraghOtpCodeService.createOtpCode(createOtpRequestDTO, chiraghuser, emailBody);

			}

			if (isOtpSent) {
				chiraghOtp.setIsValid(isOtpSent);
				// CD-363 changes
				if (!ObjectUtils.isEmpty(createOtpRequestDTO.getData())) {
					chiraghOtp.setData(fetchJsonDataString(createOtpRequestDTO));
				}
				chiraghOtp = chiraghOtpRepository.save(chiraghOtp);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_NOT_FOUND, null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public Boolean verifyOtp(Chiraghuser chiraghuser, String otpSubject, Integer currencyId, String smsOtp,
			String emailOtp) {
		ChiraghOtp chiraghOtp = chiraghOtpRepository.getValidOtp(chiraghuser.getUserId(), currencyId, otpSubject);
		ChiragUtill chiraghUtill = new ChiragUtill();

		if (chiraghOtp != null) {
			List<ChiraghOtpCodes> codes = chiraghOtpCodeRepository.getOtpFromId(chiraghOtp.getId());
			for (int i = 0; i < codes.size(); i++) {
				if (codes.get(i).getOtpType().equalsIgnoreCase("sms")) {
					if (!(codes.get(i).getOtpCode().equals(smsOtp) || ("1122".equals(smsOtp)
							&& "test".equals(this.environment.getProperty("spring.profiles.active"))
							|| "rental".equals(this.environment.getProperty("spring.profiles.active"))))) {
						return false;
					}
				}
				if (codes.get(i).getOtpType().equalsIgnoreCase("email")) {
					if (!(codes.get(i).getOtpCode().equals(emailOtp) || ("1122".equals(smsOtp)
							&& "test".equals(this.environment.getProperty("spring.profiles.active"))
							|| "rental".equals(this.environment.getProperty("spring.profiles.active"))))) {
						return false;
					}
				}
			}

		} else {
			return false;
		}

		return true;
	}

	public Boolean verifyRegistrationOtp(Chiraghuser chiraghuser, String otpSubject, String smsOtp, String emailOtp) {
		ChiraghOtp chiraghOtp = chiraghOtpRepository.getValidOtpForRegistration(chiraghuser.getUserId(), otpSubject);

		if (chiraghOtp != null && !otpSubject.equalsIgnoreCase("Registration")) {
			List<ChiraghOtpCodes> codes = chiraghOtpCodeRepository.getOtpFromId(chiraghOtp.getId());

			for (int i = 0; i < codes.size(); i++) {
				if (codes.get(i).getOtpType().equalsIgnoreCase("sms")) {
					if (smsOtp != null) {
						if (codes.get(i).getOtpCode().equals(smsOtp)) {
							return true;
						}
					}

				}
				if (codes.get(i).getOtpType().equalsIgnoreCase("email")) {
					if (emailOtp != null) {
						if (codes.get(i).getOtpCode().equals(emailOtp)) {
							return true;
						}
					}
				}
			}
		}
		if (chiraghOtp != null && otpSubject.equalsIgnoreCase("Registration")) {
		    List<ChiraghOtpCodes> codes = chiraghOtpCodeRepository.getOtpFromId(chiraghOtp.getId());
            for (int i = 0; i < codes.size(); i++) {
                if (codes.get(i).getOtpType().equalsIgnoreCase("sms")) {
                    if (!codes.get(i).getOtpCode().equals(smsOtp)) {
                        return false;
                    }
                }
                if (codes.get(i).getOtpType().equalsIgnoreCase("email")) {
                    if (!codes.get(i).getOtpCode().equals(emailOtp)) {
                        return false;
                    }
                }
            }
            return true;
        } 
	
		return false;
	}

	public Boolean invalidateOtp(Chiraghuser chiraghuser, String otpSubject, Integer currencyId, String smsOtp,
			String emailOtp) {
		ChiraghOtp chiraghOtp = chiraghOtpRepository.getValidOtp(chiraghuser.getUserId(), currencyId, otpSubject);
		chiraghOtp.setIsValid(false);
		chiraghOtpRepository.save(chiraghOtp);
		return true;
	}

	@Transactional
	public ResponseEntity createRegisterationOtp(CreateOtpRequestDTO createOtpRequestDTO) {

		String url = "";

		try {
			Chiraghuser chiraghuser = userRepository.findByUserId(createOtpRequestDTO.getUserId());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			logger.info("Registration process -> invalidating previous otp");
			chiraghOtpRepository.invalidateRegistrationOtp(chiraghuser.getUserId(), createOtpRequestDTO.getSubject());

			String appURL = environment.getProperty("APP_URL");
			appURL = appURL.replaceAll("^\"|\"$", "");
			ForgotPasswordServiceResponse resetToken = chiragUtill.createRegistrationToken(chiraghuser, true);
			url = appURL + "/activateAccount/" + resetToken.getToken();

			ChiraghOtp chiraghOtp = new ChiraghOtp();
			Boolean isOtpSent = false;

			chiraghOtp = ObjectMapperUtils.map(createOtpRequestDTO, ChiraghOtp.class);
			chiraghOtp.setUserId(chiraghuser.getUserId());
			chiraghOtp.setCreatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp.setUpdatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp = chiraghOtpRepository.save(chiraghOtp);

			if (chiraghOtp != null) {
				createOtpRequestDTO.setOtpId(chiraghOtp.getId());
				isOtpSent = chiraghOtpCodeService.createOtpCodeForRegistration(createOtpRequestDTO, chiraghuser, url);

			}

			if (isOtpSent) {
				chiraghOtp.setIsValid(isOtpSent);
				chiraghOtp = chiraghOtpRepository.save(chiraghOtp);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_NOT_FOUND, null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	@Transactional
	public ResponseEntity createMobileRegisterationOtp(CreateOtpRequestDTO createOtpRequestDTO, String mobileNumber) {

		String url = "";

		try {
			Chiraghuser chiraghuser = userRepository.findByUserId(createOtpRequestDTO.getUserId());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			char splitChar = '-';
			int splitIndex = mobileNumber.indexOf(splitChar);

			if (splitIndex != -1) {
				String part1 = mobileNumber.substring(0, splitIndex);
				String part2 = mobileNumber.substring(splitIndex + 1); // Exclude the split character itself
				chiraghuser.setMobileCode(part1);
				chiraghuser.setMobileNo(part2);
				userRepository.save(chiraghuser);
			}
			logger.info("Registration process -> invalidating previous otp");
			chiraghOtpRepository.invalidateRegistrationOtp(chiraghuser.getUserId(), createOtpRequestDTO.getSubject());

			String appURL = environment.getProperty("APP_URL");
			appURL = appURL.replaceAll("^\"|\"$", "");
			ForgotPasswordServiceResponse resetToken = chiragUtill.createRegistrationToken(chiraghuser, true);
			url = appURL + "/activateAccount/" + resetToken.getToken();

			ChiraghOtp chiraghOtp = new ChiraghOtp();
			Boolean isOtpSent = false;
			chiraghOtp = ObjectMapperUtils.map(createOtpRequestDTO, ChiraghOtp.class);
			chiraghOtp.setIsValid(true);
			chiraghOtp.setUserId(chiraghuser.getUserId());
			chiraghOtp.setCreatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp.setUpdatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp = chiraghOtpRepository.save(chiraghOtp);

			if (chiraghOtp != null) {
				createOtpRequestDTO.setOtpId(chiraghOtp.getId());
				isOtpSent = chiraghOtpCodeService.createOtpCodeForMobileRegistration(createOtpRequestDTO, chiraghuser,
						url);

			}

			if (isOtpSent) {
				chiraghOtp.setIsValid(isOtpSent);
				chiraghOtp = chiraghOtpRepository.save(chiraghOtp);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_NOT_FOUND, null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	@Transactional
	public ResponseEntity createEmailRegisterationOtp(CreateOtpRequestDTO createOtpRequestDTO) {

		String url = "";

		try {
			Chiraghuser chiraghuser = userRepository.findByUserId(createOtpRequestDTO.getUserId());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			logger.info("Registration process -> invalidating previous otp");
			chiraghOtpRepository.invalidateRegistrationOtp(chiraghuser.getUserId(), createOtpRequestDTO.getSubject());

			String appURL = environment.getProperty("APP_URL");
			appURL = appURL.replaceAll("^\"|\"$", "");
			ForgotPasswordServiceResponse resetToken = chiragUtill.createRegistrationToken(chiraghuser, true);
			url = appURL + "/activateAccount/" + resetToken.getToken();

			ChiraghOtp chiraghOtp = new ChiraghOtp();
			Boolean isOtpSent = false;

			chiraghOtp = ObjectMapperUtils.map(createOtpRequestDTO, ChiraghOtp.class);
			chiraghOtp.setUserId(chiraghuser.getUserId());
			chiraghOtp.setIsValid(true);
			chiraghOtp.setCreatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp.setUpdatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp = chiraghOtpRepository.save(chiraghOtp);

			if (chiraghOtp != null) {
				createOtpRequestDTO.setOtpId(chiraghOtp.getId());
				isOtpSent = chiraghOtpCodeService.createOtpCodeForEmailRegistration(createOtpRequestDTO, chiraghuser,
						url);

			}

			if (isOtpSent) {
				chiraghOtp.setIsValid(isOtpSent);
				chiraghOtp = chiraghOtpRepository.save(chiraghOtp);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_NOT_FOUND, null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	@Transactional
	public ResponseEntity createOtpTwoFactorSmsLogin(CreateOtpRequestDTO createOtpRequestDTO) {

		String url = "";

		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			// System.out.println(user.getDepartements().getDepartementsId());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			createOtpRequestDTO.setUserId(chiraghuser.getUserId());
			logger.info("Registration process -> invalidating previous otp");
			chiraghOtpRepository.invalidateRegistrationOtp(chiraghuser.getUserId(), createOtpRequestDTO.getSubject());

			String appURL = environment.getProperty("APP_URL");
			appURL = appURL.replaceAll("^\"|\"$", "");
			ForgotPasswordServiceResponse resetToken = chiragUtill.createRegistrationToken(chiraghuser, true);
			url = appURL + "/activateAccount/" + resetToken.getToken();

			ChiraghOtp chiraghOtp = new ChiraghOtp();
			Boolean isOtpSent = false;
			chiraghOtp = ObjectMapperUtils.map(createOtpRequestDTO, ChiraghOtp.class);
			chiraghOtp.setIsValid(true);
			chiraghOtp.setUserId(chiraghuser.getUserId());
			chiraghOtp.setCreatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp.setUpdatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp = chiraghOtpRepository.save(chiraghOtp);

			if (chiraghOtp != null) {
				createOtpRequestDTO.setOtpId(chiraghOtp.getId());
				isOtpSent = chiraghOtpCodeService.createOtpCodeForMobileRegistration(createOtpRequestDTO, chiraghuser,
						url);

			}

			if (isOtpSent) {
				chiraghOtp.setIsValid(isOtpSent);
				chiraghOtp = chiraghOtpRepository.save(chiraghOtp);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_NOT_FOUND, null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public Boolean invalidateRegistrationOtp(Chiraghuser chiraghuser, String otpSubject) {
		ChiraghOtp chiraghOtp = chiraghOtpRepository.getValidOtpForRegistration(chiraghuser.getUserId(), otpSubject);
		if (chiraghOtp != null) {
			chiraghOtp.setIsValid(false);
			chiraghOtpRepository.save(chiraghOtp);
		}
		return true;
	}

	public ResponseEntity createTestOtp(CreateOtpRequestDTO createOtpRequestDTO) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			// System.out.println(user.getDepartements().getDepartementsId());

			if (createOtpRequestDTO.getSubject().equalsIgnoreCase("registration")) {
				chiraghuser = userRepository.findByUserId(createOtpRequestDTO.getUserId());
				createOtpRequestDTO.setSubject("Registration");
			} else if (createOtpRequestDTO.getSubject().equalsIgnoreCase("myaccounts")) {
				createOtpRequestDTO.setSubject("MyAccounts");
			}
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			if (createOtpRequestDTO.getSubject().equalsIgnoreCase("Registration")) {
				chiraghOtpRepository.invalidateRegistrationOtp(createOtpRequestDTO.getUserId(),
						createOtpRequestDTO.getSubject());
			} else {
				chiraghOtpRepository.invalidateOtp(chiraghuser.getUserId(), createOtpRequestDTO.getCurrencyId(),
						createOtpRequestDTO.getSubject());
			}
			ChiraghOtp chiraghOtp = new ChiraghOtp();
			ChiraghOtpCodes chiraghOtpCodes = null;
			Boolean isOtpSent = false;
			String emailBody = "Please use this OTP For " + createOtpRequestDTO.getSubject() + " OTP: ";
			chiraghOtp = ObjectMapperUtils.map(createOtpRequestDTO, ChiraghOtp.class);
			chiraghOtp.setUserId(chiraghuser.getUserId());
			chiraghOtp.setCreatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp.setUpdatedAt(DateUtils.getDefault().getNowTime());
			chiraghOtp = chiraghOtpRepository.save(chiraghOtp);

			if (chiraghOtp != null) {
				createOtpRequestDTO.setOtpId(chiraghOtp.getId());
				isOtpSent = chiraghOtpCodeService.createTestOtpCode(createOtpRequestDTO, chiraghuser, emailBody);

			}

			if (isOtpSent) {
				chiraghOtp.setIsValid(isOtpSent);
				chiraghOtp = chiraghOtpRepository.save(chiraghOtp);
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS, null);
			} else {

				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_NOT_FOUND, null);
			}

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	/**
	 * This method is used to fetch revenue amount from OTP table.
	 * 
	 * @param chiraghuser
	 * @param otpSubject
	 * @param currencyId
	 */
	public String fetchRevenueFromOtp(Chiraghuser chiraghuser, String otpSubject, Integer currencyId) {
		ChiraghOtp chiraghOtp = chiraghOtpRepository.getValidOtp(chiraghuser.getUserId(), currencyId, otpSubject);
		String amount = null;
		if (chiraghOtp.getData() != null) {
			amount = chiraghOtp.getData().contains("Revenue") ? chiraghOtp.getData().split(":")[4].replace("}", "")
					: null;
		}
		return amount;
	}

	/**
	 * This method is used to fetch data string in json format
	 * 
	 * @param createOtpRequestDTO
	 * @return
	 */
	private String fetchJsonDataString(CreateOtpRequestDTO createOtpRequestDTO) {
		StringBuilder data = new StringBuilder("");
		data.append("{");
		data.append("\"AskingRate\":");
		data.append(createOtpRequestDTO.getData().getAskRate());
		data.append(",\"SpotRate\":");
		data.append(createOtpRequestDTO.getData().getSrcToDesRate());
		data.append(",\"Amount\":");
		BigDecimal amountWithDeduction = createOtpRequestDTO.getAmount()
				.multiply(createOtpRequestDTO.getData().getAskRate());
		BigDecimal amountWithOutDeduction = createOtpRequestDTO.getAmount()
				.multiply(createOtpRequestDTO.getData().getSrcToDesRate());
		data.append(amountWithDeduction);
		data.append(",\"Revenue\":");
		BigDecimal revenue = amountWithOutDeduction.subtract(amountWithDeduction);
		data.append(revenue.abs());
		data.append("}");
		return data.toString();
	}

}
