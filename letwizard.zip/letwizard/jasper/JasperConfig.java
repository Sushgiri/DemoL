package com.bestercapitalmedia.letwizard.jasper;

import java.io.File;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.fill.JRFileVirtualizer;
import net.sf.jasperreports.engine.fill.JRSwapFileVirtualizer;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.util.JRSaver;
import net.sf.jasperreports.engine.util.JRSwapFile;

//@Configuration
//@Service
public class JasperConfig {
	

//	@Bean` 
//	JasperReport report() throws JRException {
//		JasperReport jr = null;
//		File f = new File("FormA.jasper");
//		if (f.exists()) {
//			jr = (JasperReport) JRLoader.loadObject(f);
//		} else {
//			jr = JasperCompileManager.compileReport("src/main/resources/FormA.jrxml");
//			JRSaver.saveObject(jr, "src/main/resources/FormA.jasper");
//		}
//		return jr;
//	}
	
	
	
	
	
}
