package com.bestercapitalmedia.letwizard.jasper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import net.sf.jasperreports.engine.JRParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.fill.JRFileVirtualizer;
import net.sf.jasperreports.engine.fill.JRSwapFileVirtualizer;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.engine.util.JRSwapFile;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;

import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.SellerMessages;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/property/")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class JasperController {

	protected Logger logger = Logger.getLogger(JasperController.class.getName());
	public static int count = 0;

	@Autowired
	DataSource datasource;

	@Autowired
	ResponseUtill responseUtill;

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/forma/{propertyId}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getReport(@PathVariable(value = "propertyId") int propertyId) {
		String name = "formA.pdf";
		String data = generateReport(name, propertyId);
		if (data != null)
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, "Form Generated Successfully",
					Stream.of(data).collect(Collectors.toList()));
		else
			return responseUtill.getApiResponse(ResponseCodes.FAILURE, SellerMessages.DATA_SAVED_FAILURE, null);
	}

	private String generateReport(String name, int propertyId) {
		FileInputStream st = null;
		Connection cc = null;
		byte[] bytes = null;
		try {
			cc = datasource.getConnection();
			Map<String, Object> params = new HashMap<>();
			params.put("propertyId", propertyId);
			JasperPrint p = JasperFillManager.fillReport(this.getClass().getResourceAsStream("/formA.jasper"), params,
					cc);
			// File file = new File(ChiraghConstants.IMAGE_PATH);
			// file.mkdirs();
			// String path = ChiraghConstants.IMAGE_PATH + propertyId + "-formA.pdf";
			// JasperExportManager.exportReportToPdfFile(p, path);
			bytes = JasperExportManager.exportReportToPdf(p);
			String string = Base64.getEncoder().encodeToString(bytes);
			return string;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (cc != null)
				try {
					cc.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return null;
	}

}
