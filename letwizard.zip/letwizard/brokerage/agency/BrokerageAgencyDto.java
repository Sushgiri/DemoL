package com.bestercapitalmedia.letwizard.brokerage.agency;

public class BrokerageAgencyDto{
	
	 String companyName;
	 String reraNumber;
	 String contactName;
	 String contactNumber;	
	 String brokerageLicense;
	 String approvalAForm;	
	 String mobileCode;
	
	public String getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}

	public BrokerageAgencyDto() {
		
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getReraNumber() {
		return reraNumber;
	}

	public void setReraNumber(String reraNumber) {
		this.reraNumber = reraNumber;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getBrokerageLicense() {
		return brokerageLicense;
	}

	public void setBrokerageLicense(String brokerageLicense) {
		this.brokerageLicense = brokerageLicense;
	}

	public String getApprovalAForm() {
		return approvalAForm;
	}

	public void setApprovalAForm(String approvalAForm) {
		this.approvalAForm = approvalAForm;
	}

}
