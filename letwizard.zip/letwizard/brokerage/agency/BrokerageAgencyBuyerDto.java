package com.bestercapitalmedia.letwizard.brokerage.agency;

import lombok.Data;

@Data
public class BrokerageAgencyBuyerDto {

	String companyName;
	String reraNumber;
	String contactName;
	String contactNumber;
	String brokerageLicense;
	String approvalBForm;
	String mobileCode;

	public BrokerageAgencyBuyerDto() {

	}

}
