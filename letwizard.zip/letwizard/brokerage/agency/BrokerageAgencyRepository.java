package com.bestercapitalmedia.letwizard.brokerage.agency;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;



public interface BrokerageAgencyRepository extends CrudRepository<BrokerageAgency,Integer>{
	
	@Query(value = "select * from brokerage_agency where rera_number = ?1", nativeQuery = true)
	public BrokerageAgency getByReraNumber(String reraNumber);
	
	@Query(value = "select * from brokerage_agency where id = ?1", nativeQuery = true)
	public BrokerageAgency getByid(Integer id);
	
	@Query(value = "select * from brokerage_agency where rera_number = ?1 and user_id =?2 ", nativeQuery = true)
	public BrokerageAgency getByReraNumberAndUserId(String reraNumber, int userId);
	
}
