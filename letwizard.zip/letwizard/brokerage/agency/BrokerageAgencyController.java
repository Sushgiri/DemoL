package com.bestercapitalmedia.letwizard.brokerage.agency;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/brokerage/agency/")
public class BrokerageAgencyController {
	
	@Autowired
	private BrokerageAgencyService brokerageAgencyService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/get/{reraNumber}", method = RequestMethod.GET)
	public ResponseEntity getBrokerageAgencyByReraNumber(@PathVariable(value ="reraNumber") String reraNumber, HttpServletRequest httpServletRequest, Authentication authentication) {
		return brokerageAgencyService.getBrokerageAgencyByReraNumber(reraNumber,authentication);
	}
	
}
