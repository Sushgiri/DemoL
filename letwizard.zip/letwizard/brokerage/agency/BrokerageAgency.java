package com.bestercapitalmedia.letwizard.brokerage.agency;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "brokerage_agency")
public class BrokerageAgency implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	@Column(name = "id", nullable = false)
	@Basic(fetch = FetchType.EAGER)

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Integer brokerageAgencyId;
	
	@Column(name = "company_name", length = 255)
	@Basic(fetch = FetchType.EAGER)
	String companyName;
	
	@Column(name = "rera_number")
	@Basic(fetch = FetchType.EAGER)
	String reraNumber;
	
	@Column(name = "contact_name")
	@Basic(fetch = FetchType.EAGER)
	String contactName;
	
	@Column(name = "contact_number")
	@Basic(fetch = FetchType.EAGER)
	String contactNumber;	
	
	@Column(name = "brokerage_license")
	@Basic(fetch = FetchType.EAGER)
	String brokerageLicense;	
	
	@Column(name = "approval_a_form")
	@Basic(fetch = FetchType.EAGER)
	String approvalAForm;
	
	@Column(name = "approval_b_form")
	@Basic(fetch = FetchType.EAGER)
	String approvalBForm;
	
	@Column(name = "user_id")
	@Basic(fetch = FetchType.EAGER)
	Integer userId;
	
	@Column(name = "created_at")
	@Basic(fetch = FetchType.EAGER)
	Date createdAt;	
	
	@Column(name = "updated_at")
	@Basic(fetch = FetchType.EAGER)
	Date updatedAt;	
	
	@Column(name = "contact_number_Code")
	@Basic(fetch = FetchType.EAGER)
	String mobileCode;	
	
	
	public BrokerageAgency() {
		
	}

	public Integer getBrokerageAgencyId() {
		return brokerageAgencyId;
	}

	public void setBrokerageAgencyId(Integer brokerageAgencyId) {
		this.brokerageAgencyId = brokerageAgencyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getReraNumber() {
		return reraNumber;
	}

	public void setReraNumber(String reraNumber) {
		this.reraNumber = reraNumber;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getBrokerageLicense() {
		return brokerageLicense;
	}

	public void setBrokerageLicense(String brokerageLicense) {
		this.brokerageLicense = brokerageLicense;
	}

	public String getApprovalAForm() {
		return approvalAForm;
	}

	public void setApprovalAForm(String approvalAForm) {
		this.approvalAForm = approvalAForm;
	}

	public String getApprovalBForm() {
		return approvalBForm;
	}

	public void setApprovalBForm(String approvalBForm) {
		this.approvalBForm = approvalBForm;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	public String getMobileCode() {
		return mobileCode;
	}

	public void setMobileCode(String mobileCode) {
		this.mobileCode = mobileCode;
	}

}
