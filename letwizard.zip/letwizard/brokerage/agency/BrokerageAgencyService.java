package com.bestercapitalmedia.letwizard.brokerage.agency;

import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.vouchers.VoucherService;



@Service
public class BrokerageAgencyService {
	private static final Logger logger = LoggerFactory.getLogger(BrokerageAgencyService.class);

	
	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private BrokerageAgencyRepository brokerageAgencyRepo;
	
	@Autowired
	private UserRepository userRepository;
	
	public ResponseEntity getBrokerageAgencyByReraNumber( String reraNumber, Authentication authentication) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
		
			BrokerageAgency brokerageAgencyExist = brokerageAgencyRepo.getByReraNumberAndUserId(reraNumber, chiraghuser.getUserId());
			if (brokerageAgencyExist == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS, Stream.of(brokerageAgencyExist).collect(Collectors.toList()));
			
		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}
}
