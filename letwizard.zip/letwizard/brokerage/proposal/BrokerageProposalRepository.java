package com.bestercapitalmedia.letwizard.brokerage.proposal;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bestercapitalmedia.letwizard.property.rental.PropertyPriceAvailability;


public interface BrokerageProposalRepository extends CrudRepository<BrokerageProposal, Integer> {

	@Query(value = "select * from brokerage_proposal where property_id =?1", nativeQuery = true)
	public BrokerageProposal findProposalByPropertyId(int propertyId);
	
	@Query(value = "select * from brokerage_proposal where id =?1", nativeQuery = true)
	public BrokerageProposal findProposalById(int brokerageProposalId);
	
	@Query(value = "SELECT bid_range FROM brokerage_proposal WHERE property_Id =?1", nativeQuery=true)
	public float getBidRangeByPropertyId(int propertyId);
	
	@Query(value = "SELECT currency_id FROM brokerage_proposal WHERE property_Id =?1", nativeQuery=true)
	public int getPropertyBaseCurrencyID(int propertyId);
	
	@Query(value = "select * from brokerage_proposal where auction_ends_at<=NOW()", nativeQuery = true)
	List<BrokerageProposal> findCheckOutProperty();
}
