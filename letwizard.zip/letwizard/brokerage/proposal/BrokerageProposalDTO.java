package com.bestercapitalmedia.letwizard.brokerage.proposal;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.bestercapitalmedia.letwizard.openhouse.OpenHousescheduleDTO;
import com.bestercapitalmedia.letwizard.valuation.companies.ValuationCompaniesDTO;
import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrencyDTO;
import com.fasterxml.jackson.annotation.JsonProperty;

public class BrokerageProposalDTO {
	
	private String action;
	private Integer id;
	private Integer propertyId;
	private String reservePriceMax;
	private String reservePriceMin;
	private BigDecimal reservePrice;
	private String openPriceMax;
	private String openPriceMin;
	private BigDecimal openPrice;
	private Integer auctionDuration;
	private String auctionStartDate;
	private Boolean openHouse;
	private String openHouseText;
	private Integer hodConfirm;
	private Integer mdConfirm;
	@JsonProperty("subsequentBid")
	private String bidRange;
	private Boolean sellerConfirm;
	private Integer feeVoucherId;
	private Integer depositVoucherId;
	private BigDecimal auctionFeeAmount; 
	private BigDecimal auctionDepositAmount;
	private String otpCode;
	private String attachment;
	private Boolean isAuctionFeeCompleted;
	private Boolean isRange;
	private List<OpenHousescheduleDTO> openHouseSchedule;
	private int exchangeCurrencyId;
	private String paymentMode;
	private Date auctioEndDate;
	private Boolean isManual;
	private Boolean brokerageConfirm;
	private Boolean isExclusive;
	private Boolean isReauction;
	private Boolean alreadyExclusive;
	private ValuationCompaniesDTO valuationCompanies;
	private String salesCommission;
	private String performanceFee;
	private BigDecimal otherFee;
	private BigDecimal buyNowPrice;
	private BigDecimal buyNowDeposit;
	private BigDecimal securityDepositFin;
	private BigDecimal otherDepositFin;
	private BigDecimal expectedPriceMinFin;
	private BigDecimal expectedPriceMaxFin;
	private BigDecimal vatFees;
	private BigDecimal rentNowPriceFin;
	private BigDecimal securityDepositHod;
	private BigDecimal otherDepositHod;
	private BigDecimal expectedPriceMinHod;
	private BigDecimal expectedPriceMaxHod;
	private BigDecimal rentNowPriceHod;
	private String rentalContractDraft;
	private String rentalContractDraftLink;
    
	

	@JsonProperty("currency")
	private VoucherCurrencyDTO voucherCurrency;
	private Date auctionEndsAt;
	private String auctionTimeZone;
	private Date auctionEndDate;
	
	public BrokerageProposalDTO() {
//		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() { 
		return id;
	}

	
	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}

	public String getReservePriceMax() {
		return reservePriceMax;
	}

	public void setReservePriceMax(String reservePriceMax) {
		this.reservePriceMax = reservePriceMax;
	}

	public String getReservePriceMin() {
		return reservePriceMin;
	}

	public void setReservePriceMin(String reservePriceMin) {
		this.reservePriceMin = reservePriceMin;
	}

	public BigDecimal getReservePrice() {
		return reservePrice;
	}

	public void setReservePrice(BigDecimal reservePrice) {
		this.reservePrice = reservePrice;
	}

	public String getOpenPriceMax() {
		return openPriceMax;
	}

	public void setOpenPriceMax(String openPriceMax) {
		this.openPriceMax = openPriceMax;
	}

	public String getOpenPriceMin() {
		return openPriceMin;
	}

	public void setOpenPriceMin(String openPriceMin) {
		this.openPriceMin = openPriceMin;
	}

	public BigDecimal getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(BigDecimal openPrice) {
		this.openPrice = openPrice;
	}

	public Integer getAuctionDuration() {
		return auctionDuration;
	}

	public void setAuctionDuration(Integer auctionDuration) {
		this.auctionDuration = auctionDuration;
	}

	public String getAuctionStartDate() {
		return auctionStartDate;
	}

	public void setAuctionStartDate(String auctionStartDate) {
		this.auctionStartDate = auctionStartDate;
	}

	public Boolean getOpenHouse() {
		return openHouse;
	}

	public void setOpenHouse(Boolean openHouse) {
		this.openHouse = openHouse;
	}

	public String getOpenHouseText() {
		return openHouseText;
	}

	public void setOpenHouseText(String openHouseText) {
		this.openHouseText = openHouseText;
	}

	public Integer getHodConfirm() {
		return hodConfirm;
	}

	public void setHodConfirm(Integer hodConfirm) {
		this.hodConfirm = hodConfirm;
	}

	public Integer getMdConfirm() {
		return mdConfirm;
	}

	public void setMdConfirm(Integer mdConfirm) {
		this.mdConfirm = mdConfirm;
	}

	public String getBidRange() {
		return bidRange;
	}

	public void setBidRange(String bidRange) {
		this.bidRange = bidRange;
	}

	public Boolean getSellerConfirm() {
		return sellerConfirm;
	}

	public void setSellerConfirm(Boolean sellerConfirm) {
		this.sellerConfirm = sellerConfirm;
	}

	public Integer getFeeVoucherId() {
		return feeVoucherId;
	}

	public void setFeeVoucherId(Integer feeVoucherId) {
		this.feeVoucherId = feeVoucherId;
	}

	public Integer getDepositVoucherId() {
		return depositVoucherId;
	}

	public void setDepositVoucherId(Integer depositVoucherId) {
		this.depositVoucherId = depositVoucherId;
	}

	public BigDecimal getAuctionFeeAmount() {
		return auctionFeeAmount;
	}

	public void setAuctionFeeAmount(BigDecimal auctionFeeAmount) {
		this.auctionFeeAmount = auctionFeeAmount;
	}

	public BigDecimal getAuctionDepositAmount() {
		return auctionDepositAmount;
	}

	public void setAuctionDepositAmount(BigDecimal auctionDepositAmount) {
		this.auctionDepositAmount = auctionDepositAmount;
	}

	public String getOtpCode() {
		return otpCode;
	}

	public void setOtpCode(String otpCode) {
		this.otpCode = otpCode;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public Boolean getIsAuctionFeeCompleted() {
		return isAuctionFeeCompleted;
	}

	public void setIsAuctionFeeCompleted(Boolean isAuctionFeeCompleted) {
		this.isAuctionFeeCompleted = isAuctionFeeCompleted;
	}

	public Boolean getIsRange() {
		return isRange;
	}

	public void setIsRange(Boolean isRange) {
		this.isRange = isRange;
	}

	public List<OpenHousescheduleDTO> getOpenHouseSchedule() {
		return openHouseSchedule;
	}

	public void setOpenHouseSchedule(List<OpenHousescheduleDTO> openHouseSchedule) {
		this.openHouseSchedule = openHouseSchedule;
	}

	public int getExchangeCurrencyId() {
		return exchangeCurrencyId;
	}

	public void setExchangeCurrencyId(int exchangeCurrencyId) {
		this.exchangeCurrencyId = exchangeCurrencyId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public Date getAuctioEndDate() {
		return auctioEndDate;
	}

	public void setAuctioEndDate(Date auctioEndDate) {
		this.auctioEndDate = auctioEndDate;
	}

	public Boolean getIsManual() {
		return isManual;
	}

	public void setIsManual(Boolean isManual) {
		this.isManual = isManual;
	}

	public Boolean getBrokerageConfirm() {
		return brokerageConfirm;
	}

	public void setBrokerageConfirm(Boolean brokerageConfirm) {
		this.brokerageConfirm = brokerageConfirm;
	}

	public Boolean getIsExclusive() {
		return isExclusive;
	}

	public void setIsExclusive(Boolean isExclusive) {
		this.isExclusive = isExclusive;
	}

	public Boolean getIsReauction() {
		return isReauction;
	}

	public void setIsReauction(Boolean isReauction) {
		this.isReauction = isReauction;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Boolean getAlreadyExclusive() {
		return alreadyExclusive;
	}

	public void setAlreadyExclusive(Boolean alreadyExclusive) {
		this.alreadyExclusive = alreadyExclusive;
	}

	public ValuationCompaniesDTO getValuationCompanies() {
		return valuationCompanies;
	}

	public void setValuationCompanies(ValuationCompaniesDTO valuationCompanies) {
		this.valuationCompanies = valuationCompanies;
	}

	public String getSalesCommission() {
		return salesCommission;
	}

	public void setSalesCommission(String salesCommission) {
		this.salesCommission = salesCommission;
	}

	public String getPerformanceFee() {
		return performanceFee;
	}

	public void setPerformanceFee(String performanceFee) {
		this.performanceFee = performanceFee;
	}

	public BigDecimal getOtherFee() {
		return otherFee;
	}

	public void setOtherFee(BigDecimal otherFee) {
		this.otherFee = otherFee;
	}

	public BigDecimal getBuyNowPrice() {
		return buyNowPrice;
	}

	public void setBuyNowPrice(BigDecimal buyNowPrice) {
		this.buyNowPrice = buyNowPrice;
	}

	public BigDecimal getBuyNowDeposit() {
		return buyNowDeposit;
	}

	public void setBuyNowDeposit(BigDecimal buyNowDeposit) {
		this.buyNowDeposit = buyNowDeposit;
	}

	public Boolean getAuctionFeeCompleted() {
		return isAuctionFeeCompleted;
	}

	public void setAuctionFeeCompleted(Boolean auctionFeeCompleted) {
		isAuctionFeeCompleted = auctionFeeCompleted;
	}

	public Boolean getRange() {
		return isRange;
	}

	public void setRange(Boolean range) {
		isRange = range;
	}

	public Boolean getManual() {
		return isManual;
	}

	public void setManual(Boolean manual) {
		isManual = manual;
	}

	public Boolean getExclusive() {
		return isExclusive;
	}

	public void setExclusive(Boolean exclusive) {
		isExclusive = exclusive;
	}

	public Boolean getReauction() {
		return isReauction;
	}

	public void setReauction(Boolean reauction) {
		isReauction = reauction;
	}

	public BigDecimal getSecurityDepositFin() {
		return securityDepositFin;
	}

	public void setSecurityDepositFin(BigDecimal securityDepositFin) {
		this.securityDepositFin = securityDepositFin;
	}

	public BigDecimal getOtherDepositFin() {
		return otherDepositFin;
	}

	public void setOtherDepositFin(BigDecimal otherDepositFin) {
		this.otherDepositFin = otherDepositFin;
	}

	public BigDecimal getExpectedPriceMinFin() {
		return expectedPriceMinFin;
	}

	public void setExpectedPriceMinFin(BigDecimal expectedPriceMinFin) {
		this.expectedPriceMinFin = expectedPriceMinFin;
	}

	public BigDecimal getExpectedPriceMaxFin() {
		return expectedPriceMaxFin;
	}

	public void setExpectedPriceMaxFin(BigDecimal expectedPriceMaxFin) {
		this.expectedPriceMaxFin = expectedPriceMaxFin;
	}

	public BigDecimal getVatFees() {
		return vatFees;
	}

	public void setVatFees(BigDecimal vatFees) {
		this.vatFees = vatFees;
	}

	public BigDecimal getRentNowPriceFin() {
		return rentNowPriceFin;
	}

	public void setRentNowPriceFin(BigDecimal rentNowPriceFin) {
		this.rentNowPriceFin = rentNowPriceFin;
	}

	public BigDecimal getSecurityDepositHod() {	return securityDepositHod;	}

	public void setSecurityDepositHod(BigDecimal securityDepositHod) { this.securityDepositHod = securityDepositHod;}

	public BigDecimal getOtherDepositHod() {return otherDepositHod;	}

	public void setOtherDepositHod(BigDecimal otherDepositHod) {this.otherDepositHod = otherDepositHod;	}

	public BigDecimal getExpectedPriceMinHod() {return expectedPriceMinHod;	}

	public void setExpectedPriceMinHod(BigDecimal expectedPriceMinHod) {this.expectedPriceMinHod = expectedPriceMinHod;	}

	public BigDecimal getExpectedPriceMaxHod() {return expectedPriceMaxHod;	}

	public void setExpectedPriceMaxHod(BigDecimal expectedPriceMaxHod) {this.expectedPriceMaxHod = expectedPriceMaxHod;	}

	public BigDecimal getRentNowPriceHod() {return rentNowPriceHod;	}

	public void setRentNowPriceHod(BigDecimal rentNowPriceHod) {this.rentNowPriceHod = rentNowPriceHod;	}

	public VoucherCurrencyDTO getVoucherCurrency() {
		return voucherCurrency;
	}

	public void setVoucherCurrency(VoucherCurrencyDTO voucherCurrency) {
		this.voucherCurrency = voucherCurrency;
	}

	public Date getAuctionEndsAt() {
		return auctionEndsAt;
	}

	public void setAuctionEndsAt(Date auctionEndsAt) {
		this.auctionEndsAt = auctionEndsAt;
	}

	public String getAuctionTimeZone() {
		return auctionTimeZone;
	}

	public void setAuctionTimeZone(String auctionTimeZone) {
		this.auctionTimeZone = auctionTimeZone;
	}

	public Date getAuctionEndDate() {
		return auctionEndDate;
	}

	public void setAuctionEndDate(Date auctionEndDate) {
		this.auctionEndDate = auctionEndDate;
	}
	public String getRentalContractDraft() {
		return rentalContractDraft;
	}

	public void setRentalContractDraft(String rentalContractDraft) {
		this.rentalContractDraft = rentalContractDraft;
	}

	public String getRentalContractDraftLink() {
		return rentalContractDraftLink;
	}

	public void setRentalContractDraftLink(String rentalContractDraftLink) {
		this.rentalContractDraftLink = rentalContractDraftLink;
	}
}