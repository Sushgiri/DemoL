package com.bestercapitalmedia.letwizard.brokerage.proposal;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface BrokerageProposalDailyRepository extends CrudRepository<BrokerageProposalDaily, Integer> {
	
	@Query(value = "select * from brokerage_proposal_daily where brokerage_proposal_id=?1", nativeQuery = true)
    List<BrokerageProposalDaily> findByBrokerageProposalId(Integer brokerageProposalId);
}