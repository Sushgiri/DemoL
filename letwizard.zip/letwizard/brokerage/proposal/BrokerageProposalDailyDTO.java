package com.bestercapitalmedia.letwizard.brokerage.proposal;

import java.math.BigDecimal;
import java.util.Date;

public class BrokerageProposalDailyDTO {
	
	private Integer id;
	private Integer brokerageProposalId;
	private Integer priceAvailabilityId;
	private Date dailyPricingDate;
	private String salesCommission;
	private String performanceFee;
	private BigDecimal otherFee;
	private BigDecimal securityDepositFin;
	private BigDecimal otherDepositFin;
	private BigDecimal expectedPriceMinFin;
	private BigDecimal expectedPriceMaxFin;
	private BigDecimal vatFees;
	private BigDecimal rentNowPriceFin;
	private BigDecimal securityDepositHod;
	private BigDecimal otherDepositHod;
	private BigDecimal expectedPriceMinHod;
	private BigDecimal expectedPriceMaxHod;
	private BigDecimal rentNowPriceHod;
	
	public BrokerageProposalDailyDTO() {
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBrokerageProposalId() {
		return brokerageProposalId;
	}

	public void setBrokerageProposalId(Integer brokerageProposalId) {
		this.brokerageProposalId = brokerageProposalId;
	}

	public Integer getPriceAvailabilityId() {
		return priceAvailabilityId;
	}

	public void setPriceAvailabilityId(Integer priceAvailabilityId) {
		this.priceAvailabilityId = priceAvailabilityId;
	}

	public Date getDailyPricingDate() {
		return dailyPricingDate;
	}

	public void setDailyPricingDate(Date dailyPricingDate) {
		this.dailyPricingDate = dailyPricingDate;
	}

	public String getSalesCommission() {
		return salesCommission;
	}

	public void setSalesCommission(String salesCommission) {
		this.salesCommission = salesCommission;
	}

	public String getPerformanceFee() {
		return performanceFee;
	}

	public void setPerformanceFee(String performanceFee) {
		this.performanceFee = performanceFee;
	}

	public BigDecimal getOtherFee() {
		return otherFee;
	}

	public void setOtherFee(BigDecimal otherFee) {
		this.otherFee = otherFee;
	}

	public BigDecimal getSecurityDepositFin() {
		return securityDepositFin;
	}

	public void setSecurityDepositFin(BigDecimal securityDepositFin) {
		this.securityDepositFin = securityDepositFin;
	}

	public BigDecimal getOtherDepositFin() {
		return otherDepositFin;
	}

	public void setOtherDepositFin(BigDecimal otherDepositFin) {
		this.otherDepositFin = otherDepositFin;
	}

	public BigDecimal getExpectedPriceMinFin() {
		return expectedPriceMinFin;
	}

	public void setExpectedPriceMinFin(BigDecimal expectedPriceMinFin) {
		this.expectedPriceMinFin = expectedPriceMinFin;
	}

	public BigDecimal getExpectedPriceMaxFin() {
		return expectedPriceMaxFin;
	}

	public void setExpectedPriceMaxFin(BigDecimal expectedPriceMaxFin) {
		this.expectedPriceMaxFin = expectedPriceMaxFin;
	}

	public BigDecimal getVatFees() {
		return vatFees;
	}

	public void setVatFees(BigDecimal vatFees) {
		this.vatFees = vatFees;
	}

	public BigDecimal getRentNowPriceFin() {
		return rentNowPriceFin;
	}

	public void setRentNowPriceFin(BigDecimal rentNowPriceFin) {
		this.rentNowPriceFin = rentNowPriceFin;
	}

	public BigDecimal getSecurityDepositHod() {
		return securityDepositHod;
	}

	public void setSecurityDepositHod(BigDecimal securityDepositHod) {
		this.securityDepositHod = securityDepositHod;
	}

	public BigDecimal getOtherDepositHod() {
		return otherDepositHod;
	}

	public void setOtherDepositHod(BigDecimal otherDepositHod) {
		this.otherDepositHod = otherDepositHod;
	}

	public BigDecimal getExpectedPriceMinHod() {
		return expectedPriceMinHod;
	}

	public void setExpectedPriceMinHod(BigDecimal expectedPriceMinHod) {
		this.expectedPriceMinHod = expectedPriceMinHod;
	}

	public BigDecimal getExpectedPriceMaxHod() {
		return expectedPriceMaxHod;
	}

	public void setExpectedPriceMaxHod(BigDecimal expectedPriceMaxHod) {
		this.expectedPriceMaxHod = expectedPriceMaxHod;
	}

	public BigDecimal getRentNowPriceHod() {
		return rentNowPriceHod;
	}

	public void setRentNowPriceHod(BigDecimal rentNowPriceHod) {
		this.rentNowPriceHod = rentNowPriceHod;
	}
}