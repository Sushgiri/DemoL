package com.bestercapitalmedia.letwizard.brokerage.proposal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.vouchers.VoucherService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/brokerage")
public class PropertyBrokerageController {
	
	@Autowired
	private BrokerageProposalService brokerageProposalService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/property/{propertyId}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity getBrokerageRecordByProperty(@PathVariable(value = "propertyId") int propertyId, HttpServletRequest httpServletRequest) {
		return brokerageProposalService.getBrokerageRecordByProperty(propertyId);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{propertyId}/brokerageproposal", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity updateBrokerageProposal(@PathVariable(value = "propertyId") int propertyId, @RequestBody BrokerageProposalDTO brokerageProposalDTO,
			Authentication authentication, HttpServletRequest httpServletRequest) {
		return brokerageProposalService.updateBrokerageProposal(authentication, propertyId, brokerageProposalDTO);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{propertyId}/sellerfee", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity submitAuctionAmounts(@PathVariable(value = "propertyId") int propertyId, @RequestBody BrokerageProposalDTO brokerageProposalDTO,
			Authentication authentication, HttpServletRequest httpServletRequest) {
		return brokerageProposalService.submitAuctionAmounts(authentication, propertyId, brokerageProposalDTO);
	}
	

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/{propertyId}/auctionfee", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity submitAuctionFee(@PathVariable(value = "propertyId") Integer propertyId,
			@RequestBody BrokerageProposalDTO brokerageProposalDTO, HttpServletRequest httpServletRequest) {
		return brokerageProposalService.submitAuctionFeeThroughWallet(propertyId, brokerageProposalDTO);
	}
	
	

}
