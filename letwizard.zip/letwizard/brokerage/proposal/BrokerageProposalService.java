package com.bestercapitalmedia.letwizard.brokerage.proposal;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.transaction.Transactional;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.bestercapitalmedia.fcmpushnotifications.firebase.FCMService;
import com.bestercapitalmedia.fcmpushnotifications.model.PushNotificationRequest;
import com.bestercapitalmedia.letwizard.admin.activitylogs.AdminActivityLogsService;
import com.bestercapitalmedia.letwizard.admin.checklist.CheckListRepository;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationConstants;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationsService;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.PropertyCheckListPivotRepository;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.Propertychecklist;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.constants.EmailTemplatesConstants;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.TransactionConstants;
import com.bestercapitalmedia.letwizard.constants.TransactionMessages;
import com.bestercapitalmedia.letwizard.leads.LeadUtils;
import com.bestercapitalmedia.letwizard.leads.Leads;
import com.bestercapitalmedia.letwizard.leads.LeadsRepository;
import com.bestercapitalmedia.letwizard.mail.MailManager;
import com.bestercapitalmedia.letwizard.openhouse.OpenHouseRepository;
import com.bestercapitalmedia.letwizard.openhouse.OpenHouseSchedule;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.bidfinalize.Product;
import com.bestercapitalmedia.letwizard.property.rental.PropertyPriceAvailability;
import com.bestercapitalmedia.letwizard.property.rental.PropertyPriceAvailabilityRepository;
import com.bestercapitalmedia.letwizard.propertyinvestment.PropertyInvestmentAnalytics;
import com.bestercapitalmedia.letwizard.propertyinvestment.PropertyInvestmentAnalyticsData;
import com.bestercapitalmedia.letwizard.propertyinvestment.PropertyInvestmentAnalyticsRepository;
import com.bestercapitalmedia.letwizard.transaction.TransactionsReceiptsGenerator;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.PusherUtil;
import com.bestercapitalmedia.letwizard.utill.StringValidationUtils;
import com.bestercapitalmedia.letwizard.vouchers.CreateVoucherDTO;
import com.bestercapitalmedia.letwizard.vouchers.Voucher;
import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrency;
import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrencyRepository;
import com.bestercapitalmedia.letwizard.vouchers.VoucherDTO;
import com.bestercapitalmedia.letwizard.vouchers.VoucherDetailsRepository;
import com.bestercapitalmedia.letwizard.vouchers.VoucherRepository;
import com.bestercapitalmedia.letwizard.vouchers.VoucherService;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.google.gson.Gson;

@Service
public class BrokerageProposalService {

	private static final Logger logger = LoggerFactory.getLogger(BrokerageProposalService.class);

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	PropertyRepository propertyRepository;

	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private BrokerageProposalRepository brokerageProposalRepository;

	@Autowired
	private AdminActivityLogsService adminActivityLogsService;

	@Autowired
	PropertyCheckListPivotRepository propertyCheckListRepo;

	@Autowired
	CheckListRepository checkListRepo;

	@Autowired
	private VoucherService voucherService;

	@Autowired
	private VoucherRepository voucherRepository;

	@Autowired
	private VoucherCurrencyRepository voucherCurrencyRepository;

	@Autowired
	private OpenHouseRepository openHouseRepository;

	@Autowired
	private NotificationsService notificationService;

	@Autowired
	private LeadsRepository leadsRepository;

	@Autowired
	private PropertyInvestmentAnalyticsRepository investmentAnalyticsRepository;

	@Autowired
	private TransactionsReceiptsGenerator receiptGenerator;

	@Autowired
	private MailManager mailManager;

	@Autowired
	private VoucherDetailsRepository voucherDetailsRepository;

	@Autowired
	private PropertyPriceAvailabilityRepository propertyPriceAvailabilityRepository;

	@Autowired
	private FCMService fcmService;
	
	public ResponseEntity getBrokerageRecordByProperty(int propertyId) {

		try {

			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();
			BrokerageProposal brokerageProposal = brokerageProposalRepository.findProposalByPropertyId(propertyId);

			if (brokerageProposal == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			BrokerageProposalDTO brokerageProposalDTO = ObjectMapperUtils.map(brokerageProposal,
					BrokerageProposalDTO.class);

			if (brokerageProposal != null && StringValidationUtils.isNotZero(brokerageProposal.getFeeVoucherId())
					&& StringValidationUtils.isNotZero(brokerageProposal.getDepositVoucherId())) {
				Voucher auctionFeeVoucher = voucherRepository
						.getVouchersByVoucherId(brokerageProposal.getFeeVoucherId());
				Voucher auctionDepositVoucher = voucherRepository
						.getVouchersByVoucherId(brokerageProposal.getDepositVoucherId());
				if (auctionFeeVoucher != null && auctionDepositVoucher != null) {
					if (!StringValidationUtils.isNotZero(auctionFeeVoucher.getUnpaid())
							&& !StringValidationUtils.isNotZero(auctionDepositVoucher.getUnpaid())) {
						brokerageProposalDTO.setIsAuctionFeeCompleted(true);
					} else {
						brokerageProposalDTO.setIsAuctionFeeCompleted(false);
					}
				}
			}
			if (brokerageProposalDTO == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						Stream.of(brokerageProposalDTO).collect(Collectors.toList()));
			}
		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}

	public ResponseEntity updateBrokerageProposal(Authentication authentication, int propertyId,
			BrokerageProposalDTO brokerageProposalDTO) {
		try {
			ModelMapper mapper = new ModelMapper();
			User user = (User) authentication.getPrincipal();
			Chiraghuser chiraghuser = userRepository.findByUserName(user.getUsername());
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			// CD-3401 - start
			Boolean isUserConfirm = isBrokerageUserConfirm(propertyId);
			if (isUserConfirm) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND,
						PropertyMessages.CHANGE_REQUEST_NOT_ALLOWED, null);
			}
			// CD-3401 - end
			BrokerageProposal proposal = brokerageProposalRepository.findProposalByPropertyId(propertyId);
			// rental contract draft saving from listing terms agree
			PropertyPriceAvailability propertyPriceAvailability = propertyPriceAvailabilityRepository
					.findByPropertyId(propertyId);
			if (propertyPriceAvailability != null) {
				propertyPriceAvailability.setRentalContractDraft(brokerageProposalDTO.getRentalContractDraft());
				propertyPriceAvailability.setRentalContractDraftLink(brokerageProposalDTO.getRentalContractDraftLink());
				propertyPriceAvailabilityRepository.save(propertyPriceAvailability);
			}

			if (StringValidationUtils.isStringTrue(proposal.getChiraghproperty().getIsBrokerageHodApproved())) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND,
						"Change request can no longer be submitted as lead as already moved to Listing department.",
						null);
			}

			if (proposal == null) {
				proposal = new BrokerageProposal();
			}

			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			if (brokerageProposalDTO.getAuctionStartDate() != null) {
				Date auctionStartDate = sdf.parse(brokerageProposalDTO.getAuctionStartDate());
				if(proposal.getAuctionStartDate() != null) {
					auctionStartDate.setTime(proposal.getAuctionStartDate().getTime());
					proposal.setAuctionStartDate(auctionStartDate);
				}else {
					SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
					auctionStartDate.setTime(System.currentTimeMillis());
					 sdf1.setTimeZone(TimeZone.getTimeZone("UTC"));
					 String formattedDate = sdf1.format(auctionStartDate);
					  Date auctionStartDate1 = sdf1.parse(formattedDate);
					proposal.setAuctionStartDate(auctionStartDate1);
				}		
			}
			// cd 908 update reserve price and open price
			if (null != brokerageProposalDTO.getOpenPrice()) {
				proposal.setOpenPrice(brokerageProposalDTO.getOpenPrice());
			}
			if (null != brokerageProposalDTO.getReservePrice()) {
				proposal.setReservePrice(brokerageProposalDTO.getReservePrice());
			}
			if (null != brokerageProposalDTO.getVatFees()) {
				proposal.setVatFees(brokerageProposalDTO.getVatFees());
			}

			if (null != brokerageProposalDTO.getVoucherCurrency()) {
				VoucherCurrency voucherCurrency = voucherCurrencyRepository
						.findByCode(brokerageProposalDTO.getVoucherCurrency().getCode());
				proposal.setVoucherCurrency(voucherCurrency);
			}
			// end

			// cd 3053 : start
			this.changeRequestCommissionAndFee(brokerageProposalDTO, proposal);
			// cd 3053: end
			proposal.setAuctionDuration(brokerageProposalDTO.getAuctionDuration());

			Leads brokerageLead = leadsRepository.getBrokerageLeadToStart(propertyId);

			proposal.setSellerConfirm(brokerageProposalDTO.getSellerConfirm());
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
			proposal.setChiraghproperty(chiraghproperty);

			if (!brokerageProposalDTO.getSellerConfirm()) {
				List<OpenHouseSchedule> openHouseSchedules = openHouseRepository
						.findProposalByBrokearegProposalId(brokerageProposalDTO.getId());
				if (openHouseSchedules != null && openHouseSchedules.size() > 0) {
					for (OpenHouseSchedule openHouseSchedule : openHouseSchedules) {
						openHouseRepository.deleteById(openHouseSchedule.getId());
					}
				}

				proposal.setBrokerageConfirm(false);
				proposal.setOpenHouse(false);
				proposal.setIsRange(false);

				Propertychecklist propertychecklist3 = propertyCheckListRepo
						.findAlreadyVerified(proposal.getChiraghproperty().getPropertyId(), 91);
				if (propertychecklist3 != null) {
					propertyCheckListRepo.deleteById(propertychecklist3.getId());
				}

				Propertychecklist propertychecklist4 = propertyCheckListRepo
						.findAlreadyVerified(proposal.getChiraghproperty().getPropertyId(), 92);
				if (propertychecklist4 != null) {
					propertyCheckListRepo.deleteById(propertychecklist4.getId());
				}

				Propertychecklist propertychecklist1 = propertyCheckListRepo
						.findAlreadyVerified(proposal.getChiraghproperty().getPropertyId(), 44);
				if (propertychecklist1 != null) {
					propertyCheckListRepo.deleteById(propertychecklist1.getId());
				}

				Propertychecklist propertychecklist2 = propertyCheckListRepo
						.findAlreadyVerified(proposal.getChiraghproperty().getPropertyId(), 45);
				if (propertychecklist2 != null) {
					propertyCheckListRepo.deleteById(propertychecklist2.getId());
				}

				if (brokerageProposalDTO.getAction() != null && brokerageProposalDTO.getAction().equals("change")
						&& (proposal.getChiraghproperty().getIsBrokerageHodApproved() == null
								|| (proposal.getChiraghproperty().getIsBrokerageHodApproved() != null && proposal
										.getChiraghproperty().getIsBrokerageHodApproved().equalsIgnoreCase("false")))) {

					if (proposal.getIsExclusive() == null || !proposal.getIsExclusive()) {
						proposal.setReverseFeeVoucherId(proposal.getFeeVoucherId());
						proposal.setReverseDepositVoucherId(proposal.getDepositVoucherId());
					} else {
						proposal.setReverseFeeVoucherId(proposal.getFeeVoucherId());
					}

//					if (proposal.getIsExclusive()) {
//						
//					} else {
//						
//					}
					proposal.setFeeVoucherId(null);
					proposal.setDepositVoucherId(null);
					proposal.setAction("change");

//					System.out.println("Brokerage Lead 1 :" + brokerageLead.getId());
					
					if (chiraghproperty.getReAuctionOf() == null) {

						proposal.getChiraghproperty().setPropertyLiveDate(null);
						proposal.setIsExclusive(false);

					} else if (chiraghproperty.getReAuctionOf() != null) {
						Chiraghproperty reAuctionedProperty = propertyRepository
								.findByPropertyId(chiraghproperty.getReAuctionOf());
						if (reAuctionedProperty.getBrokerageProposal().getIsExclusive() == null
								|| !reAuctionedProperty.getBrokerageProposal().getIsExclusive()) {
							proposal.getChiraghproperty().setPropertyLiveDate(null);
							proposal.setIsExclusive(false);
						}

					}

//					System.out.println("Brokerage Lead 2 :" + brokerageLead.getId());

				}

				if (brokerageLead != null && brokerageLead.getAssignedTo() != null) {

					System.out.println("Brokerage Lead 3 :" + brokerageLead.getId());
					brokerageLead.setStatus("request for change");
					leadsRepository.save(brokerageLead);
					
					notificationService.createNotificationForBid(
							NotificationConstants.Description.brokerageProposalChange,
							NotificationConstants.Subject.brokerageProposalChange, chiraghproperty.getPropertyId(),
							brokerageLead.getAssignedTo(), chiraghproperty, "seller");
					listingTermsApprovalPushNotification(chiraghproperty, brokerageLead, brokerageLead.getAssignedTo(),
							NotificationConstants.Type.biddingSpecificationsChangedAssignedTo);
				} else {

					brokerageLead = leadsRepository.getBrokerageLeadForHOD(propertyId);
					System.out.println("Brokerage Lead :" + brokerageLead.getId());
					notificationService.createNotificationForBid(
							NotificationConstants.Description.brokerageProposalChange,
							NotificationConstants.Subject.brokerageProposalChange, chiraghproperty.getPropertyId(),
							brokerageLead.getAssignedBy(), chiraghproperty, "seller");
					listingTermsApprovalPushNotification(chiraghproperty, brokerageLead, brokerageLead.getAssignedBy(),
							NotificationConstants.Type.biddingSpecificationsChangedAssignedBy);
				}
				if (brokerageProposalDTO.getBuyNowPrice() != null && brokerageProposalDTO.getBuyNowDeposit() != null) {
					proposal.setBuyNowDeposit(brokerageProposalDTO.getBuyNowDeposit());
					proposal.setBuyNowPrice(brokerageProposalDTO.getBuyNowPrice());
				}

			}

			BrokerageProposal savedProposal = brokerageProposalRepository.save(proposal);
			
			// Ref: CD-1893
			// update property analytics data in case of re-auctioned property

			if (savedProposal != null) {
				if (null != savedProposal.getChiraghproperty().getParentProperty()
						|| null != savedProposal.getChiraghproperty().getReAuctionOf()) {
					// function call
					updateInvestmentAnalytics(savedProposal);
				}
			}

			// CD-1893 - end

			BrokerageProposalDTO result = mapper.map(savedProposal, BrokerageProposalDTO.class);

			Map<String, String> map = new HashMap<>();
			map.put("propertyId", chiraghproperty.getPropertyId().toString());
			map.put("userId", chiraghuser.getUserId().toString());
			PusherUtil.getDefault().push("brokerage-proposal", "created", map);

			adminActivityLogsService.logAction(" created brokerage proposal", chiraghuser, propertyId);

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(result).collect(Collectors.toList()));

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	private void listingTermsApprovalPushNotification(Chiraghproperty chiraghProperty, 
			Leads brokerageLead, Integer userId, String type) {
		
		logger.info("BrokerageProposalService : listingTermsApprovalPushNotification");
		
		if(chiraghProperty != null) {
			Chiraghuser chiraghUser = userRepository.findByUserId(userId);
			if(chiraghUser != null) {
				if(chiraghUser.getFirebaseToken() != null 
						&& !chiraghUser.getFirebaseToken().isEmpty()) {

					try {
						// Build notification payload
						Notification notification = new Notification(NotificationConstants.Title.brokerageProposalChange, 
								NotificationConstants.PNDescription.brokerageProposalChange);
						
						// Build data payload
						Map<String, String> data = new HashMap<>();
						data.put("title", NotificationConstants.Title.brokerageProposalChange);
						data.put("message", NotificationConstants.PNDescription.brokerageProposalChange);
						data.put("notification_type", type);
						
						data.put("property_id", chiraghProperty.getPropertyId() + "");
						data.put("user_id", chiraghUser.getUserId() + "");
						data.put("property_title", chiraghProperty.getPropertyTitle());
						data.put("property_type", chiraghProperty.getPropertyType());
						data.put("seller_user_name", chiraghProperty.getSellerUserName());
						data.put("status", chiraghProperty.getStatus());
						
						data.put("lead_assigned_to", brokerageLead.getAssignedTo()+"");
						data.put("lead_assigned_by", brokerageLead.getAssignedBy()+"");
						data.put("lead_process", brokerageLead.getProcess());
						data.put("lead_status", brokerageLead.getStatus());
						data.put("lead_department_id", brokerageLead.getDepartementId()+"");
						
						// Build the message
						Message message = Message.builder().setToken(chiraghUser.getFirebaseToken()) // FCM Token
								.setNotification(notification) // Notification object for foreground/background
								.putAllData(data) // Data payload for additional info
								.build();
						
						logger.info("Data in message to be sent : " + data);

						// Send the message using FirebaseMessaging
						String response = FirebaseMessaging.getInstance().send(message);
						
						logger.info("Successfully sent message : " + response);
						
					} catch (Exception e) {
						logger.error("Exception in BrokerageProposalService : listingTermsApprovalPushNotification : " + e.getMessage(), e);
					}
				}
			}
		}
	}

	private Boolean isBrokerageUserConfirm(int propertyId) {

		try {
			Leads leadForBrokeargeHod = leadsRepository.findByPropertyIdAndDeptId(propertyId,
					LeadUtils.Department.BROKERAGE);
			if (leadForBrokeargeHod == null) {
				return false;
			} else {
				return true;
			}

		} catch (Exception e) {
			logger.error("error occured while checking isBrokerageUserConfirm ", e);
			return null;
		}

	}

	public void changeRequestCommissionAndFee(BrokerageProposalDTO brokerageProposalDTO, BrokerageProposal proposal) {
		if (null != brokerageProposalDTO.getSalesCommission()) {
			proposal.setSalesCommission(brokerageProposalDTO.getSalesCommission());
		}
		if (null != brokerageProposalDTO.getPerformanceFee()) {
			proposal.setPerformanceFee(brokerageProposalDTO.getPerformanceFee());
		}
		if (null != brokerageProposalDTO.getOtherFee()) {
			proposal.setOtherFee(brokerageProposalDTO.getOtherFee());
		}
	}

	private void updateInvestmentAnalytics(BrokerageProposal savedProposal) {
		try {
			PropertyInvestmentAnalytics investmentAnalytics = savedProposal.getChiraghproperty()
					.getInvestmentAnalytics();
			String investmentAnalyticsData = investmentAnalytics.getInvestmentAnalyticsData();

			Gson gson = new Gson();
			PropertyInvestmentAnalyticsData analyticsData = gson
					.fromJson(chiragUtill.jsonToObject(investmentAnalyticsData), PropertyInvestmentAnalyticsData.class);
			if (null != savedProposal.getOpenPrice()) {

				analyticsData.getRental().setOpenPrice(savedProposal.getOpenPrice().toString());
				analyticsData.getTraditional().setOpenPrice(savedProposal.getOpenPrice().toString());
				String analyticsJson = gson.toJson(analyticsData);
				investmentAnalytics.setInvestmentAnalyticsData(analyticsJson);
				investmentAnalyticsRepository.save(investmentAnalytics);

			}

		} catch (Exception e) {
			logger.error("Exception occured while updating investment analytics open price");
		}
	}

	@Transactional
	public ResponseEntity submitAuctionAmounts(Authentication authentication, int propertyId,
			BrokerageProposalDTO brokerageProposalDTO) {
		try {

			Chiraghuser chiraghuser = chiragUtill
					.getUserNameFromAuthenticationWithOTP(brokerageProposalDTO.getOtpCode());
			Leads brokerageLead = leadsRepository.getBrokerageLeadToStart(propertyId);
			System.out.println("opt checking= " + chiraghuser);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.INVALID_OTP, null);
			}
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
			BrokerageProposal proposal = refundAuctionFeeVoucher(propertyId, chiraghuser);

			if (proposal.getReverseDepositVoucherId() != null) {
				voucherService.refundGenericVoucher(chiraghuser, proposal.getReverseDepositVoucherId(),
						"Auction deposit reversal");
				proposal.setReverseDepositVoucherId(null);
			}

			if (null != brokerageProposalDTO.getVoucherCurrency()) {
				VoucherCurrency voucherCurrency = voucherCurrencyRepository
						.findByCode(brokerageProposalDTO.getVoucherCurrency().getCode());
				proposal.setVoucherCurrency(voucherCurrency);
			}

			brokerageProposalRepository.save(proposal);
			VoucherCurrency selectedCurrency = voucherCurrencyRepository
					.getVoucherCurrency(brokerageProposalDTO.getExchangeCurrencyId());

			BigDecimal availableBalance = voucherRepository.getBalanceByCurrency(chiraghuser.getUserId(), "ab",
					brokerageProposalDTO.getExchangeCurrencyId());// available
			// balance
			int balanceCheck = availableBalance.compareTo(brokerageProposalDTO.getAuctionFeeAmount());
			if (balanceCheck == -1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE,
						"Insufficient balance for this transaction in your " + selectedCurrency.getCode()
								+ " wallet. Top Up your " + selectedCurrency.getCode()
								+ " account to complete the transaction or choose other currency wallet",
						null);
			}
			int chiraghAccount = 0;
			CreateVoucherDTO auctionFeeVoucher = new CreateVoucherDTO();

			auctionFeeVoucher.setPropertyId(propertyId);
			auctionFeeVoucher.setIsCredit(false);
			auctionFeeVoucher.setAmount(brokerageProposalDTO.getAuctionFeeAmount());
			if (chiraghproperty.getRentalProperty() == null) {
				auctionFeeVoucher.setDescription(TransactionConstants.RevenueStreamDescription.auctionFee);
				auctionFeeVoucher.setRevenueStreamId(TransactionConstants.RevenueStream.auctionFee);
			} else {
				auctionFeeVoucher.setDescription(TransactionConstants.RevenueStreamDescription.rentalAuctionFee);
				auctionFeeVoucher.setRevenueStreamId(TransactionConstants.RevenueStream.rentalAuctionFee);
			}
			availableBalance = voucherRepository.getBalanceByCurrency(chiraghuser.getUserId(), "ab",
					brokerageProposalDTO.getExchangeCurrencyId()); // available balance
			int auctionFeeAmountCheck = availableBalance.compareTo(brokerageProposalDTO.getAuctionFeeAmount());

			// if (availableBalance >= brokerageProposalDTO.getAuctionFeeAmount()) {
			if (auctionFeeAmountCheck >= 0) {
				auctionFeeVoucher.setTransactionStatus(2);
				chiraghAccount = TransactionMessages.Accounts.INCOME;
			} else {
				auctionFeeVoucher.setTransactionStatus(1);
				auctionFeeVoucher.setUnpaid(1);
				chiraghAccount = TransactionMessages.Accounts.RECEIVABLE;
			}
			auctionFeeVoucher.setExchangeCurrencyId(brokerageProposalDTO.getExchangeCurrencyId());
			auctionFeeVoucher.setAttachment(brokerageProposalDTO.getAttachment());
			auctionFeeVoucher.setPaymentMode(brokerageProposalDTO.getPaymentMode());
			auctionFeeVoucher.setFromAccountId(TransactionMessages.Accounts.CASH_IN_BANK);
			auctionFeeVoucher.setFromReference(TransactionMessages.Reference.USER);
			auctionFeeVoucher.setToAccountId(chiraghAccount);
			auctionFeeVoucher.setToReference(TransactionMessages.Reference.CHIRAGH);
			VoucherDTO auctionFeeVoucherDTO = voucherService.createGenericVoucher(auctionFeeVoucher, chiraghuser);

			availableBalance = voucherRepository.getBalanceByCurrency(chiraghuser.getUserId(), "ab",
					brokerageProposalDTO.getExchangeCurrencyId());// available
			// balance
			// if (availableBalance < brokerageProposalDTO.getAuctionDepositAmount()) {
			if (brokerageProposalDTO.getIsExclusive() == null || !brokerageProposalDTO.getIsExclusive()) {
			if (availableBalance.compareTo(brokerageProposalDTO.getAuctionDepositAmount()) == -1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.AMOUNT_INSUFFICIENT, null);
				}
			}
			CreateVoucherDTO auctionDepositVoucher = new CreateVoucherDTO();
			auctionDepositVoucher.setPropertyId(propertyId);
			auctionDepositVoucher.setIsCredit(false);
			auctionDepositVoucher.setAmount(brokerageProposalDTO.getAuctionDepositAmount());
			if (proposal.getChiraghproperty().getRentalProperty() != null) {
				auctionDepositVoucher.setDescription(TransactionConstants.RevenueStreamDescription.landlordSecurity);
			} else {
				auctionDepositVoucher.setDescription(TransactionConstants.RevenueStreamDescription.sellerSecurity);
			}
			availableBalance = voucherRepository.getBalanceByCurrency(chiraghuser.getUserId(), "ab",
					brokerageProposalDTO.getExchangeCurrencyId()); // available balance
			if (brokerageProposalDTO.getIsExclusive() != null && brokerageProposalDTO.getIsExclusive()) {
				auctionDepositVoucher.setIsExclusive(true);
				auctionDepositVoucher.setTransactionStatus(2);
				chiraghAccount = TransactionMessages.Accounts.RECEIVABLE;
				// } else if (availableBalance >=
				// brokerageProposalDTO.getAuctionDepositAmount()) {
			} else if (availableBalance.compareTo(brokerageProposalDTO.getAuctionDepositAmount()) >= 0) {
				auctionDepositVoucher.setIsExclusive(false);
				auctionDepositVoucher.setTransactionStatus(2);
				chiraghAccount = TransactionMessages.Accounts.PAYABLE;
			} else {
////				auctionDepositVoucher.setTransactionStatus(1);
////				auctionDepositVoucher.setUnpaid(1);
////				chiraghAccount = TransactionMessages.Accounts.RECEIVABLE;
				return responseUtill.getApiResponse(ResponseCodes.FAILURE,
						"Insufficient balance for this transaction in your " + selectedCurrency.getCode()
								+ " wallet. Top Up your " + selectedCurrency.getCode()
								+ " account to complete the transaction or choose other currency wallet",
						null);
			}

			auctionDepositVoucher.setExchangeCurrencyId(brokerageProposalDTO.getExchangeCurrencyId());
			auctionDepositVoucher.setAttachment(brokerageProposalDTO.getAttachment());
			if (proposal.getChiraghproperty().getRentalProperty() != null) {
				auctionDepositVoucher.setRevenueStreamId(TransactionConstants.RevenueStream.landlordSecurity);
			} else {
				auctionDepositVoucher.setRevenueStreamId(TransactionConstants.RevenueStream.sellerSecurity);
			}
			auctionDepositVoucher.setPaymentMode(brokerageProposalDTO.getPaymentMode());
			if (brokerageProposalDTO.getIsExclusive() != null && brokerageProposalDTO.getIsExclusive()) {
				auctionDepositVoucher.setFromAccountId(TransactionMessages.Accounts.EXCLUSIVE_RIGHTS);
				auctionDepositVoucher.setFromReference(TransactionMessages.Reference.CHIRAGH);
			} else {
				auctionDepositVoucher.setFromAccountId(TransactionMessages.Accounts.CASH_IN_BANK);
				auctionDepositVoucher.setFromReference(TransactionMessages.Reference.USER);
			}
			auctionDepositVoucher.setToAccountId(chiraghAccount);
			auctionDepositVoucher.setToReference(TransactionMessages.Reference.CHIRAGH);
			VoucherDTO auctionDepositVoucherDTO = voucherService.createGenericVoucherForChiragh(auctionDepositVoucher,
					chiraghuser);

//			Auto checklist 'Auction specifications finalized' checked

			if (chiraghproperty.getRentalProperty() != null) {
				Propertychecklist propertyChecklistForAuctionFinalized = propertyCheckListRepo
						.findAlreadyVerified(propertyId, 91);
				if (propertyChecklistForAuctionFinalized == null) {
					propertyChecklistForAuctionFinalized = new Propertychecklist();
					Checklist checklist = checkListRepo.findCheckListById(91);
					propertyChecklistForAuctionFinalized.setChiraghproperty(proposal.getChiraghproperty());
					propertyChecklistForAuctionFinalized.setChiraghuser(chiraghuser);
					propertyChecklistForAuctionFinalized.setChecklist(checklist);
					propertyChecklistForAuctionFinalized.setDate(DateUtils.getDefault().getNowCalender());
					propertyCheckListRepo.save(propertyChecklistForAuctionFinalized);
				}

				Propertychecklist propertyChecklistForLandlordConfirmation = propertyCheckListRepo
						.findAlreadyVerified(propertyId, 92);
				if (propertyChecklistForLandlordConfirmation == null) {
					propertyChecklistForLandlordConfirmation = new Propertychecklist();
					Checklist checklist = checkListRepo.findCheckListById(92);
					propertyChecklistForLandlordConfirmation.setChiraghproperty(proposal.getChiraghproperty());
					propertyChecklistForLandlordConfirmation.setChiraghuser(chiraghuser);
					propertyChecklistForLandlordConfirmation.setChecklist(checklist);
					propertyChecklistForLandlordConfirmation.setDate(DateUtils.getDefault().getNowCalender());
					propertyCheckListRepo.save(propertyChecklistForLandlordConfirmation);
				}
			} else {
				Propertychecklist propertychecklist = propertyCheckListRepo.findAlreadyVerified(propertyId, 45);
				if (propertychecklist == null) {
					propertychecklist = new Propertychecklist();
					Checklist checklist = checkListRepo.findCheckListById(45);
					propertychecklist.setChiraghproperty(proposal.getChiraghproperty());
					propertychecklist.setChiraghuser(chiraghuser);
					propertychecklist.setChecklist(checklist);
					propertychecklist.setDate(DateUtils.getDefault().getNowCalender());
					propertyCheckListRepo.save(propertychecklist);
				}
			}

			notificationService.createNotificationForBid(NotificationConstants.Description.brokerageProposalAgreed,
					NotificationConstants.Subject.brokerageProposalAgreed,
					proposal.getChiraghproperty().getPropertyId(), brokerageLead.getAssignedTo(),
					proposal.getChiraghproperty(), "seller");

			List<VoucherDTO> result = new ArrayList();
			result.add(auctionFeeVoucherDTO);
			result.add(auctionDepositVoucherDTO);

			BrokerageProposal brokerageProposal = brokerageProposalRepository.findProposalByPropertyId(propertyId);
			brokerageProposal.setFeeVoucherId(auctionFeeVoucherDTO.getId());
			brokerageProposal.setDepositVoucherId(auctionDepositVoucherDTO.getId());
			if (brokerageProposalDTO.getIsExclusive() != null && brokerageProposalDTO.getIsExclusive()) {
				if (brokerageProposal.getIsExclusive() == null || !brokerageProposal.getIsExclusive()) {
					brokerageProposal.getChiraghproperty().setPropertyLiveDate(brokerageProposal.getAuctionStartDate());
				}
				brokerageProposal.setIsExclusive(brokerageProposalDTO.getIsExclusive());

			}
			brokerageProposal = brokerageProposalRepository.save(brokerageProposal);
			BrokerageProposalDTO proposalDTO = ObjectMapperUtils.map(brokerageProposal, BrokerageProposalDTO.class);
			String listingUrl = null;
			if (brokerageProposal.getChiraghproperty().getRentalProperty() == null) {
				listingUrl = receiptGenerator.generateSellerListingTerms(brokerageProposal, propertyId);
			}

			try {
				voucherDetailsRepository.updateListingAttachment(listingUrl, auctionDepositVoucherDTO.getId());
			} catch (Exception e) {
				throw e;
			}

			String listStartDate = "N/A";
			String availability = "N/A";
			PropertyPriceAvailability pp = propertyPriceAvailabilityRepository
					.findByPropertyId(brokerageProposal.getChiraghproperty().getPropertyId());
			Optional<Object> optionalObject = Optional.ofNullable(pp);
			if (!optionalObject.isPresent()) {
				try {
					listStartDate = "N/A";
					availability = "N/A";
				} catch (NullPointerException e) {
					throw e;
				}
			} else {
				if (pp != null) {
					if (brokerageProposal.getChiraghproperty().getRentalProperty() != null) {
						listingUrl = receiptGenerator.generateRentalListingTerms(brokerageProposal, propertyId);
					}
					availability = pp.getAvailabilityType();	
				}
			}

			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			listStartDate = (brokerageProposal.getAuctionStartDate() != null) ? dateFormat.format(brokerageProposal.getAuctionStartDate())
					: "N/A";
			
			DecimalFormat chosenFormat = new DecimalFormat("#,##,###.00");
			String listingPrice = (brokerageProposal.getOpenPriceMax() != null)
					? chosenFormat.format(Double.parseDouble(brokerageProposal.getOpenPriceMax()))
					: "N/A";
			String reservePrice = (brokerageProposal.getExpectedPriceMinFin() != null)
					? chosenFormat.format(brokerageProposal.getExpectedPriceMinFin())
					: "N/A";
			String pgAmount = "5";

			int auctionDuration = brokerageProposal.getAuctionDuration();
			String buyNowPrice = (brokerageProposal.getBuyNowPrice() != null)
					? chosenFormat.format(brokerageProposal.getBuyNowPrice())
					: "0";
			String buyNowDeposit = (brokerageProposal.getBuyNowDeposit() != null)
					? chosenFormat.format(brokerageProposal.getBuyNowDeposit())
					: "0";
			String commissionFee = (brokerageProposal.getSalesCommission() != null)
					? (brokerageProposal.getSalesCommission())
					: "N/A";
			String performanceFee = (brokerageProposal.getVatFees() != null)
					? String.valueOf(brokerageProposal.getVatFees())
					: "N/A";

			String tax = (brokerageProposal.getVatFees() != null) ? String.valueOf(brokerageProposal.getVatFees())
					: "N/A";
			System.out.println("rentnowprice" + brokerageProposal.getRentNowPriceFin());
			String rentNowPrice = (brokerageProposal.getRentNowPriceFin() != null)
					? chosenFormat.format(brokerageProposal.getRentNowPriceFin())
					: "N/A";
			String maximumPrice = (brokerageProposal.getExpectedPriceMaxFin() != null)
					? chosenFormat.format(brokerageProposal.getExpectedPriceMaxFin())
					: "N/A";
			String otherfees = chosenFormat.format(brokerageProposal.getOtherFee());
			String link = "<a href=" + listingUrl + ">" + listingUrl + "</a>";
			String totalFees = chosenFormat.format(brokerageProposal.getOtherFee());
			String body = null;
			String Subject = null;
			String ownerFirstName = chiraghuser.getFirstName().substring(0, 1).toUpperCase() + chiraghuser.getFirstName().substring(1);
			String currencyCode = chiraghproperty.getBrokerageProposal().getVoucherCurrency().getCode();
			if (brokerageProposal.getChiraghproperty().getRentalProperty() == null) {
				body = "Here are the property sales listing details you provided during the property Sale.</br></br>"
						+ "<b> Property Details: </b> </br></br>" + "<b> Property ID :</b>" + propertyId + "</br>"
						+ "<b> Property Name :</b>" + brokerageProposal.getChiraghproperty().getPropertyTitle()
						+ "</br>" + "<b> Listing Price :</b> " + currencyCode + " " + listingPrice + "</br>"
						+ "<b> Reserve Price :</b> " + currencyCode + " " + reservePrice + "</br>"
						+ "<b> Participation Guarantee :</b> " + pgAmount + "%</br>" + "<b> Listing Start Date :</b> "
						+ listStartDate + "</br>" + "<b> Listing Duration :</b>" + auctionDuration + " days</br>"
						+ "<b> Commission Fee :</b>" + commissionFee + "%</br>" + "<b> Performance Fee :</b>"
						+ performanceFee + "%</br>" + "<b> BuyNow Price :</b>" + currencyCode + " " + buyNowPrice
						+ "</br>" + "<b> Buy Now Deposit :</b>" + buyNowDeposit + "%</br>" + "<b> VAT Tax :</b> " + tax
						+ "%</br>" + "<b> Applicable Fees & Charges :</b> " + currencyCode + " " + totalFees
						+ "</br></br></br>"
						+ " For more details, you can view the complete listing and download the PDF here : " + link
						+ "</br></br>";
				Subject = "Regarding Your Recent Sale Listing with Property ID- " + propertyId;
			}

			if (brokerageProposal.getChiraghproperty().getRentalProperty() != null) {
				body = "Here are the details of the property rental listing you provided during the property Rent</br></br>"
						+ "<b> Property Details: </b> </br></br>" + "<b> Property ID :</b>" + propertyId + "</br>"
						+ "<b> Property Name :</b>" + brokerageProposal.getChiraghproperty().getPropertyTitle()
						+ "</br>" + "<b> Availability :</b>  " + availability + "</br>" + "<b> Reserve Price :</b>  "
						+ currencyCode + " " + reservePrice + "</br>" + "<b> Maximum Price :</b> " + currencyCode + " "
						+ maximumPrice + "</br>" + "<b> Rent Now Price :</b>  " + currencyCode + " " + rentNowPrice
						+ "</br>" + "<b> Participation Guarantee :</b>  " + pgAmount + "%</br>"
						+ "<b> Listing Start Date :</b>  " + listStartDate + "</br>" + "<b> Listing Duration :</b> "
						+ auctionDuration + " days</br>" + "<b> Commission Fee :</b> " + commissionFee + "%</br>"
						+ "<b> Performance Fee :</b> " + performanceFee + "%</br>" + "<b> VAT Tax :</b>  " + tax
						+ "%</br>" + "<b> Applicable Fees & Charges :</b>  " + currencyCode + " " + totalFees
						+ "</br></br></br>"
						+ "For more details, you can view the complete listing and download the PDF here : " + link
						+ "</br></br>";
				Subject = "Regarding Your Recent Rental Listing with Property ID- " + propertyId;

			}

			mailManager.sendPlainHTMLEmailForEWallet(chiraghuser.getUserEmail(), Subject, body,
					EmailTemplatesConstants.LISTING_TERM_TEMP, ownerFirstName);

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(proposalDTO).collect(Collectors.toList()));

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	@Transactional
	public ResponseEntity submitAuctionFeeThroughWallet(Integer propertyId, BrokerageProposalDTO brokerageProposalDTO) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghUser = userRepository.findByUserName(userName);

			if (chiraghUser == null) {
				return responseUtill.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
			BrokerageProposal proposal = refundAuctionFeeVoucher(propertyId, chiraghUser);
			brokerageProposalRepository.save(proposal);

			VoucherCurrency selectedCurrency = voucherCurrencyRepository
					.getVoucherCurrency(brokerageProposalDTO.getExchangeCurrencyId());

			BigDecimal availableBalance = voucherRepository.getBalanceByCurrency(chiraghUser.getUserId(), "ab",
					brokerageProposalDTO.getExchangeCurrencyId());// available
			// balance
			int balanceCheck = availableBalance.compareTo(brokerageProposalDTO.getAuctionFeeAmount());
			if (balanceCheck == -1) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE,
						"Insufficient balance for this transaction in your " + selectedCurrency.getCode()
								+ " wallet. Top Up your " + selectedCurrency.getCode()
								+ " account to complete the transaction or choose other currency wallet",
						null);
			}
			int chiraghAccount = 0;
			CreateVoucherDTO auctionFeeVoucher = new CreateVoucherDTO();

			auctionFeeVoucher.setPropertyId(propertyId);
			auctionFeeVoucher.setIsCredit(false);
			auctionFeeVoucher.setAmount(brokerageProposalDTO.getAuctionFeeAmount());
			if (chiraghproperty.getRentalProperty() == null) {
				auctionFeeVoucher.setDescription(TransactionConstants.RevenueStreamDescription.auctionFee);
				auctionFeeVoucher.setRevenueStreamId(TransactionConstants.RevenueStream.auctionFee);
			} else {
				auctionFeeVoucher.setDescription(TransactionConstants.RevenueStreamDescription.rentalAuctionFee);
				auctionFeeVoucher.setRevenueStreamId(TransactionConstants.RevenueStream.rentalAuctionFee);
			}
			availableBalance = voucherRepository.getBalanceByCurrency(chiraghUser.getUserId(), "ab",
					brokerageProposalDTO.getExchangeCurrencyId()); // available balance
			int auctionFeeAmountCheck = availableBalance.compareTo(brokerageProposalDTO.getAuctionFeeAmount());

			if (auctionFeeAmountCheck >= 0) {
				auctionFeeVoucher.setTransactionStatus(2);
				chiraghAccount = TransactionMessages.Accounts.INCOME;
			} else {
				auctionFeeVoucher.setTransactionStatus(1);
				auctionFeeVoucher.setUnpaid(1);
				chiraghAccount = TransactionMessages.Accounts.RECEIVABLE;
			}
			auctionFeeVoucher.setExchangeCurrencyId(brokerageProposalDTO.getExchangeCurrencyId());
			auctionFeeVoucher.setAttachment(brokerageProposalDTO.getAttachment());
			auctionFeeVoucher.setPaymentMode(brokerageProposalDTO.getPaymentMode());
			auctionFeeVoucher.setFromAccountId(TransactionMessages.Accounts.CASH_IN_BANK);
			auctionFeeVoucher.setFromReference(TransactionMessages.Reference.USER);
			auctionFeeVoucher.setToAccountId(chiraghAccount);
			auctionFeeVoucher.setToReference(TransactionMessages.Reference.CHIRAGH);
			VoucherDTO auctionFeeVoucherDTO = voucherService.createGenericVoucher(auctionFeeVoucher, chiraghUser);

			BrokerageProposal brokerageProposal = brokerageProposalRepository.findProposalByPropertyId(propertyId);
			brokerageProposal.setFeeVoucherId(auctionFeeVoucherDTO.getId());

			brokerageProposal = brokerageProposalRepository.save(brokerageProposal);
			BrokerageProposalDTO proposalDTO = ObjectMapperUtils.map(brokerageProposal, BrokerageProposalDTO.class);

			return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(proposalDTO).collect(Collectors.toList()));

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public BrokerageProposal refundAuctionFeeVoucher(Integer propertyId, Chiraghuser chiraghUser) {
		BrokerageProposal proposal = brokerageProposalRepository.findProposalByPropertyId(propertyId);

		if (proposal.getReverseFeeVoucherId() != null) {
			voucherService.refundAuctionFeeVoucher(chiraghUser, proposal.getReverseFeeVoucherId(),
					"Auction fee reversal");
			proposal.setReverseFeeVoucherId(null);
		}
		return proposal;
	}

	public void updateAuctionEndsAtTimeWithThreeMinues(Chiraghproperty chiraghProperty) {
		System.out.println("BrokerageProposal going to updateAuctionEndsAtTimeWithThreeMinues");
		BrokerageProposal brokerageProposal = brokerageProposalRepository
				.findProposalByPropertyId(chiraghProperty.getPropertyId());
		Date auctionEndsAtExtended = DateUtils.extendClosureTimeByThreeMinutes(brokerageProposal.getAuctionEndsAt());
		int auctionTimeExtendCount = brokerageProposal.getAuctionEndTimeExtendCount();
		System.out.println("auctionEndsAtExtended is : " + auctionEndsAtExtended);
		System.out.println("auctionTimeExtendCount is : " + auctionTimeExtendCount);
		brokerageProposal.setAuctionEndsAt(auctionEndsAtExtended);
		brokerageProposal.setAuctionEndTimeExtendCount(auctionTimeExtendCount + 1);
		brokerageProposalRepository.save(brokerageProposal);

		Product product = new Product();
		product.setProductId(chiraghProperty.getPropertyId());
		product.setAuctionEndDate(brokerageProposal.getAuctionEndsAt());
		ResponseEntity<Product> response = extendBidClosureTimeByThreeMinutesInBiddingEngine(product);
		logger.info("Response : {}", response);
	}

	public ResponseEntity<Product> extendBidClosureTimeByThreeMinutesInBiddingEngine(Product product) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("user-agent",
				"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
//		headers.set("Authorization", "Bearer " + accessToken);
		logger.info("URL: " + LetwizardConstants.BIDDING_ENGINE_SERVER_PATH + "/api/product/extendBidClosureTime");
		HttpEntity entity = new HttpEntity(product, headers);
		ResponseEntity<Product> response = restTemplate.postForEntity(
				LetwizardConstants.BIDDING_ENGINE_SERVER_PATH + "/api/product/extendBidClosureTime", entity,
				Product.class);
		logger.info("Response : {}", response);
		return response;
	}
}