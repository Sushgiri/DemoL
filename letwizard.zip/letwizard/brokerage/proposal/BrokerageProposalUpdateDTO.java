package com.bestercapitalmedia.letwizard.brokerage.proposal;

public class BrokerageProposalUpdateDTO {
	private Integer hodConfirm;
	private Integer mdConfirm;
	
	public BrokerageProposalUpdateDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getHodConfirm() {
		return hodConfirm;
	}
	public void setHodConfirm(Integer hodConfirm) {
		this.hodConfirm = hodConfirm;
	}
	public Integer getMdConfirm() {
		return mdConfirm;
	}
	public void setMdConfirm(Integer mdConfirm) {
		this.mdConfirm = mdConfirm;
	}

}
