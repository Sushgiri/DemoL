package com.bestercapitalmedia.letwizard.events;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.buyer.dashboard.BuyerDashBoard;
import com.bestercapitalmedia.letwizard.buyer.dashboard.BuyerDashBoardRepository;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.constants.UserMessages;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;



@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/events")
public class EventsController {

	@Autowired
	private EventsService eventsService;
	
	@Autowired
	private UserRepository chiraghuserRepository;
	
	@Autowired
	private ResponseUtill responseUtill;
	
	@Autowired
	private BuyerDashBoardRepository buyerDashBoardRepository;
	
	@Autowired
	private Environment env;
	/*
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity saveEvent(@RequestBody EventRequestDTO request, HttpServletRequest httpServletRequest) {
		
		if (env.getProperty("recommendation.engine.enable").equals("true")) {
			return eventsService.createEvent(request);
		} else {
			return null;
		}
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/createPropertyEvent", method = RequestMethod.POST)
	public @ResponseBody Map<String, String> testEvent(@RequestBody EventRequestDTO request, HttpServletRequest httpServletRequest) {
		
		if (env.getProperty("recommendation.engine.enable").equals("true")) {
			return eventsService.testEvent(request);

		} else {
			return null;
		}
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/createUser/{username}", method = RequestMethod.GET)
	public Map<String, String> createUser(@PathVariable(value = "username") String username, HttpServletRequest httpServletRequest) {
		
		if (env.getProperty("recommendation.engine.enable").equals("true")) {
			Chiraghuser user = chiraghuserRepository.findByUserName(username);
			return eventsService.createUser(user);
		} else {
			return null;
		}
		
	}
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/indexing/{event}", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity indexing(@PathVariable(value = "event") String event, HttpServletRequest httpServletRequest) {
		
		if (env.getProperty("recommendation.engine.enable").equals("true")) {
			
			if (event.equals("user")) {
				List<Integer> userList = chiraghuserRepository.getActivatedChiraghuser();
				for (int i = 0; i < userList.size(); i++) {
					
					eventsService.createUser(chiraghuserRepository.findByUserId(userList.get(i)));
				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, UserMessages.USER_INDEXED, null);
			}
			if(event.equals("view")) {
				
				List<BuyerDashBoard> livePropertiesHistory = buyerDashBoardRepository.getLivePropertiesHistory();
				for (int i = 0; i < livePropertiesHistory.size(); i++) {

					eventsService.propertyViewed(livePropertiesHistory.get(i).getChiraghproperty(), livePropertiesHistory.get(i).getChiraghuser());
				}
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.VIEWED_PROPERTY_AND_USER_INDEXED, null);

			}
			return null;	
		} else {
			return null;
		}
		
	}*/
	
}
