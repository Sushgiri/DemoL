package com.bestercapitalmedia.letwizard.events;

import java.util.List;

public class PredictionIORequestDTO {

	List<String> items;
	List<String> categories;
	private int num;
	public List<String> getItems() {
		return items;
	}
	public void setItems(List<String> items) {
		this.items = items;
	}
	public List<String> getCategories() {
		return categories;
	}
	public void setCategories(List<String> categories) {
		this.categories = categories;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public PredictionIORequestDTO() {
		super();
	}
	

	@Override
	public String toString(){
		StringBuilder item = new StringBuilder();
		StringBuilder category = new StringBuilder();
		int i = 0;
		int c = 0;
		while (i < getItems().size() - 1 ) {
			item.append("\""+ getItems().get(i) +"\",");
			i++;
		}
		while(c < getCategories().size() - 1 ) {
			category.append("\""+ getCategories().get(c) +"\",");			
			c++;
		}
		item.append("\""+ getItems().get(i) + "\"");
		category.append("\""+ getCategories().get(c) + "\"");
		String items = item.toString();
		String categories = category.toString();

		
	   return  "{" + 
				"\"items\": ["+ items + "]," + 
				"\"num\": "+getNum() +"," + 
				"\"categories\" : ["+categories+"]" + 
				"}";

	}
	
}
