package com.bestercapitalmedia.letwizard.events;

public class EventRequestDTO  {
	
	private String event;
	private String targetEntityType;
	private String targetEntityId;
	public EventRequestDTO() {

	}

	
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getTargetEntityType() {
		return targetEntityType;
	}
	public void setTargetEntityType(String targetEntityType) {
		this.targetEntityType = targetEntityType;
	}
	public String getTargetEntityId() {
		return targetEntityId;
	}
	public void setTargetEntityId(String targetEntityId) {
		this.targetEntityId = targetEntityId;
	}
	
	
	
}
