package com.bestercapitalmedia.letwizard.events;

import java.util.List;

public class EventPropertiesDTO {

	List<String> categories;

	public List<String> getCategories() {
		return categories;
	}

	public void setCategories(List<String> categories) {
		this.categories = categories;
	}

	public EventPropertiesDTO() {
		
	}
	
}
