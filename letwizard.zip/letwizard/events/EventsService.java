package com.bestercapitalmedia.letwizard.events;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.simpleworkflow.flow.annotations.Asynchronous;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.appointments.AppointmentsDTO;
import com.bestercapitalmedia.letwizard.constants.LetwizardConstants;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.property.LetwizardPropertyService;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.recommendationevents.RecommendationEvent;
import com.bestercapitalmedia.letwizard.recommendationevents.RecommendationEventRepository;
import com.bestercapitalmedia.letwizard.recommendations.Recommendations;
import com.bestercapitalmedia.letwizard.recommendations.RecommendationsRepository;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.StringValidationUtils;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Service
public class EventsService {

	private static final Logger logger = LoggerFactory.getLogger(LetwizardPropertyService.class);
	@Autowired
	private ResponseUtill responseUtill;

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PropertyRepository propertyRepository;
	
	@Autowired 
	private RecommendationEventRepository recommendationEventRepository;
	
	@Autowired
	private RecommendationsRepository recommendationsRepository;

	/*public ResponseEntity createEvent(EventRequestDTO request) {

		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();

			LogEventDTO requestObject = mapper.map(request, LogEventDTO.class);
			requestObject.setEntityId(Integer.toString(chiraghuser.getUserId()));
			requestObject.setEntityType("user");
			requestObject.setEventTime(getDate());
			Map<String, String> response = logEvent(requestObject);
			if (response == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS,
						Stream.of(response).collect(Collectors.toList()));
			}

		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}



	public Map<String, String> testEvent(EventRequestDTO request) {
		Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(622);
		return propertyPushToPrediction(chiraghproperty);
	}

	public Map<String, String> propertyPushToPrediction(Chiraghproperty property) {
		CreateEventDTO requestObject = new CreateEventDTO();
		requestObject.setEvent("$set");
		requestObject.setEntityId(property.getPropertyId().toString());
		requestObject.setEntityType("item");
		requestObject.setEventTime(getDate());
		EventPropertiesDTO properties = new EventPropertiesDTO();
		List<String> categories = new ArrayList<String>();
		categories.add(property.getPropertyType() == "" ? "0" : property.getPropertyType());
		categories.add(property.getTypeArea() == "" ? "0" : property.getTypeArea());
//		categories.add(property.getPropertyTitle() == "" ? "0" : property.getPropertyTitle());
		properties.setCategories(categories);
		requestObject.setProperties(properties);
		return logEvent(requestObject);
	}
	@Async
	public Map<String, String> propertyViewed(Chiraghproperty property, Chiraghuser user) {
		LogEventDTO requestObject = new LogEventDTO();
		requestObject.setEvent("view");
		if (user != null) {
			requestObject.setEntityId(user.getUserId().toString());
		}
		else {
			requestObject.setEntityId("null");
		}
		requestObject.setEntityType("user");
		requestObject.setTargetEntityId(property.getPropertyId().toString());
		requestObject.setTargetEntityType("item");
		requestObject.setEventTime(getDate());
		
		Map<String, String> eventId = logEvent(requestObject);
		RecommendationEvent requestEvent = new RecommendationEvent();
		requestEvent.setRequestName("property viewed");
		requestEvent.setRequestData(requestObject.toString());
		requestEvent.setResponseData(eventId.toString());
		requestEvent.setCreatedAt(DateUtils.getDefault().getNowTime());
		requestEvent.setUpdatedAt(DateUtils.getDefault().getNowTime());
		recommendationEventRepository.save(requestEvent);
		System.out.println("Viewed Property Event ID : " + eventId);
		return eventId;
	}
	
	@Async
	public List<String> findRecomendationsForProperty(Chiraghproperty property) throws InterruptedException {

		// JsonArray categories = new JsonArray();

//		JsonArray items = new JsonArray();
//		

//		JsonObject request = new JsonObject();
//		request.add("categories", categories);
//		request.add("items", items);
//		request.addProperty("num", "10");
//		return findRecommendations(request);

		PredictionIORequestDTO request = new PredictionIORequestDTO();
		List<String> items = new ArrayList();
		items.add(property.getPropertyId().toString());
		List<String> categories = new ArrayList();
		categories.add(StringValidationUtils.isEmpty(property.getPropertyType()) ? "0" : property.getPropertyType() );
		categories.add(StringValidationUtils.isEmpty(property.getTypeArea()) ? "0" : property.getTypeArea()  );
		categories.add(StringValidationUtils.isEmpty(property.getPropertyTitle()) ? "0" : property.getPropertyTitle() );
		categories.add(StringValidationUtils.isEmpty(String.valueOf(property.getNoOfBaths())) ? "0" : property.getNoOfBaths().toString() );
		categories.add(StringValidationUtils.isEmpty(String.valueOf(property.getNoOfBedrooms())) ? "0" : property.getNoOfBedrooms().toString() );
		categories.add(StringValidationUtils.isEmpty(String.valueOf(property.getCarParks())) ? "0" : property.getCarParks().toString());

		request.setItems(items);
		request.setCategories(categories);
		request.setNum(10);
		
		List<String> propertyIds = findRecommendations(request);
//		List<String> propertyIds = new ArrayList<String>();

		Recommendations recommendationExist = recommendationsRepository.findRecommendationsById(property.getPropertyId());
		
		if (recommendationExist == null){
			Recommendations recommendations = new Recommendations();
			recommendations.setPropertyId(property.getPropertyId());
			recommendations.setResponseData(propertyIds.toString());
			recommendations.setCreatedAt(DateUtils.getDefault().getNowTime());
			recommendations.setUpdatedAt(DateUtils.getDefault().getNowTime());
			recommendationsRepository.save(recommendations);
		}
		else {
			recommendationExist.setPropertyId(property.getPropertyId());
			recommendationExist.setResponseData(propertyIds.toString());
			recommendationExist.setUpdatedAt(DateUtils.getDefault().getNowTime());
			recommendationsRepository.save(recommendationExist);

		}

		System.out.println("Recommended Property ID List : "+ propertyIds);	  
	    	return propertyIds;
		
	}
	private List<String> findRecommendations(PredictionIORequestDTO request) {
		ModelMapper mapper = new ModelMapper();
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<PredictionIORequestDTO> entity = new HttpEntity<>(request, headers);
		Map<String, Object> res = restTemplate.postForObject(ChiraghConstants.EVENTS_SERVER_REQUEST_PATH, entity,
				Map.class);
		PredictionIOResponseDTO response = mapper.map(res, PredictionIOResponseDTO.class);
		return response.getListOfItemIds();
	}

	public ResponseEntity createUser(EventRequestDTO request) {

		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			logger.info(userName, "user name {}");
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}
			logger.info("userId" + chiraghuser.getUserId(), "user Id {}");
			ModelMapper mapper = new ModelMapper();

			LogEventDTO requestObject = mapper.map(request, LogEventDTO.class);
			requestObject.setEntityId(Integer.toString(chiraghuser.getUserId()));
			requestObject.setEntityType("user");
			requestObject.setEventTime(getDate());
			requestObject.setEvent("$set");
			Map<String, String> response = logEvent(requestObject);
			if (response == null) {
				return responseUtill.getApiResponse(ResponseCodes.FAILURE, PropertyMessages.DATA_SAVED_FAILURE, null);
			} else {
				return responseUtill.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_SAVED_SUCCESS,
						Stream.of(response).collect(Collectors.toList()));
			}

		} catch (Exception e) {

			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtill.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}

	}*/
	
	/*private Map<String, String> logEvent(BaseEventDTO request) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<BaseEventDTO> entity = new HttpEntity<>(request, headers);
		Map<String, String> res = restTemplate.postForObject(ChiraghConstants.EVENTS_SERVER_PATH, entity, Map.class);
		return res;
	}*/

	private String getDate() {
		Date date = Calendar.getInstance().getTime();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
		String strDate = dateFormat.format(date);
		return strDate;

	}
	
	/*@Async
	public Map<String, String> createUser(Chiraghuser user) {

			LogEventDTO requestObject = new LogEventDTO();
			requestObject.setEntityId(Integer.toString(user.getUserId()));
			requestObject.setEntityType("user");
			requestObject.setEventTime(getDate());
			requestObject.setEvent("$set");
			Map<String, String> eventId = logEvent(requestObject);
			RecommendationEvent requestEvent = new RecommendationEvent();
			
			BaseEventDTO request = new BaseEventDTO();
			request.setEntityId(requestObject.getEntityId());
			request.setEntityType(requestObject.getEntityType());
			request.setEvent(requestObject.getEvent());
			
			requestEvent.setRequestName("register user");
			requestEvent.setRequestData(request.toString());
			requestEvent.setResponseData(eventId.toString());
			requestEvent.setCreatedAt(DateUtils.getDefault().getNowTime());
			requestEvent.setUpdatedAt(DateUtils.getDefault().getNowTime());
			recommendationEventRepository.save(requestEvent);
			System.out.println("Create user Event ID :"+ eventId);

			return eventId;
	}*/
}
