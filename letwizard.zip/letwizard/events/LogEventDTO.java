package com.bestercapitalmedia.letwizard.events;

public class LogEventDTO extends BaseEventDTO {

	private String targetEntityType;
	private String targetEntityId;
	public String getTargetEntityType() {
		return targetEntityType;
	}
	public void setTargetEntityType(String targetEntityType) {
		this.targetEntityType = targetEntityType;
	}
	public String getTargetEntityId() {
		return targetEntityId;
	}
	public void setTargetEntityId(String targetEntityId) {
		this.targetEntityId = targetEntityId;
	}
	public LogEventDTO() {
		super();
	}
	
	@Override
	public String toString(){
		return "{" + 
				"  \"event\" : \""+ getEvent()+"\"," + 
				"  \"entityType\" : \""+getEntityType()+"\"," + 
				"  \"entityId\" : \""+getEntityId()+"\"," + 
				"  \"targetEntityType\" : \""+getTargetEntityType()+"\"," + 
				"  \"targetEntityId\" : \""+getTargetEntityId()+"\"" + 
				"}";
	}
	
	
	
}
