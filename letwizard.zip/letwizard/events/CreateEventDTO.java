package com.bestercapitalmedia.letwizard.events;

public class CreateEventDTO extends BaseEventDTO {

	
	private EventPropertiesDTO properties;
	
	public EventPropertiesDTO getProperties() {
		return properties;
	}
	public void setProperties(EventPropertiesDTO properties) {
		this.properties = properties;
	}
	public CreateEventDTO() {
		super();
	}
	
	
	
}
