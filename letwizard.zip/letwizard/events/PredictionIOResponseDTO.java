package com.bestercapitalmedia.letwizard.events;

import java.util.ArrayList;
import java.util.List;

public class PredictionIOResponseDTO {

	private List<PredictionIOItemDTO> itemScores;

	public List<PredictionIOItemDTO> getItemScores() {
		return itemScores;
	}

	public void setItemScores(List<PredictionIOItemDTO> itemScores) {
		this.itemScores = itemScores;
	}

	public PredictionIOResponseDTO() {
		super();
	} 
	
	public List<String> getListOfItemIds() {
		List<String> items = new ArrayList<String>();
		for (PredictionIOItemDTO item : itemScores) {
			items.add(item.getItem());
		}
		return items;
	}
	
}
