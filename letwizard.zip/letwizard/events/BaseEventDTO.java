package com.bestercapitalmedia.letwizard.events;

public class BaseEventDTO {


	private String event;
	private String eventTime;
	private String entityType;
	private String entityId;
	
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}
	public String getEventTime() {
		return eventTime;
	}
	public void setEventTime(String eventTime) {
		this.eventTime = eventTime;
	}
	
	
	public String getEntityType() {
		return entityType;
	}

	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	public String getEntityId() {
		return entityId;
	}

	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}

	public BaseEventDTO() {
		super();
	}
	
	@Override
	public String toString(){
		return "{" + 
				"\"event\" : \""+getEvent()+"\"," + 
				"\"entityType\" : \""+getEntityType()+"\"," + 
				"\"entityId\" : \""+getEntityId() +"\"" + 
				"}";
	}
}
