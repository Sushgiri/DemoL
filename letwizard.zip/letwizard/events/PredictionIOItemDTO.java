package com.bestercapitalmedia.letwizard.events;

public class PredictionIOItemDTO {

	private String item;
	private double score;
	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public PredictionIOItemDTO() {
		super();
		
	}
	
	
}
