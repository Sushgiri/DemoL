package com.bestercapitalmedia.letwizard.openhouse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import com.bestercapitalmedia.fcmpushnotifications.firebase.FCMService;
import com.bestercapitalmedia.fcmpushnotifications.model.PushNotificationRequest;
import com.bestercapitalmedia.letwizard.admin.activitylogs.AdminActivityLogsService;
import com.bestercapitalmedia.letwizard.admin.checklist.CheckListRepository;
import com.bestercapitalmedia.letwizard.admin.checklist.Checklist;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationConstants;
import com.bestercapitalmedia.letwizard.admin.notifications.NotificationsService;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.PropertyCheckListPivotRepository;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.PropertyCheckListRepository;
import com.bestercapitalmedia.letwizard.admin.propertychecklist.Propertychecklist;
import com.bestercapitalmedia.letwizard.api.response.ResponseUtill;
import com.bestercapitalmedia.letwizard.appointments.Appointments;
import com.bestercapitalmedia.letwizard.appointments.AppointmentsDTO;
import com.bestercapitalmedia.letwizard.appointments.AppointmentsRepository;
import com.bestercapitalmedia.letwizard.brokerage.proposal.BrokerageProposal;
import com.bestercapitalmedia.letwizard.brokerage.proposal.BrokerageProposalRepository;
import com.bestercapitalmedia.letwizard.buyer.leads.BuyerLeads;
import com.bestercapitalmedia.letwizard.buyer.leads.BuyerLeadsRepository;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcess;
import com.bestercapitalmedia.letwizard.buyer.process.BuyerProcessRepository;
import com.bestercapitalmedia.letwizard.constants.PropertyMessages;
import com.bestercapitalmedia.letwizard.constants.ResponseCodes;
import com.bestercapitalmedia.letwizard.mail.MailManager;
import com.bestercapitalmedia.letwizard.property.Chiraghproperty;
import com.bestercapitalmedia.letwizard.property.PropertyRepository;
import com.bestercapitalmedia.letwizard.property.bidprocess.Propertybidprocess;
import com.bestercapitalmedia.letwizard.user.Chiraghuser;
import com.bestercapitalmedia.letwizard.user.UserRepository;
import com.bestercapitalmedia.letwizard.utill.ChiragUtill;
import com.bestercapitalmedia.letwizard.utill.DateUtils;
import com.bestercapitalmedia.letwizard.utill.ObjectMapperUtils;
import com.bestercapitalmedia.letwizard.utill.PusherUtil;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;


@Service
public class OpenHouseService {
	
	private static final Logger logger = LoggerFactory.getLogger(OpenHouseService.class);

	@Autowired
	private ChiragUtill chiragUtill;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private OpenHouseRepository openHouseRepository;

	@Autowired
	private BrokerageProposalRepository brokerageProposalRepository;

	@Autowired
	private ResponseUtill responseUtil;
	
	@Autowired 
	private MailManager mailManager;
	
	@Autowired
	private CheckListRepository checkListRepo;

	@Autowired
	private AppointmentsRepository appointmentsRepository;

	@Autowired
	private NotificationsService notificationService;

	@Autowired
	private BuyerProcessRepository buyerProcessRepo;
	
	@Autowired
	PropertyCheckListPivotRepository propertyCheckListRepo;
	
	@Autowired
	private AdminActivityLogsService adminActivityLogsService;

	@Autowired
	private PropertyRepository propertyRepository;

	@Autowired
	private BuyerLeadsRepository buyerLeadsRepository;

	@Autowired
	private FCMService fcmService;

	public ResponseEntity createOpenHouseSchedule(int brokerageProposalId, OpenHousescheduleDTO openHousescheduleDTO) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			BrokerageProposal brokerageProposal = brokerageProposalRepository.findProposalById(brokerageProposalId);
			OpenHouseSchedule openHouseSchedule = ObjectMapperUtils.map(openHousescheduleDTO, OpenHouseSchedule.class);
			openHouseSchedule.setCreatedBy(chiraghuser.getUserId());
			openHouseSchedule.setBrokerageProposal(brokerageProposal);
			openHouseSchedule.setCreatedAt(DateUtils.getDefault().getNowTime());
			openHouseSchedule = openHouseRepository.save(openHouseSchedule);
			openHousescheduleDTO = ObjectMapperUtils.map(openHouseSchedule, OpenHousescheduleDTO.class);
			sendNotificationToBuyer(chiraghuser, brokerageProposal);
			return responseUtil.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(openHousescheduleDTO).collect(Collectors.toList()));

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}
	
	public ResponseEntity updateOpenHouseSchedule(int openHouseId, OpenHousescheduleDTO openHousescheduleDTO) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			OpenHouseSchedule openHouseSchedule = openHouseRepository.findProposalById(openHouseId);
			openHouseSchedule.setScheduleDate(openHousescheduleDTO.getScheduleDate());
			openHouseSchedule.setStartTime(openHousescheduleDTO.getStartTime());
			openHouseSchedule.setEndTime(openHousescheduleDTO.getEndTime());
			openHouseSchedule = openHouseRepository.save(openHouseSchedule);
			openHousescheduleDTO = ObjectMapperUtils.map(openHouseSchedule, OpenHousescheduleDTO.class);
			sendNotificationToBuyer(chiraghuser, openHouseSchedule.getBrokerageProposal());
			return responseUtil.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(openHousescheduleDTO).collect(Collectors.toList()));

		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity deleteOpenHouseSchedule(int openHouseId) {
		try {
			String userName = chiragUtill.getUserNameFromAuthentication();
			Chiraghuser chiraghuser = userRepository.findByUserName(userName);
			if (chiraghuser == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			OpenHouseSchedule openHouseSchedule = openHouseRepository.findProposalById(openHouseId);
			if(openHouseSchedule != null) {
				openHouseRepository.deleteById(openHouseSchedule.getId());
				return responseUtil.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
						null);

			} else {

			return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_NOT_FOUND,
					null);

			}	
		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}

	public ResponseEntity confirmOpenHouseAppointment(Authentication authentication, int buyerProcessId) {
		try {
			ModelMapper mapper = new ModelMapper();
			User user = (User) authentication.getPrincipal();
			Chiraghuser chiraghuser = userRepository.findByUserNameAndRole(user.getUsername());
			if (chiraghuser == null) {
				return responseUtil.getApiResponse(ResponseCodes.NOT_FOUND, PropertyMessages.DATA_RETRIVED_FAILURE,
						null);
			}

			BuyerProcess buyerProcess = buyerProcessRepo.findBuyerProcess(buyerProcessId);
			Appointments appointment = appointmentsRepository.getOpenHouseAppointment(buyerProcess.getBuyerProcessId());
//			appointment.setTitle("Open house meeting schedule");
//			appointment.setDescription("System generated");
//			appointment.setDated(buyerProcess.getProposedDate());
//			appointment.setDepartmentId(chiraghuser.getDepartements().getId());
//			appointment.setCreatedAt(DateUtils.getDefault().getNowTime());
//			appointment.setUpdatedAt(DateUtils.getDefault().getNowTime());
//			appointment.setBrokerageConfirm(1);
//			appointment.setIsBuyer(true);
//			appointment.setBrokerageConfirm(1);
			appointment.setBuyerConfirm(true);
//			appointment.setBuyerProcessId(buyerProcess.getBuyerProcessId());
			
			
			Propertychecklist propertychecklist1b = propertyCheckListRepo
					.findBuyerAlreadyVerified(buyerProcess.getBuyerProcessId(), 52);
			if (propertychecklist1b == null) {
				Propertychecklist propertyCheckList = new Propertychecklist();
				Checklist checklist = checkListRepo.findCheckListById(52);
//				propertyCheckList.setChiraghproperty(chiraghproperty);
				propertyCheckList.setBuyerProcessId(buyerProcess.getBuyerProcessId());
				propertyCheckList.setChiraghuser(chiraghuser);
				propertyCheckList.setChecklist(checklist);
				propertyCheckList.setDate(DateUtils.getDefault().getNowCalender());
				propertyCheckListRepo.save(propertyCheckList);

			}
			
//			buyerProcess.setProposedDateConfirmed(true);
			buyerProcessRepo.save(buyerProcess);
			
			appointment = appointmentsRepository.save(appointment);

			Map<String, String> map = new HashMap<>();
//			map.put("leadId", lead.getId().toString());
			map.put("userId", chiraghuser.getUserId().toString());
			PusherUtil.getDefault().push("my-buyer-leads", "open-house-call-created", map);

//			notification to seller
			Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(buyerProcess.getChiraghproperty().getPropertyId());
			if (chiraghproperty.getRentalProperty() != null) {
				notificationService.createNotificationForBid(NotificationConstants.Description.ophMeetingRental, NotificationConstants.Subject.ophMeeting,
						chiraghproperty.getPropertyId(),
						chiraghproperty.getChiraghuser().getUserId(), chiraghproperty, "buyer");

//			notification to buyer
				notificationService.createNotificationForBid(NotificationConstants.Description.ophMeetingRental, NotificationConstants.Subject.ophMeeting,
						chiraghproperty.getPropertyId(),
						buyerProcess.getChiraghuser().getUserId(),
						chiraghproperty, "buyer");
				
				openHouseMeetingScheduledPushNotification(chiraghproperty, buyerProcess.getChiraghuser(),
						NotificationConstants.NotificationId.outBidded, NotificationConstants.Title.openHouseMeetingScheduledBuyer,
						NotificationConstants.Topic.outBidded, NotificationConstants.PNDescription.openHouseMeetingScheduledBuyer,
						NotificationConstants.Type.openHouseMeetingScheduledBuyer);
			} else {
				notificationService.createNotificationForBid(NotificationConstants.Description.ophMeeting, NotificationConstants.Subject.ophMeeting,
						chiraghproperty.getPropertyId(),
						chiraghproperty.getChiraghuser().getUserId(), chiraghproperty, "buyer");

//			notification to buyer
				notificationService.createNotificationForBid(NotificationConstants.Description.ophMeeting, NotificationConstants.Subject.ophMeeting,
						chiraghproperty.getPropertyId(),
						buyerProcess.getChiraghuser().getUserId(),
						chiraghproperty, "buyer");
				
				openHouseMeetingScheduledPushNotification(chiraghproperty, buyerProcess.getChiraghuser(),
					NotificationConstants.NotificationId.outBidded, NotificationConstants.Title.openHouseMeetingScheduledBuyer,
					NotificationConstants.Topic.outBidded, NotificationConstants.PNDescription.openHouseMeetingScheduledBuyer,
					NotificationConstants.Type.openHouseMeetingScheduledBuyer);
			}

			List<String> receipients = new ArrayList<String>();
			receipients.add(buyerProcess.getChiraghuser().getUserEmail());
			receipients.add(chiraghproperty.getChiraghuser().getUserEmail());
			receipients.add(chiraghuser.getUserEmail());
			mailManager.sendInvitation(receipients, "support@letwizard.com","Open House Visit Scheduled",
					appointment.getTitle(), appointment.getDescription(), chiraghproperty.getAddress(),
					appointment.getDated(),true);
//			mailManager.sendInvitation(receipients, chiraghuser.getUserEmail(),"Open House Visit Scheduled",
//					appointment.getTitle(), appointment.getDescription(), chiraghproperty.getAddress(),
//					appointment.getDated(),true);

			adminActivityLogsService.logAction("logged a open house call", chiraghuser, buyerProcess.getBuyerProcessId());
			
			AppointmentsDTO result = mapper.map(appointment, AppointmentsDTO.class);

			return responseUtil.getApiResponse(ResponseCodes.SUCCESS, PropertyMessages.DATA_RETRIVED_SUCCESS,
					Stream.of(result).collect(Collectors.toList()));
			
		} catch (Exception e) {
			e.printStackTrace();
			String stacktrace = ExceptionUtils.getStackTrace(e);
			return responseUtil.getApiResponse(ResponseCodes.INTERNAL_SERVER_ERROR,
					PropertyMessages.INTERNAL_SERVER_ERROR_MSG, Stream.of(stacktrace).collect(Collectors.toList()));
		}
	}
	
	public void sendNotificationToBuyer(Chiraghuser chiraghuser, BrokerageProposal brokerageProposal) {
		Map<String, String> map = new HashMap<>();
		map.put("userId", chiraghuser.getUserId().toString());
		PusherUtil.getDefault().push("my-buyer-leads", "open-house-call-created", map);
		
		Chiraghproperty chiraghproperty = brokerageProposal.getChiraghproperty();
		BuyerProcess buyerProcess = buyerProcessRepo.findBuyerByPropertyId(chiraghproperty.getPropertyId());

//		notification to buyer
		notificationService.createNotification(NotificationConstants.Description.ophMeeting, NotificationConstants.Subject.ophMeeting,
				chiraghproperty.getPropertyId(),
				chiraghproperty.getChiraghuser().getUserId(), chiraghproperty);
		
		openHouseMeetingScheduledPushNotification(chiraghproperty, chiraghproperty.getChiraghuser(),
				NotificationConstants.NotificationId.outBidded, NotificationConstants.Title.openHouseMeetingScheduledBuyer,
				NotificationConstants.Topic.outBidded, NotificationConstants.PNDescription.openHouseMeetingScheduledBuyer,
				NotificationConstants.Type.openHouseMeetingScheduledBuyer);
	}
	
	public void sendAdminNotificationToBuyer(Chiraghuser chiraghuser, Integer buyerProcessID) {
		Map<String, String> map = new HashMap<>();
		map.put("userId", chiraghuser.getUserId().toString());
		PusherUtil.getDefault().push("my-buyer-leads", "open-house-call-created", map);
		
//		Chiraghproperty chiraghproperty = propertyRepository.findByPropertyId(propertyId);
		BuyerProcess buyerProcess = buyerProcessRepo.findBuyerProcess(buyerProcessID);
		
		BuyerLeads buyerLeads = buyerLeadsRepository.findLeadForOpenHouse(buyerProcess.getChiraghproperty().getPropertyId(), buyerProcess.getBuyerProcessId());

//		notification to buyer
		notificationService.createNotificationForBid(NotificationConstants.Description.ophMeeting, "",
				buyerProcess.getChiraghproperty().getPropertyId(),
				buyerLeads.getAssignedTo().getUserId(),
				buyerProcess.getChiraghproperty(), "Buyer");
		
		openHouseMeetingScheduledPushNotification(buyerProcess.getChiraghproperty(), buyerProcess.getChiraghuser(),
				NotificationConstants.NotificationId.outBidded, NotificationConstants.Title.openHouseMeetingScheduledBuyer,
				NotificationConstants.Topic.outBidded, NotificationConstants.PNDescription.openHouseMeetingScheduledBuyer,
				NotificationConstants.Type.openHouseMeetingScheduledBuyer);
	}


	public void openHouseMeetingScheduledPushNotification(Chiraghproperty chiraghProperty, 
			Chiraghuser chiraghUser, String messageId,
			String messageTitle, String messageTopic, String messageDescription, String type) {

		logger.info("OpenHouseService : openHouseMeetingScheduledPushNotification");

		if (chiraghProperty != null && chiraghUser != null && 
				chiraghUser.getFirebaseToken() != null && !chiraghUser.getFirebaseToken().isEmpty()) {
			
			try {
				// Build notification payload
				Notification notification = new Notification(messageTitle, messageDescription);
				
				// Build data payload
				Map<String, String> data = new HashMap<>();
				data.put("message_id", messageId);
				data.put("title", messageTitle);
				data.put("message", messageDescription);
				data.put("notification_type", type);
				
				data.put("property_id", chiraghProperty.getPropertyId() + "");
				data.put("user_id", chiraghUser.getUserId() + "");
				data.put("property_title", chiraghProperty.getPropertyTitle());
				data.put("property_type", chiraghProperty.getPropertyType());
				data.put("seller_user_name", chiraghProperty.getSellerUserName());
				data.put("status", chiraghProperty.getStatus());
				
				// Build the message
				Message message = Message.builder().setToken(chiraghUser.getFirebaseToken()) // FCM Token
						.setNotification(notification) // Notification object for foreground/background
						.putAllData(data) // Data payload for additional info
						.build();
				
				logger.info("Data in message to be sent : " + data);

				// Send the message using FirebaseMessaging
				String response = FirebaseMessaging.getInstance().send(message);
				
				logger.info("Successfully sent message : " + response);
				
			} catch (Exception e) {
				logger.error("Exception in OpenHouseService : openHouseMeetingScheduledPushNotification : " + e.getMessage(), e);
			}
		}
	}

}