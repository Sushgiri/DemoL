package com.bestercapitalmedia.letwizard.openhouse;

import java.util.Date;

public class OpenHousescheduleDTO {
	private Integer id;
	private Integer brokerageProposalId;
	private Date scheduleDate;
	private String startTime;
	private String endTime;
	private Date createdAt;
	private Integer createdBy;
	private Date minDate;
	private Date maxDate;
	
	public OpenHousescheduleDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getBrokerageProposalId() {
		return brokerageProposalId;
	}
	public void setBrokerageProposalId(Integer brokerageProposalId) {
		this.brokerageProposalId = brokerageProposalId;
	}
	public Date getScheduleDate() {
		return scheduleDate;
	}
	public void setScheduleDate(Date scheduleDate) {
		this.scheduleDate = scheduleDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public Date getMinDate() {
		return minDate;
	}

	public void setMinDate(Date minDate) {
		this.minDate = minDate;
	}

	public Date getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(Date maxDate) {
		this.maxDate = maxDate;
	}

}
