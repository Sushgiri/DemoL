package com.bestercapitalmedia.letwizard.openhouse;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/open/house/")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class OpenHouseController {
	
	@Autowired
	private OpenHouseService openHouseService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "{brokerageProposalId}", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity createOpenHouseSchedule(@PathVariable(value = "brokerageProposalId") int brokerageProposalId,
			@RequestBody OpenHousescheduleDTO openHousescheduleDTO, Authentication authentication,
			HttpServletRequest httpServletRequest) {
		return openHouseService.createOpenHouseSchedule(brokerageProposalId, openHousescheduleDTO);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "{openHouseId}", method = RequestMethod.DELETE)
	public @ResponseBody ResponseEntity deleteOpenHouseSchedule(@PathVariable(value = "openHouseId") int openHouseId,
			 Authentication authentication,
			HttpServletRequest httpServletRequest) {
		return openHouseService.deleteOpenHouseSchedule(openHouseId);
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "{buyerProcessId}/accept", method = RequestMethod.PUT)
	public @ResponseBody ResponseEntity confirmOpenHouseAppointment(@PathVariable(value = "buyerProcessId") int buyerProcessId,
			Authentication authentication, HttpServletRequest httpServletRequest) {
		return openHouseService.confirmOpenHouseAppointment(authentication, buyerProcessId);
	}

	
	

}
