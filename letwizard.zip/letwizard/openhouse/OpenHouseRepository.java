package com.bestercapitalmedia.letwizard.openhouse;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;



public interface OpenHouseRepository extends CrudRepository<OpenHouseSchedule, Integer>{
	
	@Query(value = "select * from open_house_schedule where id =?1", nativeQuery = true)
	public OpenHouseSchedule findProposalById(int openHouseId);
	

	@Query(value = "SELECT * FROM open_house_schedule WHERE brokerage_proposal_id = ?1", nativeQuery = true)
	public List<OpenHouseSchedule> findProposalByBrokearegProposalId(int brokerageProposalId);



}
