package com.bestercapitalmedia.letwizard.currencyexchangerate;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface CurrencyRateRepository extends JpaRepository<CurrencyRate, Integer> {
	
	@Query(value = "SELECT * FROM currency_rate WHERE source_currency = ?1 AND destination_currency = ?2", nativeQuery = true)
	public CurrencyRate getCurrencyRateByCurrencyIds(Integer sourceCurrency, Integer destinationCurrency);
	
	@Query(value = "SELECT * FROM currency_rate", nativeQuery = true)
	public List<CurrencyRate> getAllCurrencyRate();
	
	CurrencyRate getById(Integer id);

}
