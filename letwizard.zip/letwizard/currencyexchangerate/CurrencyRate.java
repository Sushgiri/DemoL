package com.bestercapitalmedia.letwizard.currencyexchangerate;

import static javax.persistence.GenerationType.IDENTITY;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.bestercapitalmedia.letwizard.vouchers.VoucherCurrency;

import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "currency_rate")
@Data
@NoArgsConstructor
public class CurrencyRate implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private Integer id;
	@Column(name = "spot_rate")
	private BigDecimal spotRate;
	@Column(name = "bid_percentage")
	private BigDecimal bidPercentage;
	@Column(name = "ask_percentage")
	private BigDecimal askPercentage;
	@Column(name = "bid_rate")
	private BigDecimal bidRate;
	@Column(name = "ask_rate")
	private BigDecimal askRate;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
	private Date createdAt;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at")
	private Date updatedAt;
	@Column(name = "created_by")
	private Integer createdBy;
	@Column(name = "updated_by")
	private Integer updatedBy;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "source_currency")
	private VoucherCurrency sourceCurrency;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "destination_currency")
	private VoucherCurrency destinationCurrency;
	
	@Column(name = "is_visible")
	private Boolean isVisible;

	public CurrencyRate(Date createdAt, Date updatedAt) {
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
	}


}
