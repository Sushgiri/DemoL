package com.bestercapitalmedia.letwizard.currencyexchangerate;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface CurrencyRatesRepository extends CrudRepository<CurrencyRates, Integer> {
	@Query(value = "SELECT * FROM currency_rates WHERE currency_code = ?1", nativeQuery = true)
	public CurrencyRates getCurrencyRateByCode(String code);
	
}
